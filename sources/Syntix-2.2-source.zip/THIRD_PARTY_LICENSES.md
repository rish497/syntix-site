# Third-party licenses — draft

Developer: Rishabh Mittal  
Inventory updated: 3 November 2026 (license verification remains incomplete)

Scope: unchanged Gradle declarations plus resolved Android runtime, unit-test and instrumentation-test artifacts. Versions below come from Gradle, not estimates. License names/URLs are copied from Maven POMs, including verified parent inheritance, and exact source/artifact license files. Previously unresolved Gradle licenses were checked against primary Maven artifacts on 3 November 2026; see android-app/licenses/maven-verification.json. Native provenance limits are recorded separately, not silently treated as resolved. This inventory is not a substitute for complete upstream notices, source provision or legal review.

Version 2.2 application source and build information are available at:
https://rish497.github.io/syntix-site/sources/Syntix-2.2-source.zip

This archive does not certify that the unresolved native-source provenance items in NATIVE_BUILD_AUDIT.md are cleared.

## Declared Gradle dependencies

| Artifact | Declared version | Scope | POM license evidence |
|---|---|---|---|
| `androidx.activity:activity` | 1.10.1 | implementation | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.drawerlayout:drawerlayout` | 1.2.0 | implementation | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.viewpager2:viewpager2` | 1.1.0 | implementation | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `com.google.android.material:material` | 1.12.0 | implementation | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.recyclerview:recyclerview` | 1.3.2 | implementation | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.media3:media3-exoplayer` | 1.8.0 | implementation | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.media3:media3-session` | 1.8.0 | implementation | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.media3:media3-datasource-okhttp` | 1.8.0 | implementation | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `io.github.junkfood02.youtubedl-android:library` | 0.18.1 | implementation | GPL-3.0 license — https://www.gnu.org/licenses/gpl-3.0.en.html |
| `io.github.junkfood02.youtubedl-android:ffmpeg` | 0.18.1 | implementation | GPL-3.0 license — https://www.gnu.org/licenses/gpl-3.0.en.html |
| `com.android.tools:desugar_jdk_libs` | 2.1.5 | coreLibraryDesugaring | GNU General Public License, version 2, with the Classpath Exception — https://github.com/google/desugar_jdk_libs/blob/master/LICENSE |
| `junit:junit` | 4.13.2 | testImplementation | Eclipse Public License 1.0 — http://www.eclipse.org/legal/epl-v10.html (verified; evidence: android-app/licenses/maven-verification.json) |
| `org.robolectric:robolectric` | 4.17 | testImplementation | The MIT License — https://opensource.org/licenses/MIT |
| `org.json:json` | 20240303 | testImplementation | Public Domain — https://github.com/stleary/JSON-java/blob/master/LICENSE |
| `androidx.test:runner` | 1.6.2 | androidTestImplementation | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.test:core` | 1.6.1 | androidTestImplementation | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt (verified; evidence: android-app/licenses/maven-verification.json) |
| `androidx.test.ext:junit` | 1.2.1 | androidTestImplementation | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt (verified; evidence: android-app/licenses/maven-verification.json) |

## Build tooling

| Component | Version | License evidence |
|---|---|---|
| Android Gradle Plugin (`com.android.application`, implementation `com.android.tools.build:gradle`) | 9.0.1 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| Gradle wrapper/distribution | 9.3.0 | Apache-2.0 for Gradle; full distribution LICENSE/NOTICE and bundled-component attribution retained in android-app/licenses/evidence/gradle (build tool, not APK runtime) |

Build/test artifacts are distinguished from components shipped in the production APK. No analytics, ad-network or crash-reporting SDK was identified in the resolved Android runtime graph. Node development tools in this repository are not Android runtime SDKs.

## Resolved releaseRuntimeClasspath

| Artifact | Selected version | POM license evidence |
|---|---|---|
| `com.google.android.play:app-update` | 2.1.0 | Play Core Software Development Kit Terms of Service — https://developer.android.com/guide/playcore/license |
| `com.google.android.play:core-common` | 2.0.3 | Play Core Software Development Kit Terms of Service — https://developer.android.com/guide/playcore/license |
| `com.google.android.gms:play-services-basement` | 18.1.0 | Android Software Development Kit License — https://developer.android.com/studio/terms.html |
| `com.google.android.gms:play-services-tasks` | 18.0.2 | Android Software Development Kit License — https://developer.android.com/studio/terms.html |
| `androidx.activity:activity` | 1.10.1 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.annotation:annotation-experimental` | 1.4.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.annotation:annotation-jvm` | 1.8.1 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.appcompat:appcompat-resources` | 1.6.1 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.appcompat:appcompat` | 1.6.1 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.arch.core:core-common` | 2.2.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.arch.core:core-runtime` | 2.2.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.cardview:cardview` | 1.0.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.collection:collection` | 1.2.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.concurrent:concurrent-futures` | 1.1.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt (verified; evidence: android-app/licenses/maven-verification.json) |
| `androidx.constraintlayout:constraintlayout-solver` | 2.0.1 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.constraintlayout:constraintlayout` | 2.0.1 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.coordinatorlayout:coordinatorlayout` | 1.1.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.core:core-ktx` | 1.13.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.core:core-viewtree` | 1.0.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.core:core` | 1.13.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.cursoradapter:cursoradapter` | 1.0.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.customview:customview-poolingcontainer` | 1.0.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.customview:customview` | 1.1.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.documentfile:documentfile` | 1.0.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.drawerlayout:drawerlayout` | 1.2.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.dynamicanimation:dynamicanimation` | 1.0.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.emoji2:emoji2-views-helper` | 1.2.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.emoji2:emoji2` | 1.2.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.exifinterface:exifinterface` | 1.3.6 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.fragment:fragment` | 1.3.6 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.interpolator:interpolator` | 1.0.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.legacy:legacy-support-core-utils` | 1.0.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.lifecycle:lifecycle-common` | 2.6.2 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.lifecycle:lifecycle-livedata-core` | 2.6.2 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.lifecycle:lifecycle-livedata` | 2.6.2 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.lifecycle:lifecycle-process` | 2.6.2 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.lifecycle:lifecycle-runtime` | 2.6.2 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.lifecycle:lifecycle-viewmodel-savedstate` | 2.6.2 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.lifecycle:lifecycle-viewmodel` | 2.6.2 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.loader:loader` | 1.0.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.localbroadcastmanager:localbroadcastmanager` | 1.0.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.media3:media3-common` | 1.8.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.media3:media3-container` | 1.8.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.media3:media3-database` | 1.8.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.media3:media3-datasource-okhttp` | 1.8.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.media3:media3-datasource` | 1.8.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.media3:media3-decoder` | 1.8.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.media3:media3-exoplayer` | 1.8.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.media3:media3-extractor` | 1.8.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.media3:media3-session` | 1.8.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.media:media` | 1.7.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.print:print` | 1.0.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.profileinstaller:profileinstaller` | 1.4.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.recyclerview:recyclerview` | 1.3.2 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.resourceinspection:resourceinspection-annotation` | 1.0.1 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.savedstate:savedstate` | 1.2.1 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.startup:startup-runtime` | 1.1.1 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.tracing:tracing` | 1.0.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.transition:transition` | 1.5.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.vectordrawable:vectordrawable-animated` | 1.1.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.vectordrawable:vectordrawable` | 1.1.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.versionedparcelable:versionedparcelable` | 1.1.1 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.viewpager2:viewpager2` | 1.1.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.viewpager:viewpager` | 1.0.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `com.fasterxml.jackson.core:jackson-annotations` | 2.11.1 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `com.fasterxml.jackson.core:jackson-core` | 2.11.1 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `com.fasterxml.jackson.core:jackson-databind` | 2.11.1 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `com.google.android.material:material` | 1.12.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `com.google.errorprone:error_prone_annotations` | 2.15.0 | Apache 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `com.google.guava:failureaccess` | 1.0.2 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt (verified; evidence: android-app/licenses/maven-verification.json) |
| `com.google.guava:guava` | 33.3.1-android | Apache License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt (verified; evidence: android-app/licenses/maven-verification.json) |
| `com.google.guava:listenablefuture` | 9999.0-empty-to-avoid-conflict-with-guava | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt (verified; evidence: android-app/licenses/maven-verification.json) |
| `com.squareup.okhttp3:okhttp` | 4.12.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `com.squareup.okio:okio-jvm` | 3.6.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `commons-io:commons-io` | 2.5 | Apache License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt (verified; evidence: android-app/licenses/maven-verification.json) |
| `io.github.junkfood02.youtubedl-android:common` | 0.18.1 | GPL-3.0 license — https://www.gnu.org/licenses/gpl-3.0.en.html |
| `io.github.junkfood02.youtubedl-android:ffmpeg` | 0.18.1 | GPL-3.0 license — https://www.gnu.org/licenses/gpl-3.0.en.html |
| `io.github.junkfood02.youtubedl-android:library` | 0.18.1 | GPL-3.0 license — https://www.gnu.org/licenses/gpl-3.0.en.html |
| `org.apache.commons:commons-compress` | 1.12 | Apache License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt (verified; evidence: android-app/licenses/maven-verification.json) |
| `org.jetbrains.kotlin:kotlin-stdlib-jdk7` | 1.9.10 | The Apache License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `org.jetbrains.kotlin:kotlin-stdlib-jdk8` | 1.9.10 | The Apache License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `org.jetbrains.kotlin:kotlin-stdlib` | 2.2.10 | The Apache License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `org.jetbrains.kotlinx:kotlinx-coroutines-android` | 1.7.3 | The Apache Software License, Version 2.0 — https://www.apache.org/licenses/LICENSE-2.0.txt |
| `org.jetbrains.kotlinx:kotlinx-coroutines-core-jvm` | 1.7.3 | The Apache Software License, Version 2.0 — https://www.apache.org/licenses/LICENSE-2.0.txt |
| `org.jetbrains:annotations` | 23.0.0 | The Apache Software License, Version 2.0 — https://www.apache.org/licenses/LICENSE-2.0.txt (verified; evidence: android-app/licenses/maven-verification.json) |

## Resolved debugUnitTestRuntimeClasspath

| Artifact | Selected version | POM license evidence |
|---|---|---|
| `com.google.android.play:app-update` | 2.1.0 | Play Core Software Development Kit Terms of Service — https://developer.android.com/guide/playcore/license |
| `com.google.android.play:core-common` | 2.0.3 | Play Core Software Development Kit Terms of Service — https://developer.android.com/guide/playcore/license |
| `com.google.android.gms:play-services-basement` | 18.1.0 | Android Software Development Kit License — https://developer.android.com/studio/terms.html |
| `com.google.android.gms:play-services-tasks` | 18.0.2 | Android Software Development Kit License — https://developer.android.com/studio/terms.html |
| `Skipline:app` | unspecified | GPL-3.0 — this application, android-app/LICENSE (not an external dependency) |
| `androidx.activity:activity` | 1.10.1 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.annotation:annotation-experimental` | 1.4.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.annotation:annotation-jvm` | 1.8.1 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.appcompat:appcompat-resources` | 1.6.1 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.appcompat:appcompat` | 1.6.1 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.arch.core:core-common` | 2.2.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.arch.core:core-runtime` | 2.2.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.cardview:cardview` | 1.0.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.collection:collection` | 1.2.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.concurrent:concurrent-futures` | 1.1.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt (verified; evidence: android-app/licenses/maven-verification.json) |
| `androidx.constraintlayout:constraintlayout-solver` | 2.0.1 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.constraintlayout:constraintlayout` | 2.0.1 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.coordinatorlayout:coordinatorlayout` | 1.1.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.core:core-ktx` | 1.13.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.core:core-viewtree` | 1.0.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.core:core` | 1.13.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.cursoradapter:cursoradapter` | 1.0.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.customview:customview-poolingcontainer` | 1.0.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.customview:customview` | 1.1.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.documentfile:documentfile` | 1.0.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.drawerlayout:drawerlayout` | 1.2.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.dynamicanimation:dynamicanimation` | 1.0.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.emoji2:emoji2-views-helper` | 1.2.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.emoji2:emoji2` | 1.2.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.exifinterface:exifinterface` | 1.3.6 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.fragment:fragment` | 1.3.6 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.interpolator:interpolator` | 1.0.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.legacy:legacy-support-core-utils` | 1.0.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.lifecycle:lifecycle-common` | 2.6.2 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.lifecycle:lifecycle-livedata-core` | 2.6.2 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.lifecycle:lifecycle-livedata` | 2.6.2 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.lifecycle:lifecycle-process` | 2.6.2 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.lifecycle:lifecycle-runtime` | 2.6.2 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.lifecycle:lifecycle-viewmodel-savedstate` | 2.6.2 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.lifecycle:lifecycle-viewmodel` | 2.6.2 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.loader:loader` | 1.0.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.localbroadcastmanager:localbroadcastmanager` | 1.0.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.media3:media3-common` | 1.8.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.media3:media3-container` | 1.8.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.media3:media3-database` | 1.8.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.media3:media3-datasource-okhttp` | 1.8.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.media3:media3-datasource` | 1.8.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.media3:media3-decoder` | 1.8.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.media3:media3-exoplayer` | 1.8.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.media3:media3-extractor` | 1.8.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.media3:media3-session` | 1.8.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.media:media` | 1.7.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.print:print` | 1.0.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.profileinstaller:profileinstaller` | 1.4.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.recyclerview:recyclerview` | 1.3.2 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.resourceinspection:resourceinspection-annotation` | 1.0.1 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.savedstate:savedstate` | 1.2.1 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.startup:startup-runtime` | 1.1.1 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.test.espresso:espresso-idling-resource` | 3.7.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.test:monitor` | 1.8.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.tracing:tracing` | 1.0.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.transition:transition` | 1.5.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.vectordrawable:vectordrawable-animated` | 1.1.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.vectordrawable:vectordrawable` | 1.1.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.versionedparcelable:versionedparcelable` | 1.1.1 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.viewpager2:viewpager2` | 1.1.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.viewpager:viewpager` | 1.0.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `com.almworks.sqlite4java:sqlite4java` | 1.0.392 | Apache License 2.0 — https://www.apache.org/licenses/LICENSE-2.0 (verified; evidence: android-app/licenses/maven-verification.json) |
| `com.fasterxml.jackson.core:jackson-annotations` | 2.11.1 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `com.fasterxml.jackson.core:jackson-core` | 2.11.1 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `com.fasterxml.jackson.core:jackson-databind` | 2.11.1 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `com.google.android.material:material` | 1.12.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `com.google.auto.value:auto-value-annotations` | 1.11.1 | Apache 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt (verified; evidence: android-app/licenses/maven-verification.json) |
| `com.google.errorprone:error_prone_annotations` | 2.47.0 | Apache 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `com.google.guava:failureaccess` | 1.0.3 | Apache License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt (verified; evidence: android-app/licenses/maven-verification.json) |
| `com.google.guava:guava` | 33.6.0-jre | Apache License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt (verified; evidence: android-app/licenses/maven-verification.json) |
| `com.google.guava:listenablefuture` | 9999.0-empty-to-avoid-conflict-with-guava | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt (verified; evidence: android-app/licenses/maven-verification.json) |
| `com.google.j2objc:j2objc-annotations` | 3.1 | Apache License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `com.google.testparameterinjector:test-parameter-injector` | 1.22 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `com.ibm.icu:icu4j` | 78.3 | Unicode-3.0 — https://raw.githubusercontent.com/unicode-org/icu/maint/maint-78/LICENSE |
| `com.squareup.okhttp3:okhttp` | 4.12.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `com.squareup.okio:okio-jvm` | 3.6.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `commons-io:commons-io` | 2.5 | Apache License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt (verified; evidence: android-app/licenses/maven-verification.json) |
| `io.github.junkfood02.youtubedl-android:common` | 0.18.1 | GPL-3.0 license — https://www.gnu.org/licenses/gpl-3.0.en.html |
| `io.github.junkfood02.youtubedl-android:ffmpeg` | 0.18.1 | GPL-3.0 license — https://www.gnu.org/licenses/gpl-3.0.en.html |
| `io.github.junkfood02.youtubedl-android:library` | 0.18.1 | GPL-3.0 license — https://www.gnu.org/licenses/gpl-3.0.en.html |
| `javax.annotation:javax.annotation-api` | 1.3.2 | CDDL + GPLv2 with classpath exception — https://github.com/javaee/javax.annotation/blob/master/LICENSE (verified; evidence: android-app/licenses/maven-verification.json) |
| `javax.inject:javax.inject` | 1 | Apache License 2.0 — https://www.apache.org/licenses/LICENSE-2.0 (verified; evidence: android-app/licenses/maven-verification.json) |
| `junit:junit` | 4.13.2 | Eclipse Public License 1.0 — http://www.eclipse.org/legal/epl-v10.html (verified; evidence: android-app/licenses/maven-verification.json) |
| `org.apache.commons:commons-compress` | 1.12 | Apache License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt (verified; evidence: android-app/licenses/maven-verification.json) |
| `org.bouncycastle:bcprov-jdk18on` | 1.85 | MIT — https://raw.githubusercontent.com/bcgit/bc-java/r1rv85/LICENSE.html (verified; evidence: android-app/licenses/maven-verification.json) |
| `org.conscrypt:conscrypt-openjdk-uber` | 2.6.2 | Apache 2 — https://www.apache.org/licenses/LICENSE-2.0 |
| `org.hamcrest:hamcrest-core` | 1.3 | New BSD License — http://www.opensource.org/licenses/bsd-license.php (verified; evidence: android-app/licenses/maven-verification.json) |
| `org.jetbrains.kotlin:kotlin-stdlib-jdk7` | 1.9.10 | The Apache License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `org.jetbrains.kotlin:kotlin-stdlib-jdk8` | 1.9.10 | The Apache License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `org.jetbrains.kotlin:kotlin-stdlib` | 2.2.10 | The Apache License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `org.jetbrains.kotlinx:kotlinx-coroutines-android` | 1.7.3 | The Apache Software License, Version 2.0 — https://www.apache.org/licenses/LICENSE-2.0.txt |
| `org.jetbrains.kotlinx:kotlinx-coroutines-core-jvm` | 1.7.3 | The Apache Software License, Version 2.0 — https://www.apache.org/licenses/LICENSE-2.0.txt |
| `org.jetbrains:annotations` | 23.0.0 | The Apache Software License, Version 2.0 — https://www.apache.org/licenses/LICENSE-2.0.txt (verified; evidence: android-app/licenses/maven-verification.json) |
| `org.json:json` | 20240303 | Public Domain — https://github.com/stleary/JSON-java/blob/master/LICENSE |
| `org.jspecify:jspecify` | 1.0.0 | The Apache License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `org.ow2.asm:asm-commons` | 9.10.1 | BSD-3-Clause — https://asm.ow2.io/license.html |
| `org.ow2.asm:asm-tree` | 9.10.1 | BSD-3-Clause — https://asm.ow2.io/license.html |
| `org.ow2.asm:asm` | 9.10.1 | BSD-3-Clause — https://asm.ow2.io/license.html |
| `org.robolectric:annotations` | 4.17 | The MIT License — https://opensource.org/licenses/MIT |
| `org.robolectric:junit` | 4.17 | The MIT License — https://opensource.org/licenses/MIT |
| `org.robolectric:nativeruntime-dist-compat` | 1.0.19 | Apache 2.0 — http://www.apache.org/licenses/LICENSE-2.0 |
| `org.robolectric:nativeruntime` | 4.17 | The MIT License — https://opensource.org/licenses/MIT |
| `org.robolectric:pluginapi` | 4.17 | The MIT License — https://opensource.org/licenses/MIT |
| `org.robolectric:plugins-maven-dependency-resolver` | 4.17 | The MIT License — https://opensource.org/licenses/MIT |
| `org.robolectric:resources` | 4.17 | The MIT License — https://opensource.org/licenses/MIT |
| `org.robolectric:robolectric` | 4.17 | The MIT License — https://opensource.org/licenses/MIT |
| `org.robolectric:sandbox` | 4.17 | The MIT License — https://opensource.org/licenses/MIT |
| `org.robolectric:shadowapi` | 4.17 | The MIT License — https://opensource.org/licenses/MIT |
| `org.robolectric:shadows-framework` | 4.17 | The MIT License — https://opensource.org/licenses/MIT |
| `org.robolectric:utils-reflector` | 4.17 | The MIT License — https://opensource.org/licenses/MIT |
| `org.robolectric:utils` | 4.17 | The MIT License — https://opensource.org/licenses/MIT |
| `org.yaml:snakeyaml` | 2.6 | Apache License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |

## Resolved debugAndroidTestRuntimeClasspath

| Artifact | Selected version | POM license evidence |
|---|---|---|
| `com.google.android.play:app-update` | 2.1.0 | Play Core Software Development Kit Terms of Service — https://developer.android.com/guide/playcore/license |
| `com.google.android.play:core-common` | 2.0.3 | Play Core Software Development Kit Terms of Service — https://developer.android.com/guide/playcore/license |
| `com.google.android.gms:play-services-basement` | 18.1.0 | Android Software Development Kit License — https://developer.android.com/studio/terms.html |
| `com.google.android.gms:play-services-tasks` | 18.0.2 | Android Software Development Kit License — https://developer.android.com/studio/terms.html |
| `androidx.annotation:annotation-jvm` | 1.8.1 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.concurrent:concurrent-futures-ktx` | 1.1.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt (verified; evidence: android-app/licenses/maven-verification.json) |
| `androidx.concurrent:concurrent-futures` | 1.1.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt (verified; evidence: android-app/licenses/maven-verification.json) |
| `androidx.lifecycle:lifecycle-common` | 2.6.2 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.test.ext:junit` | 1.2.1 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt (verified; evidence: android-app/licenses/maven-verification.json) |
| `androidx.test.services:storage` | 1.5.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt (verified; evidence: android-app/licenses/maven-verification.json) |
| `androidx.test:core` | 1.6.1 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt (verified; evidence: android-app/licenses/maven-verification.json) |
| `androidx.test:monitor` | 1.7.2 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.test:runner` | 1.6.2 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `androidx.tracing:tracing` | 1.0.0 | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `com.google.guava:listenablefuture` | 9999.0-empty-to-avoid-conflict-with-guava | The Apache Software License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt (verified; evidence: android-app/licenses/maven-verification.json) |
| `junit:junit` | 4.13.2 | Eclipse Public License 1.0 — http://www.eclipse.org/legal/epl-v10.html (verified; evidence: android-app/licenses/maven-verification.json) |
| `org.hamcrest:hamcrest-core` | 1.3 | New BSD License — http://www.opensource.org/licenses/bsd-license.php (verified; evidence: android-app/licenses/maven-verification.json) |
| `org.jetbrains.kotlin:kotlin-stdlib-jdk7` | 1.9.10 | The Apache License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `org.jetbrains.kotlin:kotlin-stdlib-jdk8` | 1.9.10 | The Apache License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `org.jetbrains.kotlin:kotlin-stdlib` | 2.2.10 | The Apache License, Version 2.0 — http://www.apache.org/licenses/LICENSE-2.0.txt |
| `org.jetbrains.kotlinx:kotlinx-coroutines-android` | 1.7.3 | The Apache Software License, Version 2.0 — https://www.apache.org/licenses/LICENSE-2.0.txt |
| `org.jetbrains.kotlinx:kotlinx-coroutines-core-jvm` | 1.7.3 | The Apache Software License, Version 2.0 — https://www.apache.org/licenses/LICENSE-2.0.txt |
| `org.jetbrains:annotations` | 23.0.0 | The Apache Software License, Version 2.0 — https://www.apache.org/licenses/LICENSE-2.0.txt (verified; evidence: android-app/licenses/maven-verification.json) |

## Embedded binaries and assets (not separate Gradle coordinates)

| Component | Version/evidence | License status |
|---|---|---|
| yt-dlp Python archive | `2025.11.12`, read from `yt_dlp/version.py` inside library 0.18.1 AAR `res/raw/ytdlp`; runtime engine updates can replace it | Upstream source uses Unlicense; verify this packaged binary and every bundled dependency/NOTICE against that exact build. https://github.com/yt-dlp/yt-dlp/blob/2025.11.12/LICENSE |
| Python runtime and bundled Python modules | CPython 3.12.11; Mutagen 1.47.0; PyCryptodomex 3.23.0, read from packaged binaries/source | PSF plus incorporated notices; Mutagen GPLv2-or-later; PyCryptodome BSD/public-domain components. Exact release texts bundled; additional native dependencies/source limits: NATIVE_BUILD_AUDIT.md |
| FFmpeg executable/libraries and codecs | FFmpeg 7.1.1; --enable-gpl --enable-version3; payload/configuration hashes in native-payload-inventory.json | GPLv3-or-later FFmpeg build, plus separately licensed codecs/native libraries. Baseline source https://github.com/FFmpeg/FFmpeg/tree/n7.1.1 ; exact Termux patch/build/source mapping NOT CLEARED: NATIVE_BUILD_AUDIT.md |
| Outfit bundled fonts | Both font name tables: Version 1.100;gftools[0.9.27] | SIL Open Font License 1.1; full local notice bundled in APK |
| Phosphor vector icons | Converted by tools/android-assets.cjs; installed source package @phosphor-icons/core 2.1.1; original generated-file revision not recorded | MIT; full copyright/license notice preserved in APK, android-app/licenses/Phosphor-MIT.txt |
| QuickJS / other native runtime components | QuickJS 2025-04-26; exact ARM payloads inventoried | MIT for QuickJS, full exact-release license bundled; additional native libraries/provenance NOT CLEARED, see NATIVE_BUILD_AUDIT.md |
| Syntix logos, artwork and prototype/reference images | User-provided/generated assets; no license inferred | Ownership/redistribution permission NOT VERIFIED and distinguish shipped app assets from development reference images |

## Open obligations and limits

- The wrapper POMs declare GPL-3.0. The existing project LICENSE is retained unchanged. Verify corresponding-source, license-text, notices and any installation-information obligations for the exact distributed binaries; a Markdown inventory alone does not fulfil them.
- Release 0.13.1 replaces license/notice exclusions with resource merges. Full extracted Maven artifact notices and local font/icon notices are also bundled under assets/legal/notices, indexed by THIRD_PARTY_NOTICES.md.
- All formerly unresolved Gradle coordinate licenses have primary evidence. Exact native build recipes/patches and full corresponding source remain an explicit release blocker; see NATIVE_BUILD_AUDIT.md. No dependency version was changed.
- Engine updates change the executable independently of the APK. Recheck its version, bundled dependencies, notices and source obligations for the runtime version actually distributed/installed.
- This document is an inventory, not a warranty of complete license compliance.

## Source distribution preference

The developer plans to keep the GitHub repository private. No public GitHub repository is inherently required, but a private-only repository does not itself fulfil corresponding-source access obligations for recipients of GPL-covered binaries. Version-matched application source is bundled in the APK and exportable from Privacy & About → Open-source software. This does not supply missing native corresponding source. See https://www.gnu.org/licenses/gpl-3.0.html#section6 and https://www.gnu.org/licenses/gpl-faq.en.html#SourceAndBinaryOnDifferentSites .


## Play update SDK addition (2.1)

The four Google Play/Google Play services coordinates listed above were checked against their exact Google Maven POM files on 5 November 2026. They are distributed under Google's named SDK terms, not assumed to be Apache/MIT. The interaction of these terms with the application's existing GPL components requires legal review; no compatibility clearance is claimed. The update SDK talks to the Play Store process and does not implement a developer analytics backend.
