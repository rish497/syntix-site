package app.skipline.android;

import android.graphics.*;
import android.view.*;
import android.widget.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import org.robolectric.android.controller.ActivityController;
import org.json.*;
import java.io.*;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class)
@Config(sdk=29,application=ListeningFeaturesUiTest.UiApp.class,qualifiers="w393dp-h852dp-mdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@androidx.media3.common.util.UnstableApi
public class V141FeaturesTest {
    @Test public void playlistTapKeepsExistingViewsAndScroll(){
        try(ActivityController<MainActivity> c=Robolectric.buildActivity(MainActivity.class).create().visible()){
            MainActivity a=c.get();a.welcome=false;a.page="library";SavedPlaylist saved=new SavedPlaylist("Test playlist");saved.tracks.add(new Track("https://www.youtube.com/watch?v=abcdefghijk","Song","Artist","",180));a.app.library.add(saved);a.app.queue.add(saved.tracks.get(0).copy());a.selectedPlaylist=saved;a.refresh();View existing=a.root.getChildAt(0);ScrollView scroll=a.bodyScroll;a.app.listeners.add(a::refresh);a.playPlaylistAt(saved,0);assertSame("Song selection must not rebuild the playlist",existing,a.root.getChildAt(0));assertSame(scroll,a.bodyScroll);assertFalse(a.pendingPlay.isEmpty());
        }
    }
    @Test public void searchHasTwentyNativeCartoonCategoriesAndPresetPhotosPersist()throws Exception{
        try(ActivityController<MainActivity> c=Robolectric.buildActivity(MainActivity.class).create().visible()){
            MainActivity a=c.get();a.welcome=false;a.page="search";a.refresh();assertNotNull(text(a.root,"Browse all"));for(int i=0;i<20;i++){View tile=description(a.root,"Browse "+NativeSearch.NAMES[i]);assertNotNull(tile);View portrait=((FrameLayout)tile).getChildAt(0);assertEquals(a.dp(78),portrait.getLayoutParams().height);assertEquals(a.dp(96),portrait.getLayoutParams().width);assertEquals(ImageView.ScaleType.FIT_CENTER,((ImageView)portrait).getScaleType());assertNotEquals(0,ProfileArtwork.resource(a,String.format(java.util.Locale.ROOT,"avatar:cartoon_%02d",i)));}capture(a,"v14.1-search.png");
            ProfileArtwork.choose(a);View sheet=a.activeSheets.get(a.activeSheets.size()-1).getWindow().getDecorView();assertNotNull(text(sheet,"Choose from gallery"));description(sheet,"Choose character 2").performClick();assertEquals("avatar:cartoon_01",new LocalProfiles(a).current().photo);assertNotNull(NativeScreens.avatar(a,48));
        }
    }
    @Test public void homePlaylistFilterStaysOnHomeAndAddSongOffersHistory()throws Exception{
        try(ActivityController<MainActivity> c=Robolectric.buildActivity(MainActivity.class).create().visible()){
            MainActivity a=c.get();a.welcome=false;a.page="home";a.app.prefs("discovery_playlists").edit().putString("public:music official playlists",new JSONObject().put("time",System.currentTimeMillis()).put("items",new JSONArray().put(new PublicPlaylists.Entry("PLabcdefghijk","Public music","Creator","").json())).toString()).commit();a.refresh();text(a.root,"Playlists").performClick();assertEquals("home",a.page);assertNull(a.selectedPlaylist);assertNotNull(text(a.root,"Explore playlists"));assertNotNull(text(a.root,"Public music"));SavedPlaylist saved=new SavedPlaylist("My playlist");a.app.library.add(saved);RecommendationGrid.show(a,saved,new SongRecommendations.Cursor(java.util.Collections.singletonList("test"),(q,t)->new org.json.JSONObject()));View sheet=a.activeSheets.get(a.activeSheets.size()-1).getWindow().getDecorView();assertNotNull(text(sheet,"YouTube or Spotify link"));assertNotNull(text(sheet,"Recommended"));assertNull(text(sheet,"Recently listened"));assertFalse(text(sheet,"Recommended") instanceof com.google.android.material.button.MaterialButton);
        }
    }
    @Test public void spotifyTrackMetadataNeverUsesPreviewAudio()throws Exception{
        String link="https://open.spotify.com/track/2g20aO38HBLIpg6NbCrjE3?si=test";assertEquals("https://open.spotify.com/track/2g20aO38HBLIpg6NbCrjE3",SpotifySong.musicLink(link));assertFalse(SpotifySong.accepts("https://open.spotify.com.evil/track/2g20aO38HBLIpg6NbCrjE3"));assertFalse(SpotifySong.accepts("https://open.spotify.com/playlist/2g20aO38HBLIpg6NbCrjE3"));
        JSONObject entity=new JSONObject().put("type","track").put("title","Original song").put("artists",new JSONArray().put(new JSONObject().put("name","Original Artist"))).put("duration",180000).put("uri","spotify:track:2g20aO38HBLIpg6NbCrjE3").put("audioPreview",new JSONObject().put("url","https://invalid.example/preview.mp3"));JSONObject root=new JSONObject().put("props",new JSONObject().put("pageProps",new JSONObject().put("state",new JSONObject().put("data",new JSONObject().put("entity",entity)))));SpotifyPlaylist.Song song=SpotifySong.parse("<script id='__NEXT_DATA__'>"+root+"</script>");assertEquals("Original song",song.title);assertEquals("Original Artist",song.artist);assertEquals(180000,song.durationMs);
    }
    @Test public void publicPlaylistsParseCurrentAndLegacyResponses()throws Exception{
        JSONObject old=new JSONObject().put("playlistRenderer",new JSONObject().put("playlistId","PLabcdefghijk").put("title",new JSONObject().put("simpleText","Old playlist")));
        JSONObject modern=new JSONObject().put("lockupViewModel",new JSONObject().put("contentId","PLlmnopqrstuv").put("contentType","LOCKUP_CONTENT_TYPE_PLAYLIST").put("metadata",new JSONObject().put("lockupMetadataViewModel",new JSONObject().put("title",new JSONObject().put("content","Modern playlist")))));
        assertEquals(2,PublicPlaylists.parse(new JSONObject().put("items",new JSONArray().put(old).put(modern))).size());
    }
    private static TextView text(View v,String label){if(v instanceof TextView&&((TextView)v).getText().toString().equals(label))return (TextView)v;if(v instanceof ViewGroup)for(int i=0;i<((ViewGroup)v).getChildCount();i++){TextView found=text(((ViewGroup)v).getChildAt(i),label);if(found!=null)return found;}return null;}
    private static View description(View v,String label){if(label.contentEquals(v.getContentDescription()==null?"":v.getContentDescription()))return v;if(v instanceof ViewGroup)for(int i=0;i<((ViewGroup)v).getChildCount();i++){View found=description(((ViewGroup)v).getChildAt(i),label);if(found!=null)return found;}return null;}
    private static void capture(MainActivity a,String name)throws Exception{String path=System.getProperty("syntix.reviewDir");if(path==null)return;a.root.forceLayout();a.root.measure(View.MeasureSpec.makeMeasureSpec(393,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(852,View.MeasureSpec.EXACTLY));a.root.layout(0,0,393,852);a.root.getViewTreeObserver().dispatchOnPreDraw();Bitmap image=Bitmap.createBitmap(393,852,Bitmap.Config.ARGB_8888);a.root.draw(new Canvas(image));File dir=new File(path);dir.mkdirs();try(FileOutputStream out=new FileOutputStream(new File(dir,name))){image.compress(Bitmap.CompressFormat.PNG,100,out);}finally{image.recycle();}}
}
