package app.skipline.android;

import android.graphics.*;
import android.os.Bundle;
import android.text.Spanned;
import android.text.style.ClickableSpan;
import android.view.*;
import android.widget.*;
import androidx.appcompat.widget.AppCompatCheckBox;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.android.controller.ActivityController;
import org.robolectric.annotation.*;
import java.io.*;
import java.util.zip.*;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class)
@Config(sdk=31,application=ListeningFeaturesUiTest.UiApp.class,qualifiers="w393dp-h852dp-mdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@androidx.media3.common.util.UnstableApi
public class OnboardingReleaseTest {
    @Test public void consentStartsUncheckedLinksWorkAndOnlyExplicitAcceptanceCreatesTheProfile()throws Exception{
        try(ActivityController<MainActivity> c=Robolectric.buildActivity(MainActivity.class).create().visible()){
            MainActivity a=c.get();a.welcome=true;a.onboardingStage=1;a.refresh();AppCompatCheckBox box=a.root.findViewWithTag("onboarding_terms");View create=a.root.findViewWithTag("create_profile");assertFalse(box.isChecked());assertFalse(create.isEnabled());a.onboardingName="Listener One";assertFalse(Onboarding.completeProfile(a));assertEquals("Listener",a.app.profiles.current().name);assertFalse(a.app.prefs("legal").contains("accepted_at"));
            TextView legal=find(a.root,Onboarding.CONSENT);ClickableSpan[] links=((Spanned)legal.getText()).getSpans(0,legal.length(),ClickableSpan.class);assertEquals(2,links.length);links[0].onClick(legal);assertTrue(a.activeSheets.get(0).isShowing());a.activeSheets.get(0).dismiss();assertFalse(box.isChecked());box.performClick();assertTrue(create.isEnabled());capture(a,"profile-accepted",393,852);create.performClick();assertEquals(2,a.onboardingStage);assertEquals("Listener One",a.app.profiles.current().name);assertEquals(Onboarding.LEGAL_VERSION,a.app.prefs("legal").getString("terms_version",""));assertTrue(a.app.prefs("legal").getLong("accepted_at",0)>0);assertNotNull(find(a.root,"Import a playlist"));assertNotNull(find(a.root,"Find a song instead"));capture(a,"first-playlist",393,852);
        }
    }
    @Test public void returningListenersAreNotSentThroughTheNewOnboarding(){
        try(ActivityController<MainActivity> c=Robolectric.buildActivity(MainActivity.class).create().visible()){c.get().getPreferences(0).edit().putInt("onboarding_version",6).commit();}
        try(ActivityController<MainActivity> c=Robolectric.buildActivity(MainActivity.class).create().visible()){assertFalse(c.get().welcome);}
    }
    @Test public void savedConsentChoiceSurvivesActivityRecreation(){
        Bundle state=new Bundle();try(ActivityController<MainActivity> c=Robolectric.buildActivity(MainActivity.class).create().visible()){MainActivity a=c.get();a.onboardingStage=1;a.onboardingName="Local name";a.onboardingAccepted=true;c.saveInstanceState(state);}
        try(ActivityController<MainActivity> c=Robolectric.buildActivity(MainActivity.class).create(state).visible()){MainActivity a=c.get();assertEquals("Local name",a.onboardingName);assertTrue(a.onboardingAccepted);assertTrue(((AppCompatCheckBox)a.root.findViewWithTag("onboarding_terms")).isChecked());}
    }
    @Test public void additionalProfilesRequireAcceptanceButEditingAnExistingOneDoesNot(){
        try(ActivityController<MainActivity> c=Robolectric.buildActivity(MainActivity.class).create().visible()){
            MainActivity a=c.get();a.welcome=false;NativeScreens.editProfile(a,true);View sheet=a.activeSheets.get(0).getWindow().getDecorView();assertFalse(find(sheet,"Save profile").isEnabled());a.activeSheets.get(0).dismiss();NativeScreens.editProfile(a,false);sheet=a.activeSheets.get(a.activeSheets.size()-1).getWindow().getDecorView();assertTrue(find(sheet,"Save profile").isEnabled());assertNull(sheet.findViewWithTag("onboarding_terms"));
        }
    }
    @Test public void sourceMovesToWebsiteWhileLicenseNoticesStayBundled()throws Exception{
        try(ActivityController<MainActivity> c=Robolectric.buildActivity(MainActivity.class).create().visible()){
            MainActivity a=c.get();PrivacyLegal.show(a);assertNotNull(find(a.activeSheets.get(0).getWindow().getDecorView(),"Open-source software"));PrivacyLegal.software(a);View sheet=a.activeSheets.get(1).getWindow().getDecorView();assertNull(find(sheet,"Save application source"));assertNull(find(sheet,"Source and build information"));assertNull(sheet.findViewWithTag("application_source_link"));assertNotNull(find(sheet,"Third-party licenses"));assertTrue(PrivacyLegal.read(a,"THIRD_PARTY_LICENSES.md").contains("https://rish497.github.io/syntix-site/sources/Syntix-2.2-source.zip"));
            try(InputStream ignored=a.getAssets().open("legal/Syntix-application-source.zip")){fail("Source ZIP must not be bundled");}catch(java.io.FileNotFoundException expected){}
        }
    }
    @Test public void nativeWelcomeAndProfileRenderAcrossCompactLargeTextLandscapeAndTablet()throws Exception{
        try(ActivityController<MainActivity> c=Robolectric.buildActivity(MainActivity.class).create().visible()){
            MainActivity a=c.get();a.welcome=true;for(int i=0;i<3;i++){a.onboardingStage=0;a.onboardingSlide=i;a.refresh();capture(a,"welcome-"+i,393,852);}a.onboardingStage=1;a.refresh();capture(a,"profile-unchecked",393,852);
            android.content.res.Configuration config=new android.content.res.Configuration(a.getResources().getConfiguration());config.fontScale=1.3f;a.getResources().updateConfiguration(config,a.getResources().getDisplayMetrics());a.refresh();capture(a,"profile-large-text",320,640);assertNotNull(find(a.root,Onboarding.CONSENT));
            a.onboardingStage=0;a.onboardingSlide=0;a.refresh();capture(a,"welcome-landscape",852,393);capture(a,"welcome-tablet",768,1024);
        }
    }
    private static TextView find(View view,String value){if(view instanceof TextView&&((TextView)view).getText().toString().equals(value))return (TextView)view;if(view instanceof ViewGroup)for(int i=0;i<((ViewGroup)view).getChildCount();i++){TextView found=find(((ViewGroup)view).getChildAt(i),value);if(found!=null)return found;}return null;}
    private static void capture(MainActivity a,String name,int width,int height)throws Exception{String path=System.getProperty("syntix.reviewDir");if(path==null)return;a.root.forceLayout();a.root.measure(View.MeasureSpec.makeMeasureSpec(width,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(height,View.MeasureSpec.EXACTLY));a.root.layout(0,0,width,height);a.root.getViewTreeObserver().dispatchOnGlobalLayout();a.root.getViewTreeObserver().dispatchOnPreDraw();a.root.measure(View.MeasureSpec.makeMeasureSpec(width,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(height,View.MeasureSpec.EXACTLY));a.root.layout(0,0,width,height);Bitmap bitmap=Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888);a.root.draw(new Canvas(bitmap));File dir=new File(path);dir.mkdirs();try(FileOutputStream out=new FileOutputStream(new File(dir,"onboarding-"+name+".png"))){bitmap.compress(Bitmap.CompressFormat.PNG,100,out);}finally{bitmap.recycle();}}
}
