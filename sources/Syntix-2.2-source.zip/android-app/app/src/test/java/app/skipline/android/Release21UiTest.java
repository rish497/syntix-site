package app.skipline.android;

import android.view.*;
import android.widget.*;
import android.graphics.*;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import org.robolectric.android.controller.ActivityController;
import androidx.recyclerview.widget.*;
import java.util.*;
import java.io.*;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class)
@Config(sdk=29,application=Release21UiTest.UiApp.class,qualifiers="w393dp-h852dp-mdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@androidx.media3.common.util.UnstableApi
public class Release21UiTest {
    public static class UiApp extends ListeningFeaturesUiTest.UiApp {
        @Override public void onCreate(){super.onCreate();SkiplineApp.instance=this;try{java.lang.reflect.Field field=Images.class.getDeclaredField("http");field.setAccessible(true);byte[] png=java.util.Base64.getDecoder().decode("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR4nGOQ0zD6DwACWAF41TTQUQAAAABJRU5ErkJggg==");field.set(null,new okhttp3.OkHttpClient.Builder().addInterceptor(chain->new okhttp3.Response.Builder().request(chain.request()).protocol(okhttp3.Protocol.HTTP_1_1).code(200).message("OK").body(okhttp3.ResponseBody.create(png,okhttp3.MediaType.get("image/png"))).build()).build());}catch(Exception failed){throw new AssertionError(failed);}}
    }
    @Test public void recommendationGridLoadsNextPageAndLinksAreQuiet()throws Exception{
        try(ActivityController<MainActivity> c=Robolectric.buildActivity(MainActivity.class).create().visible()){
            MainActivity a=c.get();a.welcome=false;SavedPlaylist saved=new SavedPlaylist("80s rock");a.app.library.add(saved);SongRecommendations.Cursor cursor=new SongRecommendations.Cursor(Collections.singletonList("80s rock"),(q,t)->t.isEmpty()?SongRecommendationsTest.page(0,20,"next"):SongRecommendationsTest.page(20,20,""));RecommendationGrid.show(a,saved,cursor);com.google.android.material.bottomsheet.BottomSheetDialog dialog=a.activeSheets.get(a.activeSheets.size()-1);View sheet=dialog.getWindow().getDecorView();RecyclerView grid=sheet.findViewWithTag("recommended_song_grid");assertNotNull(grid);assertNull(text(sheet,"Recently listened"));assertFalse(text(sheet,"Recommended") instanceof com.google.android.material.button.MaterialButton);await(grid,20);grid.scrollToPosition(19);grid.scrollBy(0,2400);await(grid,40);capture(sheet,"recommendations-2.1.png");dialog.dismiss();Shadows.shadowOf(android.os.Looper.getMainLooper()).idleFor(java.time.Duration.ofSeconds(1));assertTrue("Dismissal must cancel the recommendation request",cursor.closed);
            PrivacyLegal.show(a);sheet=a.activeSheets.get(a.activeSheets.size()-1).getWindow().getDecorView();TextView notice=sheet.findViewWithTag("open_source_text_link"),source=sheet.findViewWithTag("source_website_text_link");assertNotNull(notice);assertNotNull(source);assertFalse(notice instanceof com.google.android.material.button.MaterialButton);assertEquals(12,notice.getTextSize()/a.getResources().getDisplayMetrics().scaledDensity,.01);source.performClick();android.content.Intent intent=Shadows.shadowOf(a).getNextStartedActivity();assertEquals("https://rish497.github.io/syntix-site/sources/Syntix-2.2-source.zip",intent.getDataString());
        }
    }
    @Test public void playlistAutomaticallyAppendsBeyondOneHundredWithoutReplacingPage()throws Exception{
        try(ActivityController<MainActivity> c=Robolectric.buildActivity(MainActivity.class).create().visible()){
            MainActivity a=c.get();a.welcome=false;a.page="library";SavedPlaylist saved=new SavedPlaylist("Long playlist");for(int i=0;i<160;i++)saved.tracks.add(new Track(String.format(Locale.ROOT,"https://www.youtube.com/watch?v=vid%08d",i),"Song "+i,"Artist","",180));a.app.library.add(saved);a.selectedPlaylist=saved;a.refresh();View host=a.root.getChildAt(0);assertNull(text(a.root,"Show more songs"));layout(a.root,393,852);a.bodyScroll.scrollTo(0,a.bodyScroll.getChildAt(0).getHeight());org.robolectric.util.ReflectionHelpers.callInstanceMethod(a.bodyScroll.getViewTreeObserver(),"dispatchOnScrollChanged");Shadows.shadowOf(android.os.Looper.getMainLooper()).idle();assertNotNull(text(a.root,"Song 159"));assertSame(host,a.root.getChildAt(0));
        }
    }
    @Test public void searchOmitsDiscoveryRailAndCreateAcceptsBothProviders()throws Exception{
        try(ActivityController<MainActivity> c=Robolectric.buildActivity(MainActivity.class).create().visible()){
            MainActivity a=c.get();a.welcome=false;a.page="search";a.refresh();assertNull(text(a.root,"Discover something new"));assertNotNull(text(a.root,"Browse all"));NativeScreens.createSheet(a);View sheet=a.activeSheets.get(a.activeSheets.size()-1).getWindow().getDecorView();assertNotNull(text(sheet,"Import song"));VideoScreens.importSheet(a);sheet=a.activeSheets.get(a.activeSheets.size()-1).getWindow().getDecorView();assertNotNull(text(sheet,"Import YouTube or Spotify song"));assertNotNull(text(sheet,"Import song"));
        }
    }
    static void capture(View view,String name)throws Exception{layout(view,393,750);Bitmap image=Bitmap.createBitmap(393,750,Bitmap.Config.ARGB_8888);view.draw(new Canvas(image));File dir=new File(System.getProperty("syntix.reviewDir","."));dir.mkdirs();try(FileOutputStream out=new FileOutputStream(new File(dir,name))){image.compress(Bitmap.CompressFormat.PNG,100,out);}finally{image.recycle();}}
    static void await(RecyclerView grid,int count)throws Exception{for(int i=0;i<150&&grid.getAdapter().getItemCount()<count;i++){Thread.sleep(20);Shadows.shadowOf(android.os.Looper.getMainLooper()).idle();}assertTrue("Grid must load "+count+" real fixture rows",grid.getAdapter().getItemCount()>=count);}
    static void layout(View v,int w,int h){v.measure(View.MeasureSpec.makeMeasureSpec(w,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(h,View.MeasureSpec.EXACTLY));v.layout(0,0,w,h);v.getViewTreeObserver().dispatchOnPreDraw();}
    static TextView text(View v,String s){if(v instanceof TextView&&((TextView)v).getText().toString().equals(s))return (TextView)v;if(v instanceof ViewGroup)for(int i=0;i<((ViewGroup)v).getChildCount();i++){TextView f=text(((ViewGroup)v).getChildAt(i),s);if(f!=null)return f;}return null;}
}
