package app.skipline.android;



import android.app.Activity;

import android.content.Intent;

import android.content.res.ColorStateList;

import android.graphics.Color;

import android.net.Uri;

import android.text.Editable;

import android.text.TextUtils;

import android.text.TextWatcher;

import android.view.Gravity;

import android.view.View;

import android.view.inputmethod.EditorInfo;

import android.widget.*;

import androidx.media3.common.MediaItem;

import androidx.media3.common.Player;

import com.google.android.material.button.MaterialButton;

import com.google.android.material.bottomsheet.BottomSheetDialog;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import com.google.android.material.snackbar.Snackbar;

import java.util.*;



/** Native implementation of the user-approved Reference composition. No sample library is seeded. */

@androidx.media3.common.util.UnstableApi

final class NativeScreens {

    private static final int PAGE=MainActivity.PAGE,SURFACE=MainActivity.SURFACE,INK=MainActivity.INK,MUTED=MainActivity.MUTED,ACCENT=MainActivity.ACCENT;

    static void render(MainActivity a){
        a.spotifyBinding=null;

        boolean theme=a.selectedPlaylist==null&&(a.page.startsWith("theme:")||a.page.startsWith("discover:"));if(theme){int index=NativeSearch.themeIndex(a.page);int color=NativeSearch.COLORS[Math.max(0,Math.min(index,NativeSearch.COLORS.length-1))];android.graphics.drawable.GradientDrawable wash=new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,new int[]{color,PAGE,PAGE});wash.setColors(new int[]{color,PAGE,PAGE},new float[]{0,.33f,1});a.root.setBackground(wash);a.getWindow().setStatusBarColor(color);}else{a.root.setBackgroundColor(PAGE);a.getWindow().setStatusBarColor(PAGE);}a.drawerHost.setDrawerLockMode(a.page.equals("library")?androidx.drawerlayout.widget.DrawerLayout.LOCK_MODE_UNLOCKED:androidx.drawerlayout.widget.DrawerLayout.LOCK_MODE_LOCKED_CLOSED,androidx.core.view.GravityCompat.END);
        String key=a.page+":"+(a.selectedPlaylist==null?"":a.selectedPlaylist.id);int scroll=key.equals(a.renderedScreen)&&a.bodyScroll!=null?a.bodyScroll.getScrollY():0;a.renderedScreen=key;a.root.removeAllViews();a.mini=null;a.bodyScroll=null;

        if(a.welcome){a.welcome();return;}

        LinearLayout host=a.column();host.setPadding(a.dp(15),0,a.dp(15),0);a.root.addView(host,new LinearLayout.LayoutParams(-1,0,1));

        if(!a.app.error.isEmpty()){TextView error=a.text(a.app.error,13,INK,false);host.addView(error);LinearLayout recovery=a.row();recovery.addView(a.button("Retry",R.drawable.ic_retry,false,()->{if(a.retryAction!=null)a.retryAction.run();else if(a.app.playback!=null){a.app.playback.player.prepare();a.app.playback.player.play();}}),new LinearLayout.LayoutParams(0,a.dp(44),1));recovery.addView(a.icon(R.drawable.ic_close,"Dismiss error",()->{a.app.error="";a.refresh();}),a.lp(48,48));host.addView(recovery);}

        if(a.app.busy&&!a.page.equals("spotify-import")&&!(a.app.spotifyImport!=null&&a.app.spotifyImport.running&&a.app.spotifyImport.target!=null)){LinearLayout busy=a.row();ProgressBar progress=new ProgressBar(a);progress.setIndeterminateTintList(ColorStateList.valueOf(ACCENT));busy.addView(progress,a.lp(20,20));TextView note=a.text(a.app.status,13,MUTED,false);note.setPadding(a.dp(10),a.dp(9),0,a.dp(9));busy.addView(note,new LinearLayout.LayoutParams(0,-2,1));host.addView(busy);}

        LinearLayout content=a.column();a.scrollArea(host,content);

        if(a.selectedPlaylist!=null)playlist(a,content,a.selectedPlaylist);

        else if(a.page.startsWith("mix:"))ListeningFeatures.mix(a,content);else if(a.page.startsWith("theme:")||a.page.startsWith("discover:"))NativeSearch.theme(a,content);else switch(a.page){case "spotify-import":SpotifyImport.render(a,content);break;case "equalizer":EqualizerScreen.render(a,content);break;case "sleep":ListeningFeatures.sleep(a,content);break;case "mixes":ListeningFeatures.mixes(a,content);break;case "imported":VideoScreens.render(a,content);break;case "statistics":StatisticsScreens.render(a,content,false);break;case "artists":StatisticsScreens.render(a,content,true);break;case "downloads":DownloadScreens.render(a,content);break;case "search":NativeSearch.render(a,content);break;case "library":library(a,content);break;case "create":create(a,content);break;case "profile":profile(a,content);break;case "recent":recents(a,content);break;default:home(a,content);}

        if(a.page.equals("equalizer")&&a.selectedPlaylist==null){a.navBarView=null;return;}
        if(!a.app.queue.isEmpty())mini(a);

        LinearLayout nav=a.row();nav.setPadding(a.dp(5),0,a.dp(5),a.dp(2));String[] titles={"Home","Search","Your Library","Downloads","Create"},routes={"home","search","library","downloads","create"};int[] glyphs={R.drawable.ic_home,R.drawable.ic_search,R.drawable.ic_library,R.drawable.ic_download,R.drawable.ic_plus};

        for(int i=0;i<routes.length;i++){final String route=routes[i];LinearLayout target=a.column();target.setGravity(Gravity.CENTER);target.setPadding(a.dp(2),a.dp(7),a.dp(2),a.dp(5));ImageView image=new ImageView(a);image.setImageResource(glyphs[i]);image.setColorFilter(a.mainTab.equals(route)?INK:MUTED);target.addView(image,a.lp(24,24));a.gap(target,4);TextView label=a.text(titles[i],10,a.mainTab.equals(route)?INK:MUTED,a.mainTab.equals(route));label.setGravity(Gravity.CENTER);label.setIncludeFontPadding(false);label.setSingleLine(true);label.setEllipsize(TextUtils.TruncateAt.END);target.addView(label,new LinearLayout.LayoutParams(-1,-2));target.setContentDescription(titles[i]);target.setFocusable(true);target.setClickable(true);target.setBackground(new android.graphics.drawable.RippleDrawable(ColorStateList.valueOf(0x20e1cdae),new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT),new android.graphics.drawable.ColorDrawable(Color.WHITE)));target.setOnClickListener(v->a.tab(route));nav.addView(target,new LinearLayout.LayoutParams(0,a.dp(65),1));}a.navBarView=nav;a.root.addView(nav);a.updateChrome();

        if(scroll>0&&a.bodyScroll!=null){ScrollView active=a.bodyScroll;active.post(()->active.scrollTo(0,scroll));}if(a.sessionDialog!=null&&a.sessionDialog.isShowing()&&a.adapter!=null)a.adapter.notifyDataSetChanged();

    }

    static View avatar(MainActivity a,int size){FrameLayout box=new FrameLayout(a);a.rounded(box,ACCENT,size/2);TextView initial=a.text(a.app.profiles.current().name.substring(0,1).toUpperCase(Locale.ROOT),Math.max(15,size/2),MainActivity.ON_ACCENT,true);initial.setGravity(Gravity.CENTER);box.addView(initial,new FrameLayout.LayoutParams(-1,-1));String uri=a.app.profiles.current().photo;if(!uri.isEmpty()){ImageView photo=new ImageView(a);photo.setScaleType(ImageView.ScaleType.CENTER_CROP);box.addView(photo,new FrameLayout.LayoutParams(-1,-1));Images.loadLocal(a,photo,uri);}box.setContentDescription(a.app.profiles.current().name+" profile");return box;}

    private static void avatarButton(MainActivity a,LinearLayout bar){FrameLayout hit=new FrameLayout(a);View image=avatar(a,36);FrameLayout.LayoutParams p=new FrameLayout.LayoutParams(a.dp(36),a.dp(36),Gravity.CENTER);hit.addView(image,p);hit.setContentDescription("Open profile menu");hit.setFocusable(true);hit.setClickable(true);hit.setOnClickListener(v->drawer(a));bar.addView(hit,a.lp(48,52));}

    private static void header(MainActivity a,LinearLayout content,String title){LinearLayout bar=a.row();avatarButton(a,bar);TextView label=a.text(title,25,INK,true);label.setSingleLine(true);label.setEllipsize(TextUtils.TruncateAt.END);bar.addView(label,new LinearLayout.LayoutParams(0,-2,1));bar.addView(a.icon(R.drawable.ic_plus,"Import YouTube or Spotify playlist",a::pasteSheet),a.lp(48,48));content.addView(bar,a.lp(-1,62));a.gap(content,12);}

    private static void title(MainActivity a,LinearLayout content,String title,Runnable action){LinearLayout row=a.row();row.addView(a.text(title,21,INK,true),new LinearLayout.LayoutParams(0,-2,1));if(action!=null)row.addView(a.icon(R.drawable.ic_arrow,"View all "+title,action),a.lp(48,48));content.addView(row,a.lp(-1,48));}

    private static boolean indexSelected(MainActivity a,int index){return index==(a.homePlaylists?1:0);}
    private static void home(MainActivity a,LinearLayout content){

        LinearLayout bar=a.row();avatarButton(a,bar);HorizontalScrollView filterScroll=new HorizontalScrollView(a);filterScroll.setHorizontalScrollBarEnabled(false);LinearLayout filters=a.row();String[] names={"All","Playlists","Recent"};for(int i=0;i<names.length;i++){final int index=i;MaterialButton chip=a.button(names[i],0,indexSelected(a,i),()->{if(index<2){a.homePlaylists=index==1;a.refresh();}else a.go("recent");});chip.setSingleLine(true);chip.setTextSize(12);LinearLayout.LayoutParams cp=a.lp(-2,38);cp.rightMargin=a.dp(7);filters.addView(chip,cp);}filterScroll.addView(filters);bar.addView(filterScroll,new LinearLayout.LayoutParams(0,a.dp(48),1));ImageView logo=new ImageView(a);logo.setImageResource(R.drawable.syntix_app_icon);logo.setScaleType(ImageView.ScaleType.FIT_CENTER);logo.setContentDescription("Syntix");bar.addView(logo,a.lp(30,38));content.addView(bar,a.lp(-1,62));a.gap(content,12);

        if(a.homePlaylists){PublicPlaylists.render(a,content);return;}
        title(a,content,"Start listening",null);ArrayList<Track> starts=a.app.history.recent();if(starts.isEmpty())starts.addAll(a.app.queue);if(starts.isEmpty()&&!a.app.library.isEmpty())starts.addAll(a.app.library.get(0).tracks);a.app.warmVisibleTracks(starts);if(starts.isEmpty()){content.addView(a.text("Bring your music from YouTube or Spotify, or find a song to start listening.",14,MUTED,false));a.gap(content,12);content.addView(a.button("Import playlist",R.drawable.ic_link,true,a::pasteSheet),a.lp(-1,48));a.gap(content,8);content.addView(a.button("Find music",R.drawable.ic_search,false,()->a.tab("search")),a.lp(-1,48));}else for(int i=0;i<Math.min(3,starts.size());i++)track(a,content,starts.get(i),null);

        a.gap(content,23);title(a,content,"Recommended for you",a.app::refreshRecommendations);

        if(!a.app.prefs("history").getBoolean("recommendations_enabled",true))content.addView(a.text("Suggestions are off for this profile.",14,MUTED,false));else if(a.app.discovering)content.addView(a.text("Finding music from your listening history…",14,MUTED,false));else if(!a.app.recommendationError.isEmpty())content.addView(a.text(a.app.recommendationError,14,MUTED,false));else if(a.app.recommendations.isEmpty())content.addView(a.text("Listen to songs to start discovering. Your retained listening history shapes these suggestions.",14,MUTED,false));else trackRail(a,content,a.app.recommendations);

        ListeningFeatures.home(a,content);
        VideoScreens.home(a,content);
        a.gap(content,23);title(a,content,"Your playlists",()->a.tab("library"));playlistRail(a,content);a.gap(content,24);

    }

    static void track(MainActivity a,LinearLayout content,Track t,SavedPlaylist owner){

        LinearLayout line=a.row();line.setPadding(a.dp(4),a.dp(4),a.dp(4),a.dp(4));

        FrameLayout art=new FrameLayout(a);art.addView(a.art(44,44,t.thumbnail),new FrameLayout.LayoutParams(a.dp(44),a.dp(44)));line.addView(art,a.lp(44,44));


        LinearLayout labels=a.column();labels.setPadding(a.dp(11),0,a.dp(6),0);

        TextView name=a.text(t.title,14,INK,true);name.setSingleLine(true);name.setEllipsize(TextUtils.TruncateAt.END);labels.addView(name);a.gap(labels,4);

        String subtitle=t.creator+(t.duration>0?" · "+MainActivity.format(t.duration):"")+(a.app.offline.file(t.source)!=null?" · Offline":"");

        TextView artist=a.text(subtitle,12,MUTED,false);artist.setSingleLine(true);artist.setEllipsize(TextUtils.TruncateAt.END);labels.addView(artist);line.addView(labels,new LinearLayout.LayoutParams(0,-2,1));

        line.setFocusable(true);line.setOnClickListener(v->{if(owner==null)a.playTrack(t);else a.playPlaylistAt(owner,owner.tracks.indexOf(t));});

        MaterialButton heart=heart(a,t);line.addView(heart,a.lp(44,48));line.addView(a.icon(R.drawable.ic_more,"Actions for "+t.title,()->trackMenu(a,t,owner)),a.lp(44,48));

        content.addView(line,a.lp(-1,60));

        if(owner!=null)PlaylistPlayback.bindRow(a,line,name,artist,t,owner,subtitle);

    }

    private static MaterialButton heart(MainActivity a,Track t){MaterialButton b=a.icon(a.app.isFavorite(t)?R.drawable.ic_heart_filled:R.drawable.ic_heart,a.app.isFavorite(t)?"Remove "+t.title+" from Favorites":"Favorite "+t.title,()->{a.app.toggleFavorite(t);Snackbar.make(a.root,a.app.isFavorite(t)?"Added to Favorites":"Removed from Favorites",Snackbar.LENGTH_SHORT).show();});b.setIconTint(ColorStateList.valueOf(a.app.isFavorite(t)?ACCENT:MUTED));b.setSelected(a.app.isFavorite(t));return b;}

    static void trackMenu(MainActivity a,Track track,SavedPlaylist owner){SongActions.show(a,track,owner);}

    static void trackRail(MainActivity a,LinearLayout content,List<Track> tracks){HorizontalScrollView rail=new HorizontalScrollView(a);rail.setHorizontalScrollBarEnabled(false);LinearLayout cards=a.row();for(int i=0;i<Math.min(30,tracks.size());i++){Track t=tracks.get(i);LinearLayout card=a.column();card.addView(a.art(148,148,t.thumbnail));a.gap(card,8);TextView title=a.text(t.title,14,INK,true);title.setMaxLines(2);title.setEllipsize(TextUtils.TruncateAt.END);card.addView(title,a.lp(148,-2));a.gap(card,4);TextView artist=a.text(t.creator+(a.app.offline.file(t.source)!=null?" · Offline":""),12,MUTED,false);artist.setMaxLines(2);card.addView(artist,a.lp(148,-2));card.setPadding(0,0,a.dp(12),0);card.setOnClickListener(v->a.playTrack(t));card.setContentDescription("Play "+t.title);card.setFocusable(true);cards.addView(card,a.lp(160,-2));}rail.addView(cards);content.addView(rail,a.lp(-1,-2));}

    private static void playlistRail(MainActivity a,LinearLayout content){HorizontalScrollView rail=new HorizontalScrollView(a);rail.setHorizontalScrollBarEnabled(false);LinearLayout cards=a.row();ArrayList<SavedPlaylist> lists=new ArrayList<>();lists.add(a.app.favorites);lists.addAll(a.app.library);for(SavedPlaylist saved:lists){LinearLayout card=a.column();if(saved==a.app.favorites)card.addView(favoriteArt(a,148));else card.addView(a.art(148,148,saved.tracks.isEmpty()?"":saved.tracks.get(0).thumbnail));a.gap(card,9);TextView name=a.text(saved.name,14,INK,true);name.setMaxLines(2);name.setEllipsize(TextUtils.TruncateAt.END);card.addView(name,a.lp(148,-2));a.gap(card,4);card.addView(a.text(count(SpotifyProgress.total(saved)),12,MUTED,false));card.setContentDescription("Open "+saved.name);card.setFocusable(true);card.setOnClickListener(v->a.openPlaylist(saved));cards.addView(card,a.lp(160,-2));}rail.addView(cards);content.addView(rail,a.lp(-1,-2));}

    private static View favoriteArt(MainActivity a,int size){FrameLayout art=new FrameLayout(a);a.rounded(art,ACCENT,5);ImageView heart=new ImageView(a);heart.setImageResource(R.drawable.ic_heart_filled);heart.setColorFilter(MainActivity.ON_ACCENT);FrameLayout.LayoutParams p=new FrameLayout.LayoutParams(a.dp(size/2),a.dp(size/2),Gravity.CENTER);art.addView(heart,p);art.setLayoutParams(a.lp(size,size));return art;}

    private static void library(MainActivity a,LinearLayout content){header(a,content,"Your Library");a.libraryAZ=a.app.prefs("library_view").getBoolean("az",false);a.libraryGrid=a.app.prefs("library_view").getBoolean("grid",false);LinearLayout controls=a.row();TextView description=a.text((a.libraryAZ?"A–Z":"Recent")+" · "+(a.libraryGrid?"Grid":"List"),12,MUTED,false);controls.addView(description,new LinearLayout.LayoutParams(0,-2,1));controls.addView(a.icon(R.drawable.ic_sort,"Library view options",()->libraryViewOptions(a)),a.lp(48,48));content.addView(controls);a.gap(content,10);ArrayList<SavedPlaylist> lists=new ArrayList<>(a.app.library);if(a.libraryAZ)lists.sort((x,y)->x.name.compareToIgnoreCase(y.name));else Collections.reverse(lists);lists.add(0,a.app.favorites);

        if(a.libraryGrid){LinearLayout line=null;for(int i=0;i<lists.size();i++){if(i%2==0){line=a.row();line.setGravity(Gravity.TOP);content.addView(line,a.lp(-1,-2));}SavedPlaylist saved=lists.get(i);LinearLayout tile=a.column();tile.setPadding(a.dp(3),a.dp(8),a.dp(10),a.dp(16));int size=Math.max(100,(a.getResources().getDisplayMetrics().widthPixels/a.getResources().getDisplayMetrics().density>600?220:(int)(a.getResources().getDisplayMetrics().widthPixels/a.getResources().getDisplayMetrics().density/2-30)));tile.addView(saved==a.app.favorites?favoriteArt(a,size):a.art(size,size,saved.tracks.isEmpty()?"":saved.tracks.get(0).thumbnail));a.gap(tile,9);tile.addView(a.text(saved.name,15,INK,true));tile.addView(a.text(count(SpotifyProgress.total(saved)),12,MUTED,false));tile.setOnClickListener(v->a.openPlaylist(saved));line.addView(tile,new LinearLayout.LayoutParams(0,-2,1));}if(lists.size()%2==1)line.addView(new Space(a),new LinearLayout.LayoutParams(0,1,1));}

        else for(SavedPlaylist saved:lists)playlistRow(a,content,saved);

        a.gap(content,18);content.addView(a.button("Import playlist",R.drawable.ic_link,false,a::pasteSheet),a.lp(-1,48));if(a.app.library.isEmpty()){a.gap(content,12);content.addView(a.text("Create a playlist, or import one from YouTube or Spotify.",14,MUTED,false));}}

    static void libraryViewOptions(MainActivity a){a.libraryOptionsPanel.removeAllViews();LinearLayout panel=a.column();panel.setBackgroundColor(SURFACE);panel.setPadding(a.dp(20),a.dp(40),a.dp(20),a.dp(20));a.libraryOptionsPanel.addView(panel,new FrameLayout.LayoutParams(-1,-1));LinearLayout heading=a.row();heading.addView(a.text("View options",23,INK,true),new LinearLayout.LayoutParams(0,-2,1));heading.addView(a.icon(R.drawable.ic_close,"Close view options",()->a.drawerHost.closeDrawer(androidx.core.view.GravityCompat.END,android.animation.ValueAnimator.areAnimatorsEnabled())),a.lp(48,48));panel.addView(heading);a.gap(panel,25);panel.addView(a.text("Sort by",14,ACCENT,true));a.gap(panel,10);RadioGroup sort=new RadioGroup(a);String[] sorts={"Recent","Alphabetical · A–Z"};for(int i=0;i<sorts.length;i++){RadioButton option=new RadioButton(a);option.setId(View.generateViewId());option.setText(sorts[i]);option.setTextColor(INK);option.setTextSize(14);option.setTypeface(a.face);option.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);option.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);option.setButtonTintList(ColorStateList.valueOf(ACCENT));sort.addView(option,a.lp(-1,51));if(a.libraryAZ==(i==1))option.setChecked(true);}sort.setOnCheckedChangeListener((g,id)->{a.libraryAZ=g.indexOfChild(g.findViewById(id))==1;a.app.prefs("library_view").edit().putBoolean("az",a.libraryAZ).apply();a.refresh();});panel.addView(sort);a.gap(panel,28);panel.addView(a.text("View as",14,ACCENT,true));a.gap(panel,10);RadioGroup view=new RadioGroup(a);String[] layouts={"List","Grid"};for(int i=0;i<layouts.length;i++){RadioButton option=new RadioButton(a);option.setId(View.generateViewId());option.setText(layouts[i]);option.setTextColor(INK);option.setTextSize(14);option.setTypeface(a.face);option.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);option.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);option.setButtonTintList(ColorStateList.valueOf(ACCENT));view.addView(option,a.lp(-1,51));if(a.libraryGrid==(i==1))option.setChecked(true);}view.setOnCheckedChangeListener((g,id)->{a.libraryGrid=g.indexOfChild(g.findViewById(id))==1;a.app.prefs("library_view").edit().putBoolean("grid",a.libraryGrid).apply();a.refresh();});panel.addView(view);a.drawerHost.openDrawer(androidx.core.view.GravityCompat.END,android.animation.ValueAnimator.areAnimatorsEnabled());}

    private static void playlistRow(MainActivity a,LinearLayout content,SavedPlaylist saved){LinearLayout line=a.row();line.setPadding(0,a.dp(8),0,a.dp(8));line.addView(saved==a.app.favorites?favoriteArt(a,58):a.art(58,58,saved.tracks.isEmpty()?"":saved.tracks.get(0).thumbnail));LinearLayout label=a.column();label.setPadding(a.dp(12),0,a.dp(6),0);TextView title=a.text(saved.name,16,INK,true);title.setMaxLines(2);label.addView(title);a.gap(label,5);label.addView(a.text((saved==a.app.favorites?"Your hearted songs":"Playlist · "+a.app.profiles.current().name)+" · "+count(SpotifyProgress.total(saved)),12,MUTED,false));line.addView(label,new LinearLayout.LayoutParams(0,-2,1));line.setOnClickListener(v->a.openPlaylist(saved));line.setFocusable(true);line.setContentDescription("Open "+saved.name);content.addView(line,a.lp(-1,-2));}

    private static void playlist(MainActivity a,LinearLayout content,SavedPlaylist saved){PlaylistScreen.render(a,content,saved);}

    private static void search(MainActivity a,LinearLayout content){header(a,content,"Search");LinearLayout field=a.row();EditText input=new EditText(a);input.setSingleLine(true);input.setTextSize(16);input.setTextColor(INK);input.setHintTextColor(MUTED);input.setHint("Songs, artists or YouTube links");input.setText(a.app.searchQuery);input.setImeOptions(EditorInfo.IME_ACTION_SEARCH);input.setInputType(android.text.InputType.TYPE_CLASS_TEXT);input.setSelectAllOnFocus(false);input.setPadding(a.dp(12),0,a.dp(8),0);a.rounded(input,SURFACE,6);field.addView(input,new LinearLayout.LayoutParams(0,a.dp(50),1));Runnable submit=()->{String q=input.getText().toString().trim();if(q.isEmpty())return;try{String source=Links.extract(q);a.shareSheet(source);return;}catch(Exception ignored){}if(q.length()>180){input.setError("Use up to 180 characters");return;}a.app.search(q);};field.addView(a.icon(R.drawable.ic_search,"Search YouTube",submit),a.lp(48,50));content.addView(field);input.setOnEditorActionListener((v,id,event)->{if(id==EditorInfo.IME_ACTION_SEARCH){submit.run();return true;}return false;});a.gap(content,10);content.addView(a.text("Search YouTube, or browse music already on your phone.",13,MUTED,false));LinearLayout local=a.column();content.addView(local);Runnable filter=()->{local.removeAllViews();String q=input.getText().toString().trim().toLowerCase(Locale.ROOT);ArrayList<Track> localTracks=new ArrayList<>();LinkedHashMap<String,Track> unique=new LinkedHashMap<>();for(Track t:a.app.favorites.tracks)unique.put(t.source,t);for(Track t:a.app.history.recent())unique.put(t.source,t);for(SavedPlaylist l:a.app.library)for(Track t:l.tracks)unique.put(t.source,t);for(Track t:unique.values())if((t.title+" "+t.creator).toLowerCase(Locale.ROOT).contains(q))localTracks.add(t);if(!localTracks.isEmpty()){a.gap(local,12);title(a,local,"On this phone",null);for(int i=0;i<Math.min(30,localTracks.size());i++)track(a,local,localTracks.get(i),null);}a.app.searchQuery=input.getText().toString();};input.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence t,int start,int count,int after){}public void onTextChanged(CharSequence t,int start,int before,int count){filter.run();}public void afterTextChanged(Editable e){}});filter.run();a.gap(content,18);if(a.app.searching)content.addView(a.text("Searching YouTube…",14,MUTED,false));else if(!a.app.searchError.isEmpty())content.addView(a.text(a.app.searchError,14,MUTED,false));else if(!a.app.searchResults.isEmpty()){title(a,content,"YouTube results",null);for(Track t:a.app.searchResults)track(a,content,t,null);}else if(!a.app.searchQuery.isEmpty())content.addView(a.text("Press Search to find music on YouTube.",14,MUTED,false));}

    static void createSheet(MainActivity a){LinearLayout body=a.column();a.handle(body);body.addView(a.button("New playlist",R.drawable.ic_plus,false,()->{for(BottomSheetDialog d:new ArrayList<>(a.activeSheets))d.dismiss();a.namePlaylist("",name->{SavedPlaylist saved=new SavedPlaylist(name);a.app.library.add(saved);a.app.saveLibrary();a.mainTab="library";a.page="library";a.openPlaylist(saved);});}),a.lp(-1,60));a.gap(body,8);body.addView(a.button("Import playlist",R.drawable.ic_link,false,()->{for(BottomSheetDialog d:new ArrayList<>(a.activeSheets))d.dismiss();a.pasteSheet();}),a.lp(-1,60));a.gap(body,8);body.addView(a.button("Import song",R.drawable.ic_video,false,()->{for(BottomSheetDialog d:new ArrayList<>(a.activeSheets))d.dismiss();VideoScreens.importSheet(a);}),a.lp(-1,60));a.sheet(body);}

    private static void create(MainActivity a,LinearLayout content){header(a,content,"Create");content.addView(a.text("A place for your next favorite.",17,MUTED,false));a.gap(content,25);settingRow(a,content,"Playlist","Start a collection and add songs",R.drawable.ic_plus,()->a.namePlaylist("",name->{SavedPlaylist saved=new SavedPlaylist(name);a.app.library.add(saved);a.app.saveLibrary();a.mainTab="library";a.openPlaylist(saved);}));settingRow(a,content,"Import playlist","Bring a playlist from YouTube or Spotify",R.drawable.ic_link,a::pasteSheet);}

    static void drawer(MainActivity a){a.drawerPanel.removeAllViews();LinearLayout panel=a.column();panel.setPadding(a.dp(18),a.dp(45),a.dp(18),a.dp(25));panel.setBackgroundColor(SURFACE);ScrollView drawerScroll=new ScrollView(a);drawerScroll.setFillViewport(true);drawerScroll.setVerticalScrollBarEnabled(false);drawerScroll.addView(panel,new ScrollView.LayoutParams(-1,-2));a.drawerPanel.addView(drawerScroll,new FrameLayout.LayoutParams(-1,-1));LinearLayout identity=a.row();identity.addView(avatar(a,48),a.lp(48,48));LinearLayout name=a.column();name.setPadding(a.dp(13),0,0,0);name.addView(a.text(a.app.profiles.current().name,17,INK,true));a.gap(name,5);name.addView(a.text("View profile",13,MUTED,false));identity.addView(name,new LinearLayout.LayoutParams(0,-2,1));identity.setOnClickListener(v->{a.drawerHost.closeDrawers();a.go("profile");});panel.addView(identity,a.lp(-1,76));a.gap(panel,20);settingRow(a,panel,"Add profile","On this phone",R.drawable.ic_profile,()->{a.drawerHost.closeDrawers();accounts(a);});settingRow(a,panel,"Recents","Your listening history",R.drawable.ic_recent,()->{a.drawerHost.closeDrawers();a.go("recent");});settingRow(a,panel,"Equalizer","Make it sound like you",R.drawable.ic_equalizer,()->{a.drawerHost.closeDrawers();a.go("equalizer");});settingRow(a,panel,"Sleep timer","Drift off to your music",R.drawable.ic_timer,()->{a.drawerHost.closeDrawers();a.go("sleep");});settingRow(a,panel,"Statistics","Your listening activity",R.drawable.ic_statistics,()->{a.drawerHost.closeDrawers();a.go("statistics");});settingRow(a,panel,"Privacy & About","Privacy Policy and Terms of Use",R.drawable.ic_info,()->{a.drawerHost.closeDrawers();a.privacy();});panel.addView(new Space(a),new LinearLayout.LayoutParams(1,0,1));a.brand(panel);a.drawerHost.openDrawer(androidx.core.view.GravityCompat.START);}

    private static void profile(MainActivity a,LinearLayout content){LinearLayout hero=a.column();hero.setPadding(a.dp(3),0,a.dp(3),a.dp(17));hero.setBackground(new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,new int[]{0xff726e63,PAGE}));hero.addView(a.icon(R.drawable.ic_back,"Back",()->a.tab("home")),a.lp(48,48));LinearLayout who=a.row();View photo=avatar(a,86);photo.setOnClickListener(v->choosePhoto(a));who.addView(photo,a.lp(86,86));LinearLayout label=a.column();label.setPadding(a.dp(16),0,0,0);label.addView(a.text(a.app.profiles.current().name,25,INK,true));a.gap(label,8);label.addView(a.text(a.app.library.size()+" saved playlists · On this phone",12,INK,false));who.addView(label,new LinearLayout.LayoutParams(0,-2,1));hero.addView(who);a.gap(hero,15);LinearLayout edits=a.row();edits.addView(a.button("Edit",0,false,()->editProfile(a,false)),a.lp(78,42));edits.addView(a.icon(R.drawable.ic_more,"Switch profile",()->accounts(a)),a.lp(48,48));hero.addView(edits);content.addView(hero);content.addView(a.button("Statistics",R.drawable.ic_statistics,false,()->a.go("statistics")),a.lp(-1,48));a.gap(content,12);title(a,content,"Playlists",()->a.tab("library"));for(int i=0;i<Math.min(3,a.app.library.size());i++)playlistRow(a,content,a.app.library.get(i));if(a.app.library.isEmpty())content.addView(a.text("Create a playlist to make this space yours.",14,MUTED,false));content.addView(a.button("See all playlists",0,false,()->a.tab("library")),a.lp(-1,44));a.gap(content,23);title(a,content,"Recently played",()->a.go("recent"));ArrayList<Track> recent=a.app.history.recent();for(int i=0;i<Math.min(4,recent.size());i++)track(a,content,recent.get(i),null);}

    static void editProfile(MainActivity a,boolean adding){
        LinearLayout body=a.column();a.handle(body);body.addView(a.text(adding?"Add a profile":"Edit profile",27,INK,true));a.gap(body,10);body.addView(a.text("Stored on this phone. No online sign-in or cloud sync.",14,MUTED,false));a.gap(body,20);
        EditText name=new EditText(a);name.setTextSize(16);name.setTextColor(INK);name.setHintTextColor(MUTED);name.setHint("Display name");name.setSingleLine(true);name.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(40)});if(!adding)name.setText(a.app.profiles.current().name);body.addView(name,a.lp(-1,52));a.gap(body,16);
        final boolean[] accepted={false};androidx.appcompat.widget.AppCompatCheckBox agreement=adding?Onboarding.agreement(a,body,false):null;if(adding)a.gap(body,16);BottomSheetDialog[] dialog=new BottomSheetDialog[1];
        MaterialButton save=a.button("Save profile",R.drawable.ic_profile,true,()->{
            if(adding&&!accepted[0])return;String text=name.getText().toString().trim();if(text.isEmpty()){name.setError("Enter a display name");return;}if(a.app.busy||a.app.offlineRunning||a.app.offlineClearing){name.setError("Wait for your import to finish first");return;}
            try{if(adding){LocalProfiles.Profile next=a.app.profiles.add(text);a.selectedPlaylist=null;a.pendingPlay="";a.app.switchProfile(next.id);Onboarding.recordAcceptance(a);}else{a.app.profiles.current().name=text;a.app.profiles.save();}dialog[0].dismiss();a.page="profile";a.mainTab="home";a.refresh();}catch(Exception e){name.setError(e.getMessage());}
        });if(adding){save.setEnabled(false);save.setAlpha(.45f);agreement.setOnCheckedChangeListener((button,checked)->{accepted[0]=checked;save.setEnabled(checked);save.setAlpha(checked?1:.45f);});}body.addView(save,a.lp(-1,50));if(!adding){a.gap(body,10);body.addView(a.button("Change photo",R.drawable.ic_photo,false,()->choosePhoto(a)),a.lp(-1,48));}dialog[0]=a.sheet(body);
    }

    static void choosePhoto(MainActivity a){ProfileArtwork.choose(a);}

    private static void accounts(MainActivity a){LinearLayout body=a.column();a.handle(body);body.addView(a.text("Profiles on this phone",26,INK,true));a.gap(body,10);body.addView(a.text("Each profile has its own library, Favorites and listening history.",14,MUTED,false));a.gap(body,18);BottomSheetDialog[] dialog=new BottomSheetDialog[1];for(LocalProfiles.Profile profile:a.app.profiles.all){body.addView(a.button(profile.name+(profile.id.equals(a.app.profiles.active)?" · Active":""),R.drawable.ic_profile,false,()->{if(a.app.busy||a.app.offlineRunning||a.app.offlineClearing){Snackbar.make(a.root,"Pause downloads or wait for the current import to finish",Snackbar.LENGTH_LONG).show();return;}a.selectedPlaylist=null;a.pendingPlay="";a.screenHistory.clear();a.app.switchProfile(profile.id);dialog[0].dismiss();a.tab("home");}),a.lp(-1,52));a.gap(body,8);}a.gap(body,12);body.addView(a.button("Add profile",R.drawable.ic_plus,true,()->{dialog[0].dismiss();editProfile(a,true);}),a.lp(-1,48));dialog[0]=a.sheet(body);}

    private static void recents(MainActivity a,LinearLayout content){content.addView(a.icon(R.drawable.ic_back,"Back",()->a.tab("home")),a.lp(48,48));a.gap(content,15);title(a,content,"Recents",null);ArrayList<Track> recent=a.app.history.recent();if(recent.isEmpty())content.addView(a.text("Songs appear here after five seconds of playback.",14,MUTED,false));for(int i=0;i<Math.min(a.visibleTracks,recent.size());i++)track(a,content,recent.get(i),null);if(recent.size()>a.visibleTracks)content.addView(a.button("Show more",R.drawable.ic_plus,false,()->{a.visibleTracks+=100;a.refresh();}),a.lp(-1,48));}

    private static void settingRow(MainActivity a,LinearLayout content,String title,String sub,int glyph,Runnable action){LinearLayout row=a.row();ImageView image=new ImageView(a);image.setImageResource(glyph);image.setColorFilter(INK);row.addView(image,a.lp(25,25));LinearLayout labels=a.column();labels.setPadding(a.dp(13),0,a.dp(6),0);labels.addView(a.text(title,16,INK,true));if(!sub.isEmpty()){a.gap(labels,5);labels.addView(a.text(sub,12,MUTED,false));}row.addView(labels,new LinearLayout.LayoutParams(0,-2,1));ImageView arrow=new ImageView(a);arrow.setImageResource(R.drawable.ic_chevron);arrow.setColorFilter(MUTED);row.addView(arrow,a.lp(18,18));row.setPadding(0,a.dp(11),0,a.dp(11));row.setMinimumHeight(a.dp(65));row.setFocusable(true);row.setClickable(true);row.setBackground(new android.graphics.drawable.RippleDrawable(ColorStateList.valueOf(0x18ffffff),null,new android.graphics.drawable.ColorDrawable(Color.WHITE)));row.setOnClickListener(v->action.run());content.addView(row,a.lp(-1,-2));}

    static void mini(MainActivity a){a.mini=a.column();a.rounded(a.mini,0xff4d4b44,6);a.mini.setPadding(a.dp(7),a.dp(4),a.dp(3),a.dp(4));LinearLayout.LayoutParams p=a.lp(-1,56);p.setMargins(a.dp(8),a.dp(5),a.dp(8),0);a.root.addView(a.mini,p);LinearLayout row=a.row();a.miniArt=a.art(38,38,"");row.addView(a.miniArt);LinearLayout labels=a.column();labels.setPadding(a.dp(9),0,0,0);a.miniTitle=a.text("Ready to listen",13,INK,true);a.miniTitle.setSingleLine(true);a.miniTitle.setEllipsize(TextUtils.TruncateAt.END);a.miniTime=a.text("Tap play to begin",11,0xffe1e0d9,false);a.miniTime.setSingleLine(true);a.miniTime.setEllipsize(TextUtils.TruncateAt.END);labels.addView(a.miniTitle);a.gap(labels,3);labels.addView(a.miniTime);row.addView(labels,new LinearLayout.LayoutParams(0,-2,1));a.miniFavorite=a.icon(R.drawable.ic_heart,"Favorite current song",()->{Track t=currentTrack(a);if(t!=null)a.app.toggleFavorite(t);});row.addView(a.miniFavorite,a.lp(40,48));row.addView(a.icon(R.drawable.ic_queue,"Current listening order",a::sessionSheet),a.lp(40,48));a.playButton=a.icon(R.drawable.ic_play,"Play",()->{if(a.app.playback!=null)a.app.playback.toggle();else if(!a.app.queue.isEmpty()){a.pendingPlay=a.app.queue.get(0).id;a.connectPlayback();}});row.addView(a.playButton,a.lp(40,48));a.mini.addView(row);labels.setOnClickListener(v->a.playerSheet());a.miniArt.setOnClickListener(v->a.playerSheet());a.updateMini();}

    static Track currentTrack(MainActivity a){if(a.app.playback==null)return null;MediaItem item=a.app.playback.player.getCurrentMediaItem();return item==null?null:a.app.find(item.mediaId);}

    static void player(MainActivity a){PlayerScreen.show(a);}

    private static String count(int n){return n+" song"+(n==1?"":"s");}

}

