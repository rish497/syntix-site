package app.skipline.android;

import android.content.Context;
import android.graphics.*;
import android.widget.ImageView;

/** Fits the whole portrait and blends the source artwork's cut shoulder edge into its tile. */
final class CategoryArtwork extends ImageView {
    private final Paint edge = new Paint(Paint.ANTI_ALIAS_FLAG);
    CategoryArtwork(Context context) { super(context); edge.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN)); }
    @Override protected void onSizeChanged(int w,int h,int oldw,int oldh) {
        super.onSizeChanged(w,h,oldw,oldh);
        if(w>0)edge.setShader(new LinearGradient(0,0,w,0,new int[]{Color.TRANSPARENT,Color.WHITE,Color.WHITE},new float[]{0,.22f,1},Shader.TileMode.CLAMP));
    }
    @Override protected void onDraw(Canvas canvas) {
        int layer=canvas.saveLayer(0,0,getWidth(),getHeight(),null);
        super.onDraw(canvas);
        canvas.drawRect(0,0,getWidth(),getHeight(),edge);
        canvas.restoreToCount(layer);
    }
}
