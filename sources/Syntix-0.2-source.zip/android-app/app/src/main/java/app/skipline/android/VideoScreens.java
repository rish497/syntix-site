package app.skipline.android;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.text.InputType;
import android.widget.*;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.textfield.TextInputLayout;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.snackbar.Snackbar;
import java.util.ArrayList;

@androidx.media3.common.util.UnstableApi
final class VideoScreens {
    static void home(MainActivity a,LinearLayout content){
        ArrayList<Track> tracks=ImportedVideos.read(a.app.prefs("imported_videos"));if(tracks.isEmpty())return;
        a.gap(content,23);LinearLayout title=a.row();
        title.addView(a.text("Imported videos",21,MainActivity.INK,true),new LinearLayout.LayoutParams(0,-2,1));
        title.addView(a.icon(R.drawable.ic_arrow,"View all imported videos",()->a.go("imported")),a.lp(48,48));content.addView(title,a.lp(-1,48));
        NativeScreens.trackRail(a,content,tracks);
    }
    static void render(MainActivity a,LinearLayout content){
        LinearLayout top=a.row();top.addView(a.icon(R.drawable.ic_back,"Back to Home",()->a.tab("home")),a.lp(48,48));
        top.addView(a.text("Imported videos",25,MainActivity.INK,true),new LinearLayout.LayoutParams(0,-2,1));
        top.addView(a.icon(R.drawable.ic_plus,"Import YouTube video",()->importSheet(a)),a.lp(48,48));content.addView(top);a.gap(content,16);
        ArrayList<Track> tracks=ImportedVideos.read(a.app.prefs("imported_videos"));
        if(tracks.isEmpty())content.addView(a.text("Import a YouTube video from Create to keep it here.",15,MainActivity.MUTED,false));
        for(int i=0;i<Math.min(a.visibleTracks,tracks.size());i++)NativeScreens.track(a,content,tracks.get(i),null);
        if(tracks.size()>a.visibleTracks)content.addView(a.button("Show more videos",R.drawable.ic_plus,false,()->{a.visibleTracks+=100;a.refresh();}),a.lp(-1,48));
    }
    static void importSheet(MainActivity a){
        LinearLayout body=a.column();a.handle(body);body.addView(a.text("Import YouTube video",26,MainActivity.INK,true));a.gap(body,10);
        body.addView(a.text("Keep a video in your Imported videos collection.",14,MainActivity.MUTED,false));a.gap(body,20);
        TextInputLayout field=new TextInputLayout(a);field.setHint("YouTube video link");field.setBoxBackgroundMode(TextInputLayout.BOX_BACKGROUND_OUTLINE);
        TextInputEditText input=new TextInputEditText(a);input.setTextSize(16);input.setTextColor(MainActivity.INK);input.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_URI);field.addView(input);body.addView(field);a.gap(body,12);
        body.addView(a.button("Paste from clipboard",R.drawable.ic_link,false,()->{ClipboardManager c=(ClipboardManager)a.getSystemService(android.content.Context.CLIPBOARD_SERVICE);ClipData clip=c.getPrimaryClip();if(clip!=null)input.setText(clip.getItemAt(0).coerceToText(a));}),a.lp(-1,48));a.gap(body,16);
        BottomSheetDialog[] dialog=new BottomSheetDialog[1];body.addView(a.button("Import video",R.drawable.ic_video,true,()->{
            try{String link=Links.singleVideo(input.getText().toString());if(a.app.busy){field.setError("Wait for the current import to finish.");return;}dialog[0].dismiss();load(a,link);}
            catch(Exception e){field.setError(e.getMessage());}
        }),a.lp(-1,52));dialog[0]=a.sheet(body);
    }
    private static void load(MainActivity a,String link){
        final String profile=a.app.profiles.active;final android.content.SharedPreferences prefs=a.app.prefs("imported_videos");
        a.retryAction=()->load(a,link);a.app.busy=true;a.app.error="";a.app.status="Importing video…";a.app.changed();
        a.app.worker.execute(()->{try{ArrayList<Track> tracks=Extractor.inspect(a,link);if(tracks.isEmpty())throw new IllegalArgumentException("No playable video found.");
            a.app.main.post(()->{a.app.busy=false;a.app.status="";if(!profile.equals(a.app.profiles.active))return;
                boolean added=ImportedVideos.add(prefs,tracks.get(0));a.app.changed();if(!a.isDestroyed())Snackbar.make(a.root,added?"Video added to Imported videos":"Video already imported",Snackbar.LENGTH_LONG).show();
            });
        }catch(Exception e){a.app.fail(Extractor.error(e));}});
    }
}
