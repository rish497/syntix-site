package app.skipline.android;

import android.view.*;
import android.widget.*;
import java.util.*;
import org.json.*;
import com.google.android.material.snackbar.Snackbar;

/** Saved import metadata stays separate from playable YouTube tracks. */
@androidx.media3.common.util.UnstableApi
final class SpotifyProgress {
    static void attach(SkiplineApp app,SpotifyImport.Job job,SpotifyPlaylist.Data data){
        job.data=data;for(SpotifyPlaylist.Song song:data.songs)job.rows.add(new SpotifyImport.Row(song));
        job.target=new SavedPlaylist(data.name);job.openTarget=true;app.library.add(job.target);persist(app,job);
    }
    static JSONObject snapshot(SpotifyImport.Job job)throws Exception{
        JSONArray rows=new JSONArray();for(SpotifyImport.Row row:job.rows){JSONObject item=new JSONObject().put("title",row.song.title).put("artist",row.song.artist).put("duration",row.song.durationMs).put("uri",row.song.uri).put("album",row.song.album).put("explicit",row.song.explicit).put("attempted",row.attempted).put("skipped",row.skipped);if(row.match!=null)item.put("match",row.match.json());rows.put(item);}
        return new JSONObject().put("source",job.data.source).put("total",job.data.total).put("excluded",job.data.skipped).put("rows",rows);
    }
    static SpotifyImport.Job restore(SavedPlaylist saved,String profile){
        if(saved.spotifyDraft==null)return null;
        try{JSONObject json=saved.spotifyDraft;JSONArray rows=json.getJSONArray("rows");if(rows.length()==0||rows.length()>SpotifyPlaylist.MAX_SONGS)return null;SpotifyImport.Job job=new SpotifyImport.Job(profile);job.target=saved;job.data=new SpotifyPlaylist.Data();job.data.name=saved.name;job.data.source=json.optString("source");if(!job.data.source.isEmpty())job.data.source=SpotifyPlaylist.link(job.data.source);job.data.total=json.optInt("total",-1);job.data.skipped=json.optInt("excluded");
            for(int i=0;i<rows.length();i++){JSONObject item=rows.getJSONObject(i);String title=item.getString("title"),artist=item.getString("artist");if(title.length()>1000||artist.length()>1000)return null;SpotifyPlaylist.Song song=new SpotifyPlaylist.Song(title,artist,item.optLong("duration"),item.optString("uri"),item.optString("album"),item.has("explicit")&&!item.isNull("explicit")?item.optBoolean("explicit"):null);SpotifyImport.Row row=new SpotifyImport.Row(song);row.attempted=item.optBoolean("attempted");row.skipped=item.optBoolean("skipped");JSONObject match=item.optJSONObject("match");if(match!=null){String source=match.optString("source");for(Track track:saved.tracks)if(track.source.equals(source)&&SpotifyMatching.confident(song,track)){row.match=track;break;}if(row.match==null&&!row.skipped)row.attempted=false;}job.rows.add(row);job.data.songs.add(song);}
            return job;
        }catch(Exception corrupt){return null;}
    }
    static void persist(SkiplineApp app,SpotifyImport.Job job){
        if(job.target==null||job.data==null||!job.profile.equals(app.profiles.active)||!app.library.contains(job.target))return;
        ArrayList<Track> previous=new ArrayList<>(job.target.tracks);HashSet<String> owned=new HashSet<>(),used=new HashSet<>();ArrayList<Track> next=new ArrayList<>();
        for(SpotifyImport.Row row:job.rows)if(row.match!=null){owned.add(row.match.source);if(!row.skipped&&used.add(row.match.source)){Track existing=null;for(Track old:previous)if(old.source.equals(row.match.source)){existing=old;break;}next.add(existing==null?row.match.copy():existing);}}
        for(Track old:previous)if(!owned.contains(old.source)&&used.add(old.source))next.add(old);
        job.target.tracks.clear();job.target.tracks.addAll(next);
        try{job.target.spotifyDraft=snapshot(job);}catch(Exception failed){job.error="Import progress could not be saved. Try again.";}
        boolean previousUpdate=app.importUpdate;app.importUpdate=!job.openTarget;try{
        if(app.prefs("session").getString("playing_playlist","").equals(job.target.id)){
            if(PlaylistQueue.mergeReady(app.queue,next)&&app.playback!=null)app.playback.sync(false);
        }
        if(job.wanted!=null&&job.wanted.match!=null&&app.playback!=null&&!job.cancelled&&(app.uiActive||app.playback.player.getPlayWhenReady())){
            String source=job.wanted.match.source;job.wanted=null;app.setPlayingPlaylist(job.target);PlaylistQueue.replace(app.queue,next);int index=-1;for(int i=0;i<app.queue.size();i++)if(app.queue.get(i).source.equals(source)){index=i;break;}if(index>=0){app.playback.sync(false,app.queue.get(index).id);app.playback.play(index);}
        }
        app.saveLibrary();
        }finally{app.importUpdate=previousUpdate;}
        if(!job.firstWarmSent&&!next.isEmpty()&&!app.playbackBuffering){job.firstWarmSent=true;app.warmStream(next.get(0));}
    }
    static int total(SavedPlaylist saved){JSONArray rows=saved.spotifyDraft==null?null:saved.spotifyDraft.optJSONArray("rows");if(rows==null)return saved.tracks.size();int total=0;for(int i=0;i<rows.length();i++)if(rows.optJSONObject(i)!=null&&!rows.optJSONObject(i).optBoolean("skipped"))total++;return Math.max(saved.tracks.size(),total);}
    static String duration(SavedPlaylist saved){if(saved.spotifyDraft==null)return PlaylistDurations.total(saved.tracks);JSONArray rows=saved.spotifyDraft.optJSONArray("rows");long seconds=0;boolean unknown=false;for(int i=0;rows!=null&&i<rows.length();i++){JSONObject row=rows.optJSONObject(i);if(row==null||row.optBoolean("skipped"))continue;long ms=row.optLong("duration");if(ms>0)seconds+=ms/1000;else unknown=true;}if(seconds==0)return "Duration unavailable";long min=seconds/60;String value=min>=60?min/60+" hr "+min%60+" min":Math.max(1,min)+" min";return unknown?value+" +":value;}
    static SpotifyImport.Job forPlaylist(MainActivity a,SavedPlaylist saved){SpotifyImport.Job job=a.app.spotifyImport;if(job!=null&&job.target==saved)return job;return restore(saved,a.app.profiles.active);}
    static final class Binding {
        final SavedPlaylist saved;final java.util.IdentityHashMap<SpotifyImport.Row,RowView> rows=new java.util.IdentityHashMap<>();
        TextView status;com.google.android.material.button.MaterialButton toggle;ImageView cover;String coverUrl="";Boolean running;
        Binding(SavedPlaylist value){saved=value;}
    }
    static final class RowView {LinearLayout holder;TextView artist;String source="";}
    private static Track ready(SavedPlaylist saved,SpotifyImport.Row row){if(row.match!=null)for(Track track:saved.tracks)if(track.source.equals(row.match.source))return track;return null;}
    private static void fillRow(MainActivity a,RowView view,SavedPlaylist saved,SpotifyImport.Job job,SpotifyImport.Row row){
        Track ready=ready(saved,row);String source=ready==null?"":ready.source;
        if(view.holder.getChildCount()>0&&view.source.equals(source)){if(view.artist!=null)view.artist.setText(job.wanted==row?"Finding selected song…":row.song.artist);return;}
        view.source=source;view.artist=null;view.holder.removeAllViews();
        if(ready!=null){NativeScreens.track(a,view.holder,ready,saved);return;}
        LinearLayout line=a.row();ImageView icon=new ImageView(a);icon.setImageResource(R.drawable.ic_headphones);icon.setColorFilter(MainActivity.MUTED);line.addView(icon,a.lp(44,44));LinearLayout text=a.column();text.setPadding(a.dp(11),0,0,0);TextView title=a.text(row.song.title,14,MainActivity.INK,true);title.setSingleLine(true);title.setEllipsize(android.text.TextUtils.TruncateAt.END);text.addView(title);view.artist=a.text(job.wanted==row?"Finding selected song…":row.song.artist,12,MainActivity.MUTED,false);view.artist.setSingleLine(true);view.artist.setEllipsize(android.text.TextUtils.TruncateAt.END);text.addView(view.artist);line.addView(text,new LinearLayout.LayoutParams(0,-2,1));line.addView(a.icon(R.drawable.ic_play,"Find and play "+row.song.title,()->request(a,saved,row)),a.lp(48,48));line.setOnClickListener(v->request(a,saved,row));line.setFocusable(true);line.setContentDescription("Find and play "+row.song.title);view.holder.addView(line,a.lp(-1,58));
    }
    static void updateInline(MainActivity a){
        Binding binding=a.spotifyBinding;if(binding==null||a.selectedPlaylist!=binding.saved)return;SpotifyImport.Job job=forPlaylist(a,binding.saved);if(job==null)return;
        binding.status.setText(job.running?"Finding songs · "+job.matched()+" of "+job.rows.size():job.error.isEmpty()?"Import paused":job.error);
        if(binding.running==null||binding.running!=job.running){binding.running=job.running;binding.toggle.setIconResource(job.running?R.drawable.ic_pause:R.drawable.ic_arrow);String label=job.running?"Pause import":"Continue import";binding.toggle.setContentDescription(label);binding.toggle.setTooltipText(label);}
        for(java.util.Map.Entry<SpotifyImport.Row,RowView> entry:binding.rows.entrySet())fillRow(a,entry.getValue(),binding.saved,job,entry.getKey());
        if(binding.cover!=null&&!binding.saved.tracks.isEmpty()){String url=binding.saved.tracks.get(0).thumbnail;if(!url.equals(binding.coverUrl)){binding.coverUrl=url;Images.load(binding.cover,url);}}
    }
    static void controls(MainActivity a,LinearLayout content,SavedPlaylist saved){
        if(saved.spotifyDraft==null)return;SpotifyImport.Job job=forPlaylist(a,saved);if(job==null)return;
        Binding binding=new Binding(saved);a.spotifyBinding=binding;LinearLayout bar=a.row();binding.status=a.text("",12,MainActivity.MUTED,false);bar.addView(binding.status,new LinearLayout.LayoutParams(0,-2,1));
        binding.toggle=a.icon(R.drawable.ic_pause,"Pause import",()->{if(job.running){job.cancel();a.refresh();}else SpotifyImport.restorePlaylist(a,saved,true);});bar.addView(binding.toggle,a.lp(48,48));content.addView(bar,a.lp(-1,-2));updateInline(a);
        if(!job.data.complete())content.addView(a.text(job.data.total<0?"Spotify's full playlist size is unverified.":"Spotify provided "+job.rows.size()+" of "+job.data.total+" songs.",12,MainActivity.MUTED,false));
    }
    static boolean rows(MainActivity a,LinearLayout content,SavedPlaylist saved){
        if(saved.spotifyDraft==null)return false;SpotifyImport.Job job=forPlaylist(a,saved);if(job==null)return false;HashSet<String> shown=new HashSet<>();int count=0;
        for(SpotifyImport.Row row:job.rows){if(row.skipped)continue;if(++count>a.visibleTracks)break;Track track=ready(saved,row);if(track!=null)shown.add(track.source);RowView view=new RowView();view.holder=a.column();fillRow(a,view,saved,job,row);content.addView(view.holder,a.lp(-1,58));if(a.spotifyBinding!=null)a.spotifyBinding.rows.put(row,view);}
        for(Track extra:saved.tracks)if(!shown.contains(extra.source)&&!belongs(job,extra.source)&&count++<a.visibleTracks)NativeScreens.track(a,content,extra,saved);
        if(total(saved)>a.visibleTracks)content.addView(a.button("Show more songs",R.drawable.ic_plus,false,()->{a.visibleTracks+=100;a.refresh();}),a.lp(-1,48));return true;
    }
    private static boolean belongs(SpotifyImport.Job job,String source){for(SpotifyImport.Row row:job.rows)if(row.match!=null&&row.match.source.equals(source))return true;return false;}
    static void request(MainActivity a,SavedPlaylist saved,SpotifyImport.Row row){
        if(!SpotifyImport.restorePlaylist(a,saved,false)){Snackbar.make(a.root,"Wait for your current import to finish",Snackbar.LENGTH_SHORT).show();return;}SpotifyImport.Job job=a.app.spotifyImport;
        SpotifyImport.Row wanted=null;for(SpotifyImport.Row candidate:job.rows)if(candidate.song.uri.equals(row.song.uri)&&candidate.song.title.equals(row.song.title)&&candidate.song.artist.equals(row.song.artist)){wanted=candidate;break;}if(wanted==null)return;
        a.requestNotifications();SpotifyImport.prioritize(job,wanted);if(!job.running)SpotifyImport.match(a.app,job);else if(job.cancelled)job.restartWhenStopped=true;else if(job.current!=null&&job.current!=wanted){job.client.dispatcher().cancelAll();Extractor.cancelProcesses(job.processes);}if(wanted.match!=null)persist(a.app,job);a.refresh();
    }
    static boolean startPlaylist(MainActivity a,SavedPlaylist saved,boolean shuffle){if(saved.spotifyDraft==null)return false;SpotifyImport.Job job=forPlaylist(a,saved);if(job==null||job.rows.isEmpty())return false;ArrayList<SpotifyImport.Row> available=new ArrayList<>();for(SpotifyImport.Row row:job.rows)if(!row.skipped)available.add(row);if(available.isEmpty())return false;if(a.app.playback!=null)a.app.playback.player.setShuffleModeEnabled(shuffle);else a.app.prefs("session").edit().putBoolean("shuffle",shuffle).apply();request(a,saved,available.get(shuffle?new Random().nextInt(available.size()):0));return true;}
    static void membership(SkiplineApp app,SavedPlaylist saved,Track track,boolean removed){
        if(saved.spotifyDraft==null)return;SpotifyImport.Job job=app.spotifyImport;if(job==null||job.target!=saved)job=restore(saved,app.profiles.active);if(job==null)return;for(SpotifyImport.Row row:job.rows)if(row.match!=null&&row.match.source.equals(track.source)){row.skipped=removed;row.attempted=true;}try{saved.spotifyDraft=snapshot(job);}catch(Exception ignored){}
    }
}
