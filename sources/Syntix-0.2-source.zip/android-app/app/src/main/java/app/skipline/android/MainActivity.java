package app.skipline.android;
import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.content.res.ResourcesCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.Player;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputLayout;
import com.google.android.material.textfield.TextInputEditText;
import com.yausername.youtubedl_android.YoutubeDL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Locale;
@androidx.media3.common.util.UnstableApi
public final class MainActivity extends AppCompatActivity {
    static final int PAGE=0xff171d21,SURFACE=0xff242b30,RAISED=0xff30383e,INK=0xfff7f7f5,MUTED=0xffbcc4c8,ACCENT=0xffe1cdae,ON_ACCENT=0xff252a2f;
    SkiplineApp app;
    LinearLayout root,content,mini;
    TextView miniTitle,miniTime;
    ImageView miniArt;
    MaterialButton playButton;
    QueueAdapter adapter;
    ItemTouchHelper drag;
    Typeface face,boldFace;
    String lastSource="",pendingPlay="",downloadSource="",downloadKind="",photoProfile="",backupProfile="";
    boolean welcome;
    int sleepDraftMinutes=30,sleepDraftMode=0,sleepClockHour=java.time.LocalTime.now().plusHours(1).getHour(),sleepClockMinute=0;
    int onboardingStage=0,onboardingSlide=0;
    String onboardingName="";
    boolean onboardingAccepted;
    String page="home";
    String mainTab="home";
    int visibleTracks=100;
    boolean libraryAZ,libraryGrid;
    androidx.drawerlayout.widget.DrawerLayout drawerHost;
    android.widget.FrameLayout drawerPanel,libraryOptionsPanel;
    View navBarView;
    boolean imeVisible,searchSubmitted;
    final java.util.ArrayDeque<String> screenHistory=new java.util.ArrayDeque<>();
    final java.util.ArrayList<BottomSheetDialog> activeSheets=new java.util.ArrayList<>();
    MaterialButton miniFavorite;
    void go(String destination){screenHistory.push(page);page=destination;selectedPlaylist=null;visibleTracks=100;refresh();}
    void tab(String destination){if(destination.equals("create")){NativeScreens.createSheet(this);return;}screenHistory.clear();page=destination;mainTab=destination;selectedPlaylist=null;visibleTracks=100;refresh();}

    SavedPlaylist selectedPlaylist;
    ScrollView bodyScroll;
    String renderedScreen="";
    boolean homePlaylists=false;
    BottomSheetDialog sessionDialog;
    Runnable retryAction;
    com.google.common.util.concurrent.ListenableFuture<androidx.media3.session.MediaController> controllerFuture;
    androidx.media3.session.MediaController controller;
    boolean screenStarted;
    final Runnable reconnectController=this::connectPlayback;
    void connectPlayback(){
        if(!screenStarted||controllerFuture!=null)return;
        androidx.media3.session.SessionToken token=new androidx.media3.session.SessionToken(this,new android.content.ComponentName(this,PlaybackService.class));
        controllerFuture=new androidx.media3.session.MediaController.Builder(this,token).setListener(new androidx.media3.session.MediaController.Listener(){@Override public void onDisconnected(androidx.media3.session.MediaController disconnected){controller=null;final com.google.common.util.concurrent.ListenableFuture<androidx.media3.session.MediaController> old=controllerFuture;controllerFuture=null;if(old!=null)androidx.media3.session.MediaController.releaseFuture(old);if(screenStarted)handler.postDelayed(reconnectController,1000);}}).buildAsync();
        final com.google.common.util.concurrent.ListenableFuture<androidx.media3.session.MediaController> connecting=controllerFuture;
        connecting.addListener(()->{if(!screenStarted||controllerFuture!=connecting)return;try{controller=connecting.get();if(app.error.startsWith("Could not connect to playback."))app.error="";refresh();}catch(Exception e){androidx.media3.session.MediaController.releaseFuture(connecting);controllerFuture=null;app.error="Could not connect to playback. Reconnecting…";refresh();handler.postDelayed(reconnectController,1500);}},ContextCompat.getMainExecutor(this));
    }
    final Handler handler=new Handler(Looper.getMainLooper());
    SpotifyProgress.Binding spotifyBinding;
    final Runnable refresh=this::refresh;
    final java.util.ArrayList<Runnable> playlistPlaybackUpdates=new java.util.ArrayList<>();
    final Runnable playerRefresh=()->{updateMini();if(sessionDialog!=null&&sessionDialog.isShowing()&&adapter!=null)adapter.notifyDataSetChanged();};
    private String displayedDay=java.time.LocalDate.now().toString();private long nextDayCheck;
    final Runnable ticker=new Runnable(){public void run(){updateMini();ListeningFeatures.updateTick(MainActivity.this);long now=System.currentTimeMillis();if(now>=nextDayCheck){nextDayCheck=now+60000;String day=java.time.LocalDate.now().toString();if(!day.equals(displayedDay)){displayedDay=day;if(page.equals("search")&&app.searchQuery.isEmpty())refresh();}}handler.postDelayed(this,750);}};
    @Override public void onCreate(Bundle state){
        super.onCreate(state);app=(SkiplineApp)getApplication();
        if(state!=null){sleepDraftMinutes=state.getInt("sleepDraftMinutes",30);sleepDraftMode=state.getInt("sleepDraftMode",state.getBoolean("sleepDraftEnd",false)?2:0);sleepClockHour=state.getInt("sleepClockHour",sleepClockHour);sleepClockMinute=state.getInt("sleepClockMinute",0);onboardingStage=state.getInt("onboardingStage",0);onboardingSlide=state.getInt("onboardingSlide",0);onboardingName=state.getString("onboardingName","");onboardingAccepted=state.getBoolean("onboardingAccepted",false);mainTab=state.getString("mainTab","home");searchSubmitted=state.getBoolean("searchSubmitted",false);visibleTracks=state.getInt("visibleTracks",100);photoProfile=state.getString("photoProfile","");backupProfile=state.getString("backupProfile","");page=state.getString("page","home");String selectedId=state.getString("playlist","");for(SavedPlaylist saved:app.library)if(saved.id.equals(selectedId))selectedPlaylist=saved;if(state.getBoolean("favoritesSelected"))selectedPlaylist=app.favorites;downloadSource=state.getString("downloadSource","");downloadKind=state.getString("downloadKind","");lastSource=state.getString("lastSource","");}
        if(page.equals("settings")||page.equals("replay")){page="home";mainTab="home";}else if(page.equals("quality")){page="downloads";mainTab="downloads";}
        face=ResourcesCompat.getFont(this,R.font.outfit);
        boldFace=ResourcesCompat.getFont(this,R.font.outfit_semibold);
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(PAGE);drawerHost=new androidx.drawerlayout.widget.DrawerLayout(this);drawerHost.addView(root,new androidx.drawerlayout.widget.DrawerLayout.LayoutParams(-1,-1));drawerPanel=new FrameLayout(this);androidx.drawerlayout.widget.DrawerLayout.LayoutParams drawerParams=new androidx.drawerlayout.widget.DrawerLayout.LayoutParams((int)(getResources().getDisplayMetrics().widthPixels*.85),-1);drawerParams.gravity=androidx.core.view.GravityCompat.START;drawerHost.addView(drawerPanel,drawerParams);libraryOptionsPanel=new FrameLayout(this);androidx.drawerlayout.widget.DrawerLayout.LayoutParams viewParams=new androidx.drawerlayout.widget.DrawerLayout.LayoutParams(Math.min(dp(294),(int)(getResources().getDisplayMetrics().widthPixels*.83)),-1);viewParams.gravity=androidx.core.view.GravityCompat.END;drawerHost.addView(libraryOptionsPanel,viewParams);drawerHost.setDrawerLockMode(androidx.drawerlayout.widget.DrawerLayout.LOCK_MODE_LOCKED_CLOSED,androidx.core.view.GravityCompat.END);drawerHost.setScrimColor(0x99000000);setContentView(drawerHost);
        ViewCompat.setOnApplyWindowInsetsListener(root,(v,insets)->{Insets bars=insets.getInsets(WindowInsetsCompat.Type.systemBars()|WindowInsetsCompat.Type.ime());v.setPadding(bars.left,bars.top,bars.right,bars.bottom);boolean was=imeVisible;imeVisible=insets.isVisible(WindowInsetsCompat.Type.ime());updateChrome();if(was&&!imeVisible&&page.equals("search"))root.post(this::refresh);return insets;});
        getWindow().setStatusBarColor(PAGE);getWindow().setNavigationBarColor(PAGE);getWindow().getDecorView().setSystemUiVisibility(0);
        getOnBackPressedDispatcher().addCallback(this,new androidx.activity.OnBackPressedCallback(true){@Override public void handleOnBackPressed(){if(welcome&&onboardingStage>0){onboardingStage--;refresh();}else if(welcome&&onboardingSlide>0){onboardingSlide--;refresh();}else if(drawerHost.isDrawerOpen(androidx.core.view.GravityCompat.END)){drawerHost.closeDrawers();}else if(drawerHost.isDrawerOpen(androidx.core.view.GravityCompat.START)){drawerHost.closeDrawers();}else if(selectedPlaylist!=null){selectedPlaylist=null;refresh();}else if(!screenHistory.isEmpty()){page=screenHistory.pop();refresh();}else if(!page.equals("home")){page="home";mainTab="home";refresh();}else{setEnabled(false);getOnBackPressedDispatcher().onBackPressed();}}});
        welcome=getPreferences(0).getInt("onboarding_version",0)<6;
        if(state==null&&!app.profiles.current().name.equals("Listener"))onboardingName=app.profiles.current().name;
        if(Intent.ACTION_SEND.equals(getIntent().getAction()))welcome=false;
        refresh();receive(getIntent());if(getIntent().getBooleanExtra("open_downloads",false)&&!welcome)root.post(()->OfflineScreens.manage(this));
    }
    @Override protected void onStart(){super.onStart();app.uiActive=true;app.taskDismissed=false;app.backgroundIdle=false;if(app.statistics!=null)app.statistics.resume();screenStarted=true;SpotifyImport.resumeForeground(app);connectPlayback();app.listeners.add(refresh);app.playerListeners.add(playerRefresh);handler.post(ticker);refresh();if(!welcome)app.preparePlayback();}
    @Override protected void onStop(){super.onStop();app.uiActive=false;screenStarted=false;if((app.playback==null||!app.playback.player.getPlayWhenReady())&&pendingPlay.isEmpty()&&!app.offlineRunning&&!app.manualDownloadRunning)app.pauseIdleWork();for(BottomSheetDialog dialog:new java.util.ArrayList<>(activeSheets))dialog.dismiss();activeSheets.clear();handler.removeCallbacks(reconnectController);if(controllerFuture!=null){androidx.media3.session.MediaController.releaseFuture(controllerFuture);controllerFuture=null;}controller=null;app.listeners.remove(refresh);app.playerListeners.remove(playerRefresh);handler.removeCallbacks(ticker);}
    @Override protected void onNewIntent(Intent intent){super.onNewIntent(intent);setIntent(intent);welcome=false;refresh();receive(intent);if(intent.getBooleanExtra("open_downloads",false))root.post(()->OfflineScreens.manage(this));}
    @Override protected void onSaveInstanceState(Bundle state){state.putInt("sleepDraftMinutes",sleepDraftMinutes);state.putInt("sleepDraftMode",sleepDraftMode);state.putInt("sleepClockHour",sleepClockHour);state.putInt("sleepClockMinute",sleepClockMinute);state.putInt("onboardingStage",onboardingStage);state.putInt("onboardingSlide",onboardingSlide);state.putString("onboardingName",onboardingName);state.putBoolean("onboardingAccepted",onboardingAccepted);state.putString("mainTab",mainTab);state.putBoolean("searchSubmitted",searchSubmitted);state.putInt("visibleTracks",visibleTracks);state.putBoolean("favoritesSelected",selectedPlaylist==app.favorites);state.putString("photoProfile",photoProfile);state.putString("backupProfile",backupProfile);state.putString("page",page);state.putString("playlist",selectedPlaylist==null?"":selectedPlaylist.id);state.putString("downloadSource",downloadSource);state.putString("downloadKind",downloadKind);state.putString("lastSource",lastSource);super.onSaveInstanceState(state);}
    void receive(Intent intent){if(Intent.ACTION_SEND.equals(intent.getAction())){if(SpotifyPlaylist.looksLike(intent.getStringExtra(Intent.EXTRA_TEXT))){root.post(()->SpotifyImport.showLink(this,intent.getStringExtra(Intent.EXTRA_TEXT)));return;}try{lastSource=SpotifySong.musicLink(intent.getStringExtra(Intent.EXTRA_TEXT));final String source=lastSource;root.post(()->shareSheet(source));}catch(Exception e){app.error=e.getMessage();refresh();}}}
    int dp(float n){return Math.round(n*getResources().getDisplayMetrics().density);}
    LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w<0?w:dp(w),h<0?h:dp(h));}
    void gap(LinearLayout l,int height){l.addView(new View(this),lp(1,height));}
    GradientDrawable shape(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    void rounded(View v,int color,int radius){v.setBackground(shape(color,radius));v.setClipToOutline(true);}
    TextView text(String value,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(color);t.setTypeface(bold?boldFace:face);t.setLineSpacing(dp(2),1);if(size>=24)t.setLetterSpacing(-.025f);return t;}
    MaterialButton button(String label,int icon,boolean primary,Runnable action){
        MaterialButton b=new MaterialButton(this);b.setText(label);b.setTextSize(14);b.setLetterSpacing(0);b.setAllCaps(false);b.setTypeface(face,Typeface.BOLD);b.setCornerRadius(dp(26));b.setMinHeight(dp(52));b.setMinimumHeight(dp(52));b.setInsetTop(0);b.setInsetBottom(0);b.setTextColor(primary?ON_ACCENT:INK);b.setBackgroundTintList(ColorStateList.valueOf(primary?ACCENT:SURFACE));b.setRippleColor(ColorStateList.valueOf(primary?0x30252a2f:0x20e1cdae));b.setPadding(dp(16),0,dp(16),0);
        b.setTypeface(boldFace);b.setElevation(0);b.setStateListAnimator(null);
        if(icon!=0){b.setIconResource(icon);b.setIconTint(ColorStateList.valueOf(primary?ON_ACCENT:INK));b.setIconSize(dp(21));b.setIconPadding(dp(10));}
        b.setOnClickListener(v->action.run());return b;
    }
    MaterialButton icon(int resource,String description,Runnable action){MaterialButton b=button("",resource,false,action);b.setContentDescription(description);b.setTooltipText(description);b.setMinWidth(0);b.setMinimumWidth(0);b.setPadding(0,0,0,0);b.setIconGravity(MaterialButton.ICON_GRAVITY_TEXT_START);b.setIconPadding(0);b.setBackgroundTintList(ColorStateList.valueOf(Color.TRANSPARENT));b.setCornerRadius(dp(24));return b;}
    ImageView art(int width,int height,String url){ImageView image=new ImageView(this);image.setScaleType(ImageView.ScaleType.CENTER_CROP);rounded(image,SURFACE,12);image.setLayoutParams(lp(width,height));Images.load(image,url);return image;}
    void brand(LinearLayout parent){ImageView mark=new ImageView(this);mark.setImageResource(R.drawable.syntix_wordmark);mark.setScaleType(ImageView.ScaleType.CENTER_CROP);mark.setContentDescription("Syntix");parent.addView(mark,lp(175,48));}
    void refresh(){
        if(isFinishing()||isDestroyed())return;
        SpotifyImport.openCompleted(this);
        if(!pendingPlay.isEmpty()&&app.playback!=null){String id=pendingPlay;pendingPlay="";for(int i=0;i<app.queue.size();i++)if(app.queue.get(i).id.equals(id)){app.playback.sync(false,id);app.playback.play(i);break;}}
        if(imeVisible&&page.equals("search")&&bodyScroll!=null&&renderedScreen.startsWith("search:")){updateMini();return;}
        if(app.listeningUpdate&&!welcome&&(mini!=null)==!app.queue.isEmpty()&&selectedPlaylist!=null&&(page+":"+selectedPlaylist.id).equals(renderedScreen)&&app.error.isEmpty()){SpotifyProgress.updateInline(this);updateMini();PlaylistPlayback.update(this);return;}
        if(app.importUpdate&&app.error.isEmpty()){if((mini!=null)!=!app.queue.isEmpty()){NativeScreens.render(this);return;}SpotifyProgress.updateInline(this);updateMini();return;}
        NativeScreens.render(this);
    }
    void updateChrome(){boolean hide=imeVisible&&page.equals("search");if(mini!=null)mini.setVisibility(hide?View.GONE:View.VISIBLE);if(navBarView!=null)navBarView.setVisibility(hide?View.GONE:View.VISIBLE);}
    View navButton(String label,int image,String destination){LinearLayout item=column();item.setGravity(Gravity.CENTER);ImageView glyph=new ImageView(this);glyph.setImageResource(image);glyph.setColorFilter(page.equals(destination)?ACCENT:MUTED);item.addView(glyph,lp(22,22));gap(item,3);item.addView(text(label,11,page.equals(destination)?ACCENT:MUTED,page.equals(destination)));item.setContentDescription(label);item.setClickable(true);item.setFocusable(true);item.setBackgroundResource(android.R.drawable.list_selector_background);item.setOnClickListener(v->{page=destination;selectedPlaylist=null;refresh();});return item;}
    ScrollView scrollArea(LinearLayout parent,LinearLayout contents){ScrollView scroll=new ScrollView(this);bodyScroll=scroll;scroll.setVerticalScrollBarEnabled(false);scroll.setClipToPadding(false);scroll.setPadding(0,0,0,dp(12));scroll.addView(contents);parent.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));return scroll;}
    void buildLibrary(LinearLayout body){
        LinearLayout list=column();scrollArea(body,list);list.addView(text("Your library.",32,INK,true));gap(list,7);list.addView(text("Your favorites, and what comes next.",13,MUTED,false));gap(list,18);
        LinearLayout actions=row();actions.addView(button("Import playlist",R.drawable.ic_link,true,this::pasteSheet),new LinearLayout.LayoutParams(0,dp(48),1));actions.addView(icon(R.drawable.ic_external,"Open YouTube",this::openYoutube),lp(48,48));list.addView(actions);gap(list,20);
        LinearLayout heading=row();heading.addView(text("Saved playlists",18,INK,true),new LinearLayout.LayoutParams(0,-2,1));heading.addView(button("View all",0,false,()->{page="library";selectedPlaylist=null;refresh();}),lp(96,44));list.addView(heading);gap(list,12);
        if(app.library.isEmpty()){list.addView(text("Import a playlist, give it a name, and make it yours.",15,MUTED,false));gap(list,12);list.addView(button("Try a local playback sample",R.drawable.ic_play,false,this::sample),lp(-1,48));}
        else{android.widget.HorizontalScrollView rail=new android.widget.HorizontalScrollView(this);rail.setHorizontalScrollBarEnabled(false);LinearLayout cards=row();for(SavedPlaylist saved:app.library){LinearLayout card=column();card.setPadding(0,0,dp(14),0);card.addView(art(140,134,saved.tracks.isEmpty()?"":saved.tracks.get(0).thumbnail));gap(card,10);TextView title=text(saved.name,15,INK,true);title.setMaxLines(2);title.setEllipsize(TextUtils.TruncateAt.END);card.addView(title,lp(140,-2));gap(card,4);card.addView(text(saved.tracks.size()+" songs",12,MUTED,false));card.setContentDescription("Open playlist "+saved.name);card.setClickable(true);card.setFocusable(true);card.setOnClickListener(v->openPlaylist(saved));cards.addView(card,lp(154,-2));}rail.addView(cards);list.addView(rail,lp(-1,-2));}
        gap(list,26);list.addView(text("Recently played",18,INK,true));gap(list,10);ArrayList<Track> recent=app.history.recent();if(recent.isEmpty())list.addView(text("Your recent listening will appear here.",14,MUTED,false));else for(int i=0;i<Math.min(4,recent.size());i++)libraryTrack(list,recent.get(i),null);
        gap(list,24);LinearLayout recommendations=row();recommendations.addView(text("Made for your listening",18,INK,true),new LinearLayout.LayoutParams(0,-2,1));recommendations.addView(icon(R.drawable.ic_retry,"Refresh recommendations",app::refreshRecommendations),lp(44,44));list.addView(recommendations);gap(list,7);
        if(!app.prefs("history").getBoolean("recommendations_enabled",true))list.addView(text("Suggestions are off. Enable them in Settings → Listening history and suggestions.",14,MUTED,false));else if(app.discovering)list.addView(text("Finding music inspired by your listening…",13,MUTED,false));else if(!app.recommendationError.isEmpty())list.addView(text(app.recommendationError,13,MUTED,false));else if(app.recommendations.isEmpty())list.addView(text("Listen to a song to start discovering. Suggestions use its title and channel to search YouTube.",14,MUTED,false));else{list.addView(text(app.recommendationReason,12,MUTED,false));gap(list,8);for(int i=0;i<Math.min(6,app.recommendations.size());i++)libraryTrack(list,app.recommendations.get(i),null);}gap(list,20);
    }
    void buildQueue(LinearLayout body){
        LinearLayout list=column();scrollArea(body,list);list.addView(text("Your playlists.",32,INK,true));gap(list,7);list.addView(text("Open a playlist and listen right there.",13,MUTED,false));gap(list,18);
        LinearLayout actions=row();actions.addView(button("Import playlist",R.drawable.ic_link,true,this::pasteSheet),new LinearLayout.LayoutParams(0,dp(48),1));actions.addView(icon(R.drawable.ic_plus,"New playlist",()->namePlaylist("",name->{SavedPlaylist saved=new SavedPlaylist(name);app.library.add(saved);app.saveLibrary();selectedPlaylist=saved;refresh();})),lp(48,48));list.addView(actions);gap(list,20);
        if(app.library.isEmpty())list.addView(text("Your saved playlists will appear here. Import one or create a playlist to begin.",15,MUTED,false));
        for(SavedPlaylist saved:app.library){LinearLayout line=row();line.setPadding(0,dp(12),0,dp(12));line.addView(art(58,58,saved.tracks.isEmpty()?"":saved.tracks.get(0).thumbnail));LinearLayout labels=column();labels.setPadding(dp(13),0,dp(8),0);TextView title=text(saved.name,16,INK,true);title.setMaxLines(2);labels.addView(title);gap(labels,5);labels.addView(text(saved.tracks.size()+" songs · Saved playlist",12,MUTED,false));line.addView(labels,new LinearLayout.LayoutParams(0,-2,1));line.addView(icon(R.drawable.ic_arrow,"Open "+saved.name,()->openPlaylist(saved)),lp(44,48));line.setContentDescription("Open playlist "+saved.name);line.setClickable(true);line.setOnClickListener(v->openPlaylist(saved));list.addView(line);View divider=new View(this);divider.setBackgroundColor(0xff30383e);list.addView(divider,lp(-1,1));}
        gap(list,20);if(!app.queue.isEmpty())list.addView(button("Current listening order",R.drawable.ic_queue,false,this::sessionSheet),lp(-1,48));
    }
    void openPlaylist(SavedPlaylist saved){selectedPlaylist=saved;if(saved.spotifyDraft!=null)SpotifyImport.restorePlaylist(this,saved,true);refresh();app.warmVisibleTracks(saved.tracks);}
    void legacyBuildPlaylist(LinearLayout list,SavedPlaylist saved){
        MaterialButton back=button(page.equals("library")?"Your Library":"Home",R.drawable.ic_back,false,()->{selectedPlaylist=null;refresh();});list.addView(back,lp(116,44));gap(list,18);
        LinearLayout identity=row();if(!saved.tracks.isEmpty())identity.addView(art(72,72,saved.tracks.get(0).thumbnail));LinearLayout labels=column();labels.setPadding(saved.tracks.isEmpty()?0:dp(14),0,0,0);TextView title=text(saved.name,26,INK,true);title.setMaxLines(2);title.setEllipsize(TextUtils.TruncateAt.END);labels.addView(title);gap(labels,6);labels.addView(text(saved.tracks.size()+" songs · Saved on this phone",12,MUTED,false));identity.addView(labels,new LinearLayout.LayoutParams(0,-2,1));list.addView(identity);gap(list,18);
        LinearLayout actions=row();actions.addView(button("Play",R.drawable.ic_play,true,()->playPlaylist(saved,false)),new LinearLayout.LayoutParams(0,dp(48),1));LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(0,dp(48),1);sp.leftMargin=dp(10);actions.addView(button("Shuffle",R.drawable.ic_shuffle,false,()->playPlaylist(saved,true)),sp);list.addView(actions);gap(list,10);
        LinearLayout edits=row();edits.addView(button("Add a link",R.drawable.ic_plus,false,()->pasteForPlaylist(saved)),new LinearLayout.LayoutParams(0,dp(48),1));edits.addView(icon(R.drawable.ic_more,"Playlist options",()->playlistOptions(saved)),lp(48,48));list.addView(edits);gap(list,18);
        if(saved.tracks.isEmpty())list.addView(text("Your next favorite belongs here. Add a link or save a song from your queue.",15,MUTED,false));
        for(Track track:saved.tracks)libraryTrack(list,track,saved);
    }
    void legacyLibraryTrack(LinearLayout list,Track track,SavedPlaylist owner){LinearLayout line=row();line.setPadding(0,dp(8),0,dp(8));line.addView(art(44,44,track.thumbnail));LinearLayout labels=column();labels.setPadding(dp(12),0,dp(6),0);TextView title=text(track.title,14,INK,true);title.setMaxLines(2);title.setEllipsize(TextUtils.TruncateAt.END);labels.addView(title);gap(labels,4);labels.addView(text(track.creator,12,MUTED,false));line.addView(labels,new LinearLayout.LayoutParams(0,-2,1));labels.setOnClickListener(v->{if(owner==null)playTrack(track);else playPlaylistAt(owner,owner.tracks.indexOf(track));});line.addView(icon(R.drawable.ic_plus,"Add "+track.title+" to playlist",()->choosePlaylist(java.util.Collections.singletonList(track),null)),lp(44,48));if(owner!=null)line.addView(icon(R.drawable.ic_more,"Options for "+track.title,()->trackOptions(track,owner)),lp(44,48));list.addView(line);}
    void libraryTrack(LinearLayout list,Track track,SavedPlaylist owner){NativeScreens.track(this,list,track,owner);}
    void buildSession(LinearLayout body){
        body.addView(text("Up next.",32,INK,true));gap(body,7);body.addView(text("Your listening session. In your order.",13,MUTED,false));gap(body,18);
        if(app.queue.isEmpty()){LinearLayout empty=column();scrollArea(body,empty);gap(empty,24);empty.addView(text("A little quiet for now.",24,INK,true));gap(empty,10);empty.addView(text("Play a saved playlist, or bring a link from YouTube or Spotify.",15,MUTED,false));gap(empty,24);empty.addView(button("Add a music link",R.drawable.ic_link,true,this::pasteSheet),lp(-1,52));gap(empty,10);empty.addView(button("Try a local playback sample",R.drawable.ic_play,false,this::sample),lp(-1,52));return;}
        LinearLayout controls=row();controls.addView(button("Shuffle",R.drawable.ic_shuffle,true,this::shuffleQueue),new LinearLayout.LayoutParams(0,dp(46),1));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(46),1);p.leftMargin=dp(10);controls.addView(button("Save playlist",0,false,()->saveQueue()),p);body.addView(controls);gap(body,12);
        RecyclerView list=new RecyclerView(this);list.setLayoutManager(new LinearLayoutManager(this));adapter=new QueueAdapter();list.setAdapter(adapter);body.addView(list,new LinearLayout.LayoutParams(-1,0,1));
        drag=new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(ItemTouchHelper.UP|ItemTouchHelper.DOWN,0){
            @Override public boolean onMove(RecyclerView r,RecyclerView.ViewHolder from,RecyclerView.ViewHolder to){int a=from.getBindingAdapterPosition(),b=to.getBindingAdapterPosition();if(a<0||b<0)return false;Collections.swap(app.queue,a,b);adapter.notifyItemMoved(a,b);return true;}
            @Override public void onSwiped(RecyclerView.ViewHolder holder,int direction){}
            @Override public void clearView(RecyclerView r,RecyclerView.ViewHolder holder){super.clearView(r,holder);if(app.playback!=null)app.playback.sync(false);app.changed();}
        });drag.attachToRecyclerView(list);
        LinearLayout actions=row();actions.addView(button("Add a link",R.drawable.ic_plus,false,this::pasteSheet),new LinearLayout.LayoutParams(0,dp(44),1));actions.addView(button("Clear",0,false,this::clearQueue),lp(92,44));body.addView(actions);
    }
    void welcome(){Onboarding.render(this);}
    void finishOnboarding(boolean importing){getPreferences(0).edit().putBoolean("introduced",true).putInt("onboarding_version",6).apply();welcome=false;requestNotifications();tab(importing?"create":"home");if(importing)pasteSheet();}
    void how(){new MaterialAlertDialogBuilder(this).setTitle("From YouTube to your playlist").setMessage("1. Open a video or playlist in YouTube and share it to Syntix.\n\n2. Give an imported playlist a name, or add a video to an existing playlist.\n\n3. Open the playlist in Library or Queue and press Play. You stay on that playlist.\n\nPlaylist playback stays on its screen. Stream links are reused to reduce waiting. Lock your phone and use Android media controls. Source access and download speed can vary.").setPositiveButton("Got it",null).show();}

    void requestNotifications(){if(Build.VERSION.SDK_INT>=33&&ContextCompat.checkSelfPermission(this,Manifest.permission.POST_NOTIFICATIONS)!=android.content.pm.PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},10);}
    BottomSheetDialog sheet(LinearLayout content){BottomSheetDialog dialog=new BottomSheetDialog(this);content.setPadding(dp(24),dp(16),dp(24),dp(24));rounded(content,SURFACE,24);ScrollView scroll=new ScrollView(this);scroll.setVerticalScrollBarEnabled(false);scroll.addView(content);dialog.setContentView(scroll);dialog.setOnDismissListener(d->activeSheets.remove(dialog));dialog.setOnShowListener(d->{View parent=(View)scroll.getParent();parent.setBackgroundColor(Color.TRANSPARENT);dialog.getBehavior().setSkipCollapsed(true);dialog.getBehavior().setState(com.google.android.material.bottomsheet.BottomSheetBehavior.STATE_EXPANDED);});scroll.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener(){public void onViewAttachedToWindow(View view){}public void onViewDetachedFromWindow(View view){activeSheets.remove(dialog);}});dialog.show();activeSheets.add(dialog);return dialog;}
    void handle(LinearLayout l){View handle=new View(this);rounded(handle,0xff657078,4);LinearLayout.LayoutParams p=lp(36,4);p.gravity=Gravity.CENTER_HORIZONTAL;p.bottomMargin=dp(22);l.addView(handle,p);}
    void shareSheet(String source){
        LinearLayout l=column();handle(l);brand(l);gap(l,20);l.addView(text("Keep listening.",30,INK,true));gap(l,10);l.addView(text("Play music from YouTube or Spotify links with your screen off.",16,MUTED,false));gap(l,22);LinearLayout preview=row();ImageView linkIcon=new ImageView(this);linkIcon.setImageResource(R.drawable.ic_link);linkIcon.setColorFilter(ACCENT);linkIcon.setPadding(dp(18),dp(18),dp(18),dp(18));rounded(linkIcon,RAISED,12);preview.addView(linkIcon,lp(64,64));TextView link=text(source,13,MUTED,false);link.setMaxLines(2);link.setEllipsize(TextUtils.TruncateAt.END);link.setPadding(dp(14),0,0,0);preview.addView(link,new LinearLayout.LayoutParams(0,-2,1));l.addView(preview);gap(l,24);
        final BottomSheetDialog[] ref=new BottomSheetDialog[1];l.addView(button("Listen now",R.drawable.ic_headphones,true,()->{ref[0].dismiss();requestNotifications();importLink(source,true);}),lp(-1,52));gap(l,10);
        l.addView(button(Links.isPlaylist(source)?"Save playlist":"Add to playlist",R.drawable.ic_library,false,()->{ref[0].dismiss();if(Links.isPlaylist(source))saveSharedPlaylist(source);else choosePlaylist(java.util.Collections.emptyList(),source);}),lp(-1,52));gap(l,10);
        l.addView(button("Play later",R.drawable.ic_queue,false,()->{ref[0].dismiss();importLink(source,false);}),lp(-1,48));gap(l,16);l.addView(text("No account needed. Your library stays on this phone.",12,MUTED,false));ref[0]=sheet(l);
    }
    void pasteSheet(){pasteSheet(null);}
    void pasteSheet(String supplied){
        if(app.busy){Snackbar.make(root,"Pause the current import before adding another playlist",Snackbar.LENGTH_LONG).show();return;}
        LinearLayout l=column();handle(l);l.addView(text("Import playlist",26,INK,true));gap(l,10);l.addView(text("Paste a YouTube link or a public Spotify playlist link.",15,MUTED,false));gap(l,20);
        TextInputLayout field=new TextInputLayout(this);field.setHint("YouTube or Spotify playlist link");field.setBoxBackgroundMode(TextInputLayout.BOX_BACKGROUND_OUTLINE);field.setBoxStrokeColor(ACCENT);field.setDefaultHintTextColor(ColorStateList.valueOf(MUTED));TextInputEditText input=new TextInputEditText(this);input.setTextColor(INK);input.setTextSize(16);input.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_URI);input.setMaxLines(3);field.addView(input);l.addView(field);gap(l,12);
        MaterialButton paste=button("Paste from clipboard",R.drawable.ic_link,false,()->{ClipboardManager c=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);if(c.hasPrimaryClip()){ClipData clip=c.getPrimaryClip();if(clip!=null)input.setText(clip.getItemAt(0).coerceToText(this));}});l.addView(paste,lp(-1,48));gap(l,18);
        if(supplied!=null)input.setText(supplied);
        final BottomSheetDialog[] ref=new BottomSheetDialog[1];l.addView(button("Import playlist",R.drawable.ic_arrow,true,()->{try{String text=input.getText().toString();if(SpotifyPlaylist.looksLike(text)){String source=SpotifyPlaylist.link(text);ref[0].dismiss();SpotifyImport.readLink(this,source);}else{String source=SpotifySong.musicLink(text);ref[0].dismiss();if(Links.isPlaylist(source))saveSharedPlaylist(source);else shareSheet(source);}}catch(Exception e){field.setError(e.getMessage());}}),lp(-1,54));ref[0]=sheet(l);
    }
    void namePlaylist(String initial,java.util.function.Consumer<String> commit){
        LinearLayout l=column();handle(l);l.addView(text("Name your playlist",26,INK,true));gap(l,8);l.addView(text("Save it to your Library. Make it yours.",14,MUTED,false));gap(l,18);
        TextInputLayout field=new TextInputLayout(this);field.setHint("Playlist name");field.setBoxBackgroundMode(TextInputLayout.BOX_BACKGROUND_OUTLINE);TextInputEditText name=new TextInputEditText(this);name.setSingleLine(true);name.setText(initial);name.setTextSize(16);name.setTextColor(INK);name.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(60)});field.addView(name);l.addView(field);gap(l,18);
        final BottomSheetDialog[] dialog=new BottomSheetDialog[1];l.addView(button("Save playlist",R.drawable.ic_save,true,()->{String value=name.getText().toString().trim();if(value.isEmpty()){field.setError("Give your playlist a name.");return;}dialog[0].dismiss();commit.accept(value);}),lp(-1,52));dialog[0]=sheet(l);
    }
    void saveQueue(){ArrayList<Track> snapshot=new ArrayList<>(app.queue);namePlaylist("",name->{SavedPlaylist saved=new SavedPlaylist(name);saved.add(snapshot);app.library.add(saved);app.saveLibrary();Snackbar.make(root,"Saved to Library",Snackbar.LENGTH_SHORT).show();});}
    void choosePlaylist(java.util.List<Track> tracks,String source){
        LinearLayout l=column();handle(l);l.addView(text("Add to playlist",26,INK,true));gap(l,8);l.addView(text(tracks.isEmpty()?"Choose a playlist for this song.":tracks.get(0).title,14,MUTED,false));gap(l,18);
        final BottomSheetDialog[] dialog=new BottomSheetDialog[1];for(SavedPlaylist saved:app.library){MaterialButton choice=button(saved.name,R.drawable.ic_library,false,()->{dialog[0].dismiss();if(source!=null)importToPlaylist(source,saved);else{int count=saved.add(tracks);app.saveLibrary();Snackbar.make(root,count==0?"Already in this playlist":"Added to "+saved.name,Snackbar.LENGTH_SHORT).show();}});choice.setMaxLines(2);l.addView(choice,lp(-1,-2));gap(l,8);}
        gap(l,10);l.addView(button("Create new playlist",R.drawable.ic_plus,true,()->{dialog[0].dismiss();namePlaylist("",name->{SavedPlaylist saved=new SavedPlaylist(name);app.library.add(saved);if(source==null)saved.add(tracks);app.saveLibrary();if(source!=null)importToPlaylist(source,saved);});}),lp(-1,52));dialog[0]=sheet(l);
    }
    void saveSharedPlaylist(String source){namePlaylist("",name->{SavedPlaylist saved=new SavedPlaylist(name);app.library.add(saved);page="home";selectedPlaylist=saved;app.saveLibrary();importToPlaylist(source,saved,true);});}
    void importToPlaylist(String source,SavedPlaylist saved){importToPlaylist(source,saved,false);}
    void importToPlaylist(String source,SavedPlaylist saved,boolean playAfter){
        if(app.busy){Snackbar.make(root,"Another link is loading. Try again shortly.",Snackbar.LENGTH_LONG).show();return;}lastSource=source;retryAction=()->importToPlaylist(source,saved,playAfter);app.busy=true;app.error="";app.status="Adding songs to "+saved.name+"…";app.changed();
        app.worker.execute(()->{try{ArrayList<Track> tracks=Extractor.inspect(this,source);app.main.post(()->{app.busy=false;if(app.library.contains(saved)||saved==app.favorites){int added=saved.add(tracks);app.status="";if(saved==app.favorites)app.saveFavorites();app.saveLibrary();if(playAfter)playPlaylist(saved,false);Snackbar.make(root,added+" songs saved to "+saved.name+(source.contains("list=RD")?" (current Mix snapshot)":""),Snackbar.LENGTH_LONG).show();}});}catch(Exception e){app.fail(Extractor.error(e));}});
    }
    void pasteForPlaylist(SavedPlaylist saved){PlaylistAddSongs.show(this,saved);}
    void playPlaylist(SavedPlaylist saved,boolean shuffle){SpotifyImport.clearPlayRequest(app);if(SpotifyProgress.startPlaylist(this,saved,shuffle))return;if(saved.tracks.isEmpty()){Snackbar.make(root,"Add a song to this playlist first",Snackbar.LENGTH_SHORT).show();return;}app.setPlayingPlaylist(saved);PlaylistQueue.replace(app.queue,saved.tracks);if(app.playback!=null)app.playback.player.setShuffleModeEnabled(shuffle);else app.prefs("session").edit().putBoolean("shuffle",shuffle).apply();selectedPlaylist=saved;app.error="";Track first=app.queue.get(shuffle?new java.util.Random().nextInt(app.queue.size()):0);app.warmStream(first);pendingPlay=first.id;requestNotifications();app.listeningChanged();}
    void playPlaylistAt(SavedPlaylist saved,int index){SpotifyImport.clearPlayRequest(app);if(index<0||index>=saved.tracks.size())return;app.warmStream(saved.tracks.get(index));app.setPlayingPlaylist(saved);PlaylistQueue.replace(app.queue,saved.tracks);selectedPlaylist=saved;app.error="";pendingPlay=app.queue.get(index).id;requestNotifications();app.listeningChanged();}
    void shuffleQueue(){if(app.queue.size()<2){Snackbar.make(root,"Add another song to shuffle",Snackbar.LENGTH_SHORT).show();return;}ArrayList<Track> before=new ArrayList<>(app.queue);Collections.shuffle(app.queue);if(app.queue.equals(before))Collections.rotate(app.queue,1);if(app.playback!=null)app.playback.sync(false);app.changed();Snackbar.make(root,"Queue shuffled",Snackbar.LENGTH_SHORT).show();}
    void playlistOptions(SavedPlaylist saved){new MaterialAlertDialogBuilder(this).setTitle(saved.name).setItems(new String[]{"Rename","Delete playlist"},(d,index)->{if(index==0)namePlaylist(saved.name,value->{saved.name=value;app.saveLibrary();});else{final String undoProfile=app.profiles.active;int position=app.library.indexOf(saved);if(app.spotifyImport!=null&&app.spotifyImport.target==saved)app.spotifyImport.cancel();app.library.remove(saved);selectedPlaylist=null;app.saveLibrary();Snackbar.make(root,"Playlist deleted",Snackbar.LENGTH_LONG).setAction("Undo",v->{if(!app.profiles.active.equals(undoProfile))return;app.library.add(Math.min(position,app.library.size()),saved);app.saveLibrary();}).show();}}).show();}
    void trackOptions(Track track,SavedPlaylist owner){SongActions.show(this,track,owner);}
    void importLink(String source,boolean play){
        if(app.busy){Snackbar.make(root,"A link is already loading. You can keep listening.",Snackbar.LENGTH_LONG).show();return;}
        if(Links.isPlaylist(source))namePlaylist("",name->{SavedPlaylist saved=new SavedPlaylist(name);app.library.add(saved);app.saveLibrary();importQueue(source,play,saved);});
        else importQueue(source,play,null);
    }
    void importQueue(String source,boolean play,SavedPlaylist saved){
        if(app.busy)return;lastSource=source;retryAction=()->importQueue(source,play,saved);app.busy=true;app.error="";app.status="Opening your link…";refresh();
        app.worker.execute(()->{try{ArrayList<Track> tracks=Extractor.inspect(this,source);app.main.post(()->{
            if(play)app.setPlayingPlaylist(saved);app.queue.addAll(tracks);app.busy=false;app.status="";if(saved!=null&&app.library.contains(saved)){saved.add(tracks);app.saveLibrary();}
            if(app.playback!=null){app.playback.sync(false);if(play)app.playback.play(app.queue.indexOf(tracks.get(0)));}else if(play)pendingPlay=tracks.get(0).id;
            if(saved!=null)selectedPlaylist=saved;app.changed();
            if(!isDestroyed())Snackbar.make(root,"Imported "+tracks.size()+" songs",Snackbar.LENGTH_LONG).show();
        });}catch(Exception e){app.fail(Extractor.error(e));}});
    }
    void sample(){Track t=new Track("android.resource://"+getPackageName()+"/"+R.raw.playback_sample,"Playback test","Local sample · 20 seconds","",20);app.queue.add(t);if(app.playback!=null)app.playback.sync(false);pendingPlay=t.id;app.error="";app.status="A local tone to test playback and lock-screen controls.";app.changed();}
    void openYoutube(){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.youtube.com")));}catch(Exception e){Snackbar.make(root,"No app could open YouTube. Paste a link instead.",Snackbar.LENGTH_LONG).show();}}
    void clearQueue(){final String undoProfile=app.profiles.active;ArrayList<Track> removed=new ArrayList<>(app.queue);app.queue.clear();app.error="";app.status="";if(app.playback!=null)app.playback.sync(false);app.changed();Snackbar.make(root,"Queue cleared",Snackbar.LENGTH_LONG).setAction("Undo",v->{if(!app.profiles.active.equals(undoProfile))return;app.queue.addAll(removed);if(app.playback!=null)app.playback.sync(false);app.changed();}).show();}
    void remove(Track t){final String undoProfile=app.profiles.active;int at=app.queue.indexOf(t);app.queue.remove(t);if(app.playback!=null)app.playback.sync(false);app.changed();Snackbar.make(root,"Removed from queue",Snackbar.LENGTH_LONG).setAction("Undo",v->{if(!app.profiles.active.equals(undoProfile))return;app.queue.add(Math.min(at,app.queue.size()),t);if(app.playback!=null)app.playback.sync(false);app.changed();}).show();}
    String current(){return app.playback==null||app.playback.player.getCurrentMediaItem()==null?"":app.playback.player.getCurrentMediaItem().mediaId;}
    void legacyMini(){
        mini=column();rounded(mini,SURFACE,20);mini.setPadding(dp(8),dp(8),dp(4),dp(8));LinearLayout.LayoutParams box=lp(-1,-2);box.setMargins(dp(12),dp(6),dp(12),dp(2));root.addView(mini,box);LinearLayout r=row();miniArt=art(42,42,"");r.addView(miniArt);LinearLayout labels=column();labels.setPadding(dp(12),0,dp(4),0);miniTitle=text("Ready to listen",14,INK,true);miniTitle.setSingleLine(true);miniTitle.setEllipsize(TextUtils.TruncateAt.END);miniTime=text("Tap play to begin",12,MUTED,false);labels.addView(miniTitle);gap(labels,4);labels.addView(miniTime);r.addView(labels,new LinearLayout.LayoutParams(0,-2,1));playButton=icon(R.drawable.ic_play,"Play",()->{if(app.playback!=null)app.playback.toggle();});r.addView(playButton,lp(48,48));r.addView(icon(R.drawable.ic_next,"Next track",()->{if(app.playback!=null)app.playback.next();}),lp(48,48));mini.addView(r);labels.setOnClickListener(v->playerSheet());miniArt.setOnClickListener(v->playerSheet());updateMini();
    }
    void buildMini(){NativeScreens.mini(this);}
    void updateMini(){PlaylistPlayback.update(this);if(mini==null||app.playback==null)return;Player p=app.playback.player;MediaItem item=p.getCurrentMediaItem();Track t=item==null?null:app.find(item.mediaId);if(t!=null){miniTitle.setText(t.title);if(!t.thumbnail.equals(miniArt.getTag()))Images.load(miniArt,t.thumbnail);}boolean loading=p.getPlaybackState()==Player.STATE_BUFFERING;miniTime.setText(loading?"Opening audio…":t==null?"Tap play to begin":t.creator);if(t!=null&&miniFavorite!=null){miniFavorite.setIconResource(app.isFavorite(t)?R.drawable.ic_heart_filled:R.drawable.ic_heart);miniFavorite.setContentDescription(app.isFavorite(t)?"Remove from Favorites":"Add to Favorites");}playButton.setIconResource(p.getPlayWhenReady()?R.drawable.ic_pause:R.drawable.ic_play);playButton.setContentDescription(p.getPlayWhenReady()?"Pause":"Play");}
    static String format(long seconds){if(seconds<0||seconds>864000)return "–:–";return String.format(Locale.ROOT,"%d:%02d",seconds/60,seconds%60);}
    void playerSheet(){NativeScreens.player(this);}
    void playTrack(Track track){app.error="";app.warmStream(track);SpotifyImport.clearPlayRequest(app);app.setPlayingPlaylist(null);int index=-1;for(int i=0;i<app.queue.size();i++)if(app.queue.get(i).source.equals(track.source)){index=i;break;}if(index<0){Track copy=track.copy();app.queue.add(copy);index=app.queue.size()-1;}pendingPlay=app.queue.get(index).id;requestNotifications();app.changed();}
    void sessionSheet(){LinearLayout l=column();handle(l);LinearLayout body=column();l.addView(body,lp(-1,440));buildSession(body);sessionDialog=sheet(l);}
    void historySettings(){LinearLayout l=column();handle(l);l.addView(text("Your listening history",26,INK,true));gap(l,10);l.addView(text("A song enters Recently played after five seconds of playback. All retained listening history contributes to channel weights. Suggestions combine searches from multiple channels, rotate discovery and exclude songs already heard. History and play counts stay on this device. They are Syntix suggestions, not YouTube’s account recommendations.",14,MUTED,false));gap(l,18);androidx.appcompat.widget.SwitchCompat enabled=new androidx.appcompat.widget.SwitchCompat(this);enabled.setText("Suggestions from my listening");enabled.setTextColor(INK);enabled.setChecked(app.prefs("history").getBoolean("recommendations_enabled",true));enabled.setOnCheckedChangeListener((button,checked)->{app.prefs("history").edit().putBoolean("recommendations_enabled",checked).apply();if(checked)app.refreshRecommendations();else{app.recommendations.clear();app.changed();}});l.addView(enabled,lp(-1,64));gap(l,12);l.addView(button("Clear listening history",R.drawable.ic_close,false,()->{app.clearHistory();Snackbar.make(root,"Listening history cleared",Snackbar.LENGTH_SHORT).show();}),lp(-1,52));sheet(l);}
    void exportPlaylists(){
        try{backupProfile=app.profiles.active;app.pendingBackup=LibraryBackups.snapshot(app);startActivityForResult(new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/json").putExtra(Intent.EXTRA_TITLE,"Syntix-playlists-backup.json"),40);}catch(Exception e){Snackbar.make(root,"Could not create backup. Try again.",Snackbar.LENGTH_LONG).show();}
    }
    void importPlaylists(){backupProfile=app.profiles.active;startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/json"),50);}
    void privacy(){PrivacyLegal.show(this);}

    void legacySettings(){
        LinearLayout l=column();handle(l);l.addView(text("Simple, on purpose.",28,INK,true));gap(l,12);l.addView(text("Syntix 0.5 · Android 12+\nPlaylists and history stay on this device. Local profiles only. No online sign-in or analytics. No automatic music downloads.",15,MUTED,false));gap(l,24);
        l.addView(button("Listening history and suggestions",R.drawable.ic_library,false,this::historySettings),lp(-1,52));gap(l,10);l.addView(button("Export playlists",R.drawable.ic_external,false,this::exportPlaylists),lp(-1,52));gap(l,10);l.addView(button("Import playlist backup",R.drawable.ic_library,false,this::importPlaylists),lp(-1,52));gap(l,10);PrivacyLegal.section(this,l);gap(l,10);l.addView(button("How it works",R.drawable.ic_info,false,this::how),lp(-1,52));gap(l,10);l.addView(button("Update playback engine",R.drawable.ic_retry,false,()->{
            if(app.busy)return;app.busy=true;app.status="Updating playback engine…";app.error="";app.changed();app.worker.execute(()->{try{Extractor.init(this);YoutubeDL.INSTANCE.updateYoutubeDL(this,YoutubeDL.UpdateChannel.STABLE.INSTANCE);app.main.post(()->{app.busy=false;app.status="Playback engine is up to date. Retry your link.";app.changed();});}catch(Exception e){app.fail("Could not update. Check your connection and try again.");}});
        }),lp(-1,52));gap(l,10);l.addView(button("Open an audio file",R.drawable.ic_headphones,false,()->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("audio/*").addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,30);}),lp(-1,52));gap(l,20);l.addView(text("YouTube can restrict or change playback access. Updating may restore compatibility, but playback is not guaranteed for every link.\n\nOpen-source software: GPL-3.0. Includes AndroidX Media3, youtubedl-android, yt-dlp, FFmpeg and Outfit. Source and license notices are included in your download package.",12,MUTED,false));sheet(l);
    }
    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(result!=Activity.RESULT_OK||data==null||data.getData()==null)return;Uri uri=data.getData();
        if(request==60){try{getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);LocalProfiles.Profile target=app.profiles.find(photoProfile);if(target==null)throw new IllegalStateException();target.photo=uri.toString();app.profiles.save();refresh();}catch(Exception e){Snackbar.make(root,"Could not keep access to this photo. Choose another image.",Snackbar.LENGTH_LONG).show();}return;}
        if(request==40){final String snapshot=app.pendingBackup;app.pendingBackup="";if(snapshot.isEmpty()){Snackbar.make(root,"Backup interrupted. Export again.",Snackbar.LENGTH_LONG).show();return;}app.worker.execute(()->{try(java.io.OutputStream output=getContentResolver().openOutputStream(uri,"wt")){if(output==null)throw new java.io.IOException();output.write(snapshot.getBytes(java.nio.charset.StandardCharsets.UTF_8));}catch(Exception e){app.fail("Could not save backup. Export again.");return;}app.main.post(()->{if(!isDestroyed())Snackbar.make(root,"Playlist backup saved",Snackbar.LENGTH_LONG).show();});});return;}
        if(request==50){final String targetProfile=backupProfile;app.worker.execute(()->{try(java.io.InputStream input=getContentResolver().openInputStream(uri)){ArrayList<SavedPlaylist> imported=LibraryBackups.read(input);app.main.post(()->{if(!app.profiles.active.equals(targetProfile)){app.fail("Switch back to the importing profile and try again.");return;}LibraryBackups.merge(app,imported);if(!isDestroyed())Snackbar.make(root,"Playlists imported. Local files may need to be selected again.",Snackbar.LENGTH_LONG).show();});}catch(Exception e){app.fail(e.getMessage()==null?"Could not read this playlist backup.":e.getMessage());}});return;}
        if(request==30){try{getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}String name="Local audio";try(android.database.Cursor cursor=getContentResolver().query(uri,null,null,null,null)){if(cursor!=null&&cursor.moveToFirst()){int col=cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);if(col>=0)name=cursor.getString(col);}}catch(Exception ignored){}Track t=new Track(uri.toString(),name,"On this device","",0);DownloadedDocuments.record(this,app.profiles.active,t);app.queue.add(t);if(app.playback!=null)app.playback.sync(false);pendingPlay=t.id;app.changed();}
    }
    final class QueueAdapter extends RecyclerView.Adapter<QueueAdapter.Holder>{
        @Override public Holder onCreateViewHolder(ViewGroup parent,int type){LinearLayout card=row();card.setPadding(dp(4),dp(12),dp(2),dp(12));RecyclerView.LayoutParams p=new RecyclerView.LayoutParams(-1,-2);p.bottomMargin=dp(10);card.setLayoutParams(p);return new Holder(card);}
        @Override public void onBindViewHolder(Holder h,int index){Track t=app.queue.get(index);LinearLayout card=(LinearLayout)h.itemView;card.removeAllViews();rounded(card,t.id.equals(current())?RAISED:PAGE,12);
            MaterialButton grip=icon(R.drawable.ic_grip,"Reorder "+t.title,()->{drag.startDrag(h);});grip.setOnLongClickListener(v->{drag.startDrag(h);return true;});card.addView(grip,lp(48,56));card.addView(art(44,48,t.thumbnail));LinearLayout labels=column();labels.setPadding(dp(14),0,dp(8),0);TextView title=text(t.title,14,INK,true);title.setMaxLines(2);title.setEllipsize(TextUtils.TruncateAt.END);labels.addView(title);gap(labels,5);labels.addView(text((t.id.equals(current())?"Now playing · ":"")+(t.duration>0?format(t.duration):t.creator),12,MUTED,false));card.addView(labels,new LinearLayout.LayoutParams(0,-2,1));labels.setOnClickListener(v->{if(app.playback!=null)app.playback.play(h.getBindingAdapterPosition());});
            MaterialButton more=icon(R.drawable.ic_more,"Actions for "+t.title,()->SongActions.show(MainActivity.this,t,null));card.addView(more,lp(48,56));
        }
        @Override public int getItemCount(){return app.queue.size();}
        final class Holder extends RecyclerView.ViewHolder{Holder(View view){super(view);}}
    }
}
