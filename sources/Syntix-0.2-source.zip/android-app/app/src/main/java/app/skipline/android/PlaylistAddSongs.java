package app.skipline.android;

import android.widget.*;
import android.text.TextUtils;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.textfield.*;
import com.google.android.material.snackbar.Snackbar;
import java.util.*;

@androidx.media3.common.util.UnstableApi
final class PlaylistAddSongs {
    static void show(MainActivity a,SavedPlaylist saved){
        LinearLayout body=a.column();a.handle(body);body.addView(a.text("Add songs",26,MainActivity.INK,true));a.gap(body,8);body.addView(a.text(saved.name,14,MainActivity.MUTED,false));a.gap(body,16);
        BottomSheetDialog[] dialog=new BottomSheetDialog[1];body.addView(a.button("YouTube or Spotify link",R.drawable.ic_link,false,()->{dialog[0].dismiss();link(a,saved);}),a.lp(-1,52));a.gap(body,18);
        LinearLayout tabs=a.row(),list=a.column();ScrollView scroll=new ScrollView(a);scroll.setVerticalScrollBarEnabled(false);scroll.addView(list);String[] labels={"Recommended","Recently listened"};
        for(int i=0;i<2;i++){final int tab=i;tabs.addView(a.button(labels[i],0,false,()->fill(a,list,saved,tab==0?a.app.recommendations:a.app.history.recent())),new LinearLayout.LayoutParams(0,a.dp(48),1));}
        body.addView(tabs);a.gap(body,12);body.addView(scroll,a.lp(-1,320));fill(a,list,saved,a.app.history.recent());dialog[0]=a.sheet(body);
    }
    private static void fill(MainActivity a,LinearLayout list,SavedPlaylist saved,List<Track> tracks){
        list.removeAllViews();if(tracks.isEmpty()){list.addView(a.text("Listen to more music to find songs here.",14,MainActivity.MUTED,false));return;}
        for(Track t:tracks){LinearLayout row=a.row();row.addView(a.art(44,44,t.thumbnail));LinearLayout labels=a.column();labels.setPadding(a.dp(12),0,a.dp(8),0);TextView title=a.text(t.title,14,MainActivity.INK,true);title.setSingleLine();title.setEllipsize(TextUtils.TruncateAt.END);labels.addView(title);TextView artist=a.text(t.creator,12,MainActivity.MUTED,false);artist.setSingleLine();labels.addView(artist);row.addView(labels,new LinearLayout.LayoutParams(0,-2,1));boolean exists=contains(saved,t);com.google.android.material.button.MaterialButton add=a.icon(exists?R.drawable.ic_check:R.drawable.ic_plus,exists?"Already added":"Add "+t.title,()->{if(saved==a.app.favorites){if(!a.app.isFavorite(t))a.app.toggleFavorite(t);}else{saved.add(Collections.singletonList(t));a.app.saveLibrary();}fill(a,list,saved,tracks);});add.setEnabled(!exists);row.addView(add,a.lp(48,56));list.addView(row,a.lp(-1,64));}
    }
    private static boolean contains(SavedPlaylist saved,Track t){for(Track existing:saved.tracks)if(existing.source.equals(t.source))return true;return false;}
    static void link(MainActivity a,SavedPlaylist saved){
        LinearLayout body=a.column();a.handle(body);body.addView(a.text("Add to "+saved.name,24,MainActivity.INK,true));a.gap(body,16);TextInputLayout field=new TextInputLayout(a);field.setHint("YouTube or Spotify song link");field.setBoxBackgroundMode(TextInputLayout.BOX_BACKGROUND_OUTLINE);TextInputEditText input=new TextInputEditText(a);input.setTextSize(16);input.setTextColor(MainActivity.INK);input.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_URI);field.addView(input);body.addView(field);a.gap(body,18);BottomSheetDialog[] dialog=new BottomSheetDialog[1];body.addView(a.button("Add songs",R.drawable.ic_plus,true,()->{try{String source=SpotifySong.musicLink(input.getText().toString());dialog[0].dismiss();a.importToPlaylist(source,saved);}catch(Exception e){field.setError(e.getMessage());}}),a.lp(-1,52));dialog[0]=a.sheet(body);
    }
}
