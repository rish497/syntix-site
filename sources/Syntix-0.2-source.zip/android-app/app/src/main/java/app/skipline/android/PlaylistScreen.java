package app.skipline.android;

import android.content.res.ColorStateList;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import com.google.android.material.button.MaterialButton;

@androidx.media3.common.util.UnstableApi
final class PlaylistScreen {
    static void render(MainActivity a,LinearLayout content,SavedPlaylist saved){
        LinearLayout top=a.row();
        top.addView(a.icon(R.drawable.ic_back,"Back",()->{a.selectedPlaylist=null;a.visibleTracks=100;a.refresh();}),a.lp(48,48));
        top.addView(new Space(a),new LinearLayout.LayoutParams(0,1,1));
        if(saved!=a.app.favorites)top.addView(a.icon(R.drawable.ic_more,"Playlist options",()->a.playlistOptions(saved)),a.lp(48,48));
        content.addView(top);
        View cover;
        if(saved==a.app.favorites){FrameLayout box=new FrameLayout(a);a.rounded(box,MainActivity.ACCENT,10);ImageView heart=new ImageView(a);heart.setImageResource(R.drawable.ic_heart_filled);heart.setColorFilter(MainActivity.ON_ACCENT);box.addView(heart,new FrameLayout.LayoutParams(a.dp(70),a.dp(70),Gravity.CENTER));cover=box;}
        else cover=a.art(192,192,saved.tracks.isEmpty()?"":saved.tracks.get(0).thumbnail);
        LinearLayout.LayoutParams cp=a.lp(192,192);cp.gravity=Gravity.CENTER_HORIZONTAL;cp.setMargins(0,a.dp(10),0,a.dp(24));content.addView(cover,cp);
        content.addView(a.text(saved.name,29,MainActivity.INK,true));a.gap(content,10);
        content.addView(a.text(a.app.profiles.current().name+" · "+SpotifyProgress.total(saved)+" songs",13,MainActivity.MUTED,false));a.gap(content,6);
        content.addView(a.text(SpotifyProgress.duration(saved),13,MainActivity.MUTED,false));a.gap(content,14);
        LinearLayout actions=a.row();
        actions.addView(a.icon(R.drawable.ic_plus,"Add song",()->{a.pasteForPlaylist(saved);}),a.lp(48,56));
        MaterialButton download=a.icon(R.drawable.ic_download,"Download playlist",()->OfflineScreens.playlist(a,saved));
        actions.addView(download,a.lp(48,56));actions.addView(new Space(a),new LinearLayout.LayoutParams(0,1,1));
        actions.addView(a.icon(R.drawable.ic_shuffle,"Shuffle playlist",()->a.playPlaylist(saved,true)),a.lp(52,56));
        MaterialButton play=a.icon(R.drawable.ic_play,"Play playlist",()->{if(PlaylistPlayback.isCurrentPlaylist(a,saved))a.app.playback.toggle();else a.playPlaylist(saved,false);});
        play.setIconSize(a.dp(26));play.setBackgroundTintList(ColorStateList.valueOf(MainActivity.ACCENT));play.setIconTint(ColorStateList.valueOf(MainActivity.ON_ACCENT));play.setCornerRadius(a.dp(30));
        LinearLayout.LayoutParams pp=a.lp(56,56);pp.leftMargin=a.dp(10);actions.addView(play,pp);content.addView(actions);PlaylistPlayback.bindPlayButton(a,play,saved);
        TextView state=a.text("",12,MainActivity.ACCENT,false);state.setSingleLine(true);state.setEllipsize(TextUtils.TruncateAt.END);content.addView(state,a.lp(-1,24));
        java.util.concurrent.atomic.AtomicBoolean reading=new java.util.concurrent.atomic.AtomicBoolean();
        java.util.concurrent.atomic.AtomicInteger downloaded=new java.util.concurrent.atomic.AtomicInteger();
        final OfflineStore store=a.app.offline;
        Runnable update=new Runnable(){public void run(){
            if(!a.screenStarted||!download.isAttachedToWindow())return;
            if(reading.compareAndSet(false,true))a.app.worker.execute(()->{try{downloaded.set(store.ready(saved.tracks));}finally{reading.set(false);}});
            int pending=store.pendingFor(saved.tracks),ready=downloaded.get();
            boolean active=a.app.offlineRunning&&pending>0,complete=saved.spotifyDraft==null&&!saved.tracks.isEmpty()&&ready==saved.tracks.size();
            String label=active?"Downloading playlist":complete?"Playlist downloaded":pending>0?"Continue playlist download":"Download playlist";
            download.setContentDescription(label);download.setTooltipText(label);
            download.setIconResource(active?R.drawable.ic_pause:complete?R.drawable.ic_check:R.drawable.ic_download);
            download.setIconTint(ColorStateList.valueOf(active||complete?MainActivity.ACCENT:MainActivity.INK));
            state.setText(active?"Downloading playlist…":pending>0?"Playlist download paused":complete?"Available offline":"");
            a.handler.postDelayed(this,750);
        }};
        download.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener(){public void onViewAttachedToWindow(View v){a.handler.post(update);}public void onViewDetachedFromWindow(View v){a.handler.removeCallbacks(update);}});
        SpotifyProgress.controls(a,content,saved);
        if(a.spotifyBinding!=null&&cover instanceof ImageView){a.spotifyBinding.cover=(ImageView)cover;a.spotifyBinding.coverUrl=saved.tracks.isEmpty()?"":saved.tracks.get(0).thumbnail;}
        if(SpotifyProgress.rows(a,content,saved))return;
        if(saved.tracks.isEmpty())content.addView(a.text(saved==a.app.favorites?"Tap a heart beside a song to add it to Favorites.":"Add songs to start this playlist.",14,MainActivity.MUTED,false));
        for(int i=0;i<Math.min(a.visibleTracks,saved.tracks.size());i++)NativeScreens.track(a,content,saved.tracks.get(i),saved);
        if(saved.tracks.size()>a.visibleTracks)content.addView(a.button("Show more songs",R.drawable.ic_plus,false,()->{a.visibleTracks+=100;a.refresh();}),a.lp(-1,48));
    }
}
