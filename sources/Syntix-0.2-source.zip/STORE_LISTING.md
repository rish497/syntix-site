# Syntix — store submission copy

Audience: ages 13 and older (13+). Not intended for children under 13. Higher local/service minimum ages and guardian-permission requirements still apply.

This is an intended minimum age, not an awarded PEGI/IARC rating. Answer each store content-rating form accurately; do not select Everyone. Music/search results can contain explicit content, and there is no child-specific filtering mode.

Short description: Your playlists, listening history and offline music in one app.

Syntix is an independent Android music app for listeners aged 13 and older (13+). Create a local profile, import a YouTube or Spotify playlist, find songs, organize favorites and listen using playback, queue, equalizer and sleep-timer controls. Spotify imports match public track metadata to YouTube; they do not play Spotify audio. Managed offline downloads are available for content you are authorized to access and save. Completed managed audio is encrypted inside Syntix; local profiles and library metadata are not password-protected. Searches and media requests contact third-party services. Profiles are stored on the device and are not password-protected. Android 12 or later is required. Syntix is not affiliated with YouTube, Google or Spotify.

Developer: Rishabh Mittal
Support: mittal.rishabh2010@gmail.com
Software license: GPL-3.0; third-party terms also apply.
Ads: no integrated ad SDK identified in this APK. No paid subscription or purchases implemented.

Before submission: publish a stable HTTPS Privacy Policy URL and any requested source/license/notice URLs; provide ownership evidence, real screenshots and required age/content declarations. Local profile setup needs no test credentials; reviewers choose a name and affirm the 13+ terms. Distribution is not approved by either store yet. See STORE_POLICY_REVIEW.md and RELEASE_OPEN_ITEMS.md.


## Version 0.2 source directions

Include alongside the store/binary download: Source code and build information: https://rish497.github.io/syntix-site/sources/Syntix-0.2-source.zip
