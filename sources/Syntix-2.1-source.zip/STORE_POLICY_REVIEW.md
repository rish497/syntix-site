# Store-policy check — 3 November 2026

Primary public rules checked before further polish. No submission, store rating, legal certification or approval has occurred.

## Uptodown

Publication criteria (updated 20 October 2026): https://support.uptodown.com/hc/en-us/articles/360052792972-Uptodown-s-app-publication-criteria

Uptodown can reject apps for paid-content streaming/downloads, piracy-related use, confusing third-party branding, missing publication rights, malfunction or harmful software. Circumventing requirements can result in a developer ban. The policy does not promise acceptance for YouTube downloaders. Syntix's free public YouTube extraction is not automatically proven to fall into the paid-content ban, but unrestricted downloader/export positioning creates review and rights risk. Do not describe it as free YouTube Premium or hide exports from reviewers.

Submission guide (updated 7 October 2026): https://support.uptodown.com/hc/en-us/articles/360053260491-How-to-publish-an-app-on-Uptodown

The form requests author/category, package information, an age range based on PEGI or regional equivalent, app descriptions, distribution details and suitable assets. It exposes software-license, source-code and notice URL fields when applicable. Enter the truthful 13+ minimum in listing copy; do not invent a PEGI 13 certification (PEGI uses its own bands). Provide accurate content disclosures and accept the resulting appropriate rating, which may be higher. Prepare stable public policy/source/notice links and ownership evidence.

## Aptoide

Restrictions: https://docs.connect.aptoide.com/docs/app-restrictions

Aptoide Connect lists intellectual-property infringement as a rejection ground. It also identifies crashes/freezes, non-original apps, certain low-quality webviews and external APK downloading among possible rejection causes. Syntix downloads media and updates an extraction engine; it does not install external APKs, but those behaviors must be disclosed accurately. The reviewed rules do not give a downloader exemption or guarantee approval.

App information: https://docs.connect.aptoide.com/docs/app-information

The submission information can include a category, age rating, support email, website and Privacy Policy URL, along with a 512x512 icon and 1024x500 feature image. A bundled policy alone does not supply the hosted URL requested in a form. Keep the stated audience 13+ and answer the actual age/content fields truthfully.

Policy declarations: https://docs.connect.aptoide.com/docs/policy-declarations

This page specifically describes a phased programme for Aptoide Games US distribution through Google Play, enabled per app. Do not assume every Syntix submission is subject to that particular flow. If enabled, complete its ads, advertising-ID, target-audience, app-access and other applicable fields. Based on the inspected APK: no ad SDK/advertising-ID use identified, no paid purchases, no developer backend, local-profile setup needs no remote credentials. Describe setup instructions and third-party requests; do not answer blanket no data collected solely because profiles are local.

Aptoide general terms/distribution framework: https://en.aptoide.com/company/legal

The distributor must have the necessary rights. A malware/trusted badge does not certify copyright compliance. Store discretion and regional laws still apply.

## Submission decisions that remain

1. Actual content rating and target-age selections must be completed in each live store form. No Everyone claim is present in the new listing draft. A self-declared minimum age is not verified age assurance or worldwide child-law compliance.
2. Obtain native corresponding-source/notice completeness documented in NATIVE_BUILD_AUDIT.md and verify asset/content rights.
3. Publish stable HTTPS Privacy Policy/source/license/notice URLs, using the actual release date.
4. Submit transparently for each store's review; they may decline the existing features. No feature was removed or obscured to evade review.
