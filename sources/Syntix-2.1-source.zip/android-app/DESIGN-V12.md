# V12 Spotify import release

Preserves V11.3 native slate/ivory import flow and all existing playback controls, styling and exact branding. Public links are the primary import option; CSV stays optional for incomplete public previews. The feature stores reviewed YouTube matches in ordinary saved playlists and does not introduce Spotify playback, ads, authentication or bulk downloading.

A volatile playback-buffering signal is published by the playback service and cleared on service destruction. Before each automatic match request, the background matcher waits while that signal is active. Cancellation, task dismissal, background idle and interruption release the wait. No playback thread waits for the import and no new permanent worker or timer is introduced. Already-running HTTP requests remain bounded by the existing timeout. Cached-stream lookup, first/next-song warmup and existing player buffer sizes remain unchanged.

No UI redesign or new motion was needed. This uses the existing native sheets, slate surfaces, ivory primary actions and grey press feedback. Device screenshots/audio measurements remain pending.
