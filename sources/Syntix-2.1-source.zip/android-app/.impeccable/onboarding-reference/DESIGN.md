# Syntix first-launch exploration

Prototype only; APK unchanged. Inherits approved Reference slate/ivory colors, Outfit and exact supplied PNG symbol. Three compositions: Immersive (cinematic full bleed), Sleeves (layered album covers), Library (workflow preview). Three benefit slides, optional local name/photo setup, then a named playlist import preview. Example songs and metadata are explicitly illustrative, no actual playback, authentication, upload or download. Offline playlist download remains a proposed feature, with internet needed before travel.

Mode: Operate. First-time mobile listeners should reach their first import quickly. No email/phone collected. Profile fields and photo object URLs exist in memory only. Native scroll snapping supports touch/trackpad gestures; reduced motion removes smooth snapping and GSAP reveals. Picker follows the prototype skill's verbatim chrome and keyboard contract. Production files remain untouched.
