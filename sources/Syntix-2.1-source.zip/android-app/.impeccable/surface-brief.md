# Syntix V6 native surface

Mode: Operate. Approved Reference music UI plus selected Immersive welcome carousel/local profile flow. Exact PNG branding, Outfit and slate/ivory colors. Native ViewPager2 and Android Back/insets; no WebView. Explicit per-profile offline playlist download sheet and notifications, no automatic audio preparation. Native rendering/download lifecycle remains unverified because no device is connected and emulator launch was previously blocked. See ../DESIGN.md and ../VERIFICATION.md.
