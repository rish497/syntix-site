# V12.1 verification

Version 0.12.1 / code 21 retains Android 12+ and the existing production signing identity.

Scope: public-link Spotify import automatically reads, matches, saves and opens a normal Syntix playlist. CSV UI/file-picker callback and manual review/save/name prompts are removed. Playlist titles use Spotify metadata with the existing fallback. Confident matches are deduplicated; skipped entries and partial/unverified public lists remain disclosed. All-unmatched imports produce no saved playlist. Cancellation, pending work, task dismissal, wrong profile and repeated completion callbacks are guarded.

Automatic matching still yields during audio buffering; native cached/offline playback and first/next-track warmup remain unchanged. Background-paused imports resume on foreground return, including the transition where the worker is finishing its pause. No advertising or Spotify playback embed is introduced. No music is downloaded during metadata import.

Checks passed: release assembly, release lint (0 errors) and all 82 debug unit tests (0 failures/errors). New native tests cover the sheet without CSV, absence of review controls, automatic playlist save/open, duplicate completion/deduplication, partial-source summaries, cancellation, wrong profile, task dismissal and all-unmatched failure. Existing metadata/matching and playback-priority tests remain.

An initial compile caught mixed text encoding in the edited importer; source was normalized to UTF-8 before the final build. Native UI fixture captures are development renders, not phone screenshots.

Limits: live full-playlist matching, physical-phone latency/audio/lifecycle and service availability have not been measured for this release. Spotify can expose only part of a public playlist; removing CSV does not remove that restriction. Matching can omit uncertain recordings. Draft progress is in-memory only and not durable across Android process termination. The earlier native finish-review device recapture remains pending. No fixed song-loading speed or public-release certification is claimed.

APK signature is checked against the existing production certificate. Packaging excludes keys, local SDK paths and build caches and retains earlier releases. See Syntix-0.12.1.sha256 for the file hash.
