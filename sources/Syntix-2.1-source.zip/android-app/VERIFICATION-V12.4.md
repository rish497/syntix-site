# V12.4 verification

Version 0.12.4 / code 24, Android 12+, existing production signing identity.

## Live metadata reproduction

Playlist: the supplied Sidhu Moose Wala Radio public snapshot, 50 tracks. Spotify metadata was sanitized to titles, artists, durations and public track IDs. No Spotify account, cookies or audio was used for these matching tests.

The earlier direct HTML/OkHttp search route reproduced 5 matches and 45 blocked-search errors. This release routes Spotify searches through yt-dlp's supported `ytsearch20` metadata extractor instead.

First yt-dlp run: 50 sequential metadata searches completed in 113.84 seconds with exit code 0; two alternate queries took 8.64 seconds. Candidate inspection identified repeated-letter title spelling differences and altered audio uploads. Matching was refined without disabling artist, duration or version checks.

A separate clean run explicitly disabled yt-dlp user configuration (`--ignore-config`), used no login/cookie arguments, and completed all 50 primary searches in 175.62 seconds with exit code 0 and no request errors. The final production Java matcher evaluated only that run's first-page candidates: 50/50 matched, 50 distinct video IDs, no remaining searches. No selected title contained the checked boosted/8D/reverb/mashup/slowed/cover/remix labels. These are metadata checks, not audio fingerprinting or proof of upload ownership.

Public diagnostic output: `.site-deps/ytsearch-audit/report.json`. Raw search results and diagnostic tools remain ignored workspace artifacts, not production seed data or packaged app resources. Search pacing was 0.6 seconds between engine requests. Test timings include desktop network and process overhead; they are not phone performance promises.

## Native implementation checks

Native Spotify matching uses the existing Android yt-dlp library with flat metadata extraction, one worker and per-import process IDs. Playback stream resolution is not changed. Cancellation targets the import's process IDs; playback-buffering/background gates remain. Cache tests cover reuse, fresh queue identity, expiry, rejection of wrong recordings, bounded eviction and no audio storage. Matcher regressions cover collaborator credits, duration/metadata omissions, narrow spelling variants, altered-version rejection and temporary versus blocked search failures.

Release build, lint and unit results are appended after completion. No Android emulator or physical phone is connected. Actual APK import timing, bundled-engine behavior on the phone, audible recording identity and Android lifecycle behavior still require device verification. This release does not guarantee zero future failures or certify public-release readiness.

The source cache holds at most 512 public recording matches for seven days; it never stores audio or Spotify credentials. Playback and existing visual styling remain unchanged. Source packaging excludes keys, local SDK paths, build caches and ignored diagnostics.

Final checks passed: release assembly, all 98 unit tests (0 failures/errors), and release lint (0 errors / 66 warnings).
