# Syntix V7 verification — 2026-11-02

## Scope and implementation

Native Android extension only: Search, Create, Statistics and Downloads. Existing layout, playback, library, import, profiles and authentication behavior remain the baseline. Application ID remains `app.skipline.android`, minimum API 31, version code 7 / version name 0.7.0. Production certificate is retained; keep the existing 0.6 APK separate.

- `NativeSearch.java`: live global keyword autocomplete and YouTube song/channel results; 20 discovery themes with two live metadata rails per theme. `Extractor.search` requests up to 30 YouTube results. The APK extracts public metadata directly, without a localhost server. The 20 bundled theme JPEGs are standalone decorative artwork copied from the approved mockup, not fabricated song results.
- `StatisticsScreens.java`: top-three artist summary, separate Expand view leaderboard, ascending/descending ordering, and listening/data/battery graphs grouped by hour, day or month. Empty activity starts honestly; no demo statistics text is shipped as recorded activity. Chart data is also available as text.
- `ActivityStats.java` and `StatsTime.java`: per-profile hourly SQLite observations from this update onwards. Playback events track `isPlaying`, excluding pauses and buffering. Old listening history is not converted into estimates. Records older than three calendar months are pruned on writes and reports, with SQLite `secure_delete` enabled. Traffic is app UID receive/transmit traffic, including downloads, attributed to the active profile; unsupported counters show unavailable. Battery data is observed whole-device percentage drop during unplugged playback, normalized by observation time, not app-only battery consumption. Storage failures present an unavailable state.
- `DownloadScreens.java` and `DownloadedDocuments.java`: searchable inventory of actual completed internal files plus accessible SAF documents successfully exported or explicitly opened from this update onwards. Missing/revoked documents are excluded. Older external files require Open local audio. Internal partial files are excluded by `OfflineStore`.
- Integration hooks: `NativeScreens` routes new pages and exposes Statistics from profile/drawer; `MainActivity` opens the two-action Create sheet and records local document opens. `SkiplineApp` initializes statistics and handles profile switching/history reset; `PlaybackService` supplies playback events. `DownloadService` records successful SAF audio exports; the offline store/service applies quality selection to new downloads.

Standard is the default and preserves original source audio. Compact is optional 16 kbps Opus for new offline downloads at lower fidelity; it does not rewrite existing files or guarantee a fixed collection size such as 60 MB. No Google authentication change was made.

## Build and review evidence

- Final `assembleRelease`, `lintRelease` and `testDebugUnitTest` completed successfully together. Full lint: 0 errors, 55 warnings. APK signature verified with apksigner (v2); certificate SHA-256 matches V6: `a3e24ba7f432a86074664663f9f2e5a7752ca9eb073e8df439498725c47d90e3`.
- Latest `testDebugUnitTest` and full `lintRelease` rerun: BUILD SUCCESSFUL. All 11 JVM tests passed: StatsTime (3), Links (5), OfflineStore (3).
- The first full lint run found 285 existing `UnsafeOptInUsageError` instances across five classes. Explicit opt-in annotations fixed those errors; the successful rerun retains warnings. This is not a claim of zero lint warnings.
- Source finish review found no source bugs; its visual disposition was recapture, not visual ship approval.
- `npm run dev` was attempted and returned EADDRINUSE because a preview server already occupied the port. This was not a policy rejection and is unrelated to APK runtime dependencies.

## Native validation still required

No ADB devices were connected and no emulator was installed for V7. No V7 native visual capture, device playback/download/airplane-mode check or battery measurement was performed. Build/JVM/source evidence does not establish native appearance, runtime stability, live-source availability or energy savings. Approved mockups and web previews are design references only.

APK badging confirms Syntix, application ID app.skipline.android, versionCode 7, versionName 0.7.0, minSdk 31, targetSdk 35, ARM64 and ARMv7. V6 APK is preserved; V7 is packaged separately as Syntix-0.7.0.apk with a SHA-256 sidecar and corresponding source archive.
