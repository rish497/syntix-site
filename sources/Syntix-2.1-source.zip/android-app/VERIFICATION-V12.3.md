# V12.3 unified playlist import

Create replaces the two provider-specific playlist actions with one Import playlist action. Its shared sheet accepts YouTube or Spotify links and detects the provider using the existing validated link parsers. Spotify shares and recovery actions reuse that sheet with their supplied link prefilled. YouTube playlist submissions enter the existing save/name/import path directly; single-video links retain their existing handling.

The native UI regression test checks the unified Create action, absence of the two provider-specific menu entries, retained YouTube video action and shared input prefill for either provider. Existing link validation, auto-save, skipped-result dismissal and playback-priority tests remain. No new network client, playback code, audio download or advertising integration is introduced.

Physical-phone import/playback testing and latency measurement remain pending. Spotify public-list availability and matching limitations are unchanged. Release assembly, lint and unit results are recorded after the build. Existing production signing identity is retained; source packaging excludes signing keys and local build caches.

Release build and all 84 unit tests passed, with 0 failures/errors. Release lint found no errors.
