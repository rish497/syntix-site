# V12.2 import-result popup

Version 0.12.2 / code 22, Android 12+, existing production signing key.

The completed Spotify import is consumed before posting its result dialog, so normal page refresh/navigation cannot replay it. Only imports with a nonzero skipped count show the native themed Playlist imported dialog with imported/skipped counts and an OK action. The dialog follows saving and opening the playlist. It contains no notice about future display behavior. Successful imports without skipped entries do not show completion notifications. Partial/unverified source counts remain disclosed when relevant.

Release assembly, release lint (0 errors) and all 83 unit tests passed (0 failures/errors). Verification includes native tests for skipped-count dialog contents, OK dismissal and no replay after refresh, plus the silent all-matched path. Existing import cancellation/profile/deduplication tests remain. No physical-device test or playback-speed measurement is claimed; playback code is unchanged.
