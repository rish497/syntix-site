# Syntix V6 (0.6.0) release candidate

Android 12+ (minSdk 31), targetSdk 35, versionCode 6, ARMv7 and ARM64. Application ID app.skipline.android retained. Production certificate SHA-256: a3e24ba7f432a86074664663f9f2e5a7752ca9eb073e8df439498725c47d90e3. Same key as production V4/V5; credentials stay outside the project and must never be shipped.

Adds the selected Immersive first-launch carousel, optional native local name/photo setup, first playlist import, and explicit offline playlist audio downloads. Queue/partials persist, downloads run sequentially with Wi-Fi-only default and pause/resume controls. Playback resolves completed local audio first. Profile switching is blocked while download startup/running or deletion is in progress. Manual saves and playlist downloads have mutual service guards. No automatic bulk audio preparation returns.

Build: tools/build-android-release.ps1. Package: tools/package-android.ps1. Send Syntix-0.6.0.apk directly to a phone; ZIP extraction is unnecessary. APK checksum/size and certificate are in ARTIFACTS.txt.

Source review and automated build checks do not prove Android runtime behavior. No connected device was available; the prior emulator-launch attempt was rejected by automatic approval review with "blocked by policy". Device verification of onboarding/swipe/font scale, extraction, download pause/resume, network transitions, airplane-mode playback and service lifecycle remains required before public release. Android may stop long-running data-sync services; resume explicitly in the app.
