# Google Play package

The Google Play listing uses `app.syntix.android`. Build its signed bundle with
`bundleRelease -PsyntixApplicationId=app.syntix.android` using the production
signing environment described in the release build script.

The default application ID remains `app.skipline.android` for existing direct
APK installations. The Play package installs separately and does not inherit
the old package's private profiles, library or downloads. The Java namespace
remains `app.skipline.android`; Android Gradle generates the Play manifest with
the existing fully qualified component classes.

Public version: 0.1.0. Internal version code: 31. Compile and target API: 36.
