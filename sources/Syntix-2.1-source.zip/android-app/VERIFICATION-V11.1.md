# Syntix V11.1 — Smart Mix correction

Version 0.11.1, code 17; same application ID, Android 12+ requirement and production signing identity as V11.

Each generated mix is visible only when its own history filter produces at least 50 distinct song sources. The generated playlist remains capped at 50 tracks. Home omits the entire Smart Mixes section when no mix qualifies. The all-mixes page applies the same filter; restored/stale detail routes expose no Play or Save action for a mix that no longer qualifies. Previously saved Library playlists are not removed or changed.

Mix cards use real song artwork: a single image, two-image split or four-tile collage, selected from distinct thumbnail URLs within the mix. Titles and counts use the existing slate/ivory/Outfit playlist treatment below the artwork. No gradient artwork, generated cover images or screenshot crops are used. Missing thumbnail metadata falls back to the exact supplied Syntix symbol on a solid app surface. Image loading uses the existing bounded artwork caches and workers; there is no bulk audio preparation.

Regression coverage adds boundaries at 49/50 eligible songs, independent per-mix thresholds and duplicate-source exclusion. Release assembly, release lint and the full unit suite passed: 52 tests, zero failures/errors/skips, lint zero errors and 62 warnings. The production certificate is unchanged. Art composition reuses native image/playlist views; it has not been visually verified on a connected phone. V11's real-device visual/audio acceptance remains pending; native test renders are not device evidence.
