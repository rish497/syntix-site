# Syntix V10 verification

Release: 0.10.0, version code 14, application ID `app.skipline.android`, minimum API 31 (Android 12), target API 35.

## Baseline and scope

The pre-edit Android source matched `syntix-v9-3-android-source.zip` byte for byte. V9.3 is the requested baseline; V9.4 is not the baseline. `PlaybackService.java`, `Extractor.java`, `PlayerScreen.java` and `OfflineDownloadService.java` remain byte-identical to V9.3. No `PlaybackCache` exists.

Native Statistics lives in `StatisticsScreens.java`, `StatsSeries.java` and `StatisticsPlot.java`; `NativeScreens.java` delegates Statistics and reads Settings/About version copy from PackageInfo. Existing ActivityStats records provide all displayed activity. No browser runtime, fixture activity or sample rankings are used by the APK.

## Validation status

The initial build passed 31 unit tests and release lint with 0 errors and 56 warnings before the spoken-value precision correction. That initial result is not final validation of the latest source.

The correction adds a dedicated spoken-value formatter and three regression tests covering sub-minute listening, small network readings and missing versus measured-zero battery readings. `StatsSeriesTest` contains five tests for retained partial months, India half-hour alignment, daylight-saving calendar days, weighted battery rates and selected-window network totals. `StatsChartAccessibilityTest` contains three formatter regression tests; these do not constitute an on-device TalkBack test.

Final validation of the corrected source passed: **34 unit tests, zero failures/errors; release lint 0 errors and 56 warnings; assembleRelease succeeded**. The scoped source reviewer accepted the spoken-value correction and returned **ship within the source-review scope**. Native visual and TalkBack verification remains outstanding.

Binary DEX inspection found no old View chart data, Expand view, Most first or Least first labels, and no V9.4 replay-cache path. `aapt` verified application ID, version 0.10.0, version code 14 and minimum API 31.

## Release artifacts

- Installer: repository-root `Syntix-0.10.0.apk`.
- Source archive: repository-root `syntix-v10-android-source.zip`.
- Packaging: `tools/package-syntix-v10.ps1`; excludes build caches, local SDK configuration and signing keys from the source archive.
- `apksigner` verified the existing production certificate SHA-256: `a3e24ba7f432a86074664663f9f2e5a7752ca9eb073e8df439498725c47d90e3`.
- Signed release APK size: **121,213,972 bytes**, below the 500 MB limit.
- Signed release APK SHA-256: `be2b776bf18b50ab12b1aeb826e0fd85e500a1d94be8c71df6e1bb6ef062aa64`.
- Packaging and final source archive verification follow these checks; the source ZIP must include this final verification record.

The APK is a same-key direct update; existing app data is retained without uninstalling first. The ZIP is source material and is not required to install the APK.

## Native checks still unperformed

No ADB device was attached and no native V10 screenshot or screen recording was captured. Approved browser images are reference evidence only and cannot establish exact phone appearance.

On-device checks remain for text scaling/insets, all chart touch and keyboard actions, TalkBack announcements/actions, vertical scrolling, independently remembered periods, and absence of page jumps during metric changes. Confirm the real-profile empty/unavailable states, full artist ranking, rolling month boundaries and same-key update with retained data on a phone. Playback and download behavior was preserved at source level; this release has no new device playback or energy measurement evidence.
