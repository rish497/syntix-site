# Syntix 0.9.3

Version code 12. Launcher-only refinement: the supplied Syntix PNG remains unchanged, displayed as an adaptive foreground over explicit solid black. Both standard and round launcher references use this icon; Android retains control of the launcher mask. The inset keeps the supplied mark inside the adaptive-icon safe region. In-app branding, player, playback and all other behavior remain unchanged from 0.9.2.

Release assembly, lint and production-signature verification accompany the package. No new tests are added for this resource-only refinement and no phone launcher screenshot is available.
