# V12.1 automatic Spotify import

Uses the existing slate/ivory native sheet and progress page. The primary action is Import playlist. CSV import entry points and Activity file-picker state/callback are removed. The metadata parser's internal CSV helpers remain unused by the app; historical documentation describes older releases.

Reading a public link immediately starts automatic metadata matching. When all available rows have been attempted, the app deduplicates confident YouTube matches, saves an ordinary playlist under the Spotify title and opens it. There is no match-review UI, save confirmation or playlist-name sheet in this path. The existing playlist rename action remains available.

Incomplete/unverified public lists remain disclosed during import and in the completion message. Uncertain matches are omitted and counted; an all-unmatched import produces an error instead of an empty saved playlist. Cancellation, task dismissal, wrong profile, pending work and duplicate completion callbacks cannot commit a playlist. The first saved track receives the existing stream warmup when the playlist opens. Native playback, Downloads, Equalizer, Sleep Timer, statistics and app branding remain unchanged.

The V12 buffering priority gate and two-request matching limit are preserved. This is a metadata snapshot, not synchronization, Spotify audio playback or bulk audio download. Native progress rendering is test evidence, not phone acceptance.
