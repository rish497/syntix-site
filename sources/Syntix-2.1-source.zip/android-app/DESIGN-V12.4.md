# V12.4 Spotify search reliability

Keep the existing native slate/ivory theme and shared Import playlist entry. This release changes the metadata search implementation, not the app identity or playback UI. Spotify continues to supply track metadata only; playback stays in the existing player.

Use yt-dlp's supported ytsearch20 metadata extractor for Spotify matching. Do not use the direct results-page HTML scraper for this path. Run one background matching worker, pace engine requests and retain the existing buffering gate. Each search has its own process ID so cancelling an import targets its metadata searches without cancelling playback stream resolution.

Cache successful public recording matches for seven days with a 512-entry limit. Cache lookups revalidate identity; expired/malformed entries are dropped and cache-write failures cannot fail an import. No audio, authentication data or playlist membership is stored in this cache.

An interrupted/blocked search leaves rows pending and cannot commit an incomplete successful playlist. A genuine completed search with no acceptable recording can still be skipped. Keep counts truthful. Existing automatic save/open and conditional one-time result dialog remain in place.

For matching, accept a credited artist rather than requiring all collaborators; preserve title and version checks. A repeated-letter romanized title variant is eligible only for a multiword title, one variant word, strong artist evidence and an eight-second duration difference or less. Boosted/8D/reverb and other altered versions are rejected unless the source specifically requests that version. Artist-channel evidence improves ranking; it is not proof of upload ownership or audio fidelity.

Physical-device layout/playback/lifecycle verification remains pending. No new animation or visual surface was needed for this change.
