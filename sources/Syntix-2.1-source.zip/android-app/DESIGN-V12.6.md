# V12.6 stable progressive UI and faster matching

Keep the existing slate/ivory native UI. This is a performance/refresh fix, not a visual redesign.

Root cause of repeated import flicker: SpotifyProgress.persist calls saveLibrary -> changed -> MainActivity.refresh -> NativeScreens.render, which removes the entire root content and recreates song rows, artwork and chrome for every progress event. Import-only persistence now carries a scoped update flag. MainActivity updates the existing binding in place. Stable row holders retain their views when their resolved source is unchanged; newly playable rows alone receive the existing NativeScreens.track controls. Preserve the ScrollView and unrelated song views. Initial navigation, normal edits and completion retain the regular screen lifecycle.

Prefer one public YouTube search JSON POST per query using the import-owned pooled OkHttp transport. Client metadata follows yt-dlp's current WEB client configuration. The app's existing renderer parser converts real videos into Tracks, and the unchanged SpotifyMatching confidence checks select a recording. Do not seed diagnostic results or weaken matching to hit a timing target. No Spotify audio extraction, credentials or new audio download is involved.

Use the existing yt-dlp route if the lightweight metadata route is unavailable; suppress repeat lightweight failures within that job. HTTP 429/403 or verification redirects stop matching rather than cycling clients/proxies. Priority preemption cancels the import's HTTP calls and metadata subprocesses, never playback transport.

Primary implementation reference: https://github.com/yt-dlp/yt-dlp/blob/master/yt_dlp/extractor/youtube/_base.py . This internal metadata format may change; fallback is necessary. No new subscription or developer key is configured.
