# Syntix Android product contract

Android 12+ native listening app, approved Reference composition with immersive slate/ivory colors. No signup backend: local profiles, photo references, switching, separate libraries/history/Favorites. No verified Google/phone identity or cloud sync.

Navigation: Home, Search, Your Library, Create. Profile drawer: profile, add/switch profile, Recents, Settings and privacy. Favorites is pinned in Library. Heart songs from rows and player. Play and Shuffle stay inside playlist detail; listening order is a sheet.

Named public playlist imports, single-song additions, real public search, media playback service, manual downloads, local files, speed, Undo and portable playlist/Favorites backups. No YouTube UI injection, Accessibility automation, bulk audio preparation or readiness banners. Recommendations aggregate retained listening history rather than only the current track.

Account information stays small (10 names and URI photo references). Downloaded music is not subject to a 100 MB cap; APK limit 500 MB. Source extraction/runtime and libraries also occupy storage. Preserve existing app ID and production certificate for V4 upgrades.

Release candidate: compile, existing unit tests and release lint passed. Native device validation unavailable because emulator launch was policy blocked. No claims that Android 17 playback issues are proven resolved. Extension and landing page remain outside this change.


## V6 additions
First-launch Immersive carousel appears once on V6 upgrade/new install; local name/photo setup and first import are optional. Explicit Download playlist saves per-profile audio for offline playback. Completed files resolve before network streams, pending downloads/partials persist, Wi-Fi only defaults on, pause/resume/remove remain user actions. Android may interrupt downloads; user resumes from the app. No automatic playlist preparation or global readiness banners. No device validation yet; see VERIFICATION.md.

## V7 additions

Version 0.7.0 (code 7, minimum API 31) extends the existing native app with live global YouTube autocomplete, 20 decorative discovery themes and real music metadata, a two-action Create sheet, Statistics and Downloads. Public metadata extraction runs inside the APK; it has no local preview-server dependency. Google authentication is unchanged; profiles remain local.

Statistics begin with playback observed from this update onwards, without reconstructing old history. Per-profile hourly SQLite records retain three calendar months. The summary shows the top three artists; Expand view opens the complete leaderboard with ascending/descending sorting. Listening, UID network traffic and observed device discharge each have Hour/Day/Month graphs. Battery figures describe whole-device discharge during unplugged playback, including other device activity. Clearing listening history resets that profile's statistics.

Downloads lists completed internal audio and accessible documents explicitly exported or opened from this update onwards. Older external files require Open local audio. Standard remains the default and preserves source audio; optional Compact transcodes new offline downloads to 16 kbps Opus at lower fidelity. Existing files stay unchanged; no 60 MB storage guarantee is made. See VERIFICATION-V7.md for build evidence and unperformed native checks.

## V8 additions

Version 0.8.0 (code 8, Android 12+) adds a native Library eye control opening an end drawer with Recent/A–Z and List/Grid radio choices, saved separately for each local profile. Downloads has a centered empty state, primary Add local audio action and offline management. V8 supersedes V7's quality choice: all newly downloaded audio, both internal and SAF exports, is re-encoded to 16 kbps constant-bitrate Opus, including Opus source files. This reduces fidelity; existing saved files are not rewritten. Video resolution selection is unchanged.

Search shows plain keyword and artist suggestion rows. The keyboard hides the mini-player and bottom navigation; dismissing it restores that chrome while retaining the input and submitted search. Three distinct discovery mood hashtags rotate by the local calendar day, refresh while the UI is active or resumes, and open live genre results. They are app-curated discovery themes, not official YouTube trends.

Public HTML metadata supplies first-page results before a bounded continuation, with yt-dlp fallback. A coalesced 32-entry persistent metadata cache is fresh for six hours and retained up to seven days; cached results can display immediately. Artwork has separate bounded disk HTTP and memory caches. Idle Wi-Fi warming is limited to two Made For You metadata queries, with no bulk music download. These changes do not guarantee a half-second cold-network response.

Statistics retain the same version-1 activity database and real profile records. V8 fixes the SQLite secure-delete PRAGMA cursor handling that could prevent database access. Unavailable data remains an unavailable state, with technical details in logs.

Task dismissal requests playback, download and background-search cancellation. Locking the phone or switching apps continues active audio; idle background work pauses when there is no playback, pending play or download. Foreground return and notification playback resume work. Actual phone lifecycle, gesture, visual and energy behavior remains unverified; see VERIFICATION-V8.md.

## V9 additions

Version 0.9.0 (code 9, Android 12+) continues the same application ID and signing identity. Playlist detail uses icon actions for adding, downloading, shuffling and playing, with song count, total known duration and individual song durations. A partial duration total carries a plus sign when some durations are unavailable.

The playlist download action opens one scoped native sheet with Start download, Pause download or Continue download according to state; completed playlists show Downloaded. Saved counts, waiting counts and saved bytes refer to that playlist. The separate duplicate Offline action and old playlist introduction are removed. Profile-wide offline management remains available from Downloads; its removal confirmation explicitly covers that profile's downloaded audio and partials.

Create adds explicit Import YouTube video alongside playlist creation/import. Single-video links save metadata in a separate per-profile Imported videos collection, visible as a Home rail with a full-list destination. Repeated sources are deduplicated. A video link containing playlist context imports only that video; playlist-only links are rejected by this action. Import does not download media or add a video player: listening continues through the incumbent audio playback service.

Song actions distinguish Rip the audio (export a device file) from Download for offline listening (internal Syntix storage). New audio in both paths retains V8's 16 kbps constant-bitrate Opus behavior and reduced fidelity; existing files are unchanged. The artwork-led player shows playlist/queue context, real shuffle and loop off / playlist / song states. Playback mode choices persist per local profile through session preferences.

Source review's scoped disposition is ship after one download-scope defect was corrected. This is source review only: no attached ADB device, native V9 capture or phone playback timing evidence was available. See VERIFICATION-V9.md for build evidence and remaining native checks.

## V10 additions

Version 0.10.0 (code 14, minimum API 31, target API 35) extends the V9.3 Android source, not V9.4. It keeps application ID app.skipline.android and the existing production signing identity. PlaybackService, Extractor, PlayerScreen and OfflineDownloadService remain byte-identical to V9.3; no PlaybackCache is introduced. Settings/About reads the installed version through PackageInfo.

Statistics uses real per-profile ActivityStats database records only. The overview shows numeric artist ranks 1–3 and an adjacent plain arrow opening the complete ranking. V10 supersedes the earlier Most/Least, Expand view and View Chart Data controls. Each metric starts at Day and independently cycles through Hour, Day and Month using a text-only control without arrows. Switching periods redraws only that metric from the loaded report, without refetching, a loading spinner or a whole-page refresh.

Listening time uses bars, data usage an area/line chart and battery usage narrow stems. Points support touch, keyboard and TalkBack inspection directly in the chart. Hour contains 24 locally aligned hourly buckets, including half-hour time zones; Day contains 30 calendar days across daylight-saving transitions. Month covers the full rolling three-calendar-month retention window, including both partial endpoint months, so it commonly has four calendar labels. Battery rates are weighted by observed unplugged playback time and describe whole-device discharge, including other device activity; they do not isolate app battery use. Network figures describe Syntix UID traffic, including downloads.

Approved browser studies are design references only. Native phone appearance, gestures and TalkBack behavior still require attached-device verification. See VERIFICATION-V10.md for final build/review status and INSTALL-V10.txt for the direct APK update path.

## V11 additions

Version 0.11.0 (code 16, minimum API 31, target API 35) retains application ID `app.skipline.android` and the existing production signing identity. The profile drawer adds Equalizer, Sleep timer and Syntix Replay; Home adds Smart Mixes; Settings adds Download quality. Custom playlist covers are excluded.

Equalizer processes decoded 16-bit PCM inside the existing Media3 playback service with seven software bands, independent of vendor effect support. Presets, saved custom bands, Bass boost, Stereo width, playback volume and Even volume persist per local profile. Equalizer and Even volume default off, providing a direct PCM copy on bypass. Even volume uses a smoothed energy envelope and output limiting; it is not integrated-loudness mastering. The existing extraction, cache and playback-start infrastructure is preserved apart from the PCM processor and service-owned timer; no startup network work is added.

Sleep timer offers 15/30/45/60 minutes or the end of the current song, with optional final-30-second fade. Its service-owned monotonic countdown survives Activity recreation and screen lock. Cancel restores the volume multiplier; task dismissal and profile switching cancel the timer. It does not persist a timer across process termination or restart playback.

Smart Mixes contain up to 50 tracks from that profile's retained listening history: Late Night uses observed 9 pm–5 am plays; Most Played uses play totals; Forgotten Favorites uses tracks played at least twice and untouched for seven days; Recently Discovered uses first listens within 30 days. Mixes can be played or saved to Library. V11 begins recording first-listen and night-play metadata without inventing legacy details; older play totals remain useful. Empty mixes explain how listening builds them.

Replay reads actual profile/hour activity and artist totals from the retained SQLite database. This month and last month are available within the existing retention window, with real empty and unavailable states. A monthly invitation appears once per profile on its first eligible foreground Home visit in a new month, only when the previous month has recorded listening. It has no background alarm or notification. Sharing explicitly generates a report-derived PNG in one bounded cache file and opens Android's share chooser with a scoped FileProvider URI.

V11 supersedes V8/V9's fixed future offline-download bitrate: Compact 16 kbps remains the default; Standard 128 kbps and High 192 kbps Opus are optional for future internal offline audio downloads. The separate Rip the audio export path retains its existing 16 kbps behavior. Existing files are unchanged. Audio bitrate remains separate from video resolution; estimates depend on duration and encoding overhead and do not promise a song-count storage size.

Build, lint and unit validation succeeded; finish review requires **RECAPTURE** on a real phone or emulator, including font scale 1.3. Robolectric renders are test evidence only. No on-device visual, playback latency, battery or performance claim is made. See VERIFICATION-V11.md.


## V11.1 Smart Mix correction

Generated mixes appear only after their own filter yields 50 distinct songs; Home hides the Smart Mixes section if none qualify. All-mixes and restored detail routes apply the same gate. The 50-track cap remains. Covers now use actual song thumbnail collages with normal Syntix typography and solid slate surfaces; no generated gradient artwork. Missing thumbnail metadata uses the exact existing Syntix symbol. Previously saved Library playlists remain unchanged. See VERIFICATION-V11.1.md.


## V11.2 navigation, sound and timer controls

Replay and its automatic invitation/sharing provider are removed. The Settings page and profile/sidebar links are removed. Downloads now has a gear opening a native quality-selection sheet (16/128/192 kbps, future offline downloads only). Equalizer uses solid ivory/slate bands, live dB values, clear bypass, grouped controls and scoped reset; saved sound data and the actual DSP are retained. Sleep Timer adds custom hours/minutes and device-format clock scheduling with Today/Tomorrow context; elapsed durations and chosen clock instants use their appropriate clocks. Sidebar feedback is an explicit subtle grey ripple. The V11.1 Smart Mix threshold and actual artwork stay intact. See DESIGN-V11.2.md and VERIFICATION-V11.2.md.


## V11.3 — Spotify metadata import

Public Spotify playlist links and local track-list CSV files can be reviewed and matched to YouTube before saving. Partial previews explicitly show their limits; CSV supports up to 5,000 entries without a 100-row cutoff. This is a metadata snapshot, not Spotify audio playback or automatic synchronization. See DESIGN-V11.3.md and INSTALL-V11.3.txt.


## V12

Spotify link import and optional full-list CSV are released as version 0.12.0. Automatic matching yields while the player buffers, without blocking playback. Existing ad-free native playback and theme are preserved. See INSTALL-V12.txt and DESIGN-V12.md.


## V12.1 — automatic Spotify import

Supersedes V12 import UX: public-link import automatically matches, saves and opens a playlist. CSV and manual match review/save/name steps are removed from the app flow. Unmatched/duplicate recordings are counted and skipped; partial public lists remain disclosed. See INSTALL-V12.1.txt and DESIGN-V12.1.md.


## V12.2 — import result

After saving/opening an imported playlist, show a one-time native imported/skipped count dialog only when entries were skipped. It has an OK action and does not reappear on playlist reopening. All-matched imports open silently.


## V12.4 - Spotify matching reliability

Spotify playlist matching uses paced yt-dlp metadata searches with a bounded local recording-match cache. Blocked/interrupted searches remain pending instead of becoming skipped songs. Existing playback and design remain unchanged. See INSTALL-V12.4.txt and VERIFICATION-V12.4.md.


## V12.5 progressive Spotify imports

Public metadata saves and opens a partial playlist before matching finishes. Pending song rows are distinct from playable Tracks. Resolving adds real YouTube tracks incrementally; tapping pending metadata prioritizes that row. Saved draft progress resumes when opened after restart. Queue merging preserves existing relative order and media IDs. Manual removal and import cancellation do not discard saved partial playlists. Whole-playlist offline download waits until matching is complete. No new audio downloads run on import, and no phone latency guarantee is made.


## V12.6 import refresh/performance

Import-only progress updates preserve the screen and unchanged rows instead of recreating root content. Spotify metadata queries prefer pooled HTTP JSON with the existing yt-dlp search as format/transport fallback; recording-confidence rules and interruption semantics stay intact. Fresh desktop production Java audit: 60/60 distinct matches, zero errors, 36.764 seconds, excluding initial Spotify metadata fetch and audio startup. Phone timing remains unmeasured.


## V13 first-run and software information

Version 0.13.0/code 27 retains Android 12+, app ID and production key. Fresh onboarding presents three manually swiped welcome pages, local name/photo setup, explicit unchecked Terms acceptance with Privacy acknowledgement and import-first activation with Search/Home alternatives. Existing completed listeners are not forced through the tour again. New additional profiles require the same explicit check; existing profile edits remain available. Only legal version/timestamp metadata is added locally. No identity backend or child-consent mechanism is claimed. The software section exports bundled version-matched application sources; exact native license/source verification remains an open distribution item. No change to the fast metadata matcher or playback loader.
