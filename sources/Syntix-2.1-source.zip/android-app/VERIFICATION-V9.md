# Syntix V9 verification — 2026-11-02

## Scope

Native Android application `app.skipline.android`, version name 0.9.0 / code 9, Android 12+ (minimum API 31). Deliverables are `Syntix-0.9.0.apk` and optional `syntix-v9-android-source.zip`. Preserve the existing signing identity and older release APKs. The extension and landing page remain outside this update. Exact theme/logo assets are retained; no new raster assets are introduced.

## Source-grounded behavior

- Playlist detail uses icon actions, song count, total known duration and per-song duration. Unknown durations remain unavailable; partial totals use a plus sign. One playlist download sheet provides Start/Pause/Continue and completed state with playlist-scoped saved counts, waiting counts and bytes. The duplicate Offline action and old introduction are removed.
- Create supports explicit single YouTube video import. `Links.singleVideo` canonicalizes a video URL independently of playlist context and rejects playlist-only/lookalike-host inputs. `ImportedVideos` stores deduplicated metadata through per-profile preferences. Home shows the collection rail and a full-list destination. Import does not prepare offline media or introduce video playback.
- Song actions separate internal Download for offline listening from Rip the audio through the native export flow. Both new-audio paths retain V8's 16 kbps constant-bitrate Opus behavior; lower fidelity and unchanged existing files remain part of the product contract.
- The native player uses square artwork, playlist/queue context and Media3 shuffle/repeat state. Loop cycles off, all and one; shuffle and repeat settings are saved in the active profile's session preferences and restored by the playback service.

## Review disposition

Source finish review disposition: **ship within the reviewed source scope**, after one playlist-download scope defect was corrected. Playlist-scoped progress no longer reports unrelated pending work as that playlist's activity. Profile-wide removal remains explicitly labeled in its confirmation. This disposition does not establish native visual or interaction signoff.

The existing DESIGN.md token frontmatter and `.impeccable/design.json` are preserved. Pre-existing token/sidecar drift was not repaired or promoted into a new visual authority.

## Build and package evidence

The final V9 build completed assembleRelease, lintRelease and testDebugUnitTest after the download-scope and offscreen progress-timer corrections: 23 tests passed with no failures/errors; release lint reported 0 errors and 57 warnings. Coverage includes canonical single-video imports and invalid links, per-profile imported metadata and duplicate prevention, offline queue completion/reopen, partial duration totals, SQLite statistics startup and existing metadata behavior.

The release APK is 121,204,332 bytes (121.2 MB). apksigner verifies its v2 signature with the existing production certificate SHA-256 `a3e24ba7f432a86074664663f9f2e5a7752ca9eb073e8df439498725c47d90e3`. APK metadata identifies `app.skipline.android`, version code 9/name 0.9.0, minimum API 31, target API 35, arm64-v8a and armeabi-v7a. The packaging script preserves older APKs and excludes signing keys, local SDK paths and build caches from the optional source archive. The root APK is copied from this signed release and accompanied by a SHA-256 checksum.

## Native validation still required

No attached ADB device or native V9 capture was available. No phone import, scoped-download pause/resume, export picker, offline playback, shuffle order, end-of-queue loop, screen-lock/task-dismissal, update-data-retention or accessibility gesture checks were performed. Validate those flows on an actual Android 12+ device, including profile switching and unavailable metadata/source states.

No half-second phone playback, cold-network timing or battery saving claim is established. Source review and JVM/build checks do not prove phone appearance, runtime source availability, lifecycle reliability or listening latency. Approved mockups and historical captures remain references only.
