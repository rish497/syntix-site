# V12.6 verification

Version 0.12.6 / code 26; Android 12+; existing production signing identity.

## Live fresh-search audit

1. Initial pooled Python HTTP probe: 60 public metadata queries completed in 31.56 seconds, without a song-match cache. This tested endpoint/connection overhead only.
2. Separate production Java audit compiled the actual Track, SpotifyPlaylist, SpotifyMatching and YouTubeMetadata sources and used the same OkHttp settings as the import job. All 60 distinct recordings matched in 36.7638707 seconds, 60 distinct video IDs, zero errors. The unchanged matcher generated its real queries and used alternate queries when required. No saved candidate responses were used in this production run. No cookies, Spotify tokens, login, proxies or audio files were used.

Dataset: supplied 50-song Sidhu Moose Wala Radio snapshot plus 10 distinct songs exposed by the user's other supplied public playlist. Timing starts after Spotify metadata is available and includes actual search requests, parsing and matching. It excludes metadata fetch, APK initialization, audio stream resolution and offline downloads. This is a desktop measurement, not a physical-phone benchmark or universal 60-second guarantee.

Ignored local evidence: .site-deps/ytsearch-audit/fast-production-report.json and FastSearchAudit.java. None of these records or real song lists are packaged as application seed data.

## Regression coverage

An incremental-match regression checks that root host, ScrollView, unchanged song TextView and binding identities stay the same, scroll position is retained, and only the newly matched row changes. JSON search tests check method/path/context/query, real renderer conversion/duration/artist, and HTTP 429 stopping. Existing matching, persistence, queue identity, scheduling, UI, statistics and offline tests remain.

No phone or emulator is connected. Release build, lint, test and signature results are appended below after completion.

Release assembly passed. APK is 121,285,784 bytes, below the 500 MB limit. Release lint: 0 errors / 66 warnings. apksigner verified the existing production certificate SHA-256 a3e24ba7f432a86074664663f9f2e5a7752ca9eb073e8df439498725c47d90e3. APK metadata confirms version 0.12.6 / code 26.

Final regression run: all 108 tests passed, 0 failures/errors/skipped. The incremental screen identity/scroll test passed. The production sources are unchanged from the verified signed release build.
