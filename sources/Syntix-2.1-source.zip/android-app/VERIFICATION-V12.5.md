# V12.5 verification

Version 0.12.5 / code 25. Android 12+, same production signing identity.

Change scope: progressive persistence/UI, priority scheduling and stable queue updates. The V12.4 yt-dlp metadata matcher and confidence/version checks remain. V12.4 desktop 50/50 matching evidence is historical; it is not a new V12.5 phone benchmark.

Regression coverage: playlist metadata appears before any song resolves; pending metadata does not enter queue; disk roundtrip restores partial progress; incremental ready tracks preserve media IDs; tapped row and following songs move ahead; resolved/unavailable priority does not stall other rows; a later playback selection cancels old intent; removing/undoing a row is respected; deleting an import cannot recreate its playlist; queue merging retains manual entries and existing relative order.

No emulator or physical phone is connected. Actual first-play latency, APK network behavior and background lifecycle require physical-device verification. Whole-import network time is unchanged; perceived availability improves by removing the completion gate. Initial public metadata fetch remains required.

Release assembly, lint, unit tests and artifact/signature checks are recorded below after completion.

Release lint passed with 0 errors and 66 warnings. APK metadata confirms app.skipline.android, versionCode 25 / versionName 0.12.5, minSDK 31 / targetSDK 35. apksigner verification passed; certificate SHA-256 matches the existing production key: a3e24ba7f432a86074664663f9f2e5a7752ca9eb073e8df439498725c47d90e3. Release APK is 121,283,136 bytes, below the 500 MB limit.

Final combined release build succeeded. All 105 unit tests passed (0 failures, 0 errors, 0 skipped). Source archive excludes build caches, SDK paths and signing keys.
