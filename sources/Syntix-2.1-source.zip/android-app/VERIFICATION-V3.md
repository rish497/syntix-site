# Skipline V3 verification —29 October2026

Android7/API24 x86_64 emulator. Final native suite: **9 tests passed** in126.083s. Five URL unit tests and all17 existing extension/website regression tests passed. Release lint/build passed. The phone package targets minSdk24 and ARM32/ARM64; physical-phone validation remains outstanding.

## Evidence
- Play/Shuffle kept the named playlist screen visible; Queue opened the saved-playlist browser, and Library rendered its horizontal shelf.
- Actual local playback continued after leaving the Activity. Actual playback for five seconds populated recent history. Shuffle preserved saved playlist order.
- Controlled card fixture: two recognized cards; selecting the playlist's Share clicked that card's control, not another card's. Accessibility service binding requires android.permission.BIND_ACCESSIBILITY_SERVICE.
- Automatic preparation of a public18-second YouTube clip completed:252182 bytes cached. A disk-only read with no upstream passed. Its real ExoPlayer playback started in1183ms.
- Separate cached original-tone test:1072ms playback start, with a nonexistent YouTube ID and actual cached tone bytes. No network source could supply that audio.
- Live uncached Big Buck Bunny playback passed: extraction11431ms, stream-cache lookup0ms, repeated metadata import1ms, audio start13655ms in that run. New/uncached playback is not instant.
- History persistence/channel affinity passed; live recommendation search returned8 public candidate links.
- Earlier two-minute preparation checks of a long video timed out while still downloading, not while playing cached music. Full preparation can take minutes. Successful short-clip preparation does not guarantee fast downloads for every source.

## Limits and approval boundary
The real bundled YouTube package was present (11.19.68), but automatic approval review rejected launching and inspecting its UI with “blocked by policy.” That action was not retried through another mechanism. Real YouTube overlay/share compatibility is unverified; the fixture test is not represented as a real-YouTube test. Private/personalized playlists, localized layouts and every-card coverage are not guaranteed.

Full SAF file exports, actual Bluetooth/battery policies, newer Android background restrictions and true lock-screen appearance require physical-device tests. Native screenshots in .impeccable/review/v3-* contain explicitly labeled test data; it is not seeded into users' installs. No independent whole-surface design approval is claimed.
