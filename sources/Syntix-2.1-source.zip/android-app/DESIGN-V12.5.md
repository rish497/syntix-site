# V12.5 progressive playlist import

Preserve the native slate/ivory visual system. Import uses the existing playlist screen and icon controls, not a new wizard. Keep the shared Import playlist entry.

Save Spotify metadata as a separate spotifyDraft on SavedPlaylist. Pending metadata never becomes a playable Track or enters ExoPlayer. Render pending title/artist rows with an accessible Find and play action; resolved rows reuse existing song controls. Playlist counts/duration use available Spotify metadata while matching.

Open the saved playlist once metadata arrives. Resolve one recording at a time using the verified V12.4 search backend/cache. Prioritize a user-selected pending row and its subsequent songs; cancel only import-owned metadata processes when preempting a different row. Yield to playback buffering. Ready or failed priority requests must not stall the remaining worker.

Persist partial progress, preserve resolved Track IDs, manual additions and removals. Merge newly ready songs into an active queue without undoing existing user order. Opening a partial saved playlist restores/resumes its job; no unattended bulk audio downloads or startup-wide matching.

No indefinite spinner or hardcoded matches. Honest inline pending/error state, pause/continue and existing conditional skipped-result dialog. Partial libraries survive cancellation/process death. Cold audio latency and total network search time are not described as instant.
