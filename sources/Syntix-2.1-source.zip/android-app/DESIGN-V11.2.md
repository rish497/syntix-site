# V11.2 controls and navigation refinement

Mode: Operate. This preserves Syntix's existing Outfit typography, exact user-supplied branding and slate/ivory palette. The requested scope replaces the Equalizer composition and extends Sleep Timer; it does not introduce a new app identity.

Replay, its monthly invitation, share-card code and provider are removed. The Settings page, sidebar entry and profile gear are removed. Stale restored Settings/Replay routes recover to Home; the former quality route recovers to Downloads. Statistics, profiles, playback and Smart Mixes remain.

Downloads replaces its right-hand brand symbol with a settings icon named Download quality. This opens the existing native Material bottom-sheet pattern with three radio choices and Done. Choices save immediately for future downloads; existing media stays unchanged. The sheet uses the app surface, ivory selected indicator and restrained grey ripple.

Equalizer keeps the seven actual PCM bands and presets, but uses solid ivory fills and neutral slate tracks instead of a multicolor gradient. Live dB values, a zero marker, a grouped band surface, explicit on/bypass switch, labeled volume and paired bass/width controls create a clearer reading order. Reset affects sound shaping only, preserving playback volume, saved custom settings and timer preferences. Controls react directly without added interpolation or input delays.

Sleep Timer has three modes: After, At a time and End of song. After includes the existing presets and a native hours/minutes duration sheet (1 minute through 23 hours 59 minutes). At a time uses Android's clock picker and device 12/24-hour format. The screen states Today or Tomorrow; a passed clock time uses its next occurrence. A repeated daylight-saving hour can use the second future occurrence, and nonexistent local times resolve to a valid instant. Duration timers remain monotonic; clock timers track the selected wall-clock instant. Both remain owned by the playback service and restore volume on cancellation.

Sidebar rows use explicit translucent white/grey ripple feedback, replacing the platform list selector. Existing native drawers, sheets and pickers own motion and dismissal; high-frequency audio controls remain immediate. No browser animation framework or generated artwork is added.

Native graphics tests are development renders, not device screenshots. Physical-phone visual, audio and lifecycle verification remains pending; the old review recapture requirement is not represented as resolved.
