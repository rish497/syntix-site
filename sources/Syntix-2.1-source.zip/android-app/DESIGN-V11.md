# V11 listening features

## Direction contract

THESIS: extend the existing native app with personal listening tools. Preserve current Home, Search, Library, Downloads, Create, player and statistics behavior outside the requested additions. Do not ship custom playlist covers.

OWN-WORLD: inherit Outfit and Syntix slate #171D21 / #242B30 / #30383E, ivory #E1CDAE, ink #F7F7F5, muted #BCC4C8. Keep exact supplied branding and the existing black launcher background. Equalizer uses the user's supplied vertical-control reference, with teal/lilac/ivory fills, white capsule thumbs, preset strip, playback volume, two dials and an on/off control.

STORY: open Equalizer, Sleep Timer and Replay from the profile drawer; open Smart Mix playlists on Home; select future offline audio quality in Settings. Monthly Replay opens once per profile at the first eligible foreground Home visit in a new month, only with recorded prior-month listening. No background monthly alarm or notification is needed.

FIRST VIEWPORT: native top bar and preset strip above seven tall adjustable bands. The lower area has volume, Bass boost, Stereo width, bypass, Even volume and Save preset. Content scrolls without a scrollbar, retaining the current app navigation. Other additions use existing title bars, sheets, buttons and list rows.

FORM: precise extensions in the existing Operate world. No marketing hero, AIDA page or randomized layout. Native Material drawers/sheets own their established motion; high-frequency audio controls respond directly without tweening. Respect Android animation settings through the existing components.

FINISH: unreviewed and undocumented is unfinished; this build ends with the finish review, the verdict, DESIGN.md, and every shipping raster carrying its provenance.

## Implementation boundaries

Seven software PCM biquads process decoded audio within Media3, independently of vendor equalizer band counts. Bass and stereo width are native DSP controls, not device-global effects. Optional volume balancing follows a smoothed energy envelope and limits the output; it is not an integrated-loudness mastering pass. Default bypass uses a direct buffer copy; no extraction or network request is added to song startup.

The existing playback service owns the monotonic sleep timer, fade and end-of-song stop. App dismissal cancels it; process termination cannot restart playback. Profiles store sound preferences separately. Offline bitrate defaults to the existing 16 kbps setting, with 128/192 kbps choices for future songs; estimates never guarantee a fixed size for a song count.

Smart Mixes use actual retained history. Newly observed first-listen and late-night counts begin in V11; old totals are preserved without inventing these details. Forgotten Favorites requires at least two plays and seven days away. Monthly Replay aggregates actual profile/hour activity and artist totals from the retained SQLite database. Empty months have a real empty state. Share cards are generated from the actual report via a single bounded cache file and a narrowly scoped FileProvider.

## Visual evidence and provenance

User reference: C:/Users/mitta/AppData/Local/Temp/codex-clipboard-09e2cb19-ba88-493a-90a9-c1cfdc573802.png. Existing browser study remains design evidence only, not APK evidence. Exact existing Syntix PNGs and Outfit assets are reused; icons are original vector controls. No screenshot crops, newly generated raster artwork or custom-cover editor are included in V11. Any Robolectric render is labeled a native test render, never a connected-device or emulator screenshot.

## Implemented surface record

`EqualizerScreen` implements the reference's vertical seven-band composition within existing native chrome. Frequencies are 60/150/400 Hz and 1/2.4/6/16 kHz; gain ranges from −12 to +12 dB. Presets are Flat, Pop, Custom, Rock, Bass and Vocal. Controls expose keyboard adjustment, focus and Android accessibility ranges/actions; band touch widths are at least 48 dp. Volume, two dials, equalizer bypass, Even volume and saved custom settings complete the scrolling page.

`ListeningFeatures` uses existing native controls for timer duration/song end, monthly Replay and future-download quality. `SmartMixes` supplies Home playlists from actual profile history, with native drawable covers and real empty states. Existing visual tokens and historical docs remain intact; the global `.impeccable/design.json` is unchanged by this scoped documentation pass.

## Finish review and render provenance

Disposition: **RECAPTURE**. Constrained source/render inspection found the Equalizer topology aligned with the supplied reference through the slate/ivory adaptation, including the accessible band ranges and touch widths. This does not establish real-device visual acceptance.

The following files under repository-root `.impeccable/review/v11/` are native Robolectric View graphics at 393 × 852 pixels: `equalizer-native-test.png`, `sleep-native-test.png` and `quality-native-test.png`. The Equalizer render includes app chrome; the sleep and quality renders show content only. They are neither device nor emulator screenshots, nor raster assets loaded by the APK. Replay share PNGs are generated at user request from actual report data rather than shipped artwork.

No ADB devices are attached; no emulator is installed or created. Real phone/emulator captures, including font scale 1.3 and lower-control scrolling/insets, are still required to complete the finish review. No web detector was run against these native surfaces. Build/test success and certificate verification do not constitute visual acceptance or production certification.
