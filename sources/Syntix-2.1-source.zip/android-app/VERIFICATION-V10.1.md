# Syntix 0.10.1

Version code 15. One UI change from V10: the Recents back control now uses the existing icon-only button, with a 48 dp touch target and the accessible name Back. Navigation behavior remains Home. All other production code and assets are unchanged.

Signed release assembly only; tests and separate lint checks were skipped at the user's request. The existing production signing key is retained for an in-place update. No new phone validation is claimed.
