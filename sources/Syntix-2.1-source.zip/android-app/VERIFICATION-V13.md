# V13 verification

Syntix 0.13.0 / code 27; minSDK 31, target/compile SDK 35; existing app ID and production signing identity.

## Build and tests

Final assembleRelease, lintRelease and testDebugUnitTest run passed. All 116 tests passed, 0 failures/errors/skipped. Release lint: 0 errors, 68 warnings; warnings are retained rather than described as a clean lint report. Existing Gradle deprecation/manifest packaging warnings remain. No dependencies or manifest fields were upgraded/changed.

Six new onboarding/source tests cover unchecked/default-disabled agreement, direct-call acceptance guard, readable legal links that do not silently check the box, local document-version/timestamp persistence, Activity saved-state restoration, returning-user setup preservation, new additional-profile checkbox versus ungated existing-profile edits, import/Search finish choices, source-export discovery and document-picker intent, and source ZIP absence of credentials/caches/recursive ZIPs.

The first additional-profile test mistakenly inspected a dismissed sheet while its animation was still pending; the test now checks the latest sheet. No runtime save/edit behavior was changed to mask it. The first render also found a neighboring carousel page visible at rest and a fixed-display-width compact-layout defect. Both were corrected in one batch. A second bounded render/test pass confirmed the corrections.

## Layout and interaction evidence

Native Robolectric View renders were inspected as one batched round, then one confirmation round: normal phone, compact/enlarged text (1.3), landscape and tablet dimensions. These are static native View renders, not emulator or phone screenshots. Controls retain native scrolling; compact/landscape content may require scrolling. No connected ADB device or emulator is available, so physical gesture quality, TalkBack, keyboard behavior, Android 17 and device playback timing remain unverified. No new import-speed or battery claim is made.

The one requested Impeccable mechanical scan returned an empty findings array. It is not proof of native visual acceptance or legal readiness. Existing slate/ivory tokens, Outfit fonts and exact Syntix logo assets were preserved. No added network image dependency or web/GSAP runtime.

## Integrity and scope

Compared against the prior personalized privacy release: Extractor, SpotifyImport, SpotifyProgress, PlaybackService, OfflineDownloadService, DownloadService and AndroidManifest.xml are unchanged. Existing fast matching, playback, downloads, Rip Audio and MP4 export remain in place. New acceptance applies to new-profile creation only; existing completed listeners and edits of existing profiles are not gated. A per-profile legal preferences file stores document versions/timestamp locally.

Source/legal files inside the final APK match workspace inputs byte-for-byte. The application-source ZIP matches the current production source and includes wrapper/build instructions, app resources/tests and license/doc files. It excludes user data, signing credentials, SDK/build caches and itself. Export is through Profile menu > Privacy & About > Open-source software > Save application source. It is secondary navigation, not a secret or inaccessible gesture. No repository was made public or pushed by this task.

The bundled application-source ZIP alone does not verify every native component's corresponding source or notice obligations. Worldwide child-audience eligibility, native/software licensing completeness and content/artwork rights remain the documented release items. The APK is a signed technical release candidate, not legal or store approval.

Production apksigner verification passed with certificate SHA-256 a3e24ba7f432a86074664663f9f2e5a7752ca9eb073e8df439498725c47d90e3. APK is below the requested 500 MB limit. Exact final artifact hash/size are recorded in the adjacent SHA256 file and release packaging output.
