# Syntix V8 verification — 2026-11-02

## Scope

Native Android only, application ID `app.skipline.android`, version code 8 / version name 0.8.0, minimum API 31. The existing production signing identity and V6/V7 release files are to be retained. The extension and landing page are outside this update.

## Implemented behavior

- Library: eye action opens a native end drawer with Recent/A–Z and List/Grid radio groups; choices persist per profile.
- Downloads: centered empty state, warm primary Add local audio action and offline management, with no quality section. New internal audio and SAF audio exports use 16 kbps constant-bitrate Opus, forcing FFmpegExtractAudio even for Opus input. Existing files are not rewritten. Video resolution selection is unchanged.
- Native polish: five equal navigation destinations use explicit centered full-width labels and 24 dp icons. Keyword and artist suggestions are plain left-aligned rows. IME visibility hides mini-player/navigation; hiding the keyboard rebuilds chrome while preserving input and submitted-search state. Theme washes extend across the root gutters and status bar.
- Discovery: three distinct mood hashtags rotate on the local calendar day, checked while active and on resume. Cards open live genre metadata. These are app-curated themes, not official YouTube trends.
- Search: public HTML metadata emits the first page before one bounded continuation; extraction caps results at 30 and each response at 4 MiB. yt-dlp remains the fallback. SearchCatalogue coalesces concurrent queries and bounds persistent JSON metadata to 32 entries, fresh for six hours and retained for seven days. Artwork uses an 8 MiB HTTP cache and an 8 MiB memory cache. Cached metadata can display immediately. Wi-Fi idle Made For You warmup is limited to two metadata queries, without bulk media downloads.
- Statistics: `StatsDatabase` consumes the row-returning `PRAGMA secure_delete=ON` through `rawQuery` and a cursor instead of `execSQL`. The same `activity-v7.db`, schema version 1, preserves real records and profile isolation. Storage errors use neutral unavailable copy and technical logs.
- Lifecycle: all three services route task removal to application dismissal, stopping playback and cancelling HTTP/CLI/search/recommendation work through cancellation and generation checks, while suspending statistics. Active audio continues on screen lock or app switch. UI stop pauses idle work only without playback, pending playback or downloads; completion also checks for idleness when the activity is gone. Foreground return and notification playback resume work.

## Evidence and its limits

- A real desktop metadata probe for “Imagine Dragons Believer” returned 19 first-page renderers in approximately 0.99 seconds; continuation took approximately 1.54 seconds and returned 21 additional renderers. These are desktop network observations, not phone benchmarks or proof of a half-second cold search. The app's result cap remains 30.
- A locally generated 20-second synthetic Opus 128 kbps WebM was re-encoded to Opus CBR 16 kbps. The result was 41,774 bytes, approximately 16.7 kbps including Ogg overhead. No YouTube music was downloaded for this test. This validates the desktop transcode path, not phone export integration.
- Robolectric 4.17 with native SQLite at API 31 exercised database creation, secure-delete configuration, write/reopen and profile isolation in two database tests. Robolectric and downloaded Android framework JARs are test dependencies, not an installed emulator and not included in the release APK.
- Source finish review's three specific corrections were resolved in source. Its disposition does not establish native visual ship approval.
- Final assembleRelease, lintRelease and testDebugUnitTest completed successfully together. All 17 tests passed (Links 5, OfflineStore 3, StatsTime 3, StatsDatabase 2, YouTubeMetadata 4); full lint reports 0 errors and 59 warnings. apksigner verifies APK Signature Scheme v2. Certificate SHA-256 matches V6/V7: a3e24ba7f432a86074664663f9f2e5a7752ca9eb073e8df439498725c47d90e3. Badging confirms versionCode 8, versionName 0.8.0, minimum API 31, ARM64 and ARMv7.

## Native validation still required

No ADB phone was connected. No V8 phone gesture test, native visual capture, screen-lock/task-dismissal check, playback/download/airplane-mode integration check or battery measurement was performed. Source/JVM/desktop evidence does not prove phone appearance, lifecycle reliability, runtime source availability or energy savings. Approved mockups and historical web previews are references only. No example statistics are seeded as recorded activity.
