# Syntix V6 (0.6.0) — Android 12+

Install **Syntix-0.6.0.apk** directly. No ZIP extractor needed. ARM32 and ARM64 are included. The same production signing key and application ID allow an update over production V4/V5 without uninstalling. Older development-signed apps need the existing export/reinstall migration flow.

## First launch
V6 shows the approved Immersive welcome once: unlimited listening, playlist imports, and screen-off playback. Swipe or use Continue/Back; Skip intro goes straight to optional local name/photo setup. Finish by importing a named playlist or exploring the app. Existing profiles/libraries are retained. No email, password, phone verification or authentication server. Android handles selected photo permissions. An upgrade to V6 shows this introduction once even if an earlier introduction was completed.

## Offline playlists
1. Import and save a public playlist while connected.
2. Open its detail page and tap **Download playlist**.
3. Confirm permission to download; Wi-Fi only is on by default.
4. Open **Offline downloads** on that playlist or in Settings to see progress, pause/resume, storage usage or remove downloaded audio.
5. Completed songs automatically play from the phone, without internet or the YouTube app. Songs not downloaded still require a connection.

No audio downloads start on playlist import or app startup. One low-priority download runs at a time. The pending queue and partial files survive pauses/restarts. Connection changes and Android's service limits may pause work; open the app and tap Resume downloads. Source servers may require restarting a partial file or may refuse a source. Downloaded audio is held privately for the active local profile. Removing downloads keeps playlists and Favorites; uninstalling/clearing app data removes this audio. Separate manual Save to device remains in each song's action menu, with Android choosing the destination.

## Your library
Home, Search, Your Library, Create. Heart songs to add/remove Favorites. Named playlist imports, shuffle, current listening order, playback speed, public song search, listening-history suggestions and local audio remain. No controls are injected into YouTube. Importing public finite playlists has no fixed 100-entry cap; generated Mixes are snapshots capped at 100. Private/restricted sources may fail. First streaming playback still depends on extraction/network; it is not guaranteed instant.

## Profiles, storage and backups
Local names/photo references are lightweight; up to 10 profiles have separate playlists, Favorites, history and offline files. The 100 MB account-info requirement does not cap downloaded music. Photos are referenced rather than copied. Runtime/extractor files and library/history metadata also use storage. APK limit: 500 MB; actual artifact size is recorded in ARTIFACTS.txt.

Export playlists/Favorites in Settings before uninstalling. Backups contain names/links, not audio, profile photos, history or current session. Local file permissions may need reselection after reinstalling. No authentication or cloud sync.

## Validation
Final source compilation, unit tests, release lint and signing/size verification are recorded in VERIFICATION.md and ARTIFACTS.txt. No device was connected. Earlier emulator launch was blocked by automatic approval review; native appearance, actual downloads/resume and airplane-mode/background playback have not been validated on Android 12+/17. This is a signed release candidate, not a certified public release. GPL-3.0 source and third-party notices accompany the package.
