---
name: Syntix Android — Reference
description: Native music library with immersive slate surfaces and warm ivory controls.
colors:
  page: "#171D21"
  surface: "#242B30"
  raised: "#30383E"
  ink: "#F7F7F5"
  muted: "#BCC4C8"
  accent: "#E1CDAE"
  on-accent: "#252A2F"
typography:
  family: Outfit
  weights: Regular, Semibold
---

# Approved Reference direction

Use the supplied Syntix wordmark and symbol PNGs exactly, without redrawing, recoloring or cleaning their artifacts. Native source assets are drawable-nodpi/syntix_wordmark.png and syntix_app_icon.png. The launcher, round icon and splash use the exact supplied symbol. Android launchers may apply their system mask.

Four equally spaced bottom destinations: Home, Search, Your Library, Create. A compact mini-player sits above navigation. Content respects native status/navigation insets. Compact rows use 44 dp artwork with readable text and accessible touch controls. Horizontal artwork rails carry recent listening, recommendations and saved playlists; no fake populated content on first launch.

Profile drawer and full profile page follow the approved screenshot hierarchy. Native sheets handle import, profile editing, song actions and playback. Warm ivory denotes primary actions and active Favorites. Use Outfit regular and semibold with Android font scaling, ellipsis for long track titles and clear state descriptions. Platform motion and feedback only; no decorative web timelines.

Implementation: NativeScreens.java composes Android views and delegates feature actions to MainActivity/SkiplineApp. Preserve queue, import, downloading, backups and media service behavior. Images use an 8 MiB memory cache; selected profile photos decode off the UI thread at a sampled maximum of 512 pixels.

Evidence: prototypes/syntix-reference is the approved design reference, not a runtime APK capture. Existing Porcelain screenshots in .impeccable/review are historical V1–V3 evidence only. No current native visual signoff: emulator launch blocked by policy.


## V6 first launch and offline UI
Promote the selected Immersive onboarding to native ViewPager2: three user-controlled benefit pages with supplied coastal imagery, exact Syntix mark, warm ivory Continue and subtle dots. Skip intro leads to optional local name/photo setup; complete with first import or explore. Android system bars, Back, native document picker, scaled text and Remove animations remain authoritative. Example music inside onboarding graphics is a visual teaching preview, never seeded into the actual library.

Playlist detail gains explicit Download playlist and Offline downloads actions. Download progress, Wi-Fi preference, pause/resume, saved size and removal live inside native sheets/notifications. Download state must not become a global preparation banner. Local-file availability appears beside actual downloaded songs. Remove audio confirms the files affected; playlists/Favorites remain intact.

Approved web exploration is archived as design evidence; it is not an APK screenshot or native visual signoff.

Prototype cleanup was rejected by automatic approval review (blocked by policy); the isolated source prototype remains. Native integration does not load its code.

## V7 native extension

The established slate/ivory palette, Outfit typography, exact Syntix identity, bottom navigation and mini-player remain the authority. Search, Create, Statistics and Downloads reuse native rows, rounded fields, Material buttons and sheets. No token or identity replacement is introduced.

Search adds a two-column grid of 20 colored themes with tilted standalone decorative JPEG artwork copied from the approved mockup; this art is distinct from live YouTube track thumbnails. Theme pages use a category-colored header fading into slate and two horizontal rails populated by real metadata. Create opens a native sheet with New playlist and Import YouTube playlist actions.

Statistics uses an artist summary with compact initial avatars and proportional meters, a separate complete artist page, and three native bar charts with grouping controls and accessible chart-data dialogs. Downloads uses a search field, actual saved-file inventory, offline management and quality controls. Preserve loading, empty, unavailable and retry states instead of seeding example music or usage figures.

These are source-grounded component additions, not native visual signoff. The finish review found no source bugs but requested native recapture; no Android device or emulator capture was available. Existing historical web/reference evidence must not be promoted to V7 runtime evidence. Incumbent token/schema drift is left untouched in this ordinary extension; no new system or sidecar was generated.

## V8 native refinement

The existing slate/ivory palette, Outfit type, supplied Syntix assets and component tokens remain authoritative. This additive source record preserves the incumbent token frontmatter and sidecar.

Library uses an eye action to open the native end drawer from the approved mockup. Recent/Alphabetical and List/Grid are separate radio groups with warm accent selection, plain labels and trailing controls. These choices persist per profile. Downloads uses a centered icon, heading and explanation when empty, followed by the warm primary Add local audio action and secondary offline management. The V7 quality section is removed.

Bottom navigation keeps four equal-width destinations, 24 dp icons and explicitly centered full-width labels. Search keyword and artist suggestions are plain left-aligned rows with subdued icons and native touch feedback. Preserve their readable row hierarchy; do not turn these suggestions into Material pills. While the keyboard is visible, hide the mini-player and navigation; keyboard dismissal rebuilds the chrome without discarding the typed or submitted search.

Theme color washes belong to the full-width root and status bar so they extend through the content gutters. Discovery uses three daily mood hashtag cards with existing decorative theme artwork and live genre destinations; the cards do not represent an official trend feed.

Source finish review identified three specific implementation corrections that were addressed in source. This is not visual ship approval. No V8 phone gesture test or native screenshot capture was performed. Existing reference/mockup captures remain design evidence only. Pre-existing token/schema drift is not canonized or repaired by this extension.

## V9 native extension

Preserve the exact supplied Syntix logo and symbol, incumbent slate/ivory theme, Outfit typography, token frontmatter and design sidecar. No new raster assets or visual identity are introduced. Pre-existing sidecar/schema drift remains incumbent and is outside this extension.

Playlist detail keeps centered square artwork, a prominent title and subdued profile, song-count and duration metadata. Its action row uses accessible icon controls for Add song, Download playlist and Shuffle playlist, with the warm circular Play action at the trailing edge. Rows show individual song durations. Download state updates the icon, accessible label and compact status; one native sheet owns the playlist's Start/Pause/Continue action and scoped counts. Do not restore the duplicate Offline button or obsolete playlist introduction.

Create's native sheet gains Import YouTube video. Imported videos uses the existing Home artwork rail and native full-list rows; empty, duplicate and invalid-link feedback remains explicit. Song menus use the established sheet styling with a track-artwork summary, readable labels, subdued explanatory text and native touch feedback. Rip the audio and Download for offline listening must remain visually separate, named actions.

The player follows the supplied square-art reference composition: centered playlist/queue heading, large square artwork, track and artist hierarchy, Favorite, seek position and time labels, then transport controls. Shuffle and loop expose actual state through warm selection, accessible descriptions and the repeat-one icon. Preserve Android insets, text scaling and native sheet behavior; phone layout and gesture verification remains pending.

The finish review disposition is ship within its source scope, after a download-scope correction. No native V9 screenshot or attached-device review was available; approved references and older captures remain reference evidence only.

## V10 native Statistics extension

This ordinary native extension is based on V9.3, not V9.4. Preserve the incumbent token frontmatter, design sidecar, Outfit typography, supplied logos and icons, and black V9.3 launcher identity. Statistics introduces a restrained slate/ivory header wash within that system; no global design-system replacement is made.

The artist summary uses visible numeric ranks 1–3, artist names, proportional meters and listening durations. A plain arrow beside Your top artists opens the complete ranking. Do not restore Most/Least, Expand view or View Chart Data. Each metric has one text-only Hour/Day/Month control, initially Day, without directional icons. Its 48 dp touch height and explicit accessible period/next-period description keep the compact label usable.

Metric values lead their sections with smaller inline units and subdued period context. Listening uses warm ivory bars, data usage a muted teal area/line and battery usage muted lilac stems. Charts keep sparse grid lines, native text scaling and direct selection guides; selected values replace the metric value and date in place. Missing battery observations remain distinct from measured zero. Reuse Paint, Path, dash effects and size-dependent gradient objects rather than allocating them during each draw.

Period changes update only their metric without a whole-page jump. Preserve native vertical scrolling, touch point inspection, keyboard navigation and TalkBack actions. Month labels may span four calendar months because the retained rolling window includes partial endpoint months. The battery explanation must continue to state that readings include other device activity.

Browser captures establish the approved composition only; they do not prove exact phone appearance. No native V10 visual capture or device interaction signoff is available. Source review and final build status are recorded separately in VERIFICATION-V10.md.

## V11 native listening extension

This scoped addition preserves the incumbent frontmatter, historical sections, sidecar, Outfit typography, exact supplied Syntix PNGs and black launcher identity. The existing slate/ivory system remains authoritative. The surface contract and reference provenance are in DESIGN-V11.md; verification is in VERIFICATION-V11.md.

Equalizer follows the supplied reference topology: centered title and reset, horizontally scrolling preset strip, seven tall vertical bands, playback volume, Bass boost and Stereo width dials, on/off control, Even volume and Save preset. Teal/lilac/ivory band fills and white capsule thumbs adapt the reference to existing slate surfaces. Bands cover 60/150/400 Hz and 1/2.4/6/16 kHz at −12 to +12 dB. Each band has at least a 48 dp touch width, a visible keyboard-focus treatment and native accessibility range/actions; direct adjustments do not animate. Keep vertical content scrolling and hide scrollbars without removing access to lower controls.

The profile drawer adds Equalizer, Sleep timer and Syntix Replay using incumbent rows. Sleep timer uses a circular remaining-time display, duration choices, song-end action and native fade switch. Home Smart Mixes use typographic gradient cards generated by native drawables, real song counts and ordinary native track lists. Settings Download quality uses three native radio choices and an explicitly qualified storage estimate. Replay uses actual report totals, native artist rows, empty/unavailable states and an optional generated share card. No custom playlist-cover editor or new decorative raster assets are introduced.

The finish-review disposition is **RECAPTURE**. Native Robolectric View renders support source/layout inspection only; they are not phone or emulator captures. The constrained reviewer found the Equalizer topology consistent with the reference and accessible ranges represented in source/render. Real phone/emulator captures, including font scale 1.3, remain required before visual acceptance; these additions have no device visual signoff.


## V11.1 Smart Mix correction

Generated mixes appear only after their own filter yields 50 distinct songs; Home hides the Smart Mixes section if none qualify. All-mixes and restored detail routes apply the same gate. The 50-track cap remains. Covers now use actual song thumbnail collages with normal Syntix typography and solid slate surfaces; no generated gradient artwork. Missing thumbnail metadata uses the exact existing Syntix symbol. Previously saved Library playlists remain unchanged. See VERIFICATION-V11.1.md.


## V11.2 navigation, sound and timer controls

Replay and its automatic invitation/sharing provider are removed. The Settings page and profile/sidebar links are removed. Downloads now has a gear opening a native quality-selection sheet (16/128/192 kbps, future offline downloads only). Equalizer uses solid ivory/slate bands, live dB values, clear bypass, grouped controls and scoped reset; saved sound data and the actual DSP are retained. Sleep Timer adds custom hours/minutes and device-format clock scheduling with Today/Tomorrow context; elapsed durations and chosen clock instants use their appropriate clocks. Sidebar feedback is an explicit subtle grey ripple. The V11.1 Smart Mix threshold and actual artwork stay intact. See DESIGN-V11.2.md and VERIFICATION-V11.2.md.


## V11.3 — Spotify metadata import

Public Spotify playlist links and local track-list CSV files can be reviewed and matched to YouTube before saving. Partial previews explicitly show their limits; CSV supports up to 5,000 entries without a 100-row cutoff. This is a metadata snapshot, not Spotify audio playback or automatic synchronization. See DESIGN-V11.3.md and INSTALL-V11.3.txt.


## V12

Spotify link import and optional full-list CSV are released as version 0.12.0. Automatic matching yields while the player buffers, without blocking playback. Existing ad-free native playback and theme are preserved. See INSTALL-V12.txt and DESIGN-V12.md.


## V12.1 — automatic Spotify import

Supersedes V12 import UX: public-link import automatically matches, saves and opens a playlist. CSV and manual match review/save/name steps are removed from the app flow. Unmatched/duplicate recordings are counted and skipped; partial public lists remain disclosed. See INSTALL-V12.1.txt and DESIGN-V12.1.md.


## V12.2 — import result

After saving/opening an imported playlist, show a one-time native imported/skipped count dialog only when entries were skipped. It has an OK action and does not reappear on playlist reopening. All-matched imports open silently.


## V12.4

The import flow keeps its existing UI. Matching now uses a paced metadata engine, narrow spelling tolerance, altered-version guards and a bounded public recording cache. See DESIGN-V12.4.md.


## V13 native onboarding and source access

Preserve the existing slate/ivory identity and all listening features. A three-page photo-led welcome replaces the previous first-run presentation. New local profiles use one explicitly unchecked Terms acceptance/privacy acknowledgement, with readable bundled links and local version/timestamp records. Source access is secondary but findable inside Privacy & About > Open-source software; it exports a version-matched application-source archive without a backend. See DESIGN-V13.md.
