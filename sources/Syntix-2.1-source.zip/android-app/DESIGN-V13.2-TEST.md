# Syntix Android V13.2 test — scoped design record

## Overview

This is an ordinary native component extension of the incumbent Syntix system. It records the implemented test candidate, not visual acceptance. Preserve `DESIGN.md`, both existing design sidecars, supplied Syntix identity assets and Outfit fonts. This document does not replace global tokens or historical release contracts.

Candidate identity: versionName `0.13.2-test`, versionCode `32`, compile/target API `36`, minimum API `31`. The intended test APK package is `app.syntix.android`; `app/build.gradle` permits an application-ID override and still defaults to `app.skipline.android`, so the packaged ID requires artifact verification.

Direction contract:

- **THESIS:** Introduce personal listening through a short, legible native welcome, then help the listener bring an existing playlist into Syntix.
- **OWN-WORLD:** Keep Syntix's slate base, warm ivory actions, Outfit type and existing identity. Welcome illustration adds a rounded paper field and simple human cutouts within this established world.
- **STORY:** Three manually controlled pages explain listening without ads, screen-off/background listening, and finding/queuing/shuffling/repeating music. Local profile setup follows, then playlist import leads activation with Search and Home alternatives.
- **FIRST VIEWPORT:** Syntix mark/name and Skip intro above the inset paper illustration; a large left-aligned heading and short explanation below; page indicators and an ivory circular arrow at the bottom. Keep the user's chosen reference composition recognizable.
- **FORM:** The user explicitly pinned this composition and replaced the rejected detailed illustration direction with extremely simple hand-drawn black/white cutouts and sparse ivory accents. Do not invent randomized layouts, lime accents, decorative scenes or a new visual system. The supplied reference's serif headline, white phone shell and lime controls are not native app tokens.
- **FINISH:** Native verification is pending. At documentation time final capture tests are building and no phone is connected. Test renders support layout inspection; they are not phone evidence, gesture verification or visual acceptance.

## Colors

The incumbent palette remains authoritative: page slate `#171D21`, surface `#242B30`, raised surface `#30383E`, ink `#F7F7F5`, muted text `#BCC4C8`, warm ivory accent `#E1CDAE`, and on-accent `#252A2F`.

Welcome paper is the scoped `#CBBDAF` inset field. Active playlist rows use warm-slate `#34362F`, with title and state/detail text in the existing ivory accent. These two additions are component-local values, not a global palette migration.

## Typography

Use the existing Outfit regular/semibold native text helpers and Android font scaling. Welcome headings are 38 sp, left aligned, with letter spacing `-0.025` and line-spacing multiplier `1.02`. Copy is 15 sp with 3 dp additional line spacing. Compact welcome layouts reduce headings to 30 sp. Profile and import headings use 35 sp. Preserve brief, readable explanations and accessible heading semantics.

## Layout

`Onboarding.java` uses a native ViewPager2 containing three vertically scrollable pages. The content column caps at 540 dp, with 24 dp horizontal padding. The paper is inset another 22 dp inside the artwork container, with a 16 dp lower inset. A separate transparent image sits over it using `FIT_END`; the artwork container disables child/padding clipping so the figures can overhang the paper.

Artwork height adapts to measured page/text space, with a 160 dp minimum when visible. Below a 350 dp pager height the artwork hides and the compact heading applies. This source behavior preserves a scrolling route to text on constrained layouts; actual large-font and small-phone appearance still needs native verification. Profile/import columns cap at 560 dp and scroll.

The footer offers three 48 dp page-indicator targets and a 60 dp arrow action. Pages do not auto-advance. Skip intro moves to profile setup. The arrow advances pages and then opens profile setup. ViewPager's subtle alpha transformer is conditional on Android animators being enabled.

## Elevation & Depth

Depth comes from flat tonal layering: slate shell, inset paper, then transparent illustration. Preserve the cutout silhouette and overhang instead of baking an opaque card into the image. Native controls, feedback and sheets remain responsible for interaction.

## Shapes

Welcome paper uses 22 dp corners. The footer arrow is a 60 dp circle with 30 dp corner radius. Active playlist rows use 8 dp corners. Profile fields and provider panels retain 12 dp corners. Do not clip the welcome figures to the paper's rounded rectangle.

## Components

### Welcome artwork and provenance

The original user composition reference is `C:/Users/mitta/AppData/Local/Temp/codex-clipboard-de44a603-6010-4385-87e3-d744067ad9cf.png`. It establishes the paper/overhang, heading/copy and circular-forward topology. The replacement instruction calls for far simpler black/white illustration with sparse ivory accents.

The three actual drawable-nodpi assets were visually inspected and read with Pillow:

| Asset | Dimensions | Implemented subject |
| --- | --- | --- |
| `welcome_import.png` | 1374 × 1145 | Two outlined listeners, one holding a phone, raised hands, sparse music/spark marks. |
| `welcome_background.png` | 1122 × 1402 | A seated headphone listener with a phone and sparse spark marks. |
| `welcome_freedom.png` | 1312 × 1199 | Two outlined listeners sharing a phone/earphones, one raised hand, sparse music/spark marks. |

All three are RGBA PNG cutouts with transparent surroundings. Impeccable `embed-prompt --read` successfully recovered the embedded generation/edit prompts from every final asset, although Pillow's `info` dictionary was empty. Those prompts call for minimal black outlines, white/offwhite clothing, black hair, muted beige trousers, very small ivory accents and no baked-in frame, text or interface. The seated-listener edit prompt additionally requests removal of exterior haze/shadow. The observed assets use that simple cutout vocabulary with taupe trousers, pale skin fills and sparse ivory details; no strict monochrome or visual acceptance claim is made. No asset was modified by this documentation pass.

### Profile and activation

Profile name and photo remain optional and local. The 13+ Terms agreement/Privacy acknowledgement must start unchecked; Create profile stays disabled until checked. Terms and Privacy are individually readable bundled links. Acceptance stores local legal versions and a timestamp. The interface explicitly explains that profiles are stored on the phone and are not password-protected. This is not verified age or a remote identity system.

Import a playlist is the primary next action. Find a song instead opens Search; I'll explore first enters the app. Offline listening is explained as a subsequent explicit download from a saved playlist. Welcome artwork does not seed the real library.

### Playlist playback state

`PlaylistPlayback.java` updates attached views from player events. Only the current track in the current playlist receives the selected shade and ivory text. Its subtitle prefixes the existing detail with Playing, Loading or Paused; an artwork-area indicator uses equalizer, retry or pause respectively. The row also exposes its selected state and descriptive playback state to accessibility. Unselected rows return to transparent backgrounds and incumbent ink/muted text.

The top playlist transport reflects play/pause state and toggles pause for the current playing playlist, rather than restarting it. Preserve actual buffering and paused states, playlist identity and source identity; do not imply that every matching title is active.

### Search responsiveness

`NativeSearch.java` publishes cached results when available and forwards a partial-result callback from `SearchCatalogue.liveSearch`. The live JSON search publishes first-page songs before a bounded continuation; existing HTML/extractor fallback paths remain available. Query generation, attachment/screen checks and tagged live-search cancellation prevent stale queries from repainting the current results. This scoped cancellation is distinct from the wider lifecycle stop-work path.

Visible results may trigger URL-only warming for the two leading tracks through `SkiplineApp.warmSearchResults`. It resolves links without fetching or storing music bytes, and skips work when dismissed, idle or buffering. Do not call these music downloads or claim guaranteed subsecond search/audio startup. Device latency has not been measured here.

The wider V13.2 test build also includes completed offline-audio encryption and removal of standalone media export. Those functional changes do not authorize a visual-system redesign; their verification belongs in the build/security records.

## Do's and Don'ts

- **Do** preserve the user-pinned composition, left-aligned Outfit hierarchy, existing identity and explicit local consent flow.
- **Do** verify all three pages, compact height, font scale 1.3, Back/swipe/arrow behavior, profile consent/links, import alternatives and live playlist state on a native device or emulator.
- **Do** describe captures by their actual origin and version. Final capture results and APK identity/signature were not independently verified in this documentation pass.
- **Don't** promote a reference image or Robolectric/test render into native phone evidence or visual signoff.
- **Don't** introduce automatic audio downloads or fixed latency claims into the search description.
- **Don't** silently repair incumbent documentation drift: `DESIGN.md` still has historical photo-led welcome language and noncanonical typography frontmatter; `android-app/.impeccable/design.json` still carries stale purple/porcelain/white metadata, mismatched component references and a title encoding artifact. These files remain untouched by this ordinary extension.

Evidence checked: `PRODUCT.md`, incumbent `DESIGN.md`, `android-app/.impeccable/design.json`, `Onboarding.java`, `PlaylistPlayback.java`, `NativeSearch.java`, supporting `MainActivity.java`, `NativeScreens.java`, `PlaylistScreen.java`, `SkiplineApp.java`, `SearchCatalogue.java`, `YouTubeMetadata.java`, `app/build.gradle`, the three PNG files and their embedded prompts, and the original reference. No build, tests, phone capture, interaction session or code/image/font changes were performed by the documenter.
