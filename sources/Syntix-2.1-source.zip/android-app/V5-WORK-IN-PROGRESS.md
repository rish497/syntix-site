# Historical V5 status

V5 was packaged as Syntix-0.5.0.apk. Current V6 implementation/status is documented in RELEASE.md and VERIFICATION.md. Native runtime validation remains outstanding.
