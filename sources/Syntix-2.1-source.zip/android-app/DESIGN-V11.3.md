# V11.3 Spotify metadata import

Extends the existing Create sheet and music-link sheet without changing the app identity. Import Spotify playlist opens a native sheet in the existing slate/ivory palette, Outfit typography, grey press feedback and native sheet motion. Spotify playlist links shared to Syntix enter the same flow.

The import page shows the source title and available versus total entries before matching. Partial and unknown totals receive explicit notices and a full-CSV alternative. Matching uses two background requests at a time; progress notifications are throttled and do not persist the playback queue. The user can cancel, review individual candidate recordings, edit a search, skip entries and explicitly save reviewed YouTube tracks under a chosen playlist name. No Spotify audio or credentials are imported. Audio downloads remain separate.

CSV supports title and artist columns, optional duration in milliseconds and Spotify URI, quoted fields and UTF-8 BOM. It accepts up to 5,000 entries / 5 MB and rejects oversized files instead of truncating them. Metadata drafts are in memory, survive Activity recreation, and are lost if Android kills the app process. Matching pauses after the app enters its idle background state and stops on task dismissal. Profile switching clears the draft; an active import prevents switching.

Native UI render evidence is a synthetic fixture, not a phone capture. Existing player, Downloads, Equalizer, Sleep Timer, Smart Mixes and statistics remain in place. Replay and the general Settings page remain removed.
