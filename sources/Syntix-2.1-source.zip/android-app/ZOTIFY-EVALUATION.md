# Zotify evaluation — 2026-11-03

Result: the tested Spotify Free account authenticated and retrieved metadata, but neither tested track produced audio. Do not represent this as a working free/ad-free Spotify integration.

## Environment and source

Windows, Python 3.13.14, isolated virtual environment under `.site-deps/zotify-evaluation`. Existing system FFmpeg was available. No Syntix source, APK or signing changes were made for this evaluation.

- Original Zotify 0.6.14: commit `08d844fe3e644ae6cd9bea34a3b4982e61129f33` (2024-09-01).
- Original librespot-python dependency 0.0.10: commit `683d9e76f91ba7ae03919494dac8d899ca505651`.
- Googolplexed0 Zotify fork 0.21.4: commit `10ef737e6a9a31c6992b53c32659d3bf021d23be` (2026-11-01).
- Its librespot-python fork 0.0.15: commit `01abfc8ad012dbc40e90417e640faaf271ea2f98`.

## Observations

| Check | Result |
|---|---|
| Original installation and CLI help | Passed |
| Original invocation without account credentials | Requested username; stopped on closed input; no audio |
| Maintained fork installation, CLI help and dependency check | Passed |
| User-completed browser login | Passed; the session reported `free` |
| Spotify track metadata | Retrieved for both tracks |
| Just Listen — Sidhu Moose Wala, Sunny Malton; default quality | Audio-key error code 1 twice; 0 audio files / 0 bytes |
| Old Skool — Prem Dhillon, Sidhu Moose Wala, Naseeb; normal quality, safe content feeder | Audio-key error code 1 twice; 0 audio files / 0 bytes |

The fork returned process exit code 0 despite producing no audio. A successful exit code therefore did not establish a successful download. No ad-free playback, start latency, decoding or Android compatibility was verified. The server's audio-key error is observed; its precise account/service-side cause was not established. These two tests do not prove that every track, account or fork fails.

## Test-only adjustments

The harness suppressed cosmetic terminal animation and used UTF-8 output after Windows console encoding caused its spinner thread to fail. A test-only loopback HTTPServer binding override avoided a suspected hostname-resolution stall; a direct socket check confirmed the callback listener was reachable. These adjustments did not alter Spotify's audio-key responses or bypass its access decisions.

OAuth permissions were limited to streaming and basic private-profile access. The user signed in in Spotify's own browser page. Credential saving was disabled, saved login files were not consumed, and observed credentials placeholders were empty (0 bytes). No nonempty login-credential file was written. Tokens remained in memory for each run; sessions closed afterward. The browser retains its ordinary user-managed sign-in cookies unless the user logs out.

Raw result summaries, sanitized metadata fixture and evaluation harness are under `.site-deps/zotify-evaluation`; that directory is ignored and excluded from Android source/APK packaging. They contain no passwords or saved access/refresh tokens. The earlier evaluation of Syntix's YouTube matcher is separate from these Spotify audio tests.
