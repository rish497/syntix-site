# Syntix 0.9.1 hotfix

Version code 10, app.skipline.android, Android 12+. Existing production signing identity and earlier APKs are retained.

The full player wash now belongs to the dialog window, using Syntix slate colors. The status bar is transparent, status-bar contrast protection is disabled for this dark surface, and safe-area insets pad the sheet content. This extends the wash behind the status area while keeping controls clear of it. No thumbnail color sampling or artwork downloading is added.

The user reported a 2–3 second delay after tapping tracks. Comparing V8 and V9 confirmed unchanged extractor client and startup buffer settings; the exact phone timing regression has not been reproduced. Source inspection identified avoidable costs: playlist taps created fresh media IDs and synced twice; an active player could consequently load item zero before the selected row. Stable queue entries and a requested start ID now preserve the timeline and select the intended initial item. A full stream-link cache no longer clears every valid link at once. Next-link warmup follows shuffle/repeat changes and can retry an earlier failed warmup. No bulk audio download or increase in startup buffering is introduced.

Local debug logs distinguish stream-link cache hits from resolution duration without recording song URLs or titles. These are device logs, not transmitted analytics. Three additional queue regression tests cover stable IDs, reorder/new entries and duplicate-source ID uniqueness.

Twenty-six unit tests passed with no failures or errors. Release lint reports zero errors and 57 warnings. Final release assembly and lint passed after the last selected-track warmup guard. The APK keeps the existing production certificate SHA-256 `a3e24ba7f432a86074664663f9f2e5a7752ca9eb073e8df439498725c47d90e3`.

Source finish review found no concrete material regression. Its visual disposition is **recapture**: no device is connected, so there is no new native screenshot, measured startup speed, gesture or runtime visual signoff. The supplied phone screenshot documents the previous defect, not the hotfix result. A 0.5–0.7 second cold-network start is not guaranteed.
