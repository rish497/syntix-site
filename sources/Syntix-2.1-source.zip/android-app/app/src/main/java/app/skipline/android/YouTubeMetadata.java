package app.skipline.android;

import org.json.*;
import java.util.*;
import java.io.IOException;
import okhttp3.*;

/** Lightweight public metadata; playback/download extraction stays with yt-dlp. */
final class YouTubeMetadata {
    static final class SearchBlockedException extends IOException {SearchBlockedException(){super("YouTube has paused search requests. Try again later. Your remaining songs have not been skipped.");}}
    private static final OkHttpClient client=new OkHttpClient.Builder().connectTimeout(4,java.util.concurrent.TimeUnit.SECONDS).readTimeout(7,java.util.concurrent.TimeUnit.SECONDS).callTimeout(9,java.util.concurrent.TimeUnit.SECONDS).build();
    static void cancel(){client.dispatcher().cancelAll();}
    static ArrayList<Track> search(String query)throws Exception{return search(query,null);}
    static ArrayList<Track> search(String query,java.util.function.Consumer<ArrayList<Track>> partial)throws Exception{return search(query,partial,client,true);}
    static ArrayList<Track> match(String query,OkHttpClient transport)throws Exception{return search(query,null,transport,false);}
    /** Public search JSON, with a pooled transport: no per-song interpreter startup or HTML page. */
    static ArrayList<Track> fastMatch(String query,OkHttpClient transport)throws Exception{
        JSONObject context=new JSONObject().put("client",new JSONObject().put("clientName","WEB").put("clientVersion","2.20260708.00.00").put("hl","en"));
        JSONObject body=new JSONObject().put("context",context).put("query",query).put("params","EgIQAQ==");
        Request request=new Request.Builder().url("https://www.youtube.com/youtubei/v1/search?prettyPrint=false").post(RequestBody.create(body.toString(),MediaType.get("application/json; charset=utf-8"))).build();
        try(Response response=transport.newCall(request).execute()){
            String location=response.header("Location","");if(response.code()==429||response.code()==403||location.contains("/sorry/")||location.contains("consent."))throw new SearchBlockedException();
            if(!response.isSuccessful()||response.body()==null)throw new IOException("YouTube search unavailable (HTTP "+response.code()+")");
            ArrayList<Track> found=parseResponse(new JSONObject(readBounded(response.body().byteStream())));if(found.isEmpty())throw new IOException("YouTube search format unavailable");return found;
        }
    }
    static ArrayList<Track> liveRecordings(String query,java.util.function.BooleanSupplier active)throws Exception{if(!active.getAsBoolean())throw new java.util.concurrent.CancellationException();return RecordingSearch.search(query,client,LIVE_TAG);}
    private static final String LIVE_TAG="syntix-live-query";
    static void cancelLiveSearches(){for(Call call:client.dispatcher().runningCalls())if(LIVE_TAG.equals(call.request().tag()))call.cancel();for(Call call:client.dispatcher().queuedCalls())if(LIVE_TAG.equals(call.request().tag()))call.cancel();}
    static ArrayList<Track> liveSearch(String query,java.util.function.Consumer<ArrayList<Track>> partial,java.util.function.BooleanSupplier active)throws Exception{return liveSearch(query,partial,active,client);}
    static ArrayList<Track> liveSearch(String query,java.util.function.Consumer<ArrayList<Track>> partial,java.util.function.BooleanSupplier active,OkHttpClient transport)throws Exception{
        if(!active.getAsBoolean())throw new java.util.concurrent.CancellationException();
        JSONObject context=new JSONObject().put("client",new JSONObject().put("clientName","WEB").put("clientVersion","2.20260708.00.00").put("hl","en"));
        JSONObject body=new JSONObject().put("context",context).put("query",query).put("params","EgIQAQ==");
        Request request=new Request.Builder().url("https://www.youtube.com/youtubei/v1/search?prettyPrint=false").tag(LIVE_TAG).post(RequestBody.create(body.toString(),MediaType.get("application/json; charset=utf-8"))).build();
        JSONObject data;
        try(Response response=transport.newCall(request).execute()){
            String location=response.header("Location","");if(response.code()==429||response.code()==403||location.contains("/sorry/")||location.contains("consent."))throw new SearchBlockedException();
            if(!response.isSuccessful()||response.body()==null)throw new IOException("YouTube search unavailable (HTTP "+response.code()+")");
            data=new JSONObject(readBounded(response.body().byteStream()));
        }
        if(!active.getAsBoolean())throw new java.util.concurrent.CancellationException();
        LinkedHashMap<String,Track> videos=new LinkedHashMap<>();walk(data,videos,0);
        if(videos.isEmpty())throw new IOException("YouTube search format unavailable");
        if(partial!=null)partial.accept(new ArrayList<>(videos.values()));
        String token=continuation(data,0);
        if(videos.size()<30&&!token.isEmpty()&&active.getAsBoolean())try{
            JSONObject nextBody=new JSONObject().put("context",context).put("continuation",token);
            Request next=request.newBuilder().post(RequestBody.create(nextBody.toString(),MediaType.get("application/json; charset=utf-8"))).build();
            try(Response more=transport.newBuilder().callTimeout(1500,java.util.concurrent.TimeUnit.MILLISECONDS).build().newCall(next).execute()){if(more.isSuccessful()&&more.body()!=null)walk(new JSONObject(readBounded(more.body().byteStream())),videos,0);}
        }catch(Exception ignored){/* First-page songs remain usable while later results are unavailable. */}
        return new ArrayList<>(videos.values());
    }
    static ArrayList<Track> parseResponse(JSONObject data){YouTubeSession.observe(data);LinkedHashMap<String,Track> found=new LinkedHashMap<>();walk(data,found,0);return new ArrayList<>(found.values());}
    static ArrayList<Track> liveFallback(String query,java.util.function.Consumer<ArrayList<Track>> partial,java.util.function.BooleanSupplier active)throws Exception{return search(query,partial,client,true,active,true);}
    private static ArrayList<Track> search(String query,java.util.function.Consumer<ArrayList<Track>> partial,OkHttpClient transport,boolean morePages)throws Exception{return search(query,partial,transport,morePages,()->true,false);}
    private static ArrayList<Track> search(String query,java.util.function.Consumer<ArrayList<Track>> partial,OkHttpClient transport,boolean morePages,java.util.function.BooleanSupplier active,boolean live)throws Exception{
        if(!active.getAsBoolean())throw new java.util.concurrent.CancellationException();
        HttpUrl url=HttpUrl.get("https://www.youtube.com/results").newBuilder().addQueryParameter("search_query",query).addQueryParameter("hl","en").build();
        Request request=new Request.Builder().url(url).tag(live?LIVE_TAG:null).header("User-Agent","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/131.0.0.0 Safari/537.36").build();
        try(Response response=transport.newCall(request).execute()){
            String location=response.header("Location","");
            if(response.code()==429||response.code()==403||location.contains("/sorry/")||location.contains("consent.google.")||location.contains("consent.youtube."))throw new SearchBlockedException();
            if(!response.isSuccessful()||response.body()==null)throw new IOException("YouTube metadata is unavailable (HTTP "+response.code()+")");
            String html=readBounded(response.body().byteStream());JSONObject data=new JSONObject(initialData(html));LinkedHashMap<String,Track> videos=new LinkedHashMap<>();walk(data,videos,0);
            if(!videos.isEmpty()&&partial!=null)partial.accept(new ArrayList<>(videos.values()));
            String token=continuation(data,0);java.util.regex.Matcher version=java.util.regex.Pattern.compile("\"INNERTUBE_CLIENT_VERSION\"\\s*:\\s*\"([^\"]+)\"").matcher(html);
            if(active.getAsBoolean()&&morePages&&videos.size()<30&&!token.isEmpty()&&version.find())try{
                JSONObject context=new JSONObject().put("client",new JSONObject().put("clientName","WEB").put("clientVersion",version.group(1)).put("hl","en"));
                JSONObject body=new JSONObject().put("context",context).put("continuation",token);
                Request next=new Request.Builder().url("https://www.youtube.com/youtubei/v1/search?prettyPrint=false").tag(live?LIVE_TAG:null).header("User-Agent",request.header("User-Agent")).post(RequestBody.create(body.toString(),MediaType.get("application/json; charset=utf-8"))).build();
                try(Response more=transport.newBuilder().callTimeout(2500,java.util.concurrent.TimeUnit.MILLISECONDS).build().newCall(next).execute()){if(more.isSuccessful()&&more.body()!=null)walk(new JSONObject(readBounded(more.body().byteStream())),videos,0);}
            }catch(Exception ignored){/* Keep actual first-page results if continuation is unavailable. */}
            if(videos.isEmpty())throw new IOException("YouTube metadata format changed");return new ArrayList<>(videos.values());
        }
    }
    static ArrayList<Track> parse(String html)throws Exception{JSONObject json=new JSONObject(initialData(html));LinkedHashMap<String,Track> found=new LinkedHashMap<>();walk(json,found,0);return new ArrayList<>(found.values());}
    static String readBounded(java.io.InputStream input)throws IOException{java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream();try(java.io.InputStream in=input){byte[] buffer=new byte[16384];int n;while((n=in.read(buffer))!=-1){if(out.size()+n>4*1024*1024)throw new IOException("YouTube response is too large");out.write(buffer,0,n);}}return out.toString("UTF-8");}
    private static String continuation(Object value,int depth){if(depth>70)return "";if(value instanceof JSONObject){JSONObject j=(JSONObject)value;JSONObject command=j.optJSONObject("continuationCommand");if(command!=null&&!command.optString("token").isEmpty())return command.optString("token");Iterator<String> keys=j.keys();while(keys.hasNext()){String token=continuation(j.opt(keys.next()),depth+1);if(!token.isEmpty())return token;}}else if(value instanceof JSONArray){JSONArray a=(JSONArray)value;for(int i=0;i<a.length();i++){String token=continuation(a.opt(i),depth+1);if(!token.isEmpty())return token;}}return "";}
    static String initialData(String html)throws Exception{
        for(String marker:new String[]{"var ytInitialData =","ytInitialData=","window[\"ytInitialData\"] ="}){
            int key=html.indexOf(marker);if(key<0)continue;int start=html.indexOf('{',key+marker.length());if(start<0)continue;int depth=0;boolean quote=false,escape=false;
            for(int i=start;i<html.length();i++){char c=html.charAt(i);if(quote){if(escape)escape=false;else if(c=='\\')escape=true;else if(c=='"')quote=false;}else if(c=='"')quote=true;else if(c=='{')depth++;else if(c=='}'&&--depth==0)return html.substring(start,i+1);}
        }throw new IOException("YouTube did not provide public search metadata");
    }
    private static String text(JSONObject node){if(node==null)return "";String direct=node.optString("simpleText",node.optString("content",""));if(!direct.isEmpty())return direct;StringBuilder out=new StringBuilder();JSONArray runs=node.optJSONArray("runs");if(runs!=null)for(int i=0;i<runs.length();i++){JSONObject r=runs.optJSONObject(i);if(r!=null)out.append(r.optString("text"));}return out.toString();}
    private static long seconds(String value){try{long n=0;String clean=value.replaceAll("[^0-9:]","");if(clean.isEmpty())return 0;for(String p:clean.split(":"))n=n*60+Long.parseLong(p);return n;}catch(Exception e){return 0;}}
    private static void add(LinkedHashMap<String,Track> out,String id,String title,String author,long duration){if(!id.matches("[A-Za-z0-9_-]{11}")||title.isEmpty()||title.equals("[Private video]")||title.equals("[Deleted video]")||out.containsKey(id)||out.size()>=30)return;out.put(id,new Track("https://www.youtube.com/watch?v="+id,title,author.isEmpty()?"YouTube":author,"https://i.ytimg.com/vi/"+id+"/hqdefault.jpg",duration));}
    static Track lockup(JSONObject lock){
        String id=lock.optString("contentId");if(!id.matches("[A-Za-z0-9_-]{11}"))return null;
        JSONObject metadata=lock.optJSONObject("metadata"),meta=metadata==null?null:metadata.optJSONObject("lockupMetadataViewModel");if(meta==null)return null;
        String title=text(meta.optJSONObject("title")),author="";if(title.isEmpty()||title.equals("[Private video]")||title.equals("[Deleted video]"))return null;
        JSONObject container=meta.optJSONObject("metadata"),content=container==null?null:container.optJSONObject("contentMetadataViewModel");if(content!=null)container=content;
        JSONArray rows=container==null?null:container.optJSONArray("metadataRows");if(rows!=null&&rows.length()>0){JSONObject first=rows.optJSONObject(0);JSONArray parts=first==null?null:first.optJSONArray("metadataParts");if(parts!=null&&parts.length()>0){JSONObject part=parts.optJSONObject(0);if(part!=null)author=text(part.optJSONObject("text"));}}
        String duration=badgeDuration(lock.opt("contentImage"),0);boolean verified=container!=null&&container.toString().contains("\"AUDIO_BADGE\"");
        return new Track("https://www.youtube.com/watch?v="+id,title,author,"https://i.ytimg.com/vi/"+id+"/hqdefault.jpg",seconds(duration)).verified(verified);
    }
    private static String badgeDuration(Object value,int depth){if(value==null||depth>20)return "";if(value instanceof JSONObject){JSONObject node=(JSONObject)value,badge=node.optJSONObject("thumbnailBadgeViewModel");if(badge!=null&&badge.optString("text").matches("[0-9]+(?::[0-9]{2}){1,2}"))return badge.optString("text");Iterator<String> keys=node.keys();while(keys.hasNext()){String found=badgeDuration(node.opt(keys.next()),depth+1);if(!found.isEmpty())return found;}}else if(value instanceof JSONArray){JSONArray array=(JSONArray)value;for(int i=0;i<array.length();i++){String found=badgeDuration(array.opt(i),depth+1);if(!found.isEmpty())return found;}}return "";}
    private static void walk(Object value,LinkedHashMap<String,Track> out,int depth){if(depth>70||out.size()>=30)return;
        if(value instanceof JSONObject){JSONObject j=(JSONObject)value;JSONObject v=j.optJSONObject("videoRenderer");if(v==null)v=j.optJSONObject("compactVideoRenderer");if(v!=null){String author=text(v.optJSONObject("ownerText"));if(author.isEmpty())author=text(v.optJSONObject("longBylineText"));if(author.isEmpty())author=text(v.optJSONObject("shortBylineText"));add(out,v.optString("videoId"),text(v.optJSONObject("title")),author,seconds(text(v.optJSONObject("lengthText"))));JSONArray badges=v.optJSONArray("ownerBadges");for(int i=0;badges!=null&&i<badges.length();i++){JSONObject badge=badges.optJSONObject(i);badge=badge==null?null:badge.optJSONObject("metadataBadgeRenderer");if(badge!=null&&"BADGE_STYLE_TYPE_VERIFIED_ARTIST".equals(badge.optString("style"))){Track artist=out.get(v.optString("videoId"));if(artist!=null)artist.verified(true);}}}
            JSONObject lock=j.optJSONObject("lockupViewModel");if(lock!=null){Track item=lockup(lock);if(item!=null){String id=okhttp3.HttpUrl.get(item.source).queryParameter("v");out.putIfAbsent(id,item);}}
            Iterator<String> keys=j.keys();while(keys.hasNext()){String key=keys.next();if(key.equals("adSlotRenderer")||key.startsWith("promoted"))continue;walk(j.opt(key),out,depth+1);}
        }else if(value instanceof JSONArray){JSONArray a=(JSONArray)value;for(int i=0;i<a.length()&&out.size()<30;i++)walk(a.opt(i),out,depth+1);}
    }
}
