package app.skipline.android;

import android.animation.ValueAnimator;
import android.content.res.ColorStateList;
import android.graphics.*;
import android.text.*;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.view.*;
import android.view.inputmethod.EditorInfo;
import android.widget.*;
import androidx.appcompat.widget.AppCompatCheckBox;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;
import com.google.android.material.button.MaterialButton;

/** A short, native welcome. Profiles remain local and imports use the existing engine. */
@androidx.annotation.OptIn(markerClass = androidx.media3.common.util.UnstableApi.class)
final class Onboarding {
    static final String[] TITLES={"Listen with\nno ads.","Screen off.\nMusic on.","Play what\nyou love."};
    static final String[] COPY={"Bring your YouTube or Spotify playlists into Syntix. Your favorites, without the ad breaks.","Keep your music playing when you lock your phone or switch to another app.","Find a song. Make a queue. Shuffle and repeat, without a Syntix subscription."};
    static final String CONSENT="I confirm I am 13+ and agree to the Terms of Use and acknowledge the Privacy Policy.";
    static final String LEGAL_VERSION="2026-11-05";

    static void render(MainActivity a){
        if(a.onboardingStage==1){profile(a);return;}
        if(a.onboardingStage==2){firstPlaylist(a);return;}
        LinearLayout shell=a.column();shell.setTag("welcome_carousel");a.root.addView(shell,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout bar=a.row();bar.setPadding(a.dp(24),0,a.dp(12),0);
        ImageView logo=new ImageView(a);logo.setImageResource(R.drawable.syntix_app_icon);logo.setContentDescription("Syntix");bar.addView(logo,a.lp(26,32));
        TextView word=a.text("Syntix",17,MainActivity.INK,true);word.setPadding(a.dp(8),0,0,0);bar.addView(word,new LinearLayout.LayoutParams(0,-2,1));
        MaterialButton skip=a.button("Skip intro",0,false,()->{a.onboardingStage=1;a.refresh();});skip.setTextSize(13);skip.setSingleLine(true);bar.addView(skip,a.lp(112,48));shell.addView(bar,a.lp(-1,54));
        ViewPager2 pager=new ViewPager2(a);pager.setId(View.generateViewId());pager.setOffscreenPageLimit(1);shell.addView(pager,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout footer=a.row();footer.setPadding(a.dp(12),a.dp(2),a.dp(26),a.dp(16));LinearLayout dots=a.row();
        MaterialButton next=a.icon(R.drawable.ic_arrow,"Next welcome page",()->{if(a.onboardingSlide<2)pager.setCurrentItem(a.onboardingSlide+1,ValueAnimator.areAnimatorsEnabled());else{a.onboardingStage=1;a.refresh();}});
        next.setTag("onboarding_next");next.setBackgroundTintList(ColorStateList.valueOf(MainActivity.ACCENT));next.setIconTint(ColorStateList.valueOf(MainActivity.ON_ACCENT));next.setCornerRadius(a.dp(30));
        for(int i=0;i<3;i++){final int index=i;FrameLayout hit=new FrameLayout(a);View dot=new View(a);a.rounded(dot,a.onboardingSlide==i?MainActivity.ACCENT:MainActivity.RAISED,4);FrameLayout.LayoutParams dp=new FrameLayout.LayoutParams(a.dp(a.onboardingSlide==i?24:6),a.dp(5),Gravity.CENTER);hit.addView(dot,dp);hit.setContentDescription("Welcome page "+(i+1)+" of 3");hit.setSelected(i==a.onboardingSlide);hit.setFocusable(true);hit.setClickable(true);hit.setOnClickListener(v->pager.setCurrentItem(index,ValueAnimator.areAnimatorsEnabled()));dots.addView(hit,a.lp(48,48));}
        footer.addView(dots,new LinearLayout.LayoutParams(0,a.dp(60),1));footer.addView(next,a.lp(60,60));shell.addView(footer,a.lp(-1,-2));
        pager.setAdapter(new RecyclerView.Adapter<Page>(){
            public int getItemCount(){return 3;}
            public Page onCreateViewHolder(ViewGroup parent,int type){WelcomePage page=new WelcomePage(a);page.setLayoutParams(new RecyclerView.LayoutParams(-1,-1));return new Page(page);}
            public void onBindViewHolder(Page holder,int n){
                FrameLayout page=(FrameLayout)holder.itemView;page.removeAllViews();
                ScrollView scroll=new ScrollView(a);scroll.setFillViewport(true);scroll.setVerticalScrollBarEnabled(false);scroll.setClipChildren(false);scroll.setClipToPadding(false);
                LinearLayout body=new CappedColumn(a,540);body.setClipChildren(false);body.setClipToPadding(false);body.setPadding(a.dp(24),a.dp(5),a.dp(24),a.dp(18));
                FrameLayout art=new FrameLayout(a);art.setClipChildren(false);art.setClipToPadding(false);art.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS);
                Illustration figures=new Illustration(a,n);art.addView(figures,new FrameLayout.LayoutParams(-1,-1));body.addView(art,a.lp(-1,300));a.gap(body,25);
                TextView title=a.text(TITLES[n],38,MainActivity.INK,true);title.setLetterSpacing(-.025f);title.setGravity(Gravity.START);title.setLineSpacing(0,1.02f);androidx.core.view.ViewCompat.setAccessibilityHeading(title,true);body.addView(title,a.lp(-1,-2));a.gap(body,14);
                TextView copy=a.text(COPY[n],15,MainActivity.MUTED,false);copy.setGravity(Gravity.START);copy.setLineSpacing(a.dp(3),1);body.addView(copy,a.lp(-1,-2));
                FrameLayout center=new FrameLayout(a);center.setClipChildren(false);center.setClipToPadding(false);center.addView(body,new FrameLayout.LayoutParams(-1,-2,Gravity.TOP|Gravity.CENTER_HORIZONTAL));scroll.addView(center,new ScrollView.LayoutParams(-1,-2));page.addView(scroll,new FrameLayout.LayoutParams(-1,-1));
                ((WelcomePage)page).bind(art,title,copy);
                page.setContentDescription("Welcome "+(n+1)+" of 3");
            }
        });
        if(ValueAnimator.areAnimatorsEnabled())pager.setPageTransformer((page,position)->page.setAlpha(1-Math.min(1,Math.abs(position))*.15f));
        pager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback(){public void onPageSelected(int n){a.onboardingSlide=n;next.setContentDescription(n==2?"Create your profile":"Next welcome page");next.setTooltipText(n==2?"Create your profile":"Next");for(int i=0;i<dots.getChildCount();i++){FrameLayout hit=(FrameLayout)dots.getChildAt(i);View dot=hit.getChildAt(0);a.rounded(dot,i==n?MainActivity.ACCENT:MainActivity.RAISED,4);dot.getLayoutParams().width=a.dp(i==n?24:6);dot.requestLayout();hit.setSelected(i==n);}}});pager.setCurrentItem(Math.max(0,Math.min(2,a.onboardingSlide)),false);
    }
    /** Fits the visible illustration, not its transparent export canvas, inside the screen. */
    static final class Illustration extends View {
        static final Bitmap[] images=new Bitmap[3];static final Rect[] bounds=new Rect[3];
        final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG);final int index;final MainActivity activity;
        Illustration(MainActivity a,int n){super(a);index=n;activity=a;setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);if(images[n]==null){
            Bitmap bitmap=BitmapFactory.decodeResource(a.getResources(),n==0?R.drawable.welcome_import:n==1?R.drawable.welcome_background:R.drawable.welcome_freedom);images[n]=bitmap;
            int left=bitmap.getWidth(),top=bitmap.getHeight(),right=0,bottom=0;int[] pixels=new int[bitmap.getWidth()];
            for(int y=0;y<bitmap.getHeight();y++){bitmap.getPixels(pixels,0,pixels.length,0,y,pixels.length,1);for(int x=0;x<pixels.length;x++)if((pixels[x]>>>24)>40){left=Math.min(left,x);right=Math.max(right,x+1);top=Math.min(top,y);bottom=Math.max(bottom,y+1);}}
            bounds[n]=right>left&&bottom>top?new Rect(left,top,right,bottom):new Rect(0,0,bitmap.getWidth(),bitmap.getHeight());
        }}
        @Override protected void onDraw(Canvas canvas){super.onDraw(canvas);float edge=activity.dp(16),base=getHeight()-activity.dp(8);paint.setColor(0xffcbbdaf);canvas.drawRoundRect(new RectF(edge,activity.dp(8),getWidth()-edge,base),activity.dp(22),activity.dp(22),paint);
            Rect src=bounds[index];float scale=Math.min((getWidth()-activity.dp(4))/(float)src.width(),(getHeight()-activity.dp(16))/(float)src.height());float width=src.width()*scale,height=src.height()*scale;paint.setColor(Color.WHITE);
            canvas.drawBitmap(images[index],src,new RectF((getWidth()-width)/2,base-height,(getWidth()+width)/2,base),paint);
        }
    }
    static final class WelcomePage extends FrameLayout {
        final MainActivity activity;View art;TextView title,copy;
        WelcomePage(MainActivity a){super(a);activity=a;}
        void bind(View image,TextView heading,TextView description){art=image;title=heading;copy=description;}
        @Override protected void onMeasure(int widthSpec,int heightSpec){
            if(art!=null){
                int width=MeasureSpec.getSize(widthSpec),height=MeasureSpec.getSize(heightSpec);boolean compact=height<activity.dp(350);
                art.setVisibility(compact?View.GONE:View.VISIBLE);float size=compact?30:38;if(Math.abs(title.getTextSize()-size*getResources().getDisplayMetrics().scaledDensity)>1)title.setTextSize(size);
                int textWidth=Math.max(activity.dp(120),Math.min(width,activity.dp(540))-activity.dp(48));
                title.measure(MeasureSpec.makeMeasureSpec(textWidth,MeasureSpec.EXACTLY),MeasureSpec.makeMeasureSpec(0,MeasureSpec.UNSPECIFIED));copy.measure(MeasureSpec.makeMeasureSpec(textWidth,MeasureSpec.EXACTLY),MeasureSpec.makeMeasureSpec(0,MeasureSpec.UNSPECIFIED));
                int available=height-title.getMeasuredHeight()-copy.getMeasuredHeight()-activity.dp(62);
                art.getLayoutParams().height=Math.max(activity.dp(160),Math.min((int)(textWidth*1.08f),available));
            }
            super.onMeasure(widthSpec,heightSpec);
        }
    }
    static final class CappedColumn extends LinearLayout {
        final int maximum;
        CappedColumn(MainActivity a,int dp){super(a);maximum=a.dp(dp);setOrientation(VERTICAL);}
        @Override protected void onMeasure(int width,int height){int available=MeasureSpec.getMode(width)==MeasureSpec.UNSPECIFIED?maximum:MeasureSpec.getSize(width);super.onMeasure(MeasureSpec.makeMeasureSpec(Math.min(maximum,available),MeasureSpec.EXACTLY),height);}
    }
    static final class Page extends RecyclerView.ViewHolder{Page(View view){super(view);}}

    static LinearLayout scroll(MainActivity a){
        ScrollView scroll=new ScrollView(a);scroll.setFillViewport(true);scroll.setVerticalScrollBarEnabled(false);a.root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));FrameLayout measure=new FrameLayout(a);scroll.addView(measure,new ScrollView.LayoutParams(-1,-1));LinearLayout body=new CappedColumn(a,560);body.setPadding(a.dp(26),a.dp(12),a.dp(26),a.dp(24));measure.addView(body,new FrameLayout.LayoutParams(-1,-2,Gravity.TOP|Gravity.CENTER_HORIZONTAL));body.addView(a.icon(R.drawable.ic_back,"Back",()->{a.onboardingStage--;a.refresh();}),a.lp(48,48));a.gap(body,18);return body;
    }
    static void profile(MainActivity a){
        LinearLayout body=scroll(a);TextView title=a.text("Make it yours.",36,MainActivity.INK,true);title.setLetterSpacing(-.025f);body.addView(title);a.gap(body,10);
        body.addView(a.text("A space for your playlists, favorites\nand everything you love listening to.",15,MainActivity.MUTED,false));a.gap(body,22);
        FrameLayout photoArea=new FrameLayout(a);FrameLayout photoHit=new FrameLayout(a);photoHit.setContentDescription("Choose profile photo, optional");photoHit.setClickable(true);photoHit.setFocusable(true);photoHit.setOnClickListener(v->NativeScreens.choosePhoto(a));
        ImageView photo=new ImageView(a);photo.setImageResource(R.drawable.ic_profile);photo.setPadding(a.dp(28),a.dp(28),a.dp(28),a.dp(28));a.rounded(photo,MainActivity.ACCENT,52);photo.setClipToOutline(true);
        if(a.app.profiles.current().photo.isEmpty())photo.setColorFilter(MainActivity.ON_ACCENT);else{photo.setPadding(0,0,0,0);photo.setScaleType(ImageView.ScaleType.CENTER_CROP);Images.loadLocal(a,photo,a.app.profiles.current().photo);}
        photoHit.addView(photo,new FrameLayout.LayoutParams(a.dp(104),a.dp(104),Gravity.TOP|Gravity.CENTER_HORIZONTAL));
        ImageView badge=new ImageView(a);badge.setImageResource(R.drawable.ic_photo);badge.setColorFilter(MainActivity.INK);badge.setPadding(a.dp(12),a.dp(12),a.dp(12),a.dp(12));a.rounded(badge,MainActivity.RAISED,24);FrameLayout.LayoutParams badgeSize=new FrameLayout.LayoutParams(a.dp(44),a.dp(44),Gravity.BOTTOM|Gravity.RIGHT);photoHit.addView(badge,badgeSize);photoArea.addView(photoHit,new FrameLayout.LayoutParams(a.dp(120),a.dp(112),Gravity.CENTER));body.addView(photoArea,a.lp(-1,112));
        TextView photoLabel=a.text("Add a photo",13,MainActivity.ACCENT,true);photoLabel.setGravity(Gravity.CENTER);photoLabel.setOnClickListener(v->NativeScreens.choosePhoto(a));photoLabel.setContentDescription("Add a profile photo, optional");photoLabel.setFocusable(true);body.addView(photoLabel,a.lp(-1,48));a.gap(body,8);
        body.addView(a.text("Your name",14,MainActivity.INK,true));a.gap(body,10);EditText name=new EditText(a);name.setTag("profile_name");name.setText(a.onboardingName);name.setHint("What should we call you?");name.setSingleLine(true);name.setImeOptions(EditorInfo.IME_ACTION_DONE);name.setTextSize(17);name.setTextColor(MainActivity.INK);name.setHintTextColor(MainActivity.MUTED);name.setTypeface(a.face);name.setFilters(new InputFilter[]{new InputFilter.LengthFilter(40)});name.setPadding(a.dp(18),0,a.dp(18),0);a.rounded(name,MainActivity.SURFACE,14);name.setContentDescription("Your name, optional");body.addView(name,a.lp(-1,60));
        name.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int start,int count,int after){}public void onTextChanged(CharSequence s,int start,int before,int count){a.onboardingName=s.toString();}public void afterTextChanged(Editable e){}});
        a.gap(body,8);body.addView(a.text("Make it a nickname if you like. You can change it anytime.",12,MainActivity.MUTED,false));a.gap(body,18);
        AppCompatCheckBox consent=agreement(a,body,a.onboardingAccepted);a.gap(body,18);
        MaterialButton create=a.button("Create profile",0,true,()->completeProfile(a));create.setTag("create_profile");create.setEnabled(a.onboardingAccepted);create.setAlpha(a.onboardingAccepted?1:.55f);create.setCornerRadius(a.dp(28));body.addView(create,a.lp(-1,56));
        consent.setOnCheckedChangeListener((button,checked)->{a.onboardingAccepted=checked;create.setEnabled(checked);create.setAlpha(checked?1:.55f);});a.gap(body,14);
        TextView local=a.text("No email or password. Saved on this phone.\nProfiles aren't password-protected.",12,MainActivity.MUTED,false);local.setGravity(Gravity.CENTER);body.addView(local,a.lp(-1,-2));
    }
    static AppCompatCheckBox agreement(MainActivity a,LinearLayout body,boolean checked){
        LinearLayout row=a.row();row.setGravity(Gravity.TOP);AppCompatCheckBox box=new AppCompatCheckBox(a);box.setTag("onboarding_terms");box.setText("");box.setContentDescription("I confirm I am 13 or older, agree to Terms of Use and acknowledge Privacy Policy");box.setButtonTintList(new ColorStateList(new int[][]{new int[]{android.R.attr.state_checked},new int[]{}},new int[]{MainActivity.ACCENT,MainActivity.MUTED}));box.setChecked(checked);row.addView(box,a.lp(48,48));TextView text=a.text("",13,MainActivity.MUTED,false);text.setPadding(a.dp(2),a.dp(7),0,a.dp(7));text.setLineSpacing(a.dp(3),1);SpannableString links=new SpannableString(CONSENT);link(a,links,"Terms of Use","TERMS_OF_USE.md");link(a,links,"Privacy Policy","PRIVACY_POLICY.md");text.setText(links);text.setMovementMethod(LinkMovementMethod.getInstance());text.setHighlightColor(MainActivity.RAISED);row.addView(text,new LinearLayout.LayoutParams(0,-2,1));body.addView(row);return box;
    }
    static void recordAcceptance(MainActivity a){a.app.prefs("legal").edit().putString("terms_version",LEGAL_VERSION).putString("privacy_version",LEGAL_VERSION).putLong("accepted_at",System.currentTimeMillis()).apply();}
    private static void link(MainActivity a,SpannableString text,String label,String file){int start=CONSENT.indexOf(label);text.setSpan(new ClickableSpan(){public void onClick(View v){PrivacyLegal.document(a,file,label);}public void updateDrawState(TextPaint paint){paint.setColor(MainActivity.ACCENT);paint.setUnderlineText(true);}},start,start+label.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);}
    static boolean completeProfile(MainActivity a){
        if(!a.onboardingAccepted)return false;String name=a.onboardingName.trim();if(!name.isEmpty()){a.app.profiles.current().name=name;a.app.profiles.save();}recordAcceptance(a);a.onboardingStage=2;a.refresh();return true;
    }
    static void firstPlaylist(MainActivity a){
        LinearLayout body=scroll(a);ImageView mark=new ImageView(a);mark.setImageResource(R.drawable.syntix_app_icon);body.addView(mark,a.lp(46,46));a.gap(body,24);TextView title=a.text("Bring the songs\nyou already love.",35,MainActivity.INK,true);title.setLetterSpacing(-.025f);body.addView(title);a.gap(body,14);body.addView(a.text("Paste a YouTube or Spotify playlist link. We'll take it from there.",16,MainActivity.MUTED,false));a.gap(body,30);
        LinearLayout providers=a.row();providers.setPadding(a.dp(16),a.dp(14),a.dp(16),a.dp(14));a.rounded(providers,MainActivity.SURFACE,12);ImageView link=new ImageView(a);link.setImageResource(R.drawable.ic_link);link.setColorFilter(MainActivity.ACCENT);providers.addView(link,a.lp(28,28));LinearLayout hint=a.column();hint.setPadding(a.dp(13),0,0,0);hint.addView(a.text("Your playlist, one link away.",15,MainActivity.INK,true));a.gap(hint,5);hint.addView(a.text("YouTube or Spotify",13,MainActivity.MUTED,false));providers.addView(hint,new LinearLayout.LayoutParams(0,-2,1));body.addView(providers);a.gap(body,26);body.addView(a.button("Import a playlist",R.drawable.ic_link,true,()->a.finishOnboarding(true)),a.lp(-1,56));a.gap(body,8);body.addView(a.button("Find a song instead",R.drawable.ic_search,false,()->{a.finishOnboarding(false);a.tab("search");}),a.lp(-1,48));a.gap(body,8);body.addView(a.button("I'll explore first",0,false,()->a.finishOnboarding(false)),a.lp(-1,48));a.gap(body,24);body.addView(a.text("Offline comes next: download songs from a saved playlist while you're connected.",13,MainActivity.MUTED,false));
    }

}
