package app.skipline.android;

import android.content.Intent;
import android.text.*;
import android.widget.*;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import java.io.File;
import java.util.*;
import java.util.concurrent.*;

@androidx.media3.common.util.UnstableApi
final class DownloadScreens {
    private static final ExecutorService io=Executors.newSingleThreadExecutor(r->new Thread(r,"syntix-download-inventory"));
    static void render(MainActivity a,LinearLayout body){NativeSearch.header(a,body,"Downloads",null,()->DownloadQualitySheet.show(a));body.addView(a.text("Your music, even without a signal.",14,MainActivity.MUTED,false));a.gap(body,18);
        TextView usage=a.text("Reading saved audio…",13,MainActivity.MUTED,false),size=a.text("",13,MainActivity.MUTED,false);LinearLayout storage=a.row();storage.addView(usage,new LinearLayout.LayoutParams(0,-2,1));storage.addView(size);body.addView(storage);a.gap(body,12);EditText input=new EditText(a);input.setSingleLine();input.setTextSize(16);input.setTypeface(a.face);input.setTextColor(MainActivity.INK);input.setHintTextColor(MainActivity.MUTED);input.setHint("Find a downloaded song");a.rounded(input,MainActivity.SURFACE,7);input.setPadding(a.dp(12),0,a.dp(12),0);body.addView(input,a.lp(-1,48));a.gap(body,14);
        LinearLayout list=a.column();body.addView(list);ArrayList<Track> tracks=new ArrayList<>();final int[] shown={100};final String owner=a.app.profiles.active;OfflineStore store=a.app.offline;ArrayList<Track> known=new ArrayList<>(a.app.queue);known.addAll(a.app.favorites.tracks);known.addAll(a.app.history.recent());for(SavedPlaylist p:a.app.library)known.addAll(p.tracks);
        Runnable filter=()->{list.removeAllViews();String q=input.getText().toString().toLowerCase(Locale.ROOT).trim();ArrayList<Track> matches=new ArrayList<>();for(Track t:tracks)if((t.title+" "+t.creator).toLowerCase(Locale.ROOT).contains(q))matches.add(t);for(int i=0;i<Math.min(shown[0],matches.size());i++)NativeScreens.track(a,list,matches.get(i),null);if(matches.isEmpty()){LinearLayout empty=a.column();empty.setGravity(android.view.Gravity.CENTER);empty.setPadding(a.dp(9),a.dp(32),a.dp(9),a.dp(28));ImageView symbol=new ImageView(a);symbol.setImageResource(R.drawable.ic_download);symbol.setColorFilter(MainActivity.ACCENT);empty.addView(symbol,a.lp(36,36));a.gap(empty,18);TextView heading=a.text(q.isEmpty()?"Take your music with you":"No matching downloads",20,MainActivity.INK,true);heading.setGravity(android.view.Gravity.CENTER);empty.addView(heading);a.gap(empty,10);TextView note=a.text(q.isEmpty()?"Songs saved for offline listening appear here. Download a playlist or add local audio.":"Try another song or artist.",14,MainActivity.MUTED,false);note.setGravity(android.view.Gravity.CENTER);empty.addView(note);list.addView(empty);}if(matches.size()>shown[0])list.addView(a.button("Show more songs",R.drawable.ic_plus,false,()->{shown[0]+=100;input.setText(input.getText().toString());}),a.lp(-1,48));};
        input.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int aft){}public void onTextChanged(CharSequence s,int st,int before,int count){filter.run();}public void afterTextChanged(Editable e){}});
        io.execute(()->{ArrayList<Track> saved=store.downloaded(known);long bytes=0;for(Track t:saved){File f=store.file(t.source);if(f!=null)bytes+=f.length();}ArrayList<DownloadedDocuments.Item> documents=DownloadedDocuments.list(a.getApplicationContext(),owner);for(DownloadedDocuments.Item item:documents){saved.add(item.track);if(item.bytes>0)bytes+=item.bytes;}long total=bytes;a.app.main.post(()->{if(!list.isAttachedToWindow()||!owner.equals(a.app.profiles.active))return;tracks.addAll(saved);usage.setText(saved.size()+" songs on this device");size.setText(android.text.format.Formatter.formatFileSize(a,total));filter.run();});});
        a.gap(body,20);body.addView(a.button("Add local audio",R.drawable.ic_plus,true,()->a.startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("audio/*").addCategory(Intent.CATEGORY_OPENABLE),30)),a.lp(-1,48));a.gap(body,10);body.addView(a.button("Manage offline downloads",R.drawable.ic_download,false,()->OfflineScreens.manage(a)),a.lp(-1,48));
    }
}
