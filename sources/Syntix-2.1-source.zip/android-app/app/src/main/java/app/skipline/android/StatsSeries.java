package app.skipline.android;

import java.util.*;

/** Calendar-aware chart buckets over observed records; never generates activity. */
@androidx.annotation.OptIn(markerClass = androidx.media3.common.util.UnstableApi.class)
final class StatsSeries {
    final long[] dates;
    final double[] values;
    final long[] observed;
    final long totalMs,totalBytes,totalObserved;
    final double totalDrop;
    private StatsSeries(long[] dates,double[] values,long[] observed,long ms,long bytes,long observation,double drop){this.dates=dates;this.values=values;this.observed=observed;totalMs=ms;totalBytes=bytes;totalObserved=observation;totalDrop=drop;}
    static StatsSeries make(List<ActivityStats.Point> points,int kind,int unit,long now,TimeZone zone){
        if(kind<0||kind>2||unit<0||unit>2)throw new IllegalArgumentException("Unknown statistics view");
        ArrayList<Long> starts=new ArrayList<>();long from;
        Calendar c=Calendar.getInstance(zone);c.setTimeInMillis(now);
        if(unit==0){long hour=StatsTime.hourStart(now,zone);for(int i=0;i<24;i++)starts.add(hour-(23-i)*3600000L);from=starts.get(0);}
        else if(unit==1){midnight(c);c.add(Calendar.DATE,-29);for(int i=0;i<30;i++){starts.add(c.getTimeInMillis());c.add(Calendar.DATE,1);}from=starts.get(0);}
        else{from=StatsTime.cutoff(now,zone);c.setTimeInMillis(from);c.set(Calendar.DAY_OF_MONTH,1);midnight(c);while(c.getTimeInMillis()<=now){starts.add(c.getTimeInMillis());c.add(Calendar.MONTH,1);}}
        int count=starts.size();long[] dates=new long[count],observed=new long[count];double[] values=new double[count];for(int i=0;i<count;i++)dates[i]=starts.get(i);
        long ms=0,bytes=0,observation=0;double drop=0;
        for(ActivityStats.Point p:points){if(p.at<from||p.at>now)continue;int index=Arrays.binarySearch(dates,p.at);if(index<0)index=-index-2;if(index<0)continue;
            if(kind==0){values[index]+=p.listen/60000d;ms+=p.listen;}
            else if(kind==1){values[index]+=p.bytes/1000000d;bytes+=p.bytes;}
            else{values[index]+=p.drop;observed[index]+=p.observed;observation+=p.observed;drop+=p.drop;}
        }
        if(kind==2)for(int i=0;i<count;i++)values[i]=observed[i]>0?values[i]*3600000d/observed[i]:0;
        return new StatsSeries(dates,values,observed,ms,bytes,observation,drop);
    }
    private static void midnight(Calendar c){c.set(Calendar.HOUR_OF_DAY,0);c.set(Calendar.MINUTE,0);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);}
}
