package app.skipline.android;

import android.app.job.JobScheduler;
import android.content.*;
import java.io.File;

/** One-time removal of V3's managed audio cache. Saved playlists and exported files are untouched. */
final class LegacyPreparationCleanup {
    static void migrate(Context context){
        Context app=context.getApplicationContext();
        ((JobScheduler)app.getSystemService(Context.JOB_SCHEDULER_SERVICE)).cancel(73);
        app.stopService(new Intent().setComponent(new ComponentName(app.getPackageName(),app.getPackageName()+".PreparationService")));
        app.getSharedPreferences("preparation",0).edit().clear().apply();
        android.content.SharedPreferences maintenance=app.getSharedPreferences("maintenance",0);
        if(maintenance.getBoolean("v4_removed_bulk_cache",false))return;
        Thread cleanup=new Thread(()->{android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND);try{File root=new File(app.getNoBackupFilesDir(),"prepared-audio").getCanonicalFile();if(remove(root,root))maintenance.edit().putBoolean("v4_removed_bulk_cache",true).apply();}catch(Exception ignored){}},"skipline-cache-cleanup");cleanup.start();
    }
    private static boolean remove(File root,File item)throws java.io.IOException{
        File canonical=item.getCanonicalFile();if(!canonical.equals(root)&&!canonical.getPath().startsWith(root.getPath()+File.separator))return false;
        if(!canonical.exists())return true;boolean success=true;if(canonical.isDirectory()){File[] children=canonical.listFiles();if(children==null)return false;for(File child:children)success=remove(root,child)&&success;}return canonical.delete()&&success;
    }
}
