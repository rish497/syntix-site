package app.skipline.android;

import android.app.Application;
import android.os.Handler;
import android.os.Looper;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONArray;

@androidx.annotation.OptIn(markerClass = androidx.media3.common.util.UnstableApi.class)
public class SkiplineApp extends Application {
    static SkiplineApp instance;
    private final java.util.concurrent.ConcurrentHashMap<String,OfflineStore> offlineStores=new java.util.concurrent.ConcurrentHashMap<>();
    OfflineStore offlineStore(String id){return offlineStores.computeIfAbsent(id,key->new OfflineStore(this,key));}
    final Handler main = new Handler(Looper.getMainLooper());
    private static java.util.concurrent.ThreadFactory backgroundThreads(String name){return runnable->new Thread(()->{android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND);runnable.run();},name);}
    final ExecutorService worker = Executors.newSingleThreadExecutor(backgroundThreads("skipline-work"));
    final ArrayList<Track> queue = new ArrayList<>();
    final ArrayList<SavedPlaylist> library = new ArrayList<>();
    final ArrayList<Runnable> listeners = new ArrayList<>();
    final ArrayList<Runnable> playerListeners = new ArrayList<>();
    volatile boolean taskDismissed,backgroundIdle,uiActive,playbackBuffering;
    boolean importUpdate;
    boolean listeningUpdate;
    String status="", error="";
    String pendingBackup="";
    boolean busy=false;
    PlaybackService playback;
    ListeningHistory history;
    SpotifyImport.Job spotifyImport;
    ActivityStats statistics;
    LocalProfiles profiles;
    volatile OfflineStore offline;
    volatile OfflineDownloadService offlineService;
    volatile boolean offlineRunning,offlineClearing,manualDownloadRunning;
    volatile String offlineProgress="";
    final SavedPlaylist favorites=new SavedPlaylist("Favorites");
    final ArrayList<Track> searchResults=new ArrayList<>();
    String searchQuery="",searchError="";boolean searching;
    private int searchGeneration;
    private final java.util.concurrent.ThreadPoolExecutor searchWorker=new java.util.concurrent.ThreadPoolExecutor(1,1,0,java.util.concurrent.TimeUnit.MILLISECONDS,new java.util.concurrent.ArrayBlockingQueue<>(1),backgroundThreads("syntix-search"),new java.util.concurrent.ThreadPoolExecutor.DiscardOldestPolicy());
    android.content.SharedPreferences prefs(String name){return getSharedPreferences(profiles==null||profiles.active.equals("default")?name:name+"_"+profiles.active,0);}
    boolean isFavorite(Track track){for(Track t:favorites.tracks)if(t.source.equals(track.source))return true;return false;}
    void toggleFavorite(Track track){if(isFavorite(track))favorites.tracks.removeIf(t->t.source.equals(track.source));else favorites.tracks.add(track.copy());saveFavorites();changed();}
    void saveFavorites(){try{JSONArray data=new JSONArray();for(Track t:favorites.tracks)data.put(t.json());prefs("library").edit().putString("favorites",data.toString()).apply();}catch(Exception ignored){}}
    private void loadFavorites(){favorites.tracks.clear();try{JSONArray items=new JSONArray(prefs("library").getString("favorites","[]"));for(int i=0;i<items.length();i++)favorites.tracks.add(Track.fromJson(items.getJSONObject(i)));}catch(Exception ignored){}}
    void switchProfile(String id){if(busy||offlineRunning||offlineClearing)throw new IllegalStateException("Pause downloads or wait for the current import to finish.");if(profiles.find(id)==null||profiles.active.equals(id))return;SpotifyImport.cancel(this);spotifyImport=null;saveLibrary();saveFavorites();if(playback!=null){if(playback.sleep!=null)playback.sleep.cancel();playback.resetRecording();playback.player.pause();playback.player.stop();playback.player.clearMediaItems();}queue.clear();recommendations.clear();recommendationGeneration++;discovering=false;searchGeneration++;searching=false;searchQuery="";searchResults.clear();searchError="";profiles.active=id;profiles.save();if(statistics!=null)statistics.switchProfile();offline=offlineStore(id);loadLibrary();loadFavorites();history=new ListeningHistory(this);try{JSONArray items=new JSONArray(prefs("session").getString("queue","[]"));for(int i=0;i<items.length();i++)queue.add(Track.fromJson(items.getJSONObject(i)));}catch(Exception ignored){}recommendedAt=0;recommendationReason="";recommendationError="";status="";error="";if(playback!=null){SoundSettings.apply(this);playback.sync(false);}changed();}
    void search(String query){query=query.trim();if(query.isEmpty())return;searchQuery=query;searching=true;searchError="";final int generation=++searchGeneration;final String text=query;changed();searchWorker.execute(()->{try{ArrayList<Track> found=Extractor.search(this,text);main.post(()->{if(generation!=searchGeneration)return;searching=false;searchResults.clear();searchResults.addAll(found);changed();});}catch(Exception e){main.post(()->{if(generation!=searchGeneration)return;searching=false;searchError=Extractor.error(e);changed();});}});}

    final ArrayList<Track> recommendations=new ArrayList<>();
    private final ExecutorService discovery=Executors.newSingleThreadExecutor(backgroundThreads("skipline-suggestions"));
    private final java.util.concurrent.ThreadPoolExecutor streamWarmer=new java.util.concurrent.ThreadPoolExecutor(2,2,0,java.util.concurrent.TimeUnit.MILLISECONDS,new java.util.concurrent.ArrayBlockingQueue<>(2),backgroundThreads("skipline-link-warmup"),new java.util.concurrent.ThreadPoolExecutor.DiscardOldestPolicy());
    boolean discovering;
    String recommendationReason="",recommendationError="";
    private long recommendedAt;private int recommendationGeneration;private int discoveryRound;
    @Override public void onCreate() {
        super.onCreate();androidx.appcompat.app.AppCompatDelegate.setDefaultNightMode(androidx.appcompat.app.AppCompatDelegate.MODE_NIGHT_YES); instance=this;profiles=new LocalProfiles(this);offline=offlineStore(profiles.active);LegacyPreparationCleanup.migrate(this);getSharedPreferences("youtube_shortcuts",0).edit().clear().apply();
        try { JSONArray a=new JSONArray(prefs("session").getString("queue","[]")); for(int i=0;i<a.length();i++)queue.add(Track.fromJson(a.getJSONObject(i))); } catch(Exception ignored) {}
        loadLibrary();loadFavorites();history=new ListeningHistory(this);statistics=new ActivityStats(this);
        try{org.json.JSONObject saved=new org.json.JSONObject(prefs("history").getString("recommendations","{}"));recommendedAt=saved.optLong("time");recommendationReason=saved.optString("reason");JSONArray items=saved.optJSONArray("items");if(items!=null)for(int i=0;i<items.length();i++)recommendations.add(Track.fromJson(items.getJSONObject(i)));}catch(Exception ignored){}
        worker.execute(()->{try{Extractor.init(this);}catch(Exception ignored){}});
        final ArrayList<LocalProfiles.Profile> securedProfiles=new ArrayList<>(profiles.all);
        new Thread(()->{android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND);for(LocalProfiles.Profile profile:securedProfiles){if(taskDismissed)return;offlineStore(profile.id).secureExistingDownloads(()->!taskDismissed&&!offlineClearing);}},"syntix-offline-security").start();
    }
    void idleIfNoWork(){if(!uiActive&&!offlineRunning&&!manualDownloadRunning&&(playback==null||!playback.player.getPlayWhenReady()))pauseIdleWork();}
    void pauseIdleWork(){if(backgroundIdle)return;backgroundIdle=true;recommendationGeneration++;discovering=false;if(statistics!=null)statistics.suspend();NativeSearch.stopWork();Images.cancel();streamWarmer.getQueue().clear();}
    void dismissTask(){if(taskDismissed)return;taskDismissed=true;DirectAudio.cancel();backgroundIdle=true;SpotifyImport.cancel(this);recommendationGeneration++;discovering=false;if(statistics!=null)statistics.suspend();NativeSearch.stopWork();Images.cancel();streamWarmer.getQueue().clear();if(playback!=null)playback.stopForDismissal();stopService(new android.content.Intent(this,OfflineDownloadService.class));}
    void setPlayingPlaylist(SavedPlaylist saved){prefs("session").edit().putString("playing_playlist",saved==null?"":saved==favorites?"favorites":saved.id).putString("playing_name",saved==null?"Listening queue":saved.name).apply();}
    String playingPlaylistName(){String id=prefs("session").getString("playing_playlist","");if(id.equals("favorites"))return "Favorites";for(SavedPlaylist saved:library)if(saved.id.equals(id))return saved.name;return prefs("session").getString("playing_name","Listening queue");}
    void loadLibrary(){library.clear();try{JSONArray items=new JSONArray(prefs("library").getString("playlists","[]"));for(int i=0;i<items.length();i++)library.add(SavedPlaylist.fromJson(items.getJSONObject(i)));}catch(Exception ignored){}}
    void saveLibrary(){try{JSONArray items=new JSONArray();for(SavedPlaylist list:library)items.put(list.json());prefs("library").edit().putString("playlists",items.toString()).apply();}catch(Exception ignored){}changed();}
    void preparePlayback(){if(!taskDismissed&&!backgroundIdle)streamWarmer.execute(()->{if(!taskDismissed&&!backgroundIdle)DirectAudio.prepareSession();});}
    void warmVisibleTracks(java.util.List<Track> tracks){if(playbackBuffering)return;for(int i=0;i<Math.min(2,tracks.size());i++)warmStream(tracks.get(i));}
    void warmStream(Track track){if(taskDismissed||backgroundIdle||track==null||!track.source.startsWith("https://")||offline.file(track.source)!=null)return;streamWarmer.execute(()->{if(taskDismissed||backgroundIdle)return;try{Extractor.resolve(this,track.source);}catch(Exception ignored){}});}
    private String warmedSearch="";private long searchWarmedAt;
    void warmSearchResults(String query,java.util.List<Track> results){
        if(results.isEmpty()||taskDismissed||backgroundIdle||playbackBuffering)return;
        String key=query+"\n"+results.get(0).source;if(key.equals(warmedSearch)&&android.os.SystemClock.elapsedRealtime()-searchWarmedAt<30000)return;warmedSearch=key;searchWarmedAt=android.os.SystemClock.elapsedRealtime();streamWarmer.getQueue().clear();
        // Resolve only two leading links. Native availability checks read one byte and never save audio.
        for(int i=0;i<Math.min(2,results.size());i++)warmStream(results.get(i));
    }
    void playerChanged(){for(Runnable listener:new ArrayList<>(playerListeners))listener.run();}
    void requestRecommendations(Track seed){if(!seed.source.startsWith("https://")||discovering||!prefs("history").getBoolean("recommendations_enabled",true)||System.currentTimeMillis()-recommendedAt<15*60*1000)return;discovering=true;recommendationError="";final int generation=recommendationGeneration;final ArrayList<Track> seeds=history.recommendationSeeds(discoveryRound++);discovery.execute(()->{try{ArrayList<Track> candidates=new ArrayList<>();Exception failed=null;for(Track listeningSeed:seeds){if(taskDismissed||backgroundIdle)return;try{candidates.addAll(Extractor.suggest(this,listeningSeed));}catch(Exception e){failed=e;}}if(candidates.isEmpty()&&failed!=null)throw failed;main.post(()->{if(generation!=recommendationGeneration)return;discovering=false;if(!prefs("history").getBoolean("recommendations_enabled",true))return;recommendations.clear();java.util.HashSet<String> seen=new java.util.HashSet<>();for(Track t:candidates)if(!history.heard(t.source)&&seen.add(t.source))recommendations.add(t);recommendations.sort((a,b)->Integer.compare(history.affinity(b),history.affinity(a)));recommendationReason="From your listening history · "+history.size()+" songs";recommendedAt=System.currentTimeMillis();try{JSONArray items=new JSONArray();for(Track t:recommendations)items.put(t.json());prefs("history").edit().putString("recommendations",new org.json.JSONObject().put("items",items).put("reason",recommendationReason).put("time",recommendedAt).toString()).apply();}catch(Exception ignored){}listeningChanged();});}catch(Exception e){main.post(()->{if(generation!=recommendationGeneration)return;discovering=false;recommendationError="Could not load suggestions. Try again.";listeningChanged();});}});}
    void refreshRecommendations(){recommendedAt=0;for(Track t:history.recent())if(t.source.startsWith("https://")){requestRecommendations(t);return;}}
    void clearHistory(){if(playback!=null)playback.resetRecording();recommendationGeneration++;discovering=false;recommendationError="";history.clear();if(statistics!=null)statistics.clear();recommendations.clear();recommendedAt=0;recommendationReason="";prefs("history").edit().remove("recommendations").apply();changed();}
    void listeningChanged(){boolean previous=listeningUpdate;listeningUpdate=true;try{changed();}finally{listeningUpdate=previous;}}
    void changed() {
        try { JSONArray a=new JSONArray(); for(Track t:queue)a.put(t.json());prefs("session").edit().putString("queue",a.toString()).apply(); }catch(Exception ignored){}
        for(Runnable r:new ArrayList<>(listeners))r.run();
    }
    Track find(String id) { for(Track t:queue)if(t.id.equals(id))return t;return null; }
    void fail(String message) { main.post(()->{busy=false;status="";error=message;changed();}); }
}
