package app.skipline.android;

import android.content.res.ColorStateList;
import android.graphics.Color;
import android.view.View;
import android.widget.*;
import com.google.android.material.bottomsheet.BottomSheetDialog;

@androidx.media3.common.util.UnstableApi
final class DownloadQualitySheet {
    static void show(MainActivity a){
        LinearLayout body=a.column();a.handle(body);body.addView(a.text("Download quality",26,MainActivity.INK,true));a.gap(body,10);body.addView(a.text("Choose how your offline music is saved.",14,MainActivity.MUTED,false));a.gap(body,22);
        RadioGroup choices=new RadioGroup(a);TextView estimate=a.text("",13,MainActivity.MUTED,false);
        ColorStateList colors=new ColorStateList(new int[][]{{android.R.attr.state_checked},{}},new int[]{MainActivity.ACCENT,MainActivity.MUTED});
        for(int rate:new int[]{16,128,192}){RadioButton option=new RadioButton(a);option.setId(View.generateViewId());option.setText((rate==16?"Compact":rate==128?"Standard":"High")+" · "+rate+" kbps");option.setTypeface(a.face);option.setTextSize(16);option.setTextColor(MainActivity.INK);option.setButtonTintList(colors);option.setPadding(a.dp(8),a.dp(12),a.dp(8),a.dp(12));option.setBackground(new android.graphics.drawable.RippleDrawable(ColorStateList.valueOf(0x18ffffff),null,new android.graphics.drawable.ColorDrawable(Color.WHITE)));choices.addView(option,a.lp(-1,64));option.setChecked(a.app.offline.bitrate()==rate);option.setOnClickListener(v->{a.app.offline.bitrate(rate);estimate.setText(size(rate));});}
        body.addView(choices);a.gap(body,20);estimate.setText(size(a.app.offline.bitrate()));body.addView(estimate);a.gap(body,15);body.addView(a.text("Applies to future downloads. Existing songs stay unchanged.",13,MainActivity.MUTED,false));a.gap(body,24);BottomSheetDialog[] dialog=new BottomSheetDialog[1];body.addView(a.button("Done",0,true,()->dialog[0].dismiss()),a.lp(-1,52));dialog[0]=a.sheet(body);
    }
    private static String size(int rate){return "About "+(rate*3)+" MB for 100 four-minute songs. Actual size varies.";}
}
