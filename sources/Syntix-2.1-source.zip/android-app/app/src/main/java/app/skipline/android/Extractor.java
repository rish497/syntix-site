package app.skipline.android;

import android.content.Context;
import android.net.Uri;
import com.yausername.youtubedl_android.YoutubeDL;
import com.yausername.youtubedl_android.YoutubeDLRequest;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

final class Extractor {
    private static boolean initialized;
    private static final ConcurrentHashMap<String,Resolved> cache=new ConcurrentHashMap<>();
    private static final ConcurrentHashMap<String,java.util.concurrent.FutureTask<Resolved>> pending=new ConcurrentHashMap<>();
    private static final ConcurrentHashMap<String,Long> compatibilityUntil=new ConcurrentHashMap<>();
    private static final ConcurrentHashMap<String,Track> metadata=new ConcurrentHashMap<>();
    static synchronized void init(Context context) throws Exception {
        if(initialized)return;
        YoutubeDL.INSTANCE.init(context.getApplicationContext());
        initialized=true;
    }
    static YoutubeDLRequest request(String source) {
        return new YoutubeDLRequest(source).addOption("--no-warnings").addOption("--socket-timeout","10").addOption("--retries","1").addOption("--extractor-retries","1");
    }
    private static final java.util.concurrent.atomic.AtomicInteger metadataEpoch=new java.util.concurrent.atomic.AtomicInteger();
    static int epoch(){return metadataEpoch.get();}
    private static final java.util.Set<String> metadataProcesses=java.util.concurrent.ConcurrentHashMap.newKeySet();
    static void cancelMetadata(){metadataEpoch.incrementAndGet();YouTubePlaylist.cancel();cancelProcesses(metadataProcesses);}
    static void cancelProcesses(java.util.Collection<String> processes){String[] cancelled=processes.toArray(new String[0]);if(cancelled.length==0)return;new Thread(()->{for(String id:cancelled)try{YoutubeDL.INSTANCE.destroyProcessById(id);}catch(Exception ignored){}},"syntix-metadata-cancel").start();}
    private static String executeMetadata(YoutubeDLRequest request) throws Exception {
        return executeMetadata(request,"metadata-"+System.nanoTime());
    }
    private static String executeMetadata(YoutubeDLRequest request,String process) throws Exception {
        if(SkiplineApp.instance!=null&&SkiplineApp.instance.taskDismissed)throw new java.util.concurrent.CancellationException("App task closed");
        metadataProcesses.add(process);
        java.util.concurrent.ScheduledExecutorService timer=java.util.concurrent.Executors.newSingleThreadScheduledExecutor();
        java.util.concurrent.ScheduledFuture<?> timeout=timer.schedule(()->YoutubeDL.INSTANCE.destroyProcessById(process),90,java.util.concurrent.TimeUnit.SECONDS);
        try{return YoutubeDL.INSTANCE.execute(request,process,false,null).getOut();}
        finally{metadataProcesses.remove(process);timeout.cancel(false);timer.shutdownNow();}
    }
    static ArrayList<Track> inspect(Context context,String url) throws Exception {
        if(SkiplineApp.instance!=null&&SkiplineApp.instance.backgroundIdle)throw new java.util.concurrent.CancellationException();
        if(SpotifySong.accepts(url)){int started=epoch();return new ArrayList<>(java.util.Collections.singletonList(SpotifySong.resolve(context,url,()->started==epoch()&&(SkiplineApp.instance==null||!SkiplineApp.instance.taskDismissed&&!SkiplineApp.instance.backgroundIdle))));}
        String source=Links.extract(url);
        if(Links.isPlaylist(source)){int started=epoch();try{return YouTubePlaylist.read(source,()->started==epoch()&&(SkiplineApp.instance==null||!SkiplineApp.instance.taskDismissed&&!SkiplineApp.instance.backgroundIdle));}catch(java.util.concurrent.CancellationException stopped){throw stopped;}catch(Exception unavailable){if(started!=epoch())throw unavailable;}}
        init(context);
        if(!Links.isPlaylist(source)){Uri parsed=Uri.parse(source);String id="youtu.be".equalsIgnoreCase(parsed.getHost())?parsed.getLastPathSegment():parsed.getQueryParameter("v");if(id!=null&&id.matches("[A-Za-z0-9_-]{11}"))source="https://www.youtube.com/watch?v="+id;Track known=metadata.get(source);Resolved audio=cache.get(source);if(known!=null&&audio!=null&&System.currentTimeMillis()<audio.expiresAt){ArrayList<Track> hit=new ArrayList<>();hit.add(known.copy());return hit;}}
        YoutubeDLRequest req=request(source).addOption("--dump-single-json").addOption("--skip-download");
        if(Links.isPlaylist(source))req.addOption("--flat-playlist");
        else req.addOption("--no-playlist").addOption("-f","bestaudio[protocol=https]/best[protocol=https]");
        JSONObject j=Links.isPlaylist(source)?new JSONObject(executeMetadata(req)):videoJson(source);
        ArrayList<Track> result=new ArrayList<>();
        JSONArray entries=j.optJSONArray("entries");
        if(entries==null){Track t=track(j);result.add(t);if(!Links.isPlaylist(source)&&!j.optString("url").isEmpty()){Resolved audio=resolved(j);if(metadata.size()>24)metadata.clear();cache.put(source,audio);cache.put(t.source,audio);metadata.put(source,t);metadata.put(t.source,t);}}
        else for(int i=0;i<entries.length();i++) { JSONObject item=entries.optJSONObject(i); if(item!=null&&!item.optString("id").isEmpty())result.add(track(item)); }
        if(result.isEmpty())throw new IllegalArgumentException("No playable entries were found in this link.");
        return result;
    }
    private static Track track(JSONObject j) {
        String id=j.optString("id","");
        String source=j.optString("webpage_url",j.optString("url",""));
        if(!source.startsWith("http"))source="https://www.youtube.com/watch?v="+id;
        String thumb=j.optString("thumbnail","");
        JSONArray thumbs=j.optJSONArray("thumbnails");
        if(thumb.isEmpty()&&thumbs!=null&&thumbs.length()>0)thumb=thumbs.optJSONObject(thumbs.length()-1).optString("url","");
        if(thumb.isEmpty()&&!id.isEmpty())thumb="https://i.ytimg.com/vi/"+id+"/hqdefault.jpg";
        return new Track(source,j.optString("title","Untitled video"),j.optString("uploader",j.optString("channel","YouTube")),thumb,(long)j.optDouble("duration",0));
    }
    static ArrayList<Track> search(Context context,String query)throws Exception{
        if(SkiplineApp.instance!=null&&SkiplineApp.instance.backgroundIdle)throw new java.util.concurrent.CancellationException();
        init(context);String clean=query.replaceAll("[\\p{Cntrl}]"," ").trim();if(clean.isEmpty()||clean.length()>180)throw new IllegalArgumentException("Use a search between 1 and 180 characters.");
        JSONObject result=new JSONObject(executeMetadata(request("ytsearch30:"+clean).addOption("--flat-playlist").addOption("--dump-single-json").addOption("--skip-download")));
        ArrayList<Track> tracks=new ArrayList<>();JSONArray entries=result.optJSONArray("entries");if(entries!=null)for(int i=0;i<entries.length();i++){JSONObject item=entries.optJSONObject(i);if(item!=null&&!item.optString("id").isEmpty())tracks.add(track(item));}return tracks;
    }
    static ArrayList<Track> searchForImport(Context context,String query,String process,java.util.function.BooleanSupplier proceed)throws Exception{
        if(SkiplineApp.instance!=null&&SkiplineApp.instance.backgroundIdle)throw new java.util.concurrent.CancellationException();
        init(context);String clean=query.replaceAll("[\\p{Cntrl}]"," ").trim();if(clean.isEmpty()||clean.length()>180)throw new IllegalArgumentException("Use a search between 1 and 180 characters.");
        YoutubeDLRequest req=request("ytsearch20:"+clean).addOption("--flat-playlist").addOption("--dump-single-json").addOption("--skip-download").addOption("--sleep-requests","0.6").addOption("--retries","0").addOption("--extractor-retries","0");
        JSONObject result;
        try{if(!proceed.getAsBoolean())throw new java.util.concurrent.CancellationException();result=new JSONObject(executeMetadata(req,process));}catch(Exception e){String message=String.valueOf(e.getMessage()).toLowerCase(java.util.Locale.ROOT);if(message.contains("429")||message.contains("confirm you're not a bot")||message.contains("unusual traffic")||message.contains("/sorry/"))throw new YouTubeMetadata.SearchBlockedException();throw e;}
        JSONArray entries=result.optJSONArray("entries");if(entries==null)throw new java.io.IOException("YouTube search did not return a track list.");ArrayList<Track> tracks=new ArrayList<>();for(int i=0;i<entries.length();i++){JSONObject item=entries.optJSONObject(i);if(item!=null&&item.optString("id").matches("[A-Za-z0-9_-]{11}"))tracks.add(track(item));}return tracks;
    }
    static ArrayList<Track> suggest(Context context,Track seed)throws Exception{if(SkiplineApp.instance!=null&&SkiplineApp.instance.backgroundIdle)throw new java.util.concurrent.CancellationException();init(context);String query=(seed.creator.isEmpty()?seed.title:seed.creator+" "+seed.title).replaceAll("[\\p{Cntrl}]", " ");if(query.length()>180)query=query.substring(0,180);JSONObject result=new JSONObject(executeMetadata(request("ytsearch8:"+query+" music").addOption("--flat-playlist").addOption("--dump-single-json").addOption("--skip-download")));ArrayList<Track> tracks=new ArrayList<>();JSONArray entries=result.optJSONArray("entries");if(entries!=null)for(int i=0;i<entries.length();i++){JSONObject item=entries.optJSONObject(i);if(item!=null&&!item.optString("id").isEmpty())tracks.add(track(item));}return tracks;}
    static String canonical(String source){try{return Links.singleVideo(source);}catch(Exception ignored){return source;}}
    static Resolved resolve(Context context,String source) throws Exception {
        String key=canonical(source);Resolved old=cache.get(key);
        if(old!=null&&System.currentTimeMillis()<old.expiresAt){android.util.Log.d("SyntixPlayback","Audio link cache hit");return old;}
        long started=android.os.SystemClock.elapsedRealtime();
        java.util.concurrent.FutureTask<Resolved> task=new java.util.concurrent.FutureTask<>(()->resolveFresh(context,key));
        java.util.concurrent.FutureTask<Resolved> existing=pending.putIfAbsent(key,task);
        if(existing!=null)task=existing;else task.run();
        try{return task.get();}catch(java.util.concurrent.ExecutionException e){Throwable cause=e.getCause();if(cause instanceof Exception)throw (Exception)cause;throw e;}finally{pending.remove(key,task);android.util.Log.d("SyntixPlayback","Audio link resolve: "+(android.os.SystemClock.elapsedRealtime()-started)+" ms");}
    }
    static void invalidate(String source){cache.remove(canonical(source));}
    static boolean tryCompatibility(String source){source=canonical(source);Resolved value=cache.remove(source);if(value==null||!value.fast)return false;if(compatibilityUntil.size()>24)compatibilityUntil.clear();compatibilityUntil.put(source,System.currentTimeMillis()+600000);return true;}
    private static JSONObject videoJson(String source)throws Exception{
        final int operationEpoch=epoch();
        Long until=compatibilityUntil.get(source);
        if(until==null||until<System.currentTimeMillis()){
            try{return new JSONObject(executeMetadata(videoRequest(source).addOption("--extractor-args","youtube:player_client=visionos").addOption("--retries","0"))).put("_skipline_fast",true);}
            catch(Exception unsupported){if(operationEpoch!=epoch()||SkiplineApp.instance!=null&&SkiplineApp.instance.taskDismissed)throw unsupported;/* Keep the upstream client compatibility fallback. */}
        }
        return new JSONObject(executeMetadata(videoRequest(source)));
    }
    private static YoutubeDLRequest videoRequest(String source){return request(source).addOption("--no-playlist").addOption("--skip-download").addOption("--dump-single-json").addOption("-f","bestaudio[protocol=https]/best[protocol=https]");}
    private static Resolved resolveFresh(Context context,String source)throws Exception{
        if(SkiplineApp.instance!=null&&SkiplineApp.instance.taskDismissed)throw new java.util.concurrent.CancellationException();
        Long compatibility=compatibilityUntil.get(source);
        if(compatibility==null||System.currentTimeMillis()>compatibility)try{DirectAudio.Data direct=DirectAudio.resolve(source);Resolved value=new Resolved(direct.url,direct.headers,true);trimCache();cache.put(source,value);metadata.put(source,direct.track);return value;}catch(Exception unavailable){if(SkiplineApp.instance!=null&&SkiplineApp.instance.taskDismissed)throw unavailable;}
        init(context);
        JSONObject j=videoJson(source);
        Resolved value=resolved(j);trimCache();cache.put(source,value);Track track=track(j);metadata.put(source,track);metadata.put(track.source,track);return value;
    }
    private static synchronized void trimCache(){
        long now=System.currentTimeMillis();cache.entrySet().removeIf(entry->entry.getValue().expiresAt<=now);
        while(cache.size()>=32){Map.Entry<String,Resolved> oldest=null;for(Map.Entry<String,Resolved> entry:cache.entrySet())if(oldest==null||entry.getValue().expiresAt<oldest.getValue().expiresAt)oldest=entry;if(oldest==null)break;cache.remove(oldest.getKey(),oldest.getValue());}
        if(metadata.size()>64)metadata.clear();
    }
    private static Resolved resolved(JSONObject j)throws Exception{
        String url=j.optString("url","");
        if(!url.startsWith("https://"))throw new IllegalArgumentException("This video did not provide a supported audio stream.");
        Map<String,String> headers=new HashMap<>();JSONObject h=j.optJSONObject("http_headers");
        if(h!=null){java.util.Iterator<String> keys=h.keys();while(keys.hasNext()){String key=keys.next();headers.put(key,h.optString(key));}}
        return new Resolved(url,headers,j.optBoolean("_skipline_fast",false));
    }
    static String error(Throwable e) {
        String raw=e.getMessage()==null?"":e.getMessage();
        if(raw.contains("Unknown encoder")||raw.contains("libopus"))return "Compact audio encoding failed. Retry the download, or update Syntix.";
        if(raw.contains("This song is not downloaded"))return raw;
        if(raw.contains("Storage is nearly full"))return raw;
        if(raw.contains("Sign in")||raw.contains("sign in")||raw.contains("bot"))return "YouTube is asking for verification. Try another public video or try again later. Syntix does not collect your Google login.";
        if(raw.contains("403")||raw.contains("format")||raw.contains("signature"))return "YouTube did not provide a playable stream. Try Update playback engine in Settings, then retry.";
        if(raw.contains("timed out")||raw.contains("resolve host")||raw.contains("Unable to download"))return "Could not reach YouTube. Check your connection and retry.";
        if(e instanceof IllegalArgumentException)return raw;
        return "Could not load this item. Check your connection, update the playback engine in Settings, and retry.";
    }
    static final class Resolved {
        final String url;final Map<String,String> headers;final long expiresAt;final boolean fast;
        Resolved(String url,Map<String,String> headers,boolean fast){this.url=url;this.headers=headers;this.fast=fast;long expires=System.currentTimeMillis()+600000;try{String raw=Uri.parse(url).getQueryParameter("expire");if(raw!=null)expires=Math.min(expires,Long.parseLong(raw)*1000-60000);}catch(Exception ignored){}expiresAt=expires;}
    }
}
