package app.skipline.android;

import android.net.Uri;
import androidx.media3.common.C;
import androidx.media3.datasource.*;
import java.io.*;
import java.util.*;

/** Routes only Syntix encrypted files through seekable authenticated decryption. */
@androidx.media3.common.util.UnstableApi
final class OfflineDataSource implements DataSource {
    private final DataSource.Factory defaults;
    private final List<TransferListener> listeners=new ArrayList<>();
    private DataSource active;
    OfflineDataSource(DataSource.Factory defaults){this.defaults=defaults;}
    public void addTransferListener(TransferListener listener){listeners.add(listener);if(active!=null)active.addTransferListener(listener);}
    public long open(DataSpec spec)throws IOException {
        String path=spec.uri.getPath();active="file".equals(spec.uri.getScheme())&&path!=null&&path.endsWith(".sxa")?new SecureFile():defaults.createDataSource();
        for(TransferListener listener:listeners)active.addTransferListener(listener);
        try{return active.open(spec);}catch(IOException|RuntimeException e){try{active.close();}catch(IOException ignored){}active=null;throw e;}
    }
    public int read(byte[] buffer,int offset,int length)throws IOException{if(active==null)throw new IOException("No audio is open");return active.read(buffer,offset,length);}
    public Uri getUri(){return active==null?null:active.getUri();}
    public Map<String,List<String>> getResponseHeaders(){return active==null?Collections.emptyMap():active.getResponseHeaders();}
    public void close()throws IOException{try{if(active!=null)active.close();}finally{active=null;}}

    private static final class SecureFile extends BaseDataSource {
        private EncryptedAudio.Reader reader;private Uri uri;private long position,remaining;private boolean started;
        SecureFile(){super(false);}
        public long open(DataSpec spec)throws IOException {
            transferInitializing(spec);uri=spec.uri;reader=OfflineAudio.open(new File(Objects.requireNonNull(uri.getPath())));
            position=spec.position;if(position>reader.length)throw new IOException("Invalid offline audio position");
            remaining=reader.length-position;if(spec.length!=C.LENGTH_UNSET)remaining=Math.min(remaining,spec.length);
            started=true;transferStarted(spec);return remaining;
        }
        public int read(byte[] buffer,int offset,int length)throws IOException {
            if(length==0)return 0;if(remaining==0)return C.RESULT_END_OF_INPUT;
            int count=reader.read(position,buffer,offset,(int)Math.min(length,remaining));if(count<0)throw new EOFException("Incomplete encrypted audio");
            position+=count;remaining-=count;bytesTransferred(count);return count;
        }
        public Uri getUri(){return uri;}
        public void close()throws IOException{try{if(reader!=null)reader.close();}finally{reader=null;uri=null;if(started){started=false;transferEnded();}}}
    }
}
