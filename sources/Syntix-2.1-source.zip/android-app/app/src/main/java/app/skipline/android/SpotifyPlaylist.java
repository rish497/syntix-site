package app.skipline.android;

import java.io.*;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.*;
import okhttp3.*;
import org.json.*;

/** Public playlist metadata only. Does not read tokens, cookies, previews or Spotify audio. */
final class SpotifyPlaylist {
    static final int MAX_BYTES=5*1024*1024,MAX_SONGS=5000;
    static final class Song {
        final String title,artist,uri,album;final long durationMs;final Boolean explicit;
        Song(String t,String a,long d,String u){this(t,a,d,u,"",null);}
        Song(String t,String a,long d,String u,String record,Boolean rating){title=t.trim();artist=a.replace('\u00a0',' ').trim();durationMs=Math.max(0,d);uri=u;album=record;explicit=rating;}
        String query(){String q=(title+" "+artist+" official audio").replaceAll("[\\p{Cntrl}]"," ");return q.length()>180?q.substring(0,180):q;}
    }
    static final class Data {
        String name="Spotify playlist",source="";int total=-1,skipped;boolean csv;
        final ArrayList<Song> songs=new ArrayList<>();
        boolean complete(){return csv||total>=0&&songs.size()+skipped==total;}
    }
    static boolean looksLike(String text){try{link(text);return true;}catch(IllegalArgumentException ignored){return false;}}
    static String link(String text){
        if(text==null)throw new IllegalArgumentException("Paste a Spotify playlist link.");
        Matcher uri=Pattern.compile("spotify:playlist:([A-Za-z0-9]{22})(?![A-Za-z0-9])").matcher(text);if(uri.find())return "https://open.spotify.com/playlist/"+uri.group(1);
        Matcher urls=Pattern.compile("https?://[^\\s<>\"\\[\\]\\(\\)]+",Pattern.CASE_INSENSITIVE).matcher(text);
        while(urls.find())try{URI u=new URI(urls.group().replaceAll("[),.;!?]+$",""));if(!"open.spotify.com".equalsIgnoreCase(u.getHost())||u.getUserInfo()!=null||u.getPort()!=-1)continue;Matcher path=Pattern.compile("^/(?:intl-[A-Za-z-]+/|embed/)?playlist/([A-Za-z0-9]{22})/?$").matcher(u.getPath());if(path.matches())return "https://open.spotify.com/playlist/"+path.group(1);}catch(Exception ignored){}
        throw new IllegalArgumentException("Use a full open.spotify.com/playlist link.");
    }
    static Data fetch(String text,OkHttpClient client)throws Exception{
        return fetch(text,client,()->true);
    }
    static Data fetch(String text,OkHttpClient client,java.util.function.BooleanSupplier active)throws Exception{
        try{return SpotifyPublicPlaylist.fetch(link(text),client,active);}catch(java.util.concurrent.CancellationException cancelled){throw cancelled;}catch(Exception unavailable){if(!active.getAsBoolean())throw new java.util.concurrent.CancellationException();/* Public embed remains a disclosed fallback when the full-list service is unavailable. */}
        String url=link(text),id=url.substring(url.lastIndexOf('/')+1);Data data=parseEmbed(get(client,"https://open.spotify.com/embed/playlist/"+id));data.source=url;
        try{data.total=publicCount(get(client,url));}catch(IOException unavailable){/* Unknown size remains explicitly unverified in the review UI. */}
        return data;
    }
    private static String get(OkHttpClient client,String url)throws IOException{
        Request request=new Request.Builder().url(url).header("User-Agent","Mozilla/5.0").header("Accept-Language","en-US,en;q=0.8").build();
        try(Response response=client.newCall(request).execute()){if(!response.isSuccessful()||response.body()==null)throw new IOException("Spotify could not expose this playlist publicly. Try another public playlist link.");return read(response.body().byteStream());}
    }
    static Data parseEmbed(String html)throws Exception{
        Matcher script=Pattern.compile("<script(?=[^>]*\\bid=[\"']__NEXT_DATA__[\"'])[^>]*>(.*?)</script>",Pattern.DOTALL|Pattern.CASE_INSENSITIVE).matcher(html);
        if(!script.find())throw new IOException("Spotify's public playlist format is unavailable. Try another public playlist link.");
        JSONObject entity;try{entity=new JSONObject(script.group(1)).getJSONObject("props").getJSONObject("pageProps").getJSONObject("state").getJSONObject("data").getJSONObject("entity");}catch(JSONException changed){throw new IOException("Spotify’s public format changed. Try another public playlist link.",changed);}
        if(!"playlist".equals(entity.optString("type")))throw new IOException("Choose a Spotify music playlist.");
        Data data=new Data();String name=entity.optString("title",entity.optString("name")).trim();if(!name.isEmpty())data.name=name;JSONArray tracks=entity.optJSONArray("trackList");if(tracks==null)throw new IOException("No public track list was available. Try another public playlist link.");
        for(int i=0;i<tracks.length();i++){JSONObject track=tracks.optJSONObject(i);if(track==null)continue;String title=track.optString("title").trim(),artist=track.optString("subtitle").trim(),uri=track.optString("uri");if(!uri.startsWith("spotify:track:")||title.isEmpty()||artist.isEmpty()){data.skipped++;continue;}data.songs.add(new Song(title,artist,track.optLong("duration"),uri));}
        if(data.songs.isEmpty())throw new IOException("No music tracks were exposed publicly. Try another public playlist link.");return data;
    }
    static int publicCount(String html){
        Matcher meta=Pattern.compile("<meta(?=[^>]*(?:property|name)=[\"']og:description[\"'])(?=[^>]*content=[\"']([^\"']*)[\"'])[^>]*>",Pattern.CASE_INSENSITIVE).matcher(html);
        if(!meta.find())return -1;Matcher count=Pattern.compile("(?:^|[·•])\\s*([0-9][0-9,]*)\\s+(?:items|songs|tracks)\\b",Pattern.CASE_INSENSITIVE).matcher(meta.group(1));try{return count.find()?Integer.parseInt(count.group(1).replace(",","")):-1;}catch(NumberFormatException invalid){return -1;}
    }
    static Data csv(InputStream input,String filename)throws Exception{
        String text=read(input);if(text.startsWith("\ufeff"))text=text.substring(1);ArrayList<ArrayList<String>> rows=csvRows(text);if(rows.size()<2)throw new IOException("Choose a CSV with song titles and artists.");
        ArrayList<String> header=rows.remove(0);int title=column(header,"trackname","songname","tracktitle","songtitle","title","name"),artist=column(header,"artistnames","artistname","artists","artist"),duration=column(header,"durationms","durationmilliseconds"),uri=column(header,"trackuri","spotifyuri","trackurl","spotifyurl");
        if(title<0||artist<0)throw new IOException("The CSV needs Track Name and Artist Name(s) columns.");Data data=new Data();data.csv=true;data.total=rows.size();String name=filename==null?"":filename.replaceFirst("(?i)\\.csv$","").trim();if(!name.isEmpty())data.name=name.substring(0,Math.min(80,name.length()));
        for(ArrayList<String> row:rows){String t=cell(row,title).trim(),a=cell(row,artist).trim(),u=cell(row,uri).trim();if(t.isEmpty()||a.isEmpty()||u.startsWith("spotify:episode:")||u.startsWith("spotify:local:")){data.skipped++;continue;}long ms=0;try{ms=Long.parseLong(cell(row,duration).trim());}catch(NumberFormatException ignored){}data.songs.add(new Song(t,a,ms,u));}
        if(data.songs.isEmpty())throw new IOException("The CSV contained no songs with both a title and artist.");return data;
    }
    private static int column(ArrayList<String> headers,String... choices){for(int i=0;i<headers.size();i++){String name=headers.get(i).toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]","");for(String choice:choices)if(choice.equals(name))return i;}return -1;}
    private static String cell(ArrayList<String> row,int i){return i>=0&&i<row.size()?row.get(i):"";}
    static ArrayList<ArrayList<String>> csvRows(String text)throws IOException{
        ArrayList<ArrayList<String>> rows=new ArrayList<>();ArrayList<String> row=new ArrayList<>();StringBuilder field=new StringBuilder();boolean quoted=false,closed=false;
        for(int i=0;i<text.length();i++){char c=text.charAt(i);if(quoted){if(c=='"'){if(i+1<text.length()&&text.charAt(i+1)=='"'){field.append('"');i++;}else{quoted=false;closed=true;}}else field.append(c);}else if(c=='"'&&field.length()==0&&!closed)quoted=true;else if(c==','){row.add(field.toString());field.setLength(0);closed=false;}else if(c=='\r'||c=='\n'){row.add(field.toString());field.setLength(0);if(row.size()>1||!row.get(0).trim().isEmpty())rows.add(row);row=new ArrayList<>();closed=false;if(c=='\r'&&i+1<text.length()&&text.charAt(i+1)=='\n')i++;}else if(!closed||!Character.isWhitespace(c)){if(closed)throw new IOException("Invalid CSV quoting. Export a fresh CSV and try again.");field.append(c);}if(field.length()>4000||row.size()>100||rows.size()>MAX_SONGS+1)throw new IOException("CSV is too large. Use at most 5,000 songs.");}
        if(quoted)throw new IOException("The CSV has an unfinished quoted field.");if(field.length()>0||!row.isEmpty()){row.add(field.toString());rows.add(row);}if(rows.size()>MAX_SONGS+1)throw new IOException("Use at most 5,000 songs per CSV.");return rows;
    }
    static String read(InputStream input)throws IOException{if(input==null)throw new IOException("The file could not be opened.");try(InputStream in=input;ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] buffer=new byte[16384];int n;while((n=in.read(buffer))!=-1){if(out.size()+n>MAX_BYTES)throw new IOException("Use a playlist file smaller than 5 MB.");out.write(buffer,0,n);}return new String(out.toByteArray(),StandardCharsets.UTF_8);}}
}
