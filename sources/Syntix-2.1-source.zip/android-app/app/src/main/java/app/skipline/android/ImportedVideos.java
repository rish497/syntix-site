package app.skipline.android;

import android.content.SharedPreferences;
import java.util.ArrayList;
import org.json.JSONArray;

/** Explicit video imports, separate from playlists and isolated by local profile. */
final class ImportedVideos {
    static ArrayList<Track> read(SharedPreferences prefs) {
        ArrayList<Track> result=new ArrayList<>();
        try { JSONArray data=new JSONArray(prefs.getString("videos","[]"));
            for(int i=0;i<data.length();i++)result.add(Track.fromJson(data.getJSONObject(i)));
        } catch(Exception e) { android.util.Log.w("Syntix","Could not read imported videos",e); }
        return result;
    }
    static boolean add(SharedPreferences prefs,Track track) {
        ArrayList<Track> tracks=read(prefs);
        for(Track old:tracks)if(old.source.equals(track.source))return false;
        tracks.add(0,track.copy());save(prefs,tracks);return true;
    }
    static void save(SharedPreferences prefs,ArrayList<Track> tracks) {
        try { JSONArray data=new JSONArray();for(Track t:tracks)data.put(t.json());
            prefs.edit().putString("videos",data.toString()).apply();
        } catch(Exception e) { throw new IllegalStateException("Could not save imported videos",e); }
    }
}
