package app.skipline.android;

import org.json.JSONObject;
import java.util.UUID;

public final class Track {
    public final String id, source, title, creator, thumbnail;
    public final long duration;
    final String catalogAlbum;
    final boolean musicCatalog;
    boolean verifiedArtist;
    public Track(String source, String title, String creator, String thumbnail, long duration) {
        this(UUID.randomUUID().toString(), source, title, creator, thumbnail, duration,"",false);
    }
    Track(String source,String title,String creator,String thumbnail,long duration,String album,boolean catalog){this(UUID.randomUUID().toString(),source,title,creator,thumbnail,duration,album,catalog);}
    private Track(String id, String source, String title, String creator, String thumbnail, long duration,String album,boolean catalog) {
        this.id=id; this.source=source; this.title=title; this.creator=creator; this.thumbnail=thumbnail; this.duration=duration;catalogAlbum=album;musicCatalog=catalog;
    }
    JSONObject json() throws Exception {
        return new JSONObject().put("id",id).put("source",source).put("title",title).put("creator",creator).put("thumbnail",thumbnail).put("duration",duration).put("catalogAlbum",catalogAlbum).put("musicCatalog",musicCatalog).put("verifiedArtist",verifiedArtist);
    }
    Track verified(boolean value){verifiedArtist=value;return this;}
    Track copy(){return new Track(source,title,creator,thumbnail,duration,catalogAlbum,musicCatalog).verified(verifiedArtist);}
    static Track fromJson(JSONObject j) {
        return new Track(j.optString("id",UUID.randomUUID().toString()),j.optString("source"),j.optString("title","Untitled"),j.optString("creator",""),j.optString("thumbnail",""),j.optLong("duration",0),j.optString("catalogAlbum",""),j.optBoolean("musicCatalog")).verified(j.optBoolean("verifiedArtist"));
    }
}
