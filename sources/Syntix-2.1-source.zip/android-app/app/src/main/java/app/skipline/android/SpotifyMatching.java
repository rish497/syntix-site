package app.skipline.android;

import java.text.Normalizer;
import java.util.*;

/** Conservative metadata matching. An uncertain match is never silently selected. */
final class SpotifyMatching {
    private static String normalized(String s){return Normalizer.normalize(s,Normalizer.Form.NFKD).replaceAll("[\\u0300-\\u036f]","").toLowerCase(Locale.ROOT).replaceAll("[^\\p{L}\\p{N}\\p{M}]+"," ").trim();}
    private static Set<String> words(String s){Set<String> out=new HashSet<>(Arrays.asList(normalized(s).split(" +")));out.remove("");out.removeAll(Arrays.asList("official","video","audio","lyrics","lyric","hd","hq","visualizer","music","feat","ft","the","and"));return out;}
    static double coverage(String target,String found){Set<String> wanted=words(target),have=words(found);if(wanted.isEmpty())return 0;int n=0;for(String word:wanted)if(have.contains(word))n++;return (double)n/wanted.size();}
    static String title(String raw){return raw.replaceAll("(?i)\\s*[\\(\\[]\\s*(?:feat\\.?|ft\\.?|from\\b|remaster(?:ed)?\\b)[^\\)\\]]*[\\)\\]]","").replaceAll("(?i)\\s+[-–]\\s+(?:from\\b|remaster(?:ed)?\\b).*$","").trim();}
    static String primary(String artists){return artists.split("[,;]",2)[0].trim();}
    private static double artist(SpotifyPlaylist.Song song,Track video){return artistNames(song,video.title+" "+video.creator);}
    private static double artistNames(SpotifyPlaylist.Song song,String found){double result=0;for(String target:song.artist.split("[,;]")){result=Math.max(result,coverage(target,found));String compact=normalized(target).replace(" ","");if(compact.length()>=5){String[] tokens=normalized(found).split(" +");for(int i=0;i<tokens.length;i++){String joined="";for(int j=i;j<tokens.length&&j<i+7&&joined.length()<compact.length();j++){joined+=tokens[j];if(joined.equals(compact))return 1;}}}}return result;}
    private static boolean catalogArtist(SpotifyPlaylist.Song song,Track video){
        for(String requested:song.artist.split("[,;]"))for(String credited:video.creator.split("[,;]")){
            String expected=normalized(requested).replace(" ",""),actual=normalized(credited).replace(" ","");
            if(!expected.isEmpty()&&expected.equals(actual))return true;
        }
        return false;
    }
    private static boolean wrongVersion(SpotifyPlaylist.Song song,Track video){
        Set<String> target=words(song.title),found=words(video.title);String wanted=normalized(song.title+" "+song.album),actual=normalized(video.title+" "+video.catalogAlbum);
        for(String version:new String[]{"live","remix","cover","acoustic","slowed","sped","instrumental","karaoke","nightcore","medley","compilation","reaction","tutorial","extended","boosted","bassboosted","8d","reverb","reversed","pitched","mashup","clean"})if(found.contains(version)!=target.contains(version))return true;
        for(String changed:new String[]{"remix","cover","acoustic","instrumental","karaoke","slowed","sped","tribute"})if(words(actual).contains(changed)&&!words(wanted).contains(changed))return true;
        if(words(wanted).contains("live")&&!song.album.isEmpty()){
            String context=normalized(video.title+" "+video.catalogAlbum);boolean same=coverage(song.album,context)>=.8;
            if(normalized(song.album).replace(" ","").equals("sm"))same=video.catalogAlbum.equalsIgnoreCase(song.album)||context.contains("sfso")||context.contains("san francisco symphony");
            if(!same)return true;
        }
        boolean performance=actual.matches(".*\\b(live|unplugged|concert|festivalbar|soundcheck|rehearsal|session)\\b.*")||actual.contains("battle of mexico city")||actual.contains("in dublin");
        if(performance&&!wanted.matches(".*\\b(live|unplugged|concert|festivalbar|session)\\b.*"))return true;
        for(String phrase:new String[]{"mix","alternate","alternative version","outtake","demo","re recorded","rerecorded","tribute","video version","video edit","sped up","slowed down","2002 version","2022 version"})
            if((" "+actual+" ").contains(" "+phrase+" ")&&!(" "+wanted+" ").contains(" "+phrase+" ")&&!(phrase.equals("mix")&&wanted.contains("radio edit")&&actual.contains("radio mix")))return true;

        if(actual.matches(".*(?:remaster(?:ed)? [12][0-9]{3}|[12][0-9]{3} remaster(?:ed)?).*")&&!wanted.contains("remaster"))return true;
        if(Boolean.TRUE.equals(song.explicit)&&(" "+actual+" ").contains(" clean "))return true;
        return found.contains("album")&&found.contains("full");
    }
    private static double titleEvidence(SpotifyPlaylist.Song song,Track video){
        String target=title(song.title);if(catalogArtist(song,video)&&song.durationMs>0&&Math.abs(song.durationMs/1000.0-video.duration)<=4&&normalized(target).endsWith("radio edit"))target=target.replaceFirst("(?i)\\s*(?:[-–]\\s*|\\()radio edit\\)?$", "").trim();double exact=coverage(target,video.title);Set<String> wanted=words(target),have=words(video.title);
        if(exact>=.8||wanted.size()<2||artist(song,video)<1||song.durationMs<=0||video.duration<=0||Math.abs(song.durationMs/1000.0-video.duration)>8)return exact;
        int found=0,variants=0;
        for(String word:wanted){if(have.contains(word)){found++;continue;}boolean variant=false;if(word.length()>=4)for(String candidate:have)if(candidate.length()>=4&&word.replaceAll("([a-z])\\1+","$1").equals(candidate.replaceAll("([a-z])\\1+","$1"))){variant=true;break;}if(variant){found++;variants++;}}
        return variants==1?Math.max(exact,(double)found/wanted.size()):exact;
    }
    static double score(SpotifyPlaylist.Song song,Track video){double title=titleEvidence(song,video),artist=artist(song,video),duration=.35;if(song.durationMs>0&&video.duration>0)duration=Math.max(0,1-Math.abs(song.durationMs/1000.0-video.duration)/45);return .58*title+.3*artist+.12*duration+.05*artistNames(song,video.creator)+(video.musicCatalog?.14:0)+(song.album.isEmpty()||video.catalogAlbum.isEmpty()?0:.08*coverage(song.album,video.catalogAlbum))-(normalized(video.title).contains("remaster")&&!normalized(song.title+" "+song.album).contains("remaster")?.08:0)-(wrongVersion(song,video)?.6:0);}
    static boolean confident(SpotifyPlaylist.Song song,Track video){double title=titleEvidence(song,video),artist=artist(song,video);if(title<.8||artist<.75||wrongVersion(song,video)||video.musicCatalog&&!catalogArtist(song,video))return false;if(video.duration<=0)return title==1&&artist==1;return song.durationMs<=0||Math.abs(song.durationMs/1000.0-video.duration)<=Math.max(video.musicCatalog?6:10,song.durationMs/1000.0*(video.musicCatalog?.025:.04));}
    static Track choose(SpotifyPlaylist.Song song,ArrayList<Track> candidates){ArrayList<Track> ranked=new ArrayList<>(candidates);ranked.sort((a,b)->Double.compare(score(song,b),score(song,a)));for(Track t:ranked)if(confident(song,t))return t;return null;}
    interface Searcher {ArrayList<Track> search(String query)throws Exception;}
    static Track find(SpotifyPlaylist.Song song,Searcher search,java.util.function.BooleanSupplier proceed)throws Exception{
        LinkedHashSet<String> queries=new LinkedHashSet<>();String identity=title(song.title)+" "+primary(song.artist)+(words(song.title).contains("live")&&!song.album.isEmpty()?" "+song.album:"");queries.add(query(identity+" official audio"));queries.add(query(identity));Exception failure=null;
        for(String query:queries){ArrayList<Track> found=null;for(int attempt=0;attempt<2;attempt++){if(!proceed.getAsBoolean())throw new java.util.concurrent.CancellationException();try{found=search.search(query);break;}catch(YouTubeMetadata.SearchBlockedException blocked){throw blocked;}catch(java.util.concurrent.CancellationException stopped){throw stopped;}catch(Exception unavailable){if(attempt==1)failure=unavailable;}}
            if(found!=null){Track match=choose(song,found);if(match!=null)return match;}
        }
        if(failure!=null)throw failure;return null;
    }
    private static String query(String value){String clean=value.replaceAll("[\\p{Cntrl}]"," ").trim();return clean.substring(0,Math.min(180,clean.length()));}
}
