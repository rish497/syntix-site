package app.skipline.android;

import android.graphics.*;
import android.view.*;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.SeekBar;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.function.IntConsumer;

/** Native, focusable chart with direct point inspection and no secondary data dialog. */
@androidx.media3.common.util.UnstableApi
final class StatisticsPlot extends View {
    private final MainActivity a;
    private final StatsSeries series;
    private final int color,kind,unit;
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final IntConsumer inspect;
    private final Path linePath=new Path(),fillPath=new Path();
    private final DashPathEffect gridDash,guideDash;
    private final float[] xs,ys;
    private final String[] axisLabels=new String[3],dateLabels;
    private final int[] ticks;
    private final double maximum;
    private Shader areaShader;
    private int selected=-1;
    private float downX,downY;
    private boolean horizontal;
    StatisticsPlot(MainActivity a,StatsSeries series,int color,int kind,int unit,IntConsumer inspect){
        super(a);this.a=a;this.series=series;this.color=color;this.kind=kind;this.unit=unit;this.inspect=inspect;
        gridDash=new DashPathEffect(new float[]{a.dp(2),a.dp(5)},0);guideDash=new DashPathEffect(new float[]{a.dp(2),a.dp(3)},0);
        xs=new float[series.values.length];ys=new float[xs.length];dateLabels=new String[xs.length];
        double max=1;for(double value:series.values)max=Math.max(max,value*1.12);double magnitude=Math.pow(10,Math.floor(Math.log10(max)));maximum=Math.ceil(max/magnitude*2)*magnitude/2;
        for(int n=0;n<3;n++)axisLabels[n]=amount(maximum*(1-n/2d));
        SimpleDateFormat format=new SimpleDateFormat(unit==0?"HH:mm":unit==1?"MMM d":"MMM",Locale.getDefault());for(int n=0;n<xs.length;n++)dateLabels[n]=format.format(new Date(series.dates[n]));
        if(unit==2){ticks=new int[xs.length];for(int n=0;n<ticks.length;n++)ticks[n]=n;}else ticks=new int[]{0,(xs.length-1)/3,(xs.length-1)*2/3,xs.length-1};
        setFocusable(true);setClickable(true);setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_YES);setContentDescription((kind==0?"Listening time":kind==1?"Data usage":"Battery usage")+" chart. Tap a point or use left and right to inspect readings.");
    }
    private float labelSize(){return android.util.TypedValue.applyDimension(android.util.TypedValue.COMPLEX_UNIT_SP,11,getResources().getDisplayMetrics());}
    private String amount(double n){if(kind==0)return n>=60?String.format(Locale.getDefault(),"%.1fh",n/60):String.format(Locale.getDefault(),"%.0fm",n);if(kind==1)return n>=1000?String.format(Locale.getDefault(),"%.1fG",n/1000):String.format(Locale.getDefault(),"%.0fM",n);return String.format(Locale.getDefault(),"%.1f%%",n);}
    private int withAlpha(int c,int alpha){return (c&0x00ffffff)|(alpha<<24);}
    @Override protected void onSizeChanged(int w,int h,int oldw,int oldh){super.onSizeChanged(w,h,oldw,oldh);areaShader=new LinearGradient(0,a.dp(12),0,Math.max(a.dp(13),h-a.dp(35)),withAlpha(color,64),withAlpha(color,0),Shader.TileMode.CLAMP);}
    @Override protected void onDraw(Canvas canvas){super.onDraw(canvas);
        float left=a.dp(2),right=Math.max(left+1,getWidth()-a.dp(38)),top=Math.max(a.dp(12),labelSize()),bottom=getHeight()-a.dp(35),step=(right-left)/series.values.length;
        paint.setTypeface(a.face);paint.setTextSize(labelSize());paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(a.dp(1));paint.setPathEffect(gridDash);
        for(int n=0;n<3;n++){float y=top+(bottom-top)*n/2;paint.setColor(0x1affffff);canvas.drawLine(left,y,right,y,paint);paint.setPathEffect(null);paint.setStyle(Paint.Style.FILL);paint.setColor(MainActivity.MUTED);paint.setTextAlign(Paint.Align.RIGHT);canvas.drawText(axisLabels[n],getWidth(),y+labelSize()/3,paint);paint.setStyle(Paint.Style.STROKE);paint.setPathEffect(gridDash);}
        paint.setPathEffect(null);paint.setTextAlign(Paint.Align.LEFT);
        for(int n=0;n<xs.length;n++){xs[n]=left+(n+.5f)*step;ys[n]=bottom-(float)(series.values[n]/maximum)*(bottom-top);}
        if(kind==1){linePath.reset();for(int n=0;n<xs.length;n++){if(n==0)linePath.moveTo(xs[n],ys[n]);else linePath.lineTo(xs[n],ys[n]);}fillPath.set(linePath);fillPath.lineTo(xs[xs.length-1],bottom);fillPath.lineTo(xs[0],bottom);fillPath.close();paint.setStyle(Paint.Style.FILL);paint.setShader(areaShader);canvas.drawPath(fillPath,paint);paint.setShader(null);paint.setColor(color);paint.setStrokeWidth(a.dp(2));paint.setStyle(Paint.Style.STROKE);canvas.drawPath(linePath,paint);}
        else for(int n=0;n<xs.length;n++){paint.setStyle(Paint.Style.FILL);paint.setColor(withAlpha(color,n==selected?255:150));float width=Math.min(a.dp(kind==2?4:28),step*(kind==2?.4f:.64f));if(kind==2&&series.observed[n]==0){paint.setColor(MainActivity.MUTED);canvas.drawRect(xs[n]-a.dp(2),bottom-a.dp(1),xs[n]+a.dp(2),bottom,paint);}else if(series.values[n]>0)canvas.drawRoundRect(xs[n]-width/2,ys[n],xs[n]+width/2,bottom,a.dp(2),a.dp(2),paint);}
        if(selected>=0){paint.setStyle(Paint.Style.STROKE);paint.setColor(withAlpha(color,180));paint.setStrokeWidth(a.dp(1));paint.setPathEffect(guideDash);canvas.drawLine(xs[selected],top,xs[selected],bottom,paint);paint.setPathEffect(null);if(kind!=2||series.observed[selected]>0){paint.setStyle(Paint.Style.FILL);paint.setColor(color);canvas.drawCircle(xs[selected],ys[selected],a.dp(3),paint);}}
        paint.setStyle(Paint.Style.FILL);paint.setColor(MainActivity.MUTED);paint.setTypeface(a.face);paint.setTextSize(labelSize());
        for(int n=0;n<ticks.length;n++){int point=ticks[n];paint.setTextAlign(n==0?Paint.Align.LEFT:n==ticks.length-1?Paint.Align.RIGHT:Paint.Align.CENTER);canvas.drawText(dateLabels[point],n==0?left:n==ticks.length-1?right:xs[point],getHeight()-a.dp(9),paint);}
        paint.setTextAlign(Paint.Align.LEFT);
    }
    static String accessibleAmount(android.content.Context context,int kind,double value,long observed){
        if(kind==0){if(value>0&&value<1)return "Less than one minute";long minutes=(long)value;return minutes>=60?minutes/60+" hours "+minutes%60+" minutes":minutes+" minutes";}
        if(kind==1)return android.text.format.Formatter.formatFileSize(context,Math.round(value*1000000));
        return observed>0?String.format(Locale.getDefault(),"%.1f percent per hour",value):"No reading";
    }
    private void select(int i){selected=Math.max(-1,Math.min(series.values.length-1,i));inspect.accept(selected);invalidate();String reading=selected<0?(kind==2?"Observed average":"Period total"):new SimpleDateFormat(unit==0?"MMM d, HH:mm":unit==1?"MMM d":"MMM yyyy",Locale.getDefault()).format(new Date(series.dates[selected]))+", "+accessibleAmount(a,kind,series.values[selected],series.observed[selected]);androidx.core.view.ViewCompat.setStateDescription(this,reading);}
    private int nearest(float x){float width=Math.max(1,getWidth()-a.dp(40));return Math.max(0,Math.min(series.values.length-1,(int)((x-a.dp(2))/width*series.values.length)));}
    @Override public boolean onTouchEvent(MotionEvent e){switch(e.getActionMasked()){case MotionEvent.ACTION_DOWN:downX=e.getX();downY=e.getY();horizontal=false;return true;case MotionEvent.ACTION_MOVE:if(!horizontal&&Math.abs(e.getX()-downX)>a.dp(8)&&Math.abs(e.getX()-downX)>Math.abs(e.getY()-downY)){horizontal=true;getParent().requestDisallowInterceptTouchEvent(true);}if(horizontal)select(nearest(e.getX()));return true;case MotionEvent.ACTION_UP:if(horizontal||Math.hypot(e.getX()-downX,e.getY()-downY)<a.dp(8)){int index=nearest(e.getX());select(!horizontal&&index==selected?-1:index);super.performClick();}getParent().requestDisallowInterceptTouchEvent(false);return true;case MotionEvent.ACTION_CANCEL:getParent().requestDisallowInterceptTouchEvent(false);return true;default:return super.onTouchEvent(e);}}
    @Override public boolean performClick(){select(selected<0?0:(selected+1)%series.values.length);return super.performClick();}
    @Override public boolean onKeyDown(int key,KeyEvent event){if(key==KeyEvent.KEYCODE_DPAD_RIGHT){select(selected+1);return true;}if(key==KeyEvent.KEYCODE_DPAD_LEFT){select(Math.max(0,selected-1));return true;}if(key==KeyEvent.KEYCODE_ESCAPE){select(-1);return true;}return super.onKeyDown(key,event);}
    @Override public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo info){super.onInitializeAccessibilityNodeInfo(info);info.addAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_FORWARD);info.addAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_BACKWARD);}
    @Override public boolean performAccessibilityAction(int action,android.os.Bundle args){if(action==AccessibilityNodeInfo.ACTION_SCROLL_FORWARD){select(selected+1);return true;}if(action==AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD){select(Math.max(0,selected-1));return true;}return super.performAccessibilityAction(action,args);}
}
