package app.skipline.android;

import java.util.*;
import java.util.concurrent.TimeUnit;
import okhttp3.*;
import org.json.*;

/** Real catalog continuation pages; no fabricated rows or fixed-size recommendation list. */
final class SongRecommendations {
    interface Fetcher {JSONObject fetch(String query,String token)throws Exception;}
    private static final OkHttpClient HTTP=new OkHttpClient.Builder().connectTimeout(4,TimeUnit.SECONDS).readTimeout(7,TimeUnit.SECONDS).callTimeout(10,TimeUnit.SECONDS).build();
    static List<String> queries(SavedPlaylist playlist,List<Track> history){
        LinkedHashSet<String> queries=new LinkedHashSet<>();if(!playlist.tracks.isEmpty()&&!playlist.name.trim().isEmpty())queries.add(clean(playlist.name+" songs"));
        LinkedHashMap<String,Integer> creators=new LinkedHashMap<>();for(Track t:playlist.tracks)if(!t.creator.isEmpty())creators.put(t.creator,creators.getOrDefault(t.creator,0)+3);for(Track t:history)if(!t.creator.isEmpty())creators.put(t.creator,creators.getOrDefault(t.creator,0)+1);
        ArrayList<String> ranked=new ArrayList<>(creators.keySet());ranked.sort((x,y)->Integer.compare(creators.get(y),creators.get(x)));for(String creator:ranked)queries.add(clean(creator+" songs"));
        if(queries.isEmpty())queries.add("popular music songs");return new ArrayList<>(queries);
    }
    private static String clean(String q){String s=q.replaceAll("[\\p{Cntrl}]"," ").trim();return s.substring(0,Math.min(180,s.length()));}
    static final class Cursor implements AutoCloseable {
        final List<String> queries;final Set<String> seen=new HashSet<>(),tokens=new HashSet<>();final Fetcher fetcher;int index;String token="";volatile boolean closed;volatile Call call;
        Cursor(SavedPlaylist saved,List<Track> history){this(queries(saved,history),null);for(Track t:saved.tracks)seen.add(t.source);}
        Cursor(List<String> queries,Fetcher injected){this.queries=queries;fetcher=injected==null?this::request:injected;}
        boolean hasMore(){return !closed&&index<queries.size();}
        void exclude(String source){synchronized(seen){seen.add(source);}}
        ArrayList<Track> next()throws Exception{
            ArrayList<Track> out=new ArrayList<>();for(int attempt=0;hasMore()&&out.isEmpty()&&attempt<3;attempt++){
                String q=queries.get(index);JSONObject json=fetcher.fetch(q,token);if(closed)throw new java.util.concurrent.CancellationException();ArrayList<Track> found=RecordingSearch.parse(json);if(found.isEmpty())found=YouTubeMetadata.parseResponse(json);String continuation=continuation(json,0);
                if(continuation.isEmpty()||!tokens.add(index+":"+continuation)){index++;token="";}else token=continuation;
                synchronized(seen){for(Track track:found)if(track.duration>0&&seen.add(track.source))out.add(track);}
            }return out;
        }
        private JSONObject request(String query,String continuation)throws Exception{
            if(closed)throw new java.util.concurrent.CancellationException();String version="1."+new java.text.SimpleDateFormat("yyyyMMdd",Locale.US).format(new Date())+".01.00";JSONObject body=new JSONObject().put("context",new JSONObject().put("client",new JSONObject().put("clientName","WEB_REMIX").put("clientVersion",version).put("hl","en")));
            if(continuation.isEmpty())body.put("query",query).put("params","EgWKAQIIAWoMEA4QChADEAQQCRAF");else body.put("continuation",continuation);
            Call request=HTTP.newCall(new Request.Builder().url("https://music.youtube.com/youtubei/v1/search?prettyPrint=false").post(RequestBody.create(body.toString(),MediaType.get("application/json"))).build());call=request;
            try(Response r=request.execute()){if(r.code()==429||r.code()==403)throw new YouTubeMetadata.SearchBlockedException();if(!r.isSuccessful()||r.body()==null)throw new java.io.IOException("Song recommendations unavailable");return new JSONObject(YouTubeMetadata.readBounded(r.body().byteStream()));}finally{if(call==request)call=null;}
        }
        public void close(){closed=true;Call pending=call;if(pending!=null)pending.cancel();}
    }
    static String continuation(Object value,int depth){if(depth>65)return "";if(value instanceof JSONObject){JSONObject o=(JSONObject)value;for(String key:new String[]{"continuationCommand","nextContinuationData","nextRadioContinuationData"}){JSONObject c=o.optJSONObject(key);if(c!=null){String t=c.optString("token",c.optString("continuation"));if(!t.isEmpty())return t;}}Iterator<String> keys=o.keys();while(keys.hasNext()){String t=continuation(o.opt(keys.next()),depth+1);if(!t.isEmpty())return t;}}else if(value instanceof JSONArray){JSONArray array=(JSONArray)value;for(int i=0;i<array.length();i++){String t=continuation(array.opt(i),depth+1);if(!t.isEmpty())return t;}}return "";}
}
