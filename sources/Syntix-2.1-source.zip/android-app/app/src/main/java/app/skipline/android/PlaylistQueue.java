package app.skipline.android;

import java.util.*;

/** Keep media IDs stable so selecting a playlist row does not discard its buffered timeline. */
final class PlaylistQueue {
    /** Add newly ready tracks without undoing edits to the existing listening order. */
    static boolean mergeReady(ArrayList<Track> queue,List<Track> available){
        ArrayList<Track> next=new ArrayList<>(queue);HashSet<String> seen=new HashSet<>();for(Track t:next)seen.add(t.source);boolean changed=false;
        for(int i=0;i<available.size();i++){Track t=available.get(i);if(!seen.add(t.source))continue;int insert=-1;
            for(int j=i+1;j<available.size()&&insert<0;j++)for(int k=0;k<next.size();k++)if(next.get(k).source.equals(available.get(j).source)){insert=k;break;}
            if(insert<0)for(int j=i-1;j>=0&&insert<0;j--)for(int k=0;k<next.size();k++)if(next.get(k).source.equals(available.get(j).source)){insert=k+1;break;}
            next.add(insert<0?next.size():insert,t);changed=true;
        }
        if(changed)replace(queue,next);return changed;
    }
    static void replace(ArrayList<Track> queue,List<Track> tracks){
        HashMap<String,ArrayDeque<Track>> existing=new HashMap<>();
        for(Track track:queue)existing.computeIfAbsent(track.source,k->new ArrayDeque<>()).add(track);
        ArrayList<Track> next=new ArrayList<>(tracks.size());
        for(Track track:tracks){ArrayDeque<Track> matches=existing.get(track.source);next.add(matches==null||matches.isEmpty()?track.copy():matches.removeFirst());}
        queue.clear();queue.addAll(next);
    }
}
