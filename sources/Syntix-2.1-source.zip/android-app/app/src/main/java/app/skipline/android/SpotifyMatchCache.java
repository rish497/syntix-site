package app.skipline.android;

import android.content.*;
import java.util.*;
import org.json.*;

/** Bounded public recording metadata only: no audio, credentials or playlist membership. */
final class SpotifyMatchCache {
    static final long TTL=7L*24*60*60*1000;
    static final int LIMIT=512;
    private static SharedPreferences prefs(Context c){return c.getSharedPreferences("spotify_recording_matches_v2",Context.MODE_PRIVATE);}
    private static String key(SpotifyPlaylist.Song song){try{byte[] bytes=java.security.MessageDigest.getInstance("SHA-256").digest((song.uri+"|"+song.title+"|"+song.artist+"|"+song.durationMs+"|"+song.album).getBytes(java.nio.charset.StandardCharsets.UTF_8));StringBuilder out=new StringBuilder();for(byte b:bytes)out.append(Character.forDigit((b>>4)&15,16)).append(Character.forDigit(b&15,16));return out.toString();}catch(Exception impossible){throw new IllegalStateException(impossible);}}
    static Track get(Context c,SpotifyPlaylist.Song song){return get(c,song,System.currentTimeMillis());}
    static Track get(Context c,SpotifyPlaylist.Song song,long now){SharedPreferences p=prefs(c);String key=key(song);try{String raw=p.getString(key,"");if(raw.isEmpty())return null;JSONObject entry=new JSONObject(raw);long saved=entry.getLong("time");if(now<saved||now-saved>=TTL){p.edit().remove(key).apply();return null;}Track t=Track.fromJson(entry.getJSONObject("track"));if(t.source.matches("https://www\\.youtube\\.com/watch\\?v=[A-Za-z0-9_-]{11}")&&SpotifyMatching.confident(song,t))return t.copy();}catch(Exception ignored){}p.edit().remove(key).apply();return null;}
    static synchronized void put(Context c,SpotifyPlaylist.Song song,Track track){put(c,song,track,System.currentTimeMillis());}
    static synchronized void put(Context c,SpotifyPlaylist.Song song,Track track,long now){if(!SpotifyMatching.confident(song,track))return;try{SharedPreferences p=prefs(c);String key=key(song);Map<String,?> all=p.getAll();SharedPreferences.Editor edit=p.edit();if(!all.containsKey(key)&&all.size()>=LIMIT){String oldest=null;long oldestTime=Long.MAX_VALUE;for(Map.Entry<String,?> e:all.entrySet()){long time=0;try{time=new JSONObject(String.valueOf(e.getValue())).optLong("time");}catch(Exception ignored){}if(oldest==null||time<oldestTime){oldest=e.getKey();oldestTime=time;}}if(oldest!=null)edit.remove(oldest);}edit.putString(key,new JSONObject().put("time",now).put("track",track.json()).toString()).apply();}catch(Exception ignored){/* Cache failure must not fail an import. */}}
}
