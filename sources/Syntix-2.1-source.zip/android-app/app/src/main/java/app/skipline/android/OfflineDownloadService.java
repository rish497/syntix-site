package app.skipline.android;

import android.app.*;
import android.content.*;
import android.net.*;
import android.os.*;
import androidx.core.app.NotificationCompat;
import com.yausername.youtubedl_android.*;
import java.io.File;
import java.util.concurrent.*;

/** One low-priority download at a time; pause keeps partial bytes and the persistent queue. */
@androidx.annotation.OptIn(markerClass = androidx.media3.common.util.UnstableApi.class)
public final class OfflineDownloadService extends Service {
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private volatile boolean stopped;
    private volatile String process;
    private volatile OfflineStore store;
    private SkiplineApp app;
    private ConnectivityManager connectivity;
    private volatile boolean running;
    private long lastUpdate;
    private final ConnectivityManager.NetworkCallback network=new ConnectivityManager.NetworkCallback(){@Override public void onLost(Network n){checkNetwork();}@Override public void onCapabilitiesChanged(Network n,NetworkCapabilities c){checkNetwork();}};
    private boolean allowed(){NetworkCapabilities c=connectivity.getNetworkCapabilities(connectivity.getActiveNetwork());return c!=null&&c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)&&(!store.wifiOnly()||c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI));}
    private void checkNetwork(){if(running&&store!=null&&!allowed())pause("Waiting for "+(store.wifiOnly()?"Wi-Fi":"a connection")+". Tap Continue download when connected.");}
    private void pause(String reason){stopped=true;if(store!=null)store.message(reason);String active=process;if(active!=null)workerCancel(active);}
    private void workerCancel(String id){new Thread(()->{try{YoutubeDL.INSTANCE.destroyProcessById(id);}catch(Exception ignored){}},"syntix-download-cancel").start();}
    private Notification note(String text,boolean ongoing){PendingIntent open=PendingIntent.getActivity(this,61,new Intent(this,MainActivity.class).putExtra("open_downloads",true),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);NotificationCompat.Builder b=new NotificationCompat.Builder(this,"offline").setSmallIcon(R.drawable.ic_notification).setContentTitle("Syntix offline downloads").setContentText(text).setStyle(new NotificationCompat.BigTextStyle().bigText(text)).setContentIntent(open).setOnlyAlertOnce(true).setOngoing(ongoing);if(ongoing)b.addAction(R.drawable.ic_pause,"Pause",PendingIntent.getService(this,62,new Intent(this,OfflineDownloadService.class).setAction("pause"),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE));return b.build();}
    private void update(String message){if(store!=null)store.message(message);app.offlineProgress=message;((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(61,note(message,true));}
    @Override public void onCreate(){super.onCreate();app=(SkiplineApp)getApplication();app.offlineService=this;connectivity=(ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(new NotificationChannel("offline","Offline downloads",NotificationManager.IMPORTANCE_LOW));connectivity.registerDefaultNetworkCallback(network);}
    @Override public int onStartCommand(Intent intent,int flags,int startId){if(intent==null){stopSelf();return START_NOT_STICKY;}if("check_network".equals(intent.getAction())){checkNetwork();if(!running)stopSelf();return START_NOT_STICKY;}if("pause".equals(intent.getAction())){pause("Downloads paused. Tap Continue download to continue.");if(!running)stopSelf();return START_NOT_STICKY;}if(running)return START_NOT_STICKY;
        String origin=intent.getStringExtra("profile");if(origin==null||!origin.equals(app.profiles.active)||app.offlineClearing||app.manualDownloadRunning){app.offlineRunning=false;startForeground(61,note("Download request interrupted. Open Syntix and resume.",false));stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();return START_NOT_STICKY;}store=app.offline;stopped=false;running=true;app.offlineRunning=true;startForeground(61,note("Starting offline downloads…",true));worker.execute(this::download);return START_NOT_STICKY;}
    private void download(){android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND);String result="Downloads finished. Your saved songs are ready offline.";try{if(!allowed()){result="Connect to "+(store.wifiOnly()?"Wi-Fi":"the internet")+", then tap Continue download.";return;}if(!store.directory.exists()&&!store.directory.mkdirs())throw new Exception("Could not create download storage");Extractor.init(this);
        while(!stopped){Track track=store.next();if(track==null)break;if(store.recoverReady(track))continue;if(!allowed()){result="Connection changed. Tap Continue download when connected.";break;}if(store.directory.getUsableSpace()<32L*1024*1024)throw new Exception("Storage is nearly full. Free some space, then resume.");process="syntix-offline-"+System.nanoTime();String active=process;String key=OfflineStore.key(track.source);update("Downloading "+track.title+" · "+store.remaining()+" remaining");
            YoutubeDLRequest request=Extractor.request(Links.extract(track.source)).addOption("--no-playlist").addOption("--continue").addOption("--part").addOption("--concurrent-fragments","1").addOption("--buffer-size","64K").addOption("-f","bestaudio[ext=m4a]/bestaudio").addOption("-o",new File(store.directory,key+".%(ext)s").getAbsolutePath());
            int bitrate=store.bitrate();com.yausername.ffmpeg.FFmpeg.INSTANCE.init(this);request.addOption("-x").addOption("--audio-format","opus").addOption("--audio-quality",bitrate+"K").addOption("--postprocessor-args","ExtractAudio+ffmpeg_o:-c:a libopus -b:a "+bitrate+"k -vbr off");
            if(stopped)break;
            YoutubeDL.INSTANCE.execute(request,active,false,(progress,eta,line)->{if(!stopped&&SystemClock.elapsedRealtime()-lastUpdate>1500){lastUpdate=SystemClock.elapsedRealtime();update(track.title+" · "+Math.round(progress)+"%");}return kotlin.Unit.INSTANCE;});process=null;File[] completed=store.directory.listFiles(f->f.isFile()&&f.getName().matches(key+"\\.(m4a|mp4|webm|opus|ogg|mp3|flac|aac)")&&f.length()>0);if(completed==null||completed.length!=1)throw new Exception("No complete audio file was found. Try Continue download.");store.markReady(track,completed[0]);if(stopped)break;store.completeEncrypted(track,completed[0]);app.main.post(()->{if(app.offline==store)for(Runnable r:new java.util.ArrayList<>(app.listeners))r.run();});
        }
        if(stopped)result=store.message();
    }catch(Exception e){result=stopped?store.message():"Download paused: "+Extractor.error(e)+" Tap Continue download to retry.";}finally{process=null;String end=result;if(app.offlineService==this)store.message(end);app.main.post(()->{if(app.offlineService!=this)return;app.offlineProgress=end;app.offlineRunning=false;running=false;app.idleIfNoWork();for(Runnable r:new java.util.ArrayList<>(app.listeners))r.run();stopForeground(STOP_FOREGROUND_REMOVE);((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(61,note(end,false));stopSelf();});}}
    @Override public void onTimeout(int startId,int type){pause("Android paused this long download. Open Syntix and resume.");stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();}
    @Override public void onDestroy(){stopped=true;String active=process;if(active!=null)workerCancel(active);try{connectivity.unregisterNetworkCallback(network);}catch(Exception ignored){}worker.shutdownNow();if(app.offlineService==this){app.offlineService=null;app.offlineRunning=false;}super.onDestroy();}
    @Override public void onTaskRemoved(Intent rootIntent){app.dismissTask();}
    @Override public IBinder onBind(Intent intent){return null;}
}
