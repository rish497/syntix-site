package app.skipline.android;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.LruCache;
import android.widget.ImageView;
import androidx.core.content.res.ResourcesCompat;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

final class Images {
    private static final LruCache<String,Bitmap> cache=new LruCache<String,Bitmap>(8*1024){@Override protected int sizeOf(String key,Bitmap b){return b.getByteCount()/1024;}};
    private static final ExecutorService workers=new java.util.concurrent.ThreadPoolExecutor(4,4,0,java.util.concurrent.TimeUnit.MILLISECONDS,new java.util.concurrent.ArrayBlockingQueue<>(80),new java.util.concurrent.ThreadPoolExecutor.DiscardOldestPolicy());
    static void loadLocal(android.content.Context context,ImageView view,String source){
        int preset=ProfileArtwork.resource(context,source);if(preset!=0){view.setImageResource(preset);return;}if(!source.startsWith("content://"))return;String key="profile:"+source;view.setTag(key);Bitmap hit=cache.get(key);if(hit!=null){view.setImageBitmap(hit);return;}
        final android.content.Context app=context.getApplicationContext();final java.lang.ref.WeakReference<ImageView> target=new java.lang.ref.WeakReference<>(view);
        workers.execute(()->{try{android.net.Uri uri=android.net.Uri.parse(source);BitmapFactory.Options options=new BitmapFactory.Options();options.inJustDecodeBounds=true;try(java.io.InputStream input=app.getContentResolver().openInputStream(uri)){BitmapFactory.decodeStream(input,null,options);}if(options.outWidth<=0||options.outHeight<=0)return;int sample=1;while(Math.max(options.outWidth,options.outHeight)/sample>512)sample*=2;options.inSampleSize=sample;options.inJustDecodeBounds=false;Bitmap image;try(java.io.InputStream input=app.getContentResolver().openInputStream(uri)){image=BitmapFactory.decodeStream(input,null,options);}if(image!=null){cache.put(key,image);ImageView active=target.get();if(active!=null)active.post(()->{ImageView current=target.get();if(current!=null&&key.equals(current.getTag()))current.setImageBitmap(image);});}}catch(Exception ignored){}});
    }
    private static okhttp3.OkHttpClient http;
    private static synchronized okhttp3.OkHttpClient http(){if(http==null)http=new okhttp3.OkHttpClient.Builder().cache(new okhttp3.Cache(new java.io.File(SkiplineApp.instance.getCacheDir(),"artwork-http"),8L*1024*1024)).connectTimeout(4,java.util.concurrent.TimeUnit.SECONDS).readTimeout(5,java.util.concurrent.TimeUnit.SECONDS).build();return http;}
    static void cancel(){synchronized(Images.class){if(http!=null)http.dispatcher().cancelAll();}if(workers instanceof java.util.concurrent.ThreadPoolExecutor)((java.util.concurrent.ThreadPoolExecutor)workers).getQueue().clear();}
    static void load(ImageView view,String url){view.setImageDrawable(new android.graphics.drawable.ColorDrawable(0xff30383e));view.setTag(url);if(url==null||!url.startsWith("https://"))return;Bitmap hit=cache.get(url);if(hit!=null){view.setImageBitmap(hit);return;}java.lang.ref.WeakReference<ImageView> target=new java.lang.ref.WeakReference<>(view);view.post(()->workers.execute(()->{if(SkiplineApp.instance.taskDismissed)return;ImageView current=target.get();if(current==null||!current.isAttachedToWindow()||!url.equals(current.getTag()))return;okhttp3.Request request=new okhttp3.Request.Builder().url(url).build();Bitmap image=null;
        try{try(okhttp3.Response saved=http().newCall(request.newBuilder().cacheControl(okhttp3.CacheControl.FORCE_CACHE).build()).execute()){if(saved.isSuccessful()&&saved.body()!=null)image=BitmapFactory.decodeStream(saved.body().byteStream());}if(image==null&&!SkiplineApp.instance.taskDismissed)try(okhttp3.Response response=http().newCall(request).execute()){if(response.isSuccessful()&&response.body()!=null){BitmapFactory.Options options=new BitmapFactory.Options();options.inSampleSize=2;image=BitmapFactory.decodeStream(response.body().byteStream(),null,options);}}if(image!=null){cache.put(url,image);Bitmap shown=image;current.post(()->{ImageView active=target.get();if(active!=null&&url.equals(active.getTag()))active.setImageBitmap(shown);});}}catch(Exception ignored){}
    }));}
}
