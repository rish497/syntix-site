package app.skipline.android;

import java.util.*;

/** Uses only this profile's observed history. Never seeds a sample or remote result. */
final class SmartMixes {
    static final int MIN_SONGS=50;
    static final String[] NAMES={"Late Night","Most Played","Forgotten Favorites","Recently Discovered"};
    static LinkedHashMap<String,ArrayList<Track>> available(ListeningHistory history,long now){
        LinkedHashMap<String,ArrayList<Track>> ready=new LinkedHashMap<>();
        for(String name:NAMES){ArrayList<Track> songs=tracks(history,name,now);if(songs.size()>=MIN_SONGS)ready.put(name,songs);}
        return ready;
    }
    static ArrayList<Track> tracks(ListeningHistory history,String name,long now){
        ArrayList<ListeningHistory.Entry> entries=history.entries();long week=7*86400000L;
        switch(name){
            case "Late Night":entries.removeIf(e->e.night<=0);entries.sort((a,b)->Integer.compare(b.night,a.night));break;
            case "Forgotten Favorites":entries.removeIf(e->e.plays<2||now-e.last<week);entries.sort((a,b)->Long.compare(a.last,b.last));break;
            case "Recently Discovered":entries.removeIf(e->e.first<=0||now-e.first>30*86400000L);entries.sort((a,b)->Long.compare(b.first,a.first));break;
            default:entries.sort((a,b)->a.plays==b.plays?Long.compare(b.last,a.last):Integer.compare(b.plays,a.plays));
        }
        ArrayList<Track> out=new ArrayList<>();HashSet<String> seen=new HashSet<>();for(ListeningHistory.Entry e:entries){if(!seen.add(e.track.source))continue;out.add(e.track);if(out.size()==MIN_SONGS)break;}return out;
    }
}
