package app.skipline.android;

import android.content.*;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;
import org.json.*;

/** Per-profile, persistent opt-in downloads. Partial files are never exposed to playback. */
final class OfflineStore {
    final Object storageLock=new Object();
    final String profile;
    final File directory;
    private final SharedPreferences prefs;
    private final LinkedHashMap<String,String> files=new LinkedHashMap<>();
    private final ArrayList<Track> pending=new ArrayList<>();
    private final LinkedHashMap<String,Track> metadata=new LinkedHashMap<>();
    OfflineStore(Context context,String profile){this.profile=profile;directory=new File(new File(context.getFilesDir(),"offline"),profile);prefs=context.getSharedPreferences("offline_"+profile,0);try{JSONObject index=new JSONObject(prefs.getString("files","{}"));Iterator<String> keys=index.keys();while(keys.hasNext()){String source=keys.next();String name=index.getString(source);if(validName(name))files.put(source,name);}JSONArray known=new JSONArray(prefs.getString("metadata","[]"));for(int m=0;m<known.length();m++){Track t=Track.fromJson(known.getJSONObject(m));metadata.put(t.source,t);}
JSONArray queue=new JSONArray(prefs.getString("pending","[]"));for(int i=0;i<queue.length();i++)pending.add(Track.fromJson(queue.getJSONObject(i)));}catch(Exception ignored){}}
    static boolean validName(String name){return name.matches("[a-f0-9]{64}\\.(sxa|m4a|mp4|webm|opus|ogg|mp3|flac|aac)");}
    static String key(String source){try{byte[] digest=MessageDigest.getInstance("SHA-256").digest(source.getBytes(StandardCharsets.UTF_8));StringBuilder s=new StringBuilder();for(byte b:digest)s.append(String.format(Locale.ROOT,"%02x",b&255));return s.toString();}catch(Exception e){throw new IllegalStateException(e);}}
    synchronized File file(String source){String name=files.get(source);if(name==null)return null;File secured=new File(directory,key(source)+".sxa");if(secured.isFile()&&secured.length()>EncryptedAudio.HEADER)return secured;File f=new File(directory,name);return f.isFile()&&f.length()>0?f:null;}
    File playbackFile(String source)throws java.io.IOException{File current=file(source);return current==null||OfflineAudio.encrypted(current)?current:secureExisting(source);}
    private File secureExisting(String source)throws java.io.IOException{synchronized(storageLock){
        File plain=file(source);if(plain==null)return null;
        if(OfflineAudio.encrypted(plain)){
            for(String ext:new String[]{"m4a","mp4","webm","opus","ogg","mp3","flac","aac"}){File old=new File(directory,key(source)+"."+ext);if(old.isFile()){File fresh=OfflineAudio.seal(old);if(!old.delete())throw new java.io.IOException("Could not remove an old offline file");plain=fresh;}}
            return plain;
        }
        File secured=OfflineAudio.seal(plain);
        synchronized(this){
            String indexed=files.get(source);
            if(indexed==null){secured.delete();return null;}
            files.put(source,secured.getName());save(true);
        }
        if(plain.exists()&&!plain.delete())throw new java.io.IOException("An old offline file could not be removed. Remove that download and download it again.");
        return secured;
    }}
    void markReady(Track track,File plain)throws java.io.IOException{synchronized(storageLock){if(!validName(plain.getName())||!plain.getName().startsWith(key(track.source)+".")||!plain.getParentFile().equals(directory))throw new java.io.IOException("Invalid completed audio");java.nio.file.Files.write(new File(directory,key(track.source)+".ready").toPath(),plain.getName().getBytes(java.nio.charset.StandardCharsets.UTF_8));}}
    boolean recoverReady(Track track)throws java.io.IOException{synchronized(storageLock){if(file(track.source)!=null)return true;File marker=new File(directory,key(track.source)+".ready");if(!marker.isFile()||marker.length()>100)return false;String name=new String(java.nio.file.Files.readAllBytes(marker.toPath()),java.nio.charset.StandardCharsets.UTF_8);if(!validName(name)||!name.startsWith(key(track.source)+"."))return false;File plain=new File(directory,name);if(!plain.isFile())return false;completeEncrypted(track,plain);return true;}}
    void completeEncrypted(Track track,File plain)throws java.io.IOException{synchronized(storageLock){File current=file(track.source);if(!plain.exists()&&current!=null&&OfflineAudio.encrypted(current)){new File(directory,key(track.source)+".ready").delete();return;}markReady(track,plain);File secured=OfflineAudio.seal(plain);complete(track,secured);if(!plain.delete())throw new java.io.IOException("Could not remove temporary offline audio. Remove this download and retry.");new File(directory,key(track.source)+".ready").delete();}}
    void secureExistingDownloads(java.util.function.BooleanSupplier active){
        ArrayList<String> sources;ArrayList<Track> waiting;synchronized(this){sources=new ArrayList<>(files.keySet());waiting=new ArrayList<>(pending);}
        for(Track track:waiting){if(!active.getAsBoolean())return;try{recoverReady(track);}catch(java.io.IOException e){message("Could not secure an interrupted download. Remove it and download it again.");}}
        for(String source:sources){if(!active.getAsBoolean())return;try{secureExisting(source);}catch(java.io.IOException e){message("Could not secure an older download. Remove it and download it again.");android.util.Log.w("SyntixOffline","Offline encryption migration needs retry",e);}}
    }
    synchronized void enqueue(List<Track> tracks){for(Track track:tracks){if(!track.source.startsWith("https://")||file(track.source)!=null)continue;boolean exists=false;for(Track t:pending)if(t.source.equals(track.source)){exists=true;break;}if(!exists)pending.add(track.copy());}save();}
    synchronized Track next(){while(!pending.isEmpty()&&file(pending.get(0).source)!=null)pending.remove(0);save();return pending.isEmpty()?null:pending.get(0);}
    synchronized int remaining(){return pending.size();}
    synchronized int pendingFor(List<Track> tracks){java.util.HashSet<String> waiting=new java.util.HashSet<>();for(Track t:pending)waiting.add(t.source);int n=0;for(Track t:tracks)if(waiting.contains(t.source))n++;return n;}
    synchronized int ready(List<Track> tracks){int count=0;for(Track track:tracks)if(file(track.source)!=null||track.source.startsWith("content:"))count++;return count;}
    synchronized void complete(Track t,File file){if(!validName(file.getName())||!file.getParentFile().equals(directory))throw new IllegalArgumentException("Invalid offline file");files.put(t.source,file.getName());metadata.put(t.source,t.copy());pending.removeIf(old->old.source.equals(t.source));save(OfflineAudio.encrypted(file));}
    synchronized int count(){int count=0;for(String source:files.keySet())if(file(source)!=null)count++;return count;}
    synchronized long bytes(){long bytes=0;File[] all=directory.listFiles();if(all!=null)for(File file:all)if(file.isFile())bytes+=file.length();return bytes;}
    synchronized long bytesFor(List<Track> tracks){long bytes=0;for(Track t:tracks){File saved=file(t.source);if(saved!=null)bytes+=saved.length();}return bytes;}
    void clear(){synchronized(storageLock){synchronized(this){File[] all=directory.listFiles();if(all!=null)for(File f:all)if(f.isFile()&&!f.delete())throw new IllegalStateException("Some downloads could not be removed. Try again.");files.clear();metadata.clear();pending.clear();save();}}}
    synchronized ArrayList<Track> downloaded(List<Track> known){ArrayList<Track> out=new ArrayList<>();for(String source:files.keySet()){if(file(source)==null)continue;Track found=metadata.get(source);if(found==null)for(Track t:known)if(t.source.equals(source)){found=t;break;}if(found==null)found=new Track(source,"Downloaded audio","On this device","",0);out.add(found);}return out;}
    int bitrate(){int value=prefs.getInt("audio_kbps",16);return value==128||value==192?value:16;}
    void bitrate(int value){if(value!=16&&value!=128&&value!=192)throw new IllegalArgumentException("Unsupported audio quality");prefs.edit().putInt("audio_kbps",value).apply();}
    boolean compact(){return bitrate()==16;}
    void compact(boolean value){prefs.edit().putBoolean("compact_audio",value).apply();}
    boolean wifiOnly(){return prefs.getBoolean("wifi_only",true);}
    void wifiOnly(boolean value){prefs.edit().putBoolean("wifi_only",value).apply();}
    String message(){return prefs.getString("message","");}
    void message(String value){prefs.edit().putString("message",value).apply();}
    private void save(){save(false);}
    private void save(boolean durable){try{JSONObject index=new JSONObject();for(Map.Entry<String,String> e:files.entrySet())index.put(e.getKey(),e.getValue());JSONArray known=new JSONArray();for(Track t:metadata.values())known.put(t.json());JSONArray queue=new JSONArray();for(Track t:pending)queue.put(t.json());SharedPreferences.Editor edit=prefs.edit().putString("metadata",known.toString()).putString("files",index.toString()).putString("pending",queue.toString());if(durable){if(!edit.commit())throw new IllegalStateException("Could not persist secured downloads");}else edit.apply();}catch(Exception e){throw new IllegalStateException("Could not save offline downloads",e);}}
}
