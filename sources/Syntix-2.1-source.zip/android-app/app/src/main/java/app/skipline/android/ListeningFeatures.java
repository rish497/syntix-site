package app.skipline.android;

import android.view.*;
import android.widget.*;
import com.google.android.material.snackbar.Snackbar;
import java.util.*;

@androidx.media3.common.util.UnstableApi
final class ListeningFeatures {
    private static final int INK=MainActivity.INK,MUTED=MainActivity.MUTED,ACCENT=MainActivity.ACCENT;
    static void top(MainActivity a,LinearLayout content,String title){LinearLayout bar=a.row();bar.addView(a.icon(R.drawable.ic_back,"Back",()->a.getOnBackPressedDispatcher().onBackPressed()),a.lp(48,48));bar.addView(a.text(title,24,INK,true),new LinearLayout.LayoutParams(0,-2,1));ImageView logo=new ImageView(a);logo.setImageResource(R.drawable.syntix_app_icon);logo.setScaleType(ImageView.ScaleType.FIT_CENTER);bar.addView(logo,a.lp(28,28));content.addView(bar,a.lp(-1,64));a.gap(content,18);}
    static void home(MainActivity a,LinearLayout content){
        LinkedHashMap<String,ArrayList<Track>> ready=SmartMixes.available(a.app.history,System.currentTimeMillis());if(ready.isEmpty())return;
        a.gap(content,23);LinearLayout row=a.row();row.addView(a.text("Smart Mixes",21,INK,true),new LinearLayout.LayoutParams(0,-2,1));row.addView(a.icon(R.drawable.ic_arrow,"Open Smart Mixes",()->a.go("mixes")),a.lp(48,48));content.addView(row);content.addView(a.text("Playlists that grow with your listening.",13,MUTED,false));a.gap(content,14);mixRail(a,content,ready);
    }
    static void mixRail(MainActivity a,LinearLayout content,LinkedHashMap<String,ArrayList<Track>> ready){
        HorizontalScrollView scroll=new HorizontalScrollView(a);scroll.setHorizontalScrollBarEnabled(false);LinearLayout rail=a.row();
        for(Map.Entry<String,ArrayList<Track>> entry:ready.entrySet()){
            String name=entry.getKey();ArrayList<Track> songs=entry.getValue();LinearLayout card=a.column();card.addView(mixArtwork(a,songs),a.lp(148,148));a.gap(card,10);
            TextView title=a.text(name,15,INK,true);title.setMaxLines(2);card.addView(title);a.gap(card,4);card.addView(a.text(songs.size()+" songs · Made for you",12,MUTED,false));
            card.setContentDescription("Open "+name+" Smart Mix, "+songs.size()+" songs");card.setFocusable(true);card.setClickable(true);card.setOnClickListener(v->a.go("mix:"+name));LinearLayout.LayoutParams p=a.lp(148,-2);p.rightMargin=a.dp(13);rail.addView(card,p);
        }scroll.addView(rail);content.addView(scroll);
    }
    /** Real song artwork, using the same cache/cropping as saved playlists; no synthetic cover. */
    static View mixArtwork(MainActivity a,ArrayList<Track> songs){
        FrameLayout cover=new FrameLayout(a);a.rounded(cover,MainActivity.SURFACE,12);ArrayList<String> images=new ArrayList<>();HashSet<String> seen=new HashSet<>();for(Track song:songs){if(song.thumbnail.startsWith("https://")&&seen.add(song.thumbnail))images.add(song.thumbnail);if(images.size()==4)break;}
        if(images.isEmpty()){ImageView mark=new ImageView(a);mark.setImageResource(R.drawable.syntix_app_icon);mark.setScaleType(ImageView.ScaleType.FIT_CENTER);mark.setPadding(a.dp(30),a.dp(30),a.dp(30),a.dp(30));cover.addView(mark,new FrameLayout.LayoutParams(-1,-1));}
        else if(images.size()==1){cover.addView(mixImage(a,images.get(0)),new FrameLayout.LayoutParams(-1,-1));}
        else{LinearLayout grid=a.column();int rows=images.size()==2?1:2;for(int row=0;row<rows;row++){LinearLayout line=a.row();for(int col=0;col<2;col++){ImageView art=mixImage(a,images.get((row*2+col)%images.size()));LinearLayout.LayoutParams tile=new LinearLayout.LayoutParams(0,-1,1);if(col==0)tile.rightMargin=a.dp(2);line.addView(art,tile);}LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,0,1);if(row==0&&rows==2)rp.bottomMargin=a.dp(2);grid.addView(line,rp);}cover.addView(grid,new FrameLayout.LayoutParams(-1,-1));}
        cover.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS);return cover;
    }
    private static ImageView mixImage(MainActivity a,String url){ImageView image=new ImageView(a);image.setScaleType(ImageView.ScaleType.CENTER_CROP);Images.load(image,url);return image;}
    static void mixes(MainActivity a,LinearLayout content){
        top(a,content,"Smart Mixes");LinkedHashMap<String,ArrayList<Track>> ready=SmartMixes.available(a.app.history,System.currentTimeMillis());
        if(ready.isEmpty()){content.addView(a.text("Your mixes will appear after 50 matching songs.",20,INK,true));return;}
        content.addView(a.text("Made from your listening on this profile.",14,MUTED,false));a.gap(content,20);mixRail(a,content,ready);
    }
    static void mix(MainActivity a,LinearLayout content){
        String name=a.page.substring(4);ArrayList<Track> tracks=SmartMixes.available(a.app.history,System.currentTimeMillis()).get(name);
        if(tracks==null){top(a,content,"Smart Mixes");content.addView(a.text("This mix needs at least 50 matching songs.",18,MUTED,false));return;}
        top(a,content,name);content.addView(a.text(tracks.size()+" songs · Your listening history",13,MUTED,false));a.gap(content,20);
        SavedPlaylist list=new SavedPlaylist(name);list.add(tracks);content.addView(a.button("Play mix",R.drawable.ic_play,true,()->a.playPlaylistAt(list,0)),a.lp(-1,52));a.gap(content,12);content.addView(a.button("Save to Your Library",R.drawable.ic_plus,false,()->a.namePlaylist(name,chosen->{SavedPlaylist saved=new SavedPlaylist(chosen);saved.add(tracks);a.app.library.add(saved);a.app.saveLibrary();Snackbar.make(a.root,"Mix saved to Your Library",Snackbar.LENGTH_SHORT).show();})),a.lp(-1,48));a.gap(content,20);for(Track t:tracks)NativeScreens.track(a,content,t,list);
    }
    static void sleep(MainActivity a,LinearLayout content){SleepTimerScreen.render(a,content);}
    static void updateTick(MainActivity a){SleepTimerScreen.update(a);}
}
