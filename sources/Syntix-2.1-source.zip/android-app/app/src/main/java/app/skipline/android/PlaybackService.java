package app.skipline.android;

import android.app.PendingIntent;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.media3.common.AudioAttributes;
import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MediaMetadata;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.datasource.DefaultDataSource;
import androidx.media3.datasource.ResolvingDataSource;
import androidx.media3.datasource.okhttp.OkHttpDataSource;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.session.MediaSession;
import androidx.media3.session.MediaSessionService;
import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;
import okhttp3.OkHttpClient;

@androidx.media3.common.util.UnstableApi
public final class PlaybackService extends MediaSessionService {
    ExoPlayer player;
    final SoundProcessor sound=new SoundProcessor();
    SleepTimer sleep;boolean timerFinished;
    void appChanged(){app.playerChanged();app.changed();}
    void updateVolume(){if(player!=null){float volume=Math.max(0,Math.min(100,app.prefs("sound").getInt("volume",100)))/100f;player.setVolume(volume*(sleep==null?1:sleep.multiplier()));}}
    private MediaSession session;
    private SkiplineApp app;
    private String retried="";
    private int streamRetries;
    private boolean waitingToRetry;
    private String retryMediaId="";
    private long retryPosition;
    private final Runnable retryStream=()->{waitingToRetry=false;MediaItem item=player.getCurrentMediaItem();if(item==null||!item.mediaId.equals(retryMediaId)||!player.getPlayWhenReady())return;player.seekTo(Math.max(0,retryPosition));player.prepare();};
    @Override public void onUpdateNotification(MediaSession mediaSession,boolean startInForegroundRequired){super.onUpdateNotification(mediaSession,startInForegroundRequired||waitingToRetry);}
    private boolean recoverStream(PlaybackException error){
        MediaItem item=player.getCurrentMediaItem();Track track=item==null?null:app.find(item.mediaId);
        if(track==null||!track.source.startsWith("https://")||!player.getPlayWhenReady()||streamRetries>=2)return false;
        boolean recoverable=error.errorCode>=2000&&error.errorCode<3000;
        for(Throwable cause=error;cause!=null;cause=cause.getCause())if(cause instanceof androidx.media3.datasource.HttpDataSource.InvalidResponseCodeException){int code=((androidx.media3.datasource.HttpDataSource.InvalidResponseCodeException)cause).responseCode;recoverable=code==403||code==408||code==410||code==429||code>=500;break;}
        if(!recoverable)return false;
        Extractor.tryCompatibility(track.source);Extractor.invalidate(track.source);streamRetries++;retryMediaId=item.mediaId;retryPosition=player.getCurrentPosition();waitingToRetry=true;app.error="";app.playerChanged();
        // Preserve the existing user-started foreground session during a short network recovery.
        try{onUpdateNotification(session,true);}catch(RuntimeException blocked){waitingToRetry=false;return false;}historyHandler.removeCallbacks(retryStream);historyHandler.postDelayed(retryStream,streamRetries*1000L);return true;
    }
    private final android.os.Handler historyHandler=new android.os.Handler(android.os.Looper.getMainLooper());
    private String recorded="";
    void resetRecording(){recorded="";}
    private final Runnable recordPlay=()->{MediaItem item=player.getCurrentMediaItem();if(player.isPlaying()&&item!=null&&!item.mediaId.equals(recorded)){Track track=app.find(item.mediaId);if(track!=null){recorded=item.mediaId;app.history.record(track);app.requestRecommendations(track);app.listeningChanged();}}};
    @Override public void onCreate() {
        super.onCreate();app=(SkiplineApp)getApplication();app.playback=this;
        OkHttpClient client=DirectAudio.CLIENT.newBuilder().connectTimeout(10,TimeUnit.SECONDS).readTimeout(20,TimeUnit.SECONDS).callTimeout(0,TimeUnit.MILLISECONDS).build();
        ResolvingDataSource.Factory streams=new ResolvingDataSource.Factory(()->new OfflineDataSource(new DefaultDataSource.Factory(this,new OkHttpDataSource.Factory(client))),spec->{
            if(!"skipline".equals(spec.uri.getScheme()))return spec;
            String source=spec.uri.getQueryParameter("source");if(source==null)throw new IOException("Missing audio source");
            java.io.File saved=app.offline.playbackFile(source);if(saved!=null)return spec.withUri(Uri.fromFile(saved));
            android.net.ConnectivityManager net=(android.net.ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);if(net.getActiveNetwork()==null)throw new IOException("This song is not downloaded. Connect to the internet or choose a downloaded song.");
            try{Extractor.Resolved stream=Extractor.resolve(this,source);return spec.withUri(Uri.parse(stream.url)).withRequestHeaders(stream.headers);}catch(Exception e){throw new IOException(e);}
        });
        androidx.media3.exoplayer.DefaultRenderersFactory renderers=new androidx.media3.exoplayer.DefaultRenderersFactory(this){@Override protected androidx.media3.exoplayer.audio.AudioSink buildAudioSink(android.content.Context context,boolean floats,boolean params){return new androidx.media3.exoplayer.audio.DefaultAudioSink.Builder(context).setEnableFloatOutput(false).setAudioProcessors(new androidx.media3.common.audio.AudioProcessor[]{sound}).build();}};
        player=new ExoPlayer.Builder(this,renderers).setLoadControl(new androidx.media3.exoplayer.DefaultLoadControl.Builder().setBufferDurationsMs(15000,30000,250,1000).setPrioritizeTimeOverSizeThresholds(true).build()).setMediaSourceFactory(new DefaultMediaSourceFactory(streams)).build();
        player.setAudioAttributes(new AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(),true);
        player.setRepeatMode(app.prefs("session").getInt("repeat",Player.REPEAT_MODE_OFF));player.setShuffleModeEnabled(app.prefs("session").getBoolean("shuffle",false));
        sleep=new SleepTimer(this);SoundSettings.apply(app);
        player.setHandleAudioBecomingNoisy(true);player.setWakeMode(C.WAKE_MODE_LOCAL);
        PendingIntent activity=PendingIntent.getActivity(this,0,new Intent(this,MainActivity.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        session=new MediaSession.Builder(this,player).setSessionActivity(activity).build();
        player.addListener(new Player.Listener(){
            @Override public void onRepeatModeChanged(int mode){app.prefs("session").edit().putInt("repeat",mode).apply();if(player.getPlaybackState()==Player.STATE_READY)prepareNext();}
            @Override public void onShuffleModeEnabledChanged(boolean enabled){app.prefs("session").edit().putBoolean("shuffle",enabled).apply();if(player.getPlaybackState()==Player.STATE_READY)prepareNext();}
            @Override public void onEvents(Player p,Player.Events events){if(app.statistics!=null)app.statistics.playerEvent();app.playerChanged();}
            @Override public void onPlayerError(PlaybackException e){if(recoverStream(e))return;waitingToRetry=false;MediaItem item=player.getCurrentMediaItem();Track t=item==null?null:app.find(item.mediaId);if(t!=null)Extractor.invalidate(t.source);app.error=message(e);app.changed();}
            @Override public void onPlaybackStateChanged(int state){app.playbackBuffering=state==Player.STATE_BUFFERING;sleep.playbackState(state);if(state==Player.STATE_READY){streamRetries=0;prepareNext();}}
            @Override public void onMediaItemTransition(MediaItem item,int reason){sleep.transition(reason);recorded="";waitingToRetry=false;streamRetries=0;historyHandler.removeCallbacks(retryStream);if(player.getPlaybackState()==Player.STATE_READY)prepareNext();historyHandler.removeCallbacks(recordPlay);if(player.isPlaying())historyHandler.postDelayed(recordPlay,5000);}
            @Override public void onPlayWhenReadyChanged(boolean ready,int reason){if(ready){app.backgroundIdle=false;if(app.statistics!=null)app.statistics.resume();}else app.idleIfNoWork();if(!ready){waitingToRetry=false;historyHandler.removeCallbacks(retryStream);}}
            @Override public void onIsPlayingChanged(boolean playing){historyHandler.removeCallbacks(recordPlay);if(playing)historyHandler.postDelayed(recordPlay,5000);}
        });
        sync(false);app.changed();
    }
    private String message(Throwable e){Throwable t=e;while(t.getCause()!=null)t=t.getCause();return Extractor.error(t);}
    MediaItem item(Track t) {
        Uri uri=t.source.startsWith("android.resource:")||t.source.startsWith("content:")?Uri.parse(t.source):new Uri.Builder().scheme("skipline").authority("audio").appendQueryParameter("source",t.source).build();
        MediaMetadata.Builder meta=new MediaMetadata.Builder().setTitle(t.title).setArtist(t.creator).setAlbumTitle("Syntix temporary queue");
        if(!t.thumbnail.isEmpty())meta.setArtworkUri(Uri.parse(t.thumbnail));
        return new MediaItem.Builder().setMediaId(t.id).setUri(uri).setMediaMetadata(meta.build()).build();
    }
    void sync(boolean playFirst) {
        sync(playFirst,"");
    }
    void sync(boolean playFirst,String requestedId) {
        if(app.queue.isEmpty()){player.stop();player.clearMediaItems();return;}
        MediaItem current=player.getCurrentMediaItem();
        if(current==null||app.find(current.mediaId)==null){ArrayList<MediaItem> items=new ArrayList<>();int start=0;for(Track track:app.queue){if(track.id.equals(requestedId))start=items.size();items.add(item(track));}player.setMediaItems(items,start,0);if(playFirst){player.prepare();player.play();}return;}
        // Edit the timeline in place so adding or reordering never restarts the audio.
        for(int i=player.getMediaItemCount()-1;i>=0;i--)if(app.find(player.getMediaItemAt(i).mediaId)==null)player.removeMediaItem(i);
        for(int i=0;i<app.queue.size();i++){
            Track t=app.queue.get(i);int existing=-1;
            for(int j=i;j<player.getMediaItemCount();j++)if(player.getMediaItemAt(j).mediaId.equals(t.id)){existing=j;break;}
            if(existing<0)player.addMediaItem(i,item(t));else if(existing!=i)player.moveMediaItem(existing,i);
        }
        if(playFirst){player.prepare();player.play();}
        if(player.isPlaying()&&requestedId.isEmpty())prepareNext();
    }
    private void prepareNext(){int index=player.getNextMediaItemIndex();if(index==C.INDEX_UNSET)return;Track track=app.find(player.getMediaItemAt(index).mediaId);if(track==null||!track.source.startsWith("https://"))return;app.warmStream(track);}
    void play(int index){app.backgroundIdle=false;if(app.statistics!=null)app.statistics.resume();if(index<0||index>=player.getMediaItemCount())return;recorded="";retried="";streamRetries=0;waitingToRetry=false;historyHandler.removeCallbacks(retryStream);app.error="";player.seekToDefaultPosition(index);player.prepare();player.play();app.playerChanged();}
    void toggle(){app.backgroundIdle=false;if(app.statistics!=null)app.statistics.resume();if(player.getPlaybackState()==Player.STATE_ENDED){recorded="";player.seekToDefaultPosition();player.prepare();player.play();}else if(player.getPlayWhenReady()&&player.getPlayerError()==null)player.pause();else if(player.getMediaItemCount()>0){streamRetries=0;app.error="";player.prepare();player.play();}}
    void next(){if(player.hasNextMediaItem())player.seekToNextMediaItem();}
    void previous(){if(player.getCurrentPosition()>3000)player.seekTo(0);else if(player.hasPreviousMediaItem())player.seekToPreviousMediaItem();}
    @Override public MediaSession onGetSession(MediaSession.ControllerInfo info){return session;}
    void stopForDismissal(){if(sleep!=null)sleep.cancel();waitingToRetry=false;historyHandler.removeCallbacksAndMessages(null);player.pause();player.stop();pauseAllPlayersAndStopSelf();}
    @Override public void onTaskRemoved(@Nullable Intent rootIntent){app.dismissTask();}
    @Override public void onDestroy(){app.playbackBuffering=false;if(sleep!=null)sleep.close();if(app.statistics!=null){player.pause();app.statistics.playerEvent();}app.playback=null;historyHandler.removeCallbacksAndMessages(null);session.release();player.release();app.idleIfNoWork();app.changed();super.onDestroy();}
}
