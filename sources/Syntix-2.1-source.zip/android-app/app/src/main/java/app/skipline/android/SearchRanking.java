package app.skipline.android;

import java.util.*;

/** Stable ordering by catalog and artist-verification evidence, not channel popularity. */
final class SearchRanking {
    static ArrayList<Track> order(String query,List<Track> tracks){ArrayList<Track> copy=new ArrayList<>(tracks);copy.sort((a,b)->Integer.compare(rank(query,b),rank(query,a)));return copy;}
    private static int rank(String query,Track track){
        String title=track.title.toLowerCase(Locale.ROOT),wanted=query.toLowerCase(Locale.ROOT);int score=track.musicCatalog?300:track.verifiedArtist?200:title.contains("official")?40:0;
        for(String version:new String[]{"live","cover","remix","reaction","karaoke","slowed","sped","acoustic"})if(title.matches(".*\\b"+version+"\\b.*")&&!wanted.matches(".*\\b"+version+"\\b.*"))score-=400;
        return score;
    }
    static ArrayList<Track> merge(String query,List<Track> catalog,List<Track> videos){LinkedHashMap<String,Track> all=new LinkedHashMap<>();for(List<Track> group:Arrays.asList(catalog,videos))for(Track track:group){String key;try{key=Links.singleVideo(track.source);}catch(Exception ignored){key=track.source;}all.putIfAbsent(key,track);}return order(query,new ArrayList<>(all.values()));}
}
