package app.skipline.android;

import android.content.Intent;
import android.view.Gravity;
import android.widget.*;
import com.google.android.material.bottomsheet.BottomSheetDialog;

/** Bundled avatars use stable resource names, never device-specific resource IDs. */
final class ProfileArtwork {
    static final String PREFIX="avatar:";
    static int resource(android.content.Context context,String photo){
        if(!photo.startsWith(PREFIX))return 0;
        String name=photo.substring(PREFIX.length());
        return name.matches("cartoon_[0-9]{2}")?context.getResources().getIdentifier(name,"drawable",context.getPackageName()):0;
    }
    @androidx.media3.common.util.UnstableApi
    static void choose(MainActivity a){
        LinearLayout body=a.column();a.handle(body);body.addView(a.text("Make it yours",26,MainActivity.INK,true));a.gap(body,14);
        BottomSheetDialog[] dialog=new BottomSheetDialog[1];String profile=a.app.profiles.active;
        body.addView(a.button("Choose from gallery",R.drawable.ic_photo,false,()->{dialog[0].dismiss();a.photoProfile=profile;a.startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("image/*").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION),60);}),a.lp(-1,52));a.gap(body,18);
        body.addView(a.text("Or choose a character",15,MainActivity.MUTED,false));a.gap(body,14);
        ScrollView scroll=new ScrollView(a);scroll.setVerticalScrollBarEnabled(false);LinearLayout grid=a.column();scroll.addView(grid);
        for(int row=0;row<3;row++){LinearLayout line=a.row();for(int col=0;col<4;col++){
            String name=String.format(java.util.Locale.ROOT,"cartoon_%02d",row*4+col);FrameLayout hit=new FrameLayout(a);ImageView image=new ImageView(a);image.setImageResource(resource(a,PREFIX+name));image.setScaleType(ImageView.ScaleType.CENTER_CROP);a.rounded(image,MainActivity.ACCENT,36);hit.addView(image,new FrameLayout.LayoutParams(a.dp(66),a.dp(66),Gravity.CENTER));hit.setContentDescription("Choose character "+(row*4+col+1));hit.setFocusable(true);hit.setOnClickListener(v->{LocalProfiles.Profile target=a.app.profiles.find(profile);if(target!=null){target.photo=PREFIX+name;a.app.profiles.save();}dialog[0].dismiss();a.refresh();});line.addView(hit,new LinearLayout.LayoutParams(0,a.dp(82),1));}grid.addView(line);}
        body.addView(scroll,a.lp(-1,260));dialog[0]=a.sheet(body);
    }
}
