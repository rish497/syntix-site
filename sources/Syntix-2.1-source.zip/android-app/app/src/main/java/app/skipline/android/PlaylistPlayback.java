package app.skipline.android;

import android.content.res.ColorStateList;
import android.view.View;
import android.widget.*;
import androidx.media3.common.Player;
import com.google.android.material.button.MaterialButton;
import java.util.ArrayList;

/** Updates existing playlist controls on player events without replacing their views. */
@androidx.media3.common.util.UnstableApi
final class PlaylistPlayback {
    static boolean isCurrentPlaylist(MainActivity a,SavedPlaylist saved){return a.app.playback!=null&&NativeScreens.currentTrack(a)!=null&&a.app.prefs("session").getString("playing_playlist","").equals(saved==a.app.favorites?"favorites":saved.id);}
    static void update(MainActivity a){for(Runnable update:new ArrayList<>(a.playlistPlaybackUpdates))update.run();}
    private static void register(MainActivity a,View anchor,Runnable update){
        update.run();if(anchor.isAttachedToWindow())a.playlistPlaybackUpdates.add(update);
        anchor.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener(){
            public void onViewAttachedToWindow(View v){if(!a.playlistPlaybackUpdates.contains(update))a.playlistPlaybackUpdates.add(update);update.run();}
            public void onViewDetachedFromWindow(View v){a.playlistPlaybackUpdates.remove(update);}
        });
    }
    static void bindPlayButton(MainActivity a,MaterialButton button,SavedPlaylist saved){register(a,button,()->{
        boolean active=isCurrentPlaylist(a,saved)&&a.app.playback.player.getPlayWhenReady();
        button.setIconResource(active?R.drawable.ic_pause:R.drawable.ic_play);button.setContentDescription(active?"Pause playlist":"Play playlist");button.setTooltipText(active?"Pause playlist":"Play playlist");
    });}
    static void bindRow(MainActivity a,View row,TextView title,TextView subtitle,Track track,SavedPlaylist saved,String detail){
        final String[] previous={null};
        register(a,row,()->{
            Track current=NativeScreens.currentTrack(a);boolean selected=isCurrentPlaylist(a,saved)&&current!=null&&track.source.equals(current.source);
            String state="";
            if(selected){Player player=a.app.playback.player;state=player.isPlaying()?"Playing":player.getPlayWhenReady()&&player.getPlaybackState()==Player.STATE_BUFFERING?"Loading":"Paused";}
            if(state.equals(previous[0]))return;previous[0]=state;
            a.rounded(row,selected?0xff34362f:android.graphics.Color.TRANSPARENT,8);row.setSelected(selected);
            title.setTextColor(selected?MainActivity.ACCENT:MainActivity.INK);subtitle.setText(selected?state+" · "+detail:detail);subtitle.setTextColor(selected?MainActivity.ACCENT:MainActivity.MUTED);
            row.setContentDescription(track.title+(selected?", "+state:"")+", "+detail);
        });
    }
}
