package app.skipline.android;

import android.content.SharedPreferences;

@androidx.media3.common.util.UnstableApi
final class SoundSettings {
    static int[] bands(SkiplineApp app){int[] b=new int[7];SharedPreferences p=app.prefs("sound");for(int i=0;i<7;i++)b[i]=Math.max(-12,Math.min(12,p.getInt("band_"+i,0)));return b;}
    static void apply(SkiplineApp app){if(app.playback==null)return;SharedPreferences p=app.prefs("sound");app.playback.sound.settings(new SoundProcessor.Settings(p.getBoolean("enabled",false),p.getBoolean("normalize",false),bands(app),p.getInt("bass",0),p.getInt("space",0)));app.playback.updateVolume();}
    static void reset(SkiplineApp app){SharedPreferences.Editor e=app.prefs("sound").edit().putString("preset","Flat").putInt("bass",0).putInt("space",0);for(int i=0;i<7;i++)e.putInt("band_"+i,0);e.apply();apply(app);}
    static void preset(SkiplineApp app,String name){int[] bands;switch(name){case "Pop":bands=new int[]{-1,2,3,1,2,1,0};break;case "Rock":bands=new int[]{4,2,-1,-2,1,3,4};break;case "Bass":bands=new int[]{6,4,1,0,0,0,-1};break;case "Vocal":bands=new int[]{-2,-1,1,4,3,1,0};break;case "Custom":bands=new int[7];for(int i=0;i<7;i++)bands[i]=app.prefs("sound").getInt("saved_"+i,0);break;default:bands=new int[7];}SharedPreferences.Editor e=app.prefs("sound").edit().putString("preset",name).putBoolean("enabled",true).putInt("bass",name.equals("Custom")?app.prefs("sound").getInt("saved_bass",0):0).putInt("space",name.equals("Custom")?app.prefs("sound").getInt("saved_space",0):0);for(int i=0;i<7;i++)e.putInt("band_"+i,bands[i]);e.apply();apply(app);}
}
