package app.skipline.android;

import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.style.RelativeSizeSpan;
import android.view.Gravity;
import android.widget.*;
import com.google.android.material.button.MaterialButton;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.*;

/** Native integration of the approved Statistics study; all values are observed phone data. */
@androidx.media3.common.util.UnstableApi
final class StatisticsScreens {
    private static final WeakHashMap<MainActivity,Config> configs=new WeakHashMap<>();
    private static final class Config {final int[] units={1,1,1};}
    private static Config config(MainActivity a){Config c=configs.get(a);if(c==null){c=new Config();configs.put(a,c);}return c;}
    static void render(MainActivity a,LinearLayout body,boolean expanded){
        int top=androidx.core.graphics.ColorUtils.blendARGB(MainActivity.PAGE,MainActivity.ACCENT,expanded?.14f:.09f);
        GradientDrawable wash=new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{top,MainActivity.PAGE,MainActivity.PAGE});
        wash.setColors(new int[]{top,MainActivity.PAGE,MainActivity.PAGE},new float[]{0,.38f,1});a.root.setBackground(wash);a.getWindow().setStatusBarColor(top);
        NativeSearch.header(a,body,expanded?"Your artists":"Statistics",()->{if(!a.screenHistory.isEmpty()){a.page=a.screenHistory.pop();a.refresh();}else if(expanded){a.page="statistics";a.refresh();}else a.tab("home");});
        long now=System.currentTimeMillis();SimpleDateFormat date=new SimpleDateFormat("MMM d",Locale.getDefault());
        LinearLayout range=a.row();range.addView(a.text("Your last 3 months",12,MainActivity.MUTED,false),new LinearLayout.LayoutParams(0,-2,1));range.addView(a.text(date.format(new Date(StatsTime.cutoff(now,TimeZone.getDefault())))+" – "+date.format(new Date(now)),11,MainActivity.MUTED,false));body.addView(range);a.gap(body,23);
        LinearLayout holder=a.column();body.addView(holder);holder.addView(a.text("Loading activity…",14,MainActivity.MUTED,false));
        a.app.statistics.report(report->{
            if(!holder.isAttachedToWindow())return;holder.removeAllViews();
            if(!report.available){holder.addView(a.text("Statistics could not be opened. Your library is safe. Try again.",14,MainActivity.MUTED,false));holder.addView(a.button("Try again",R.drawable.ic_retry,false,a::refresh),a.lp(-1,48));return;}
            LinearLayout heading=a.row();TextView artistTitle=a.text(expanded?"Your artists":"Your top artists",21,MainActivity.INK,true);artistTitle.setMaxWidth(a.getResources().getDisplayMetrics().widthPixels-a.dp(86));heading.addView(artistTitle,a.lp(-2,-2));heading.setMinimumHeight(a.dp(48));
            if(!expanded){MaterialButton arrow=a.icon(R.drawable.ic_arrow,"See all artists",()->a.go("artists"));arrow.setStrokeWidth(0);arrow.setIconTint(ColorStateList.valueOf(MainActivity.ACCENT));heading.addView(arrow,a.lp(48,48));}
            holder.addView(heading,a.lp(-1,-2));a.gap(holder,6);
            if(report.artists.isEmpty()){holder.addView(a.text("Your artists appear as you listen.",14,MainActivity.MUTED,false));a.gap(holder,22);}
            long maximum=report.artists.isEmpty()?1:Math.max(1,report.artists.get(0).ms);
            for(int i=0;i<Math.min(expanded?report.artists.size():3,report.artists.size());i++){
                ActivityStats.Artist artist=report.artists.get(i);LinearLayout row=a.row();row.setMinimumHeight(a.dp(70));row.setPadding(0,a.dp(8),0,a.dp(8));
                TextView rank=a.text((i+1)+".",20,i==0?MainActivity.ACCENT:MainActivity.MUTED,true);rank.setFontFeatureSettings("tnum");row.addView(rank,a.lp(31,-2));
                LinearLayout labels=a.column();labels.setPadding(a.dp(6),0,a.dp(17),0);TextView name=a.text(artist.name,15,MainActivity.INK,true);name.setMaxLines(2);name.setEllipsize(TextUtils.TruncateAt.END);labels.addView(name);a.gap(labels,9);
                ProgressBar meter=new ProgressBar(a,null,android.R.attr.progressBarStyleHorizontal);meter.setMax(1000);meter.setProgress((int)(artist.ms*1000d/maximum));meter.setProgressTintList(ColorStateList.valueOf(MainActivity.ACCENT));meter.setProgressBackgroundTintList(ColorStateList.valueOf(0x16ffffff));labels.addView(meter,a.lp(-1,3));row.addView(labels,new LinearLayout.LayoutParams(0,-2,1));
                TextView time=a.text(duration(artist.ms),12,MainActivity.MUTED,false);time.setFontFeatureSettings("tnum");row.addView(time,a.lp(-2,-2));holder.addView(row,a.lp(-1,-2));
            }
            if(expanded){a.gap(holder,24);holder.addView(a.text("Ranked by time listened over the last 3 months.",12,MainActivity.MUTED,false));return;}
            a.gap(holder,25);Config c=config(a);long snapshot=System.currentTimeMillis();
            metric(a,holder,report,c,0,"Listening time",MainActivity.ACCENT,snapshot);
            metric(a,holder,report,c,1,"Data usage",0xffa3c5c4,snapshot);
            metric(a,holder,report,c,2,"Battery usage",0xffc3b6d5,snapshot);
            divider(a,holder);a.gap(holder,23);holder.addView(a.text("Just your last 3 months.",16,MainActivity.INK,true));a.gap(holder,6);holder.addView(a.text("Older activity clears automatically. Your listening stays on your device. Clear listening history in Settings to reset your statistics.",12,MainActivity.MUTED,false));a.gap(holder,20);
        });
    }
    static String duration(long ms){long m=ms/60000;if(m==0)return ms>0?"<1 min":"0 min";return m>=60?m/60+" h "+m%60+" m":m+" min";}
    private static void divider(MainActivity a,LinearLayout body){android.view.View line=new android.view.View(a);line.setBackgroundColor(0x16ffffff);body.addView(line,a.lp(-1,1));}
    private static CharSequence scaled(String text){SpannableString value=new SpannableString(text);Matcher units=Pattern.compile("(?<![A-Za-z])(?:min|h|m|GB|MB|kB|B|% / h)(?![A-Za-z])").matcher(text);while(units.find())value.setSpan(new RelativeSizeSpan(.48f),units.start(),units.end(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);return value;}
    private static void metric(MainActivity a,LinearLayout body,ActivityStats.Report report,Config c,int kind,String name,int color,long now){
        divider(a,body);a.gap(body,23);
        LinearLayout heading=a.row();heading.addView(a.text(name,20,MainActivity.INK,true),new LinearLayout.LayoutParams(0,-2,1));
        MaterialButton cycle=a.button("Day",0,false,()->{});cycle.setIcon(null);cycle.setTextSize(13);cycle.setTextColor(color);cycle.setCornerRadius(a.dp(12));cycle.setStrokeWidth(a.dp(1));cycle.setStrokeColor(ColorStateList.valueOf(0x2affffff));cycle.setBackgroundTintList(ColorStateList.valueOf(0x08ffffff));cycle.setMinHeight(a.dp(48));cycle.setMinimumHeight(a.dp(48));cycle.setPadding(a.dp(10),0,a.dp(10),0);cycle.setMinWidth(0);cycle.setMinimumWidth(0);heading.addView(cycle,a.lp(78,48));body.addView(heading);a.gap(body,17);
        LinearLayout chart=a.column();body.addView(chart);
        Runnable draw=()->{
            chart.removeAllViews();int unit=c.units[kind];StatsSeries series=StatsSeries.make(report.points,kind,unit,now,TimeZone.getDefault());String[] choices={"Hour","Day","Month"};String period=unit==0?"Last 24 hours":unit==1?"Last 30 days":"Last 3 months";
            cycle.setText(choices[unit]);cycle.setContentDescription(name+", "+choices[unit]+" view. Tap for "+choices[(unit+1)%3]);androidx.core.view.ViewCompat.setStateDescription(cycle,choices[unit]);
            boolean available=(kind!=1||report.networkAvailable)&&(kind!=2||series.totalObserved>0);
            String total=kind==0?duration(series.totalMs):kind==1?android.text.format.Formatter.formatFileSize(a,series.totalBytes):series.totalObserved>0?String.format(Locale.getDefault(),"%.1f %% / h",series.totalDrop*3600000d/series.totalObserved):"—";
            TextView amount=a.text("",available?35:24,color,false);amount.setFontFeatureSettings("tnum");amount.setText(scaled(kind==1&&!available?"Unavailable":total));chart.addView(amount,a.lp(-1,-2));a.gap(chart,6);
            LinearLayout labels=a.row();labels.addView(a.text(period,11,MainActivity.MUTED,false),new LinearLayout.LayoutParams(0,-2,1));TextView selection=a.text(kind==2?"Observed average":"Total",11,color,false);labels.addView(selection);chart.addView(labels);a.gap(chart,14);
            if(available){
                StatisticsPlot plot=new StatisticsPlot(a,series,color,kind,unit,index->{
                    String result=index<0?total:kind==0?duration(Math.round(series.values[index]*60000)):kind==1?android.text.format.Formatter.formatFileSize(a,Math.round(series.values[index]*1000000)):series.observed[index]>0?String.format(Locale.getDefault(),"%.1f %% / h",series.values[index]):"—";
                    amount.setText(scaled(result));selection.setText(index<0?(kind==2?"Observed average":"Total"):new SimpleDateFormat(unit==0?"HH:mm":unit==1?"MMM d":"MMM yyyy",Locale.getDefault()).format(new Date(series.dates[index])));
                });chart.addView(plot,a.lp(-1,190));
            }else{TextView empty=a.text(kind==1?"Android has not provided network measurements.":"Listen while unplugged to see battery readings.",14,MainActivity.MUTED,false);empty.setGravity(Gravity.CENTER);chart.addView(empty,a.lp(-1,190));}
            a.gap(chart,11);chart.addView(a.text(kind==0?"Actual time playing, excluding buffering and pauses.":kind==1?"Syntix network traffic, including downloads.":"Device discharge during playback; includes other device activity.",12,MainActivity.MUTED,false));a.gap(chart,28);
        };
        cycle.setOnClickListener(v->{c.units[kind]=(c.units[kind]+1)%3;draw.run();});draw.run();
    }
}
