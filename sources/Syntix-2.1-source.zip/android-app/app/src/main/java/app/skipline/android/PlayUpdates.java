package app.skipline.android;

import androidx.activity.result.*;
import androidx.activity.result.contract.ActivityResultContracts;
import com.google.android.play.core.appupdate.*;
import com.google.android.play.core.install.model.*;

/** Play-owned immediate update UI. Network/store failures never prevent local playback. */
@androidx.media3.common.util.UnstableApi
final class PlayUpdates {
    final MainActivity activity;final AppUpdateManager manager;final ActivityResultLauncher<IntentSenderRequest> launcher;boolean checking,inFlight;long lastPrompt=-600000;
    PlayUpdates(MainActivity a,AppUpdateManager m){activity=a;manager=m;launcher=a.registerForActivityResult(new ActivityResultContracts.StartIntentSenderForResult(),result->finished());}
    static PlayUpdates create(MainActivity a){try{if(!"com.android.vending".equals(a.getPackageManager().getInstallerPackageName(a.getPackageName())))return null;return new PlayUpdates(a,AppUpdateManagerFactory.create(a));}catch(RuntimeException unavailable){return null;}}
    void finished(){inFlight=false;}
    void paused(){inFlight=false;}
    void check(){
        if(checking||inFlight||activity.isFinishing()||activity.isDestroyed())return;checking=true;
        manager.getAppUpdateInfo().addOnSuccessListener(info->{checking=false;if(inFlight||activity.isFinishing()||activity.isDestroyed()||!activity.getLifecycle().getCurrentState().isAtLeast(androidx.lifecycle.Lifecycle.State.RESUMED))return;boolean resume=info.updateAvailability()==UpdateAvailability.DEVELOPER_TRIGGERED_UPDATE_IN_PROGRESS;if(resume||info.updateAvailability()==UpdateAvailability.UPDATE_AVAILABLE&&info.isUpdateTypeAllowed(AppUpdateType.IMMEDIATE)&&android.os.SystemClock.elapsedRealtime()-lastPrompt>=600000){try{lastPrompt=android.os.SystemClock.elapsedRealtime();inFlight=manager.startUpdateFlowForResult(info,launcher,AppUpdateOptions.newBuilder(AppUpdateType.IMMEDIATE).build());}catch(RuntimeException unavailable){inFlight=false;}}}).addOnFailureListener(error->{checking=false;});
    }
}
