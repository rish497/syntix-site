package app.skipline.android;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.*;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import okhttp3.*;
import org.json.*;

/** Public web metadata pagination. Anonymous tokens are request-local, never saved or logged. */
final class SpotifyPublicPlaylist {
    private static final String QUERY_HASH="21ea11a6ac75a5f3e01fd365d29c18e0a4a8b7dc09f89bbb5d73910190c6acaf";
    private static int secretVersion;private static byte[] secret;private static long secretUntil;
    private static JSONObject get(OkHttpClient client,String url,String bearer)throws Exception{
        Request.Builder request=new Request.Builder().url(url).header("User-Agent","Mozilla/5.0").header("Accept-Language","en-US,en;q=0.8");
        if(bearer!=null)request.header("Authorization","Bearer "+bearer).post(RequestBody.create(new byte[0],MediaType.get("application/json")));
        try(Response response=client.newCall(request.build()).execute()){
            if(!response.isSuccessful()||response.body()==null)throw new IOException("Public Spotify metadata unavailable (HTTP "+response.code()+")");
            return new JSONObject(SpotifyPlaylist.read(response.body().byteStream()));
        }
    }
    private static synchronized String[] code(OkHttpClient client,long now)throws Exception{
        if(secret==null||now>=secretUntil){
            JSONObject versions=get(client,"https://code.thetadev.de/ThetaDev/spotify-secrets/raw/branch/main/secrets/secretDict.json",null);
            int version=0;Iterator<String> keys=versions.keys();while(keys.hasNext())try{version=Math.max(version,Integer.parseInt(keys.next()));}catch(NumberFormatException ignored){}
            JSONArray bytes=versions.optJSONArray(String.valueOf(version));if(bytes==null||bytes.length()>256)throw new IOException("Spotify public web configuration unavailable");
            StringBuilder key=new StringBuilder();for(int i=0;i<bytes.length();i++)key.append(bytes.getInt(i)^((i%33)+9));
            secret=key.toString().getBytes(StandardCharsets.UTF_8);secretVersion=version;secretUntil=now+15*60*1000;
        }
        Mac mac=Mac.getInstance("HmacSHA1");mac.init(new SecretKeySpec(secret,"HmacSHA1"));byte[] digest=mac.doFinal(ByteBuffer.allocate(8).putLong(now/30000).array());int offset=digest[digest.length-1]&15;
        int number=((digest[offset]&127)<<24)|((digest[offset+1]&255)<<16)|((digest[offset+2]&255)<<8)|(digest[offset+3]&255);
        return new String[]{String.format(Locale.US,"%06d",number%1000000),String.valueOf(secretVersion)};
    }
    static SpotifyPlaylist.Data fetch(String source,OkHttpClient client,java.util.function.BooleanSupplier active)throws Exception{
        if(!active.getAsBoolean())throw new java.util.concurrent.CancellationException();
        String[] code=code(client,System.currentTimeMillis());
        if(!active.getAsBoolean())throw new java.util.concurrent.CancellationException();
        HttpUrl tokenUrl=HttpUrl.get("https://open.spotify.com/api/token").newBuilder().addQueryParameter("reason","init").addQueryParameter("productType","web-player").addQueryParameter("totp",code[0]).addQueryParameter("totpVer",code[1]).addQueryParameter("totpServer",code[0]).build();
        JSONObject token=get(client,tokenUrl.toString(),null);String bearer=token.optString("accessToken");if(bearer.isEmpty()||!token.optBoolean("isAnonymous",true))throw new IOException("Public Spotify session unavailable");
        SpotifyPlaylist.Data data=new SpotifyPlaylist.Data();data.source=source;String id=source.substring(source.lastIndexOf('/')+1);int offset=0;
        while(true){
            if(!active.getAsBoolean()||Thread.currentThread().isInterrupted())throw new java.util.concurrent.CancellationException();
            JSONObject variables=new JSONObject().put("uri","spotify:playlist:"+id).put("offset",offset).put("limit",343).put("enableWatchFeedEntrypoint",false);
            JSONObject extensions=new JSONObject().put("persistedQuery",new JSONObject().put("version",1).put("sha256Hash",QUERY_HASH));
            HttpUrl url=HttpUrl.get("https://api-partner.spotify.com/pathfinder/v1/query").newBuilder().addQueryParameter("operationName","fetchPlaylist").addQueryParameter("variables",variables.toString()).addQueryParameter("extensions",extensions.toString()).build();
            JSONObject response=get(client,url.toString(),bearer);JSONObject root=response.optJSONObject("data"),playlist=root==null?null:root.optJSONObject("playlistV2");if(playlist==null)throw new IOException("Spotify's public playlist format changed");
            JSONObject content=playlist.optJSONObject("content");JSONArray items=content==null?null:content.optJSONArray("items");if(items==null)throw new IOException("Public Spotify track list unavailable");
            data.name=playlist.optString("name",data.name);data.total=content.optInt("totalCount",-1);append(data,items);offset+=items.length();
            if(data.total>=0&&offset>=data.total)break;
            if(items.length()==0)throw new IOException("Spotify interrupted the playlist. Try importing again.");
        }
        if(data.songs.isEmpty())throw new IOException("No public music tracks were available in this playlist");return data;
    }
    static void append(SpotifyPlaylist.Data data,JSONArray items){
        for(int i=0;i<items.length();i++){
            JSONObject row=items.optJSONObject(i),item=row==null?null:row.optJSONObject("itemV2"),song=item==null?null:item.optJSONObject("data");
            if(song==null||!"Track".equals(song.optString("__typename"))){data.skipped++;continue;}
            String uri=song.optString("uri"),name=song.optString("name");JSONObject artists=song.optJSONObject("artists");JSONArray people=artists==null?null:artists.optJSONArray("items");ArrayList<String> names=new ArrayList<>();
            for(int n=0;people!=null&&n<people.length();n++){JSONObject person=people.optJSONObject(n),profile=person==null?null:person.optJSONObject("profile");if(profile!=null&&!profile.optString("name").isEmpty())names.add(profile.optString("name"));}
            if(!uri.startsWith("spotify:track:")||name.isEmpty()||names.isEmpty()){data.skipped++;continue;}
            JSONObject duration=song.optJSONObject("trackDuration"),album=song.optJSONObject("albumOfTrack"),rating=song.optJSONObject("contentRating");
            Boolean explicit=rating==null?null:"EXPLICIT".equals(rating.optString("label"));
            data.songs.add(new SpotifyPlaylist.Song(name,String.join(", ",names),duration==null?0:duration.optLong("totalMilliseconds"),uri,album==null?"":album.optString("name"),explicit));
        }
    }
}
