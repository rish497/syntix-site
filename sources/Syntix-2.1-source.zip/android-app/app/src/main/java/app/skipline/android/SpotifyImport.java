package app.skipline.android;

import android.content.*;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.snackbar.Snackbar;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import okhttp3.OkHttpClient;

/** Public metadata is automatically matched and saved as a normal Syntix playlist. */
@androidx.media3.common.util.UnstableApi
final class SpotifyImport {
    static final class Row {
        final SpotifyPlaylist.Song song;volatile Track match;volatile ArrayList<Track> candidates=new ArrayList<>();volatile boolean attempted,skipped,searching;volatile String error="";
        Row(SpotifyPlaylist.Song value){song=value;}
    }
    static final class Job {
        final String profile;final OkHttpClient client=new OkHttpClient.Builder().connectTimeout(5,TimeUnit.SECONDS).readTimeout(10,TimeUnit.SECONDS).callTimeout(15,TimeUnit.SECONDS).followRedirects(false).build();
        final java.util.Set<String> processes=ConcurrentHashMap.newKeySet();
        SpotifyPlaylist.Data data;final ArrayList<Row> rows=new ArrayList<>();volatile boolean loading,running,cancelled,paused,searchBlocked;volatile String error="";volatile long lastNotify;ExecutorService pool;SavedPlaylist saved,target;String summary="";int importedCount,skippedCount;
        final ConcurrentLinkedDeque<Row> todo=new ConcurrentLinkedDeque<>();volatile Row current,wanted;boolean openTarget,firstWarmSent,restartWhenStopped,fastUnavailable;
        Job(String owner){profile=owner;}
        void cancel(){cancelled=true;wanted=null;client.dispatcher().cancelAll();Extractor.cancelProcesses(processes);}
        int matched(){int n=0;for(Row r:rows)if(r.match!=null&&!r.skipped)n++;return n;}
        int pending(){int n=0;for(Row r:rows)if(!r.attempted&&!r.skipped)n++;return n;}
    }
    static void showLink(MainActivity a,String supplied){
        if(a.app.busy){Snackbar.make(a.root,"Pause the current import before adding another playlist",Snackbar.LENGTH_SHORT).show();return;}
        a.pasteSheet(supplied);
    }
    private static Job begin(MainActivity a){if(a.app.busy)throw new IllegalStateException("Another import is running");Job job=new Job(a.app.profiles.active);job.loading=true;a.app.spotifyImport=job;a.app.busy=true;a.app.status="Reading playlist…";a.go("spotify-import");return job;}
    static void readLink(MainActivity a,String url){if(a.app.busy){Snackbar.make(a.root,"Pause the current import before adding another playlist",Snackbar.LENGTH_LONG).show();return;}Job job=begin(a);SkiplineApp app=a.app;app.worker.execute(()->{try{loaded(app,job,SpotifyPlaylist.fetch(url,job.client,()->!job.cancelled&&!app.taskDismissed));}catch(Exception e){failed(app,job,e);}});}
    private static void loaded(SkiplineApp app,Job job,SpotifyPlaylist.Data data){app.main.post(()->{if(app.spotifyImport!=job)return;job.loading=false;app.busy=false;app.status="";if(job.cancelled||app.taskDismissed){job.error="Import stopped. Your Library is unchanged.";}else{SpotifyProgress.attach(app,job,data);match(app,job);return;}app.changed();});}
    private static void failed(SkiplineApp app,Job job,Exception error){app.main.post(()->{if(app.spotifyImport!=job)return;job.loading=false;app.busy=false;app.status="";job.error=job.cancelled?"Import stopped. Your Library is unchanged.":error.getMessage()==null?"Could not read this public playlist. Try again.":error.getMessage();app.changed();});}
    static void match(SkiplineApp app,Job job){
        if(job.running||app.busy||!job.profile.equals(app.profiles.active))return;job.cancelled=false;job.paused=false;job.searchBlocked=false;job.running=true;app.busy=true;app.status="Matching songs to YouTube…";job.error="";job.todo.clear();for(Row r:job.rows)if(!r.attempted&&!r.skipped)job.todo.add(r);if(job.wanted!=null)prioritize(job,job.wanted);app.changed();
        AtomicInteger workers=new AtomicInteger(1);job.pool=Executors.newFixedThreadPool(1,r->new Thread(()->{android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND);r.run();},"syntix-spotify-matches"));
        Runnable work=()->{try{while(!job.cancelled&&!app.taskDismissed&&!job.searchBlocked){if(app.backgroundIdle){job.paused=true;break;}if(!awaitPlayback(app,job))break;Row row=job.todo.pollFirst();if(row==null)break;if(row.attempted||row.skipped)continue;job.current=row;try{row.match=resolveSong(app,job,row);if(job.cancelled||app.taskDismissed)break;row.attempted=true;row.error="";}catch(Exception unavailable){if(job.cancelled||app.taskDismissed)break;if(yieldsToRequested(job,row)){if(!job.todo.contains(row))job.todo.addLast(row);continue;}if(unavailable instanceof YouTubeMetadata.SearchBlockedException)job.searchBlocked=true;row.error="YouTube search unavailable";}finally{job.current=null;}notifyProgress(app,job);}}finally{if(workers.decrementAndGet()==0)app.main.post(()->{if(app.spotifyImport!=job)return;job.running=false;app.busy=false;app.status="";job.pool.shutdown();SpotifyProgress.persist(app,job);if(job.restartWhenStopped&&!app.taskDismissed&&!app.backgroundIdle){job.restartWhenStopped=false;match(app,job);return;}if(job.wanted!=null&&!job.wanted.attempted&&!job.todo.isEmpty()&&!job.cancelled&&!job.searchBlocked&&!app.backgroundIdle){match(app,job);return;}if(job.paused&&!app.backgroundIdle&&!job.cancelled&&!app.taskDismissed&&job.pending()>0){match(app,job);return;}if(job.pending()>0&&!job.paused&&!job.cancelled)job.error=job.searchBlocked?"YouTube has paused search requests. Try again later. Your remaining songs have not been skipped.":"YouTube search was interrupted. Retry to finish importing; these songs have not been counted as skipped.";complete(app,job);app.changed();app.idleIfNoWork();});}};
        job.pool.execute(work);
    }
    private static Track resolveSong(SkiplineApp app,Job job,Row row)throws Exception{
        SpotifyPlaylist.Song song=row.song;
        Track cached=SpotifyMatchCache.get(app,song);if(cached!=null)return cached;
        Track found=SpotifyMatching.find(song,q->{String id="spotify-search-"+java.util.UUID.randomUUID();job.processes.add(id);try{if(!awaitPlayback(app,job)||yieldsToRequested(job,row))throw new CancellationException();if(!job.fastUnavailable)try{try{ArrayList<Track> catalog=q.endsWith("official audio")?RecordingSearch.search(q,job.client):new ArrayList<>();if(!catalog.isEmpty())return catalog;}catch(YouTubeMetadata.SearchBlockedException blocked){throw blocked;}catch(Exception missingCatalog){/* Fall back to the existing public search, never to view-count probes. */}return YouTubeMetadata.fastMatch(q,job.client);}catch(YouTubeMetadata.SearchBlockedException blocked){throw blocked;}catch(Exception unavailable){if(!awaitPlayback(app,job)||yieldsToRequested(job,row))throw new CancellationException();job.fastUnavailable=true;}return Extractor.searchForImport(app,q,id,()->!job.cancelled&&!job.searchBlocked&&!app.taskDismissed&&!app.backgroundIdle&&!yieldsToRequested(job,row));}finally{job.processes.remove(id);}},()->awaitPlayback(app,job)&&!yieldsToRequested(job,row));
        if(found!=null&&!job.cancelled&&!app.taskDismissed)SpotifyMatchCache.put(app,song,found);return found;
    }
    // Metadata requests yield to a user-started song; never block the playback loader.
    static boolean awaitPlayback(SkiplineApp app,Job job){
        while(app.playbackBuffering&&!job.cancelled&&!job.searchBlocked&&!app.taskDismissed&&!app.backgroundIdle){
            try{Thread.sleep(100);}catch(InterruptedException interrupted){Thread.currentThread().interrupt();return false;}
        }
        if(app.backgroundIdle)job.paused=true;
        return !job.cancelled&&!job.searchBlocked&&!app.taskDismissed&&!app.backgroundIdle;
    }
    private static synchronized void notifyProgress(SkiplineApp app,Job job){long now=android.os.SystemClock.elapsedRealtime();if(now-job.lastNotify<600)return;job.lastNotify=now;app.main.post(()->{if(app.spotifyImport==job&&job.running&&!app.taskDismissed){if(job.target!=null)SpotifyProgress.persist(app,job);else for(Runnable listener:new ArrayList<>(app.listeners))listener.run();}});}
    static void cancel(SkiplineApp app){Job job=app.spotifyImport;if(job!=null)job.cancel();}
    static void clearPlayRequest(SkiplineApp app){Job job=app.spotifyImport;if(job!=null){job.wanted=null;job.restartWhenStopped=false;}}
    static boolean yieldsToRequested(Job job,Row row){Row wanted=job.wanted;return wanted!=null&&wanted!=row&&wanted.match==null&&wanted.error.isEmpty();}
    static void prioritize(Job job,Row wanted){wanted.error="";job.wanted=wanted;if(wanted.match==null)wanted.attempted=false;job.todo.clear();int start=job.rows.indexOf(wanted);if(start<0)return;for(int i=0;i<job.rows.size();i++){Row row=job.rows.get((start+i)%job.rows.size());if(row!=job.current&&!row.attempted&&!row.skipped)job.todo.add(row);}}
    static boolean restorePlaylist(MainActivity a,SavedPlaylist saved,boolean start){
        Job job=a.app.spotifyImport;if(job!=null&&job.target==saved){if(start&&!job.running&&!a.app.busy){if(job.pending()==0)for(Row row:job.rows)if(row.match==null&&!row.skipped)row.attempted=false;match(a.app,job);}return true;}
        if(saved.spotifyDraft==null)return false;if(a.app.busy)return false;job=SpotifyProgress.restore(saved,a.app.profiles.active);if(job==null)return false;a.app.spotifyImport=job;if(start)match(a.app,job);return true;
    }
    static void resumeForeground(SkiplineApp app){Job job=app.spotifyImport;if(job!=null&&job.paused&&!job.running&&!job.cancelled&&!app.busy&&job.profile.equals(app.profiles.active))match(app,job);}
    static void complete(SkiplineApp app,Job job){
        if(app.spotifyImport!=job||job.running||job.loading||job.cancelled||app.taskDismissed||job.pending()>0||job.data==null||job.saved!=null||!job.profile.equals(app.profiles.active))return;
        if(job.target!=null&&!app.library.contains(job.target))return;
        SavedPlaylist list=job.target==null?new SavedPlaylist(job.data.name):job.target;HashSet<String> sources=new HashSet<>();ArrayList<Track> ready=new ArrayList<>();
        for(Row row:job.rows)if(!row.skipped&&row.match!=null&&sources.add(row.match.source)){Track existing=null;for(Track track:list.tracks)if(track.source.equals(row.match.source)){existing=track;break;}ready.add(existing==null?row.match.copy():existing);}
        if(ready.isEmpty()){job.error=job.target==null?"No reliable matches were found. Your Library is unchanged. Try again later.":"No reliable matches were found. Tap Continue import to retry.";return;}
        int imported=ready.size();for(Track extra:list.tracks)if(sources.add(extra.source))ready.add(extra);list.tracks.clear();list.tracks.addAll(ready);list.spotifyDraft=null;
        if(job.target==null)app.library.add(list);job.saved=list;
        int removed=0;for(Row row:job.rows)if(row.skipped)removed++;int skipped=job.rows.size()-imported-removed+job.data.skipped;job.importedCount=imported;job.skippedCount=skipped;
        job.summary="Imported "+imported+" songs"+(skipped>0?" · "+skipped+" unmatched or duplicate entries skipped":"")+".";
        if(!job.data.complete())job.summary+=job.data.total>=0?" Spotify exposed "+job.rows.size()+" of "+job.data.total+" items.":" Spotify’s full playlist size could not be verified.";
        app.saveLibrary();
    }
    static void openCompleted(MainActivity a){
        Job job=a.app.spotifyImport;if(job==null||!job.profile.equals(a.app.profiles.active))return;
        if(job.target!=null&&(job.openTarget||a.page.equals("spotify-import"))){job.openTarget=false;a.selectedPlaylist=job.target;a.mainTab="library";a.page="library";a.visibleTracks=100;}
        if(job.wanted!=null&&(job.wanted.attempted||!job.wanted.error.isEmpty())&&job.wanted.match==null){job.wanted=null;a.root.post(()->{if(!a.isDestroyed())Snackbar.make(a.root,"No playable recording was found for that song. You can tap it to retry.",Snackbar.LENGTH_LONG).show();});}
        if(job.wanted!=null&&job.wanted.match!=null&&job.target!=null&&!job.cancelled){String source=job.wanted.match.source;for(int i=0;i<job.target.tracks.size();i++)if(job.target.tracks.get(i).source.equals(source)){job.wanted=null;a.playPlaylistAt(job.target,i);break;}}
        if(job.saved==null)return;
        if(a.page.equals("spotify-import")){a.selectedPlaylist=job.saved;a.mainTab="library";a.page="library";a.visibleTracks=100;}a.app.spotifyImport=null;
        if(job.skippedCount>0)a.root.post(()->{
            if(a.isDestroyed()||a.isFinishing())return;
            String message="Songs imported: "+job.importedCount+"\nSongs skipped: "+job.skippedCount;
            if(!job.data.complete())message+=job.data.total>=0?"\n\nSpotify exposed "+job.rows.size()+" of "+job.data.total+" items.":"\n\nSpotify's full playlist size could not be verified.";
            new com.google.android.material.dialog.MaterialAlertDialogBuilder(a).setTitle("Playlist imported").setMessage(message).setCancelable(false).setPositiveButton("OK",null).show();
        });
        if(!job.saved.tracks.isEmpty())a.app.warmStream(job.saved.tracks.get(0));
    }
    static void render(MainActivity a,LinearLayout body){
        ListeningFeatures.top(a,body,"Spotify import");Job job=a.app.spotifyImport;
        if(job==null||!job.profile.equals(a.app.profiles.active)){body.addView(a.text("Import a public Spotify playlist link.",15,MainActivity.MUTED,false));a.gap(body,20);body.addView(a.button("Import Spotify playlist",R.drawable.ic_link,true,()->showLink(a,null)),a.lp(-1,52));return;}
        if(job.loading){body.addView(a.text("Reading playlist…",22,MainActivity.INK,true));a.gap(body,20);body.addView(a.button("Cancel import",R.drawable.ic_close,false,job::cancel),a.lp(-1,48));return;}
        if(!job.error.isEmpty()){body.addView(a.text(job.error,15,MainActivity.INK,false));a.gap(body,18);body.addView(a.button(job.data!=null?"Retry import":"Try another link",R.drawable.ic_retry,false,()->{if(job.data!=null)match(a.app,job);else showLink(a,null);}),a.lp(-1,52));return;}
        if(job.data==null)return;body.addView(a.text(job.data.name,27,MainActivity.INK,true));a.gap(body,10);
        body.addView(a.text(job.rows.size()+" available"+(job.data.total>=0?" out of "+job.data.total+" items":" · total unverified"),15,MainActivity.ACCENT,true));a.gap(body,12);
        if(!job.data.complete()){body.addView(a.text("Spotify may expose only part of this playlist. We’ll import the available songs.",14,MainActivity.MUTED,false));a.gap(body,18);}
        body.addView(a.text(job.matched()+" matched · "+job.pending()+" remaining",18,MainActivity.INK,true));a.gap(body,12);
        if(job.running){ProgressBar progress=new ProgressBar(a,null,android.R.attr.progressBarStyleHorizontal);progress.setMax(job.rows.size());progress.setProgress(job.rows.size()-job.pending());progress.setProgressTintList(android.content.res.ColorStateList.valueOf(MainActivity.ACCENT));body.addView(progress,a.lp(-1,12));a.gap(body,14);body.addView(a.button(job.cancelled?"Stopping…":"Cancel import",R.drawable.ic_close,false,job::cancel),a.lp(-1,48));}
        else if(job.pending()>0){body.addView(a.button("Continue import",R.drawable.ic_arrow,true,()->match(a.app,job)),a.lp(-1,52));}
        else if(job.cancelled){body.addView(a.text("Import cancelled. Your Library is unchanged.",14,MainActivity.MUTED,false));}
        a.gap(body,18);body.addView(a.text("Your playlist opens automatically when matching finishes. Songs without a reliable match are skipped. Keep Syntix open to finish importing.",13,MainActivity.MUTED,false));
    }
}
