package app.skipline.android;

import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.widget.*;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.snackbar.Snackbar;

@androidx.annotation.OptIn(markerClass = androidx.media3.common.util.UnstableApi.class)
final class OfflineScreens {
    static void playlist(MainActivity a,SavedPlaylist list){
        if(list.spotifyDraft!=null){Snackbar.make(a.root,"Finish matching this playlist before downloading it. Ready songs can be downloaded individually.",Snackbar.LENGTH_LONG).show();return;}
        if(list.tracks.isEmpty()){Snackbar.make(a.root,"Add songs before downloading a playlist",Snackbar.LENGTH_LONG).show();return;}
        manage(a,list);
    }
    static void song(MainActivity a,Track track){
        if(a.app.offline.file(track.source)!=null){Snackbar.make(a.root,"Already available offline",Snackbar.LENGTH_SHORT).show();return;}
        a.app.offline.enqueue(java.util.Collections.singletonList(track));start(a);
        Snackbar.make(a.root,a.app.offlineRunning?"Downloading for offline listening":"Added to offline downloads",Snackbar.LENGTH_LONG).show();
    }
    static void start(MainActivity a){
        if(a.app.offlineRunning)return;
        if(a.app.offlineClearing||a.app.manualDownloadRunning){Snackbar.make(a.root,"Wait for the current file operation to finish",Snackbar.LENGTH_LONG).show();return;}
        if(a.app.offline.remaining()==0){Snackbar.make(a.root,"No songs waiting to download",Snackbar.LENGTH_LONG).show();return;}
        a.requestNotifications();a.app.offlineRunning=true;a.app.offlineProgress="Starting offline downloads…";
        try{a.startForegroundService(new Intent(a,OfflineDownloadService.class).putExtra("profile",a.app.profiles.active));a.app.changed();}
        catch(RuntimeException e){a.app.offlineRunning=false;a.app.offline.message("Android could not start downloads. Keep Syntix open and try again.");Snackbar.make(a.root,a.app.offline.message(),Snackbar.LENGTH_LONG).show();}
    }
    static void manage(MainActivity a){manage(a,null);}
    static void manage(MainActivity a,SavedPlaylist playlist){
        final OfflineStore store=a.app.offline;
        LinearLayout body=a.column();a.handle(body);
        body.addView(a.text(playlist==null?"Offline downloads":playlist.name,27,MainActivity.INK,true));a.gap(body,20);
        TextView status=a.text("",15,MainActivity.INK,false);body.addView(status);a.gap(body,10);
        CheckBox wifi=new CheckBox(a);wifi.setText("Download on Wi-Fi only");wifi.setTextColor(MainActivity.INK);wifi.setChecked(store.wifiOnly());
        wifi.setOnCheckedChangeListener((b,checked)->{store.wifiOnly(checked);if(a.app.offlineRunning)a.startService(new Intent(a,OfflineDownloadService.class).setAction("check_network"));});
        body.addView(wifi,a.lp(-1,52));a.gap(body,12);
        MaterialButton toggle=a.button("Start download",R.drawable.ic_download,true,()->{
            if(a.app.offlineRunning&&(playlist==null||store.pendingFor(playlist.tracks)>0))a.startService(new Intent(a,OfflineDownloadService.class).setAction("pause"));
            else {if(playlist!=null)store.enqueue(playlist.tracks);start(a);}
        });body.addView(toggle,a.lp(-1,52));a.gap(body,10);
        body.addView(a.button("Remove downloaded audio",R.drawable.ic_close,false,()->{
            if(a.app.offlineRunning||a.app.offlineClearing){Snackbar.make(a.root,"Pause downloads before removing files",Snackbar.LENGTH_LONG).show();return;}
            new MaterialAlertDialogBuilder(a).setTitle("Remove downloaded audio?").setMessage("This removes offline audio and partial downloads for this profile. Saved playlists and Favorites stay in your library.")
                .setPositiveButton("Remove audio",(d,w)->{
                    if(a.app.offlineRunning||a.app.offlineClearing)return;
                    a.app.offlineClearing=true;
                    if(a.app.playback!=null){a.app.playback.player.pause();a.app.playback.player.stop();}
                    a.app.worker.execute(()->{try{store.clear();store.message("Downloaded audio removed.");}catch(Exception e){store.message(e.getMessage());}
                        finally{a.app.main.post(()->{a.app.offlineClearing=false;for(Runnable r:new java.util.ArrayList<>(a.app.listeners))r.run();});}});
                }).setNegativeButton("Cancel",null).show();
        }),a.lp(-1,48));
        a.gap(body,18);body.addView(a.text("Downloads continue while you use other apps. Close Syntix from Recents to stop them.",13,MainActivity.MUTED,false));
        BottomSheetDialog dialog=a.sheet(body);Handler clock=new Handler(Looper.getMainLooper());
        java.util.concurrent.atomic.AtomicBoolean reading=new java.util.concurrent.atomic.AtomicBoolean();
        java.util.concurrent.atomic.AtomicInteger ready=new java.util.concurrent.atomic.AtomicInteger();
        java.util.concurrent.atomic.AtomicLong usage=new java.util.concurrent.atomic.AtomicLong();
        Runnable tick=new Runnable(){public void run(){
            if(!dialog.isShowing())return;
            if(reading.compareAndSet(false,true))a.app.worker.execute(()->{try{ready.set(playlist==null?store.count():store.ready(playlist.tracks));usage.set(playlist==null?store.bytes():store.bytesFor(playlist.tracks));}finally{reading.set(false);}});
            int waiting=playlist==null?store.remaining():store.pendingFor(playlist.tracks);
            boolean active=a.app.offlineRunning&&(playlist==null||waiting>0);
            boolean complete=playlist!=null&&ready.get()==playlist.tracks.size();
            boolean started=waiting>0||playlist!=null&&ready.get()>0;
            toggle.setText(active?"Pause download":complete?"Downloaded":started?"Continue download":"Start download");
            toggle.setIconResource(active?R.drawable.ic_pause:complete?R.drawable.ic_check:R.drawable.ic_download);
            toggle.setEnabled(active||!complete&&(playlist!=null||store.remaining()>0));
            String note=playlist==null?(active?a.app.offlineProgress:store.message()):complete?"Available offline":active?"Current download: "+a.app.offlineProgress:started?"Downloads paused":"Ready to download";
            status.setText(ready.get()+" songs saved · "+android.text.format.Formatter.formatFileSize(a,usage.get())+"\n"+waiting+" waiting\n\n"+note);
            clock.postDelayed(this,750);
        }};clock.post(tick);dialog.setOnDismissListener(d->clock.removeCallbacks(tick));
    }
}
