package app.skipline.android;

import android.view.*;
import android.widget.*;
import android.text.TextUtils;
import androidx.recyclerview.widget.*;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.button.MaterialButton;
import java.util.*;
import java.util.concurrent.*;

@androidx.media3.common.util.UnstableApi
final class RecommendationGrid {
    private static final ExecutorService WORK=new ThreadPoolExecutor(1,1,0,TimeUnit.MILLISECONDS,new ArrayBlockingQueue<>(1),r->{Thread t=new Thread(r,"syntix-add-recommendations");t.setPriority(Thread.MIN_PRIORITY);return t;},new ThreadPoolExecutor.DiscardOldestPolicy());
    static void show(MainActivity a,SavedPlaylist saved){show(a,saved,new SongRecommendations.Cursor(saved,a.app.history.recent()));}
    static void show(MainActivity a,SavedPlaylist saved,SongRecommendations.Cursor cursor){
        LinearLayout body=a.column();a.handle(body);body.addView(a.text("Add songs",26,MainActivity.INK,true));a.gap(body,8);TextView name=a.text(saved.name,14,MainActivity.MUTED,false);name.setMaxLines(2);name.setEllipsize(TextUtils.TruncateAt.END);body.addView(name);a.gap(body,16);BottomSheetDialog[] dialog=new BottomSheetDialog[1];
        body.addView(a.button("YouTube or Spotify link",R.drawable.ic_link,false,()->{dialog[0].dismiss();PlaylistAddSongs.link(a,saved);}),a.lp(-1,52));a.gap(body,20);TextView heading=a.text("Recommended",22,MainActivity.INK,true);androidx.core.view.ViewCompat.setAccessibilityHeading(heading,true);body.addView(heading);a.gap(body,12);
        RecyclerView grid=new RecyclerView(a);grid.setTag("recommended_song_grid");grid.setVerticalScrollBarEnabled(false);GridLayoutManager layout=new GridLayoutManager(a,2);grid.setLayoutManager(layout);grid.setItemAnimator(null);grid.setClipToPadding(false);body.addView(grid,a.lp(-1,Math.max(250,Math.min(420,(int)(a.getResources().getDisplayMetrics().heightPixels/a.getResources().getDisplayMetrics().density*.46f)))));TextView status=a.text("Finding songs…",13,MainActivity.MUTED,false);status.setPadding(0,a.dp(10),0,0);body.addView(status);Session session=new Session(a,saved,cursor,grid,layout,status);grid.setAdapter(session.adapter);grid.addOnScrollListener(new RecyclerView.OnScrollListener(){public void onScrolled(RecyclerView v,int dx,int dy){if(layout.findLastVisibleItemPosition()>=session.items.size()-6)session.load();}});
        dialog[0]=a.sheet(body);BottomSheetDialog opened=dialog[0];opened.setOnDismissListener(d->{a.activeSheets.remove(opened);session.close();});session.load();
    }
    static final class Session {
        final MainActivity a;final SavedPlaylist saved;final SongRecommendations.Cursor cursor;final RecyclerView grid;final GridLayoutManager layout;final TextView status;final String profile;final ArrayList<Track> items=new ArrayList<>();final Cards adapter;boolean loading,closed;int emptyPages;final Runnable retry=this::load;
        Session(MainActivity a,SavedPlaylist saved,SongRecommendations.Cursor cursor,RecyclerView grid,GridLayoutManager layout,TextView status){this.a=a;this.saved=saved;this.cursor=cursor;this.grid=grid;this.layout=layout;this.status=status;profile=a.app.profiles.active;adapter=new Cards(this);}
        boolean active(){return !closed&&!a.isDestroyed()&&!a.app.taskDismissed&&profile.equals(a.app.profiles.active);}
        void load(){if(!active()||loading||!cursor.hasMore())return;if(a.app.playbackBuffering){a.handler.removeCallbacks(retry);a.handler.postDelayed(retry,1000);return;}loading=true;status.setText("Finding songs…");status.setOnClickListener(null);
            WORK.execute(()->{try{ArrayList<Track> page=cursor.next();a.app.main.post(()->{if(!active())return;loading=false;int first=items.size();for(Track track:page)if(!contains(saved,track))items.add(track);adapter.notifyItemRangeInserted(first,items.size()-first);if(items.size()==first)emptyPages++;else emptyPages=0;status.setText(cursor.hasMore()?"":items.isEmpty()?"No recommendations available right now.":"You're caught up for now.");if(cursor.hasMore()&&emptyPages<4&&(items.isEmpty()||!grid.canScrollVertically(1)))grid.post(this::load);else if(emptyPages>=4){status.setText("No more suggestions right now. Tap to try again.");status.setOnClickListener(v->{emptyPages=0;load();});}});}catch(Exception error){a.app.main.post(()->{if(!active())return;loading=false;status.setText("Couldn't load songs. Tap to try again.");status.setOnClickListener(v->load());});}});
        }
        void close(){closed=true;cursor.close();a.handler.removeCallbacks(retry);}
    }
    private static boolean contains(SavedPlaylist saved,Track t){for(Track existing:saved.tracks)if(existing.source.equals(t.source))return true;return false;}
    static final class Holder extends RecyclerView.ViewHolder {final ImageView art;final TextView title,creator;final MaterialButton add;Holder(MainActivity a){super(a.column());LinearLayout card=(LinearLayout)itemView;card.setPadding(a.dp(4),0,a.dp(4),a.dp(16));art=a.art(-1,130,"");card.addView(art);a.gap(card,8);LinearLayout row=a.row();title=a.text("",14,MainActivity.INK,true);title.setMaxLines(2);title.setEllipsize(TextUtils.TruncateAt.END);row.addView(title,new LinearLayout.LayoutParams(0,a.dp(42),1));add=a.icon(R.drawable.ic_plus,"Add song",()->{});row.addView(add,a.lp(44,48));card.addView(row);creator=a.text("",12,MainActivity.MUTED,false);creator.setSingleLine();creator.setEllipsize(TextUtils.TruncateAt.END);card.addView(creator);}}
    static final class Cards extends RecyclerView.Adapter<Holder> {
        final Session session;Cards(Session s){session=s;}
        public Holder onCreateViewHolder(ViewGroup parent,int type){return new Holder(session.a);}
        public int getItemCount(){return session.items.size();}
        public void onBindViewHolder(Holder h,int position){Track track=session.items.get(position);Images.load(h.art,track.thumbnail);h.title.setText(track.title);h.creator.setText(track.creator);boolean added=contains(session.saved,track);h.add.setEnabled(!added);h.add.setIconResource(added?R.drawable.ic_check:R.drawable.ic_plus);h.add.setContentDescription(added?"Already added":"Add "+track.title);h.add.setOnClickListener(v->{if(!session.active())return;if(session.saved==session.a.app.favorites){if(!session.a.app.isFavorite(track))session.a.app.toggleFavorite(track);}else{session.saved.add(Collections.singletonList(track));session.a.app.saveLibrary();}session.cursor.exclude(track.source);int index=h.getBindingAdapterPosition();if(index!=RecyclerView.NO_POSITION)notifyItemChanged(index);});}
    }
}
