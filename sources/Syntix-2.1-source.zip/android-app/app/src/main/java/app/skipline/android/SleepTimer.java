package app.skipline.android;

import android.os.SystemClock;
import androidx.media3.common.Player;

/** Owned by the existing playback service: survives Activity recreation and screen lock. */
@androidx.media3.common.util.UnstableApi
final class SleepTimer {
    private final PlaybackService service;
    private final android.os.Handler handler=new android.os.Handler(android.os.Looper.getMainLooper());
    long deadline,wallDeadline;boolean endSong,fade=true;
    SleepTimer(PlaybackService owner){service=owner;}
    private final Runnable tick=new Runnable(){public void run(){if(!active())return;if(remaining()==0){finish();return;}service.updateVolume();handler.postDelayed(this,1000);}};
    void start(int minutes,boolean end,boolean gentle){if(!end&&(minutes<1||minutes>1439))throw new IllegalArgumentException("Choose between 1 minute and 23 hours 59 minutes");cancel();service.timerFinished=false;fade=gentle;endSong=end;if(!end)deadline=SystemClock.elapsedRealtime()+minutes*60000L;handler.post(tick);}
    void startAt(int hour,int minute,boolean gentle){long target=SleepSchedule.next(System.currentTimeMillis(),java.time.ZoneId.systemDefault(),hour,minute);cancel();service.timerFinished=false;fade=gentle;wallDeadline=target;handler.post(tick);}
    void cancel(){handler.removeCallbacks(tick);deadline=0;wallDeadline=0;endSong=false;service.updateVolume();}
    boolean active(){return deadline>0||wallDeadline>0||endSong;}
    long remaining(){if(endSong)return Long.MAX_VALUE;return Math.max(0,wallDeadline>0?wallDeadline-System.currentTimeMillis():deadline-SystemClock.elapsedRealtime());}
    float multiplier(){if(!fade||!active())return 1;if(endSong){long duration=service.player.getDuration();if(duration<=0)return 1;return Math.min(1,Math.max(0,(duration-service.player.getCurrentPosition())/30000f));}return Math.min(1,remaining()/30000f);}
    void transition(int reason){if(endSong&&(reason==Player.MEDIA_ITEM_TRANSITION_REASON_AUTO||reason==Player.MEDIA_ITEM_TRANSITION_REASON_REPEAT))finish();}
    void playbackState(int state){if(endSong&&state==Player.STATE_ENDED)finish();}
    private void finish(){service.player.pause();cancel();service.timerFinished=true;service.appChanged();}
    void close(){handler.removeCallbacksAndMessages(null);}
}
