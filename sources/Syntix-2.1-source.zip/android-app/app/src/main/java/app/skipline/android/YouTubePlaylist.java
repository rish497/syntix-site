package app.skipline.android;

import java.io.IOException;
import java.util.*;
import java.util.concurrent.TimeUnit;
import okhttp3.*;
import org.json.*;

/** Paged public playlist metadata without interpreter startup or per-video extraction. */
final class YouTubePlaylist {
    private static final OkHttpClient CLIENT=new OkHttpClient.Builder().connectTimeout(3,TimeUnit.SECONDS).readTimeout(5,TimeUnit.SECONDS).callTimeout(7,TimeUnit.SECONDS).build();
    static void cancel(){CLIENT.dispatcher().cancelAll();}
    static ArrayList<Track> read(String source,java.util.function.BooleanSupplier active)throws Exception{return read(source,CLIENT,active);}
    static ArrayList<Track> read(String source,OkHttpClient client,java.util.function.BooleanSupplier active)throws Exception{
        String list=HttpUrl.get(Links.extract(source)).queryParameter("list");if(list==null||!list.matches("[A-Za-z0-9_-]{2,200}")||list.startsWith("RD")&&!list.startsWith("RDCL"))throw new IOException("Use the extraction engine for this Mix snapshot");
        JSONObject context=new JSONObject().put("client",new JSONObject().put("clientName","WEB").put("clientVersion","2.20260708.00.00").put("hl","en"));
        LinkedHashMap<String,Track> tracks=new LinkedHashMap<>();Set<String> continuations=new HashSet<>();String next="";
        do{
            if(!active.getAsBoolean())throw new java.util.concurrent.CancellationException();
            JSONObject body=new JSONObject().put("context",context);if(next.isEmpty())body.put("browseId","VL"+list);else body.put("continuation",next);
            Request request=new Request.Builder().url("https://www.youtube.com/youtubei/v1/browse?prettyPrint=false").post(RequestBody.create(body.toString(),MediaType.get("application/json"))).build();
            JSONObject response;
            try(Response page=client.newCall(request).execute()){if(!page.isSuccessful()||page.body()==null)throw new IOException("Public playlist metadata unavailable");response=new JSONObject(YouTubeMetadata.readBounded(page.body().byteStream()));}
            YouTubeSession.observe(response);Object scope=response.opt("contents");if(scope==null)scope=response.opt("onResponseReceivedActions");if(scope==null)scope=response.opt("onResponseReceivedEndpoints");if(scope==null)scope=response;append(scope,tracks,0);next=continuation(scope,0);
            if(!next.isEmpty()&&!continuations.add(next))throw new IOException("Playlist pagination repeated; retry using the extraction engine");
        }while(!next.isEmpty());
        if(!active.getAsBoolean())throw new java.util.concurrent.CancellationException();if(tracks.isEmpty())throw new IOException("No public playlist videos available");return new ArrayList<>(tracks.values());
    }
    static ArrayList<Track> parse(JSONObject json){LinkedHashMap<String,Track> out=new LinkedHashMap<>();append(json,out,0);return new ArrayList<>(out.values());}
    private static void append(Object value,LinkedHashMap<String,Track> out,int depth){
        if(depth>65)return;if(value instanceof JSONObject){JSONObject node=(JSONObject)value,item=node.optJSONObject("playlistVideoRenderer");JSONObject lock=node.optJSONObject("lockupViewModel");if(lock!=null){Track track=YouTubeMetadata.lockup(lock);if(track!=null)out.putIfAbsent(HttpUrl.get(track.source).queryParameter("v"),track);}
            if(item!=null){String id=item.optString("videoId"),title=text(item.optJSONObject("title")),author=text(item.optJSONObject("shortBylineText"));
                if(id.matches("[A-Za-z0-9_-]{11}")&&!title.isEmpty()&&!title.equals("[Private video]")&&!title.equals("[Deleted video]")&&item.optBoolean("isPlayable",true)){
                    long seconds=item.optLong("lengthSeconds");if(seconds<=0)try{for(String part:text(item.optJSONObject("lengthText")).split(":"))seconds=seconds*60+Long.parseLong(part);}catch(NumberFormatException ignored){}
                    out.putIfAbsent(id,new Track("https://www.youtube.com/watch?v="+id,title,author,"https://i.ytimg.com/vi/"+id+"/hqdefault.jpg",seconds));
                }}
            Iterator<String> keys=node.keys();while(keys.hasNext())append(node.opt(keys.next()),out,depth+1);
        }else if(value instanceof JSONArray){JSONArray a=(JSONArray)value;for(int i=0;i<a.length();i++)append(a.opt(i),out,depth+1);}
    }
    private static String text(JSONObject node){if(node==null)return "";StringBuilder out=new StringBuilder(node.optString("simpleText"));JSONArray runs=node.optJSONArray("runs");if(out.length()==0)for(int i=0;runs!=null&&i<runs.length();i++)out.append(runs.optJSONObject(i)==null?"":runs.optJSONObject(i).optString("text"));return out.toString();}
    private static String continuation(Object value,int depth){if(depth>65)return "";if(value instanceof JSONObject){JSONObject node=(JSONObject)value,command=node.optJSONObject("continuationCommand");if(command!=null&&!command.optString("token").isEmpty())return command.optString("token");Iterator<String> keys=node.keys();while(keys.hasNext()){String token=continuation(node.opt(keys.next()),depth+1);if(!token.isEmpty())return token;}}else if(value instanceof JSONArray){JSONArray array=(JSONArray)value;for(int i=0;i<array.length();i++){String token=continuation(array.opt(i),depth+1);if(!token.isEmpty())return token;}}return "";}
}
