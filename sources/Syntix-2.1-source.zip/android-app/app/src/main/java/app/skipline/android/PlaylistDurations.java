package app.skipline.android;

import java.util.List;

final class PlaylistDurations {
    static String total(List<Track> tracks) {
        long seconds=0;boolean unknown=false;
        for(Track t:tracks)if(t.duration>0)seconds+=t.duration;else unknown=true;
        if(seconds==0)return tracks.isEmpty()?"0 min":"Duration unavailable";
        long minutes=seconds/60;
        String value=minutes>=60?(minutes/60)+" hr "+(minutes%60)+" min":Math.max(1,minutes)+" min";
        return unknown?value+" +":value;
    }
}
