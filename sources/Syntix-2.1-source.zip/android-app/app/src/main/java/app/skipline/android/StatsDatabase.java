package app.skipline.android;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.*;

/** Shared with real Android SQLite regression tests; keeps V7 records in place. */
final class StatsDatabase extends SQLiteOpenHelper {
    StatsDatabase(Context context){super(context,"activity-v7.db",null,1);}
    @Override public void onConfigure(SQLiteDatabase db){super.onConfigure(db);try(Cursor result=db.rawQuery("PRAGMA secure_delete=ON",null)){if(result.moveToFirst())result.getInt(0);}}
    @Override public void onCreate(SQLiteDatabase db){
        db.execSQL("CREATE TABLE usage (profile TEXT,hour INTEGER,listen INTEGER NOT NULL DEFAULT 0,bytes INTEGER NOT NULL DEFAULT 0,drop_pct REAL NOT NULL DEFAULT 0,observed INTEGER NOT NULL DEFAULT 0,PRIMARY KEY(profile,hour))");
        db.execSQL("CREATE TABLE artists (profile TEXT,hour INTEGER,name TEXT,ms INTEGER NOT NULL,PRIMARY KEY(profile,hour,name))");
    }
    @Override public void onUpgrade(SQLiteDatabase db,int oldVersion,int newVersion){}
}
