package app.skipline.android;

import java.time.*;

/** Next local occurrence, including daylight-saving gaps and repeated clock times. */
final class SleepSchedule {
    static long next(long now,ZoneId zone,int hour,int minute){
        if(hour<0||hour>23||minute<0||minute>59)throw new IllegalArgumentException("Choose a valid time");
        LocalDate date=Instant.ofEpochMilli(now).atZone(zone).toLocalDate();
        ZonedDateTime target=date.atTime(hour,minute).atZone(zone);
        if(target.toInstant().toEpochMilli()<=now){ZonedDateTime later=target.withLaterOffsetAtOverlap();target=later.toInstant().toEpochMilli()>now?later:date.plusDays(1).atTime(hour,minute).atZone(zone);}
        return target.toInstant().toEpochMilli();
    }
    static long duration(int hours,int minutes){if(hours<0||hours>23||minutes<0||minutes>59||hours*60+minutes==0)throw new IllegalArgumentException("Choose at least 1 minute");return (hours*60L+minutes)*60000;}
}
