package app.skipline.android;

import java.time.LocalDate;

final class DailyDiscovery {
    static final String[] TAGS={"#headspace","#afterhours","#onrepeat","#slowmornings","#citylights","#goodenergy","#deepfocus","#goldenhour","#latenight","#newperspectives","#weekendmood","#softlanding","#freshfinds","#quietmoments","#nightdrive","#daydreaming","#feelgood","#unwind","#rhythmandflow","#brightdays","#backtothebeat","#chillmode","#offtheclock","#startfresh"};
    static final int[] THEMES={14,13,10,14,12,15,19,10,17,13,10,14,2,19,12,14,10,14,17,10,13,14,14,2};
    static int index(long day,int slot){return Math.floorMod(day*3+slot,TAGS.length);}
    static int today(int slot){return index(LocalDate.now().toEpochDay(),slot);}
}
