package app.skipline.android;

import android.view.*;
import android.widget.*;
import java.util.function.*;

/** Appends a new page in place, keeping artwork and playback controls attached. */
@androidx.media3.common.util.UnstableApi
final class PlaylistPaging {
    static void render(MainActivity a,LinearLayout content,int total,IntConsumer row){
        int initial=Math.min(total,Math.max(100,a.visibleTracks));for(int i=0;i<initial;i++)row.accept(i);int[] shown={initial};
        watch(a,content,()->shown[0]<total,()->{int end=Math.min(total,shown[0]+100);for(int i=shown[0];i<end;i++)row.accept(i);shown[0]=end;a.visibleTracks=end;});
    }
    static void watch(MainActivity a,View anchor,BooleanSupplier more,Runnable append){
        ScrollView scroll=a.bodyScroll;if(scroll==null)return;
        class Watch implements ViewTreeObserver.OnScrollChangedListener,View.OnAttachStateChangeListener,Runnable {
            boolean posted,closed;final String profile=a.app.profiles.active;
            public void onScrollChanged(){if(closed||posted||!anchor.isAttachedToWindow()||!profile.equals(a.app.profiles.active)||!more.getAsBoolean()||scroll.getChildCount()==0||scroll.getHeight()==0)return;if(scroll.getChildAt(0).getHeight()-scroll.getScrollY()-scroll.getHeight()<=a.dp(320)){posted=true;a.handler.post(this);}}
            public void run(){posted=false;if(closed||!anchor.isAttachedToWindow()||!profile.equals(a.app.profiles.active)||!more.getAsBoolean())return;append.run();anchor.post(this::onScrollChanged);}
            public void onViewAttachedToWindow(View v){anchor.post(this::onScrollChanged);}
            public void onViewDetachedFromWindow(View v){closed=true;a.handler.removeCallbacks(this);if(scroll.getViewTreeObserver().isAlive())scroll.getViewTreeObserver().removeOnScrollChangedListener(this);}
        }
        Watch watch=new Watch();scroll.getViewTreeObserver().addOnScrollChangedListener(watch);anchor.addOnAttachStateChangeListener(watch);anchor.post(watch::onScrollChanged);
    }
}
