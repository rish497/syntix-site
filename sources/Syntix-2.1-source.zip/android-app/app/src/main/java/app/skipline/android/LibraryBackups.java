package app.skipline.android;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import org.json.*;

/** Portable playlist metadata only; never exports credentials or media bytes. */
final class LibraryBackups {
    static final String FAVORITES_ID="syntix-favorites";
    static final int MAX_BYTES=8*1024*1024;
    static String snapshot(SkiplineApp app)throws Exception{ArrayList<SavedPlaylist> lists=new ArrayList<>(app.library);SavedPlaylist favorites=new SavedPlaylist("Favorites");favorites.tracks.addAll(app.favorites.tracks);org.json.JSONObject marked=favorites.json().put("id",FAVORITES_ID);lists.add(SavedPlaylist.fromJson(marked));return snapshot(lists);}
    static String snapshot(java.util.List<SavedPlaylist> library)throws Exception{
        JSONArray lists=new JSONArray();for(SavedPlaylist list:library)lists.put(list.json());
        String json=new JSONObject().put("format","syntix-library").put("version",1).put("playlists",lists).toString(2);
        if(json.getBytes(StandardCharsets.UTF_8).length>MAX_BYTES)throw new IOException("This library is too large for a backup.");return json;
    }
    static ArrayList<SavedPlaylist> read(InputStream input)throws Exception{
        if(input==null)throw new IOException("Could not open this backup.");
        ByteArrayOutputStream bytes=new ByteArrayOutputStream();byte[] buffer=new byte[16384];int n;
        while((n=input.read(buffer))!=-1){if(bytes.size()+n>MAX_BYTES)throw new IOException("Backup must be smaller than 8 MB.");bytes.write(buffer,0,n);}
        JSONObject root=new JSONObject(bytes.toString("UTF-8"));
        if(!java.util.Arrays.asList("skipline-library","syntix-library").contains(root.optString("format"))||root.optInt("version")!=1)throw new IOException("Choose a Syntix playlist backup.");
        JSONArray lists=root.getJSONArray("playlists");if(lists.length()>2000)throw new IOException("Too many playlists in this backup.");
        ArrayList<SavedPlaylist> result=new ArrayList<>();int count=0;
        for(int i=0;i<lists.length();i++){
            JSONObject entry=lists.getJSONObject(i);String name=entry.getString("name").trim();if(name.isEmpty()||name.length()>60)throw new IOException("A playlist name is invalid.");
            SavedPlaylist list=FAVORITES_ID.equals(entry.optString("id"))?SavedPlaylist.fromJson(new JSONObject().put("id",FAVORITES_ID).put("name","Favorites").put("tracks",new JSONArray())):new SavedPlaylist(name);JSONArray tracks=entry.getJSONArray("tracks");
            for(int j=0;j<tracks.length();j++){
                if(++count>20000)throw new IOException("Too many songs in this backup.");JSONObject track=tracks.getJSONObject(j);String source=track.getString("source");
                // File grants do not survive uninstall. Keep their labels so users can reselect them.
                if(source.startsWith("content://")){if(source.length()>4096)throw new IOException("Invalid local audio link.");}
                else if(source.startsWith("android.resource://app.skipline.android/"))source="android.resource://app.skipline.android/"+R.raw.playback_sample;
                else if(!source.startsWith("https://")||!source.equals(Links.extract(source))||!Links.isMediaLink(source))throw new IOException("A song has an unsupported link.");
                String title=track.optString("title","Untitled"),creator=track.optString("creator","");if(title.length()>1000||creator.length()>1000)throw new IOException("Invalid song details.");
                String thumbnail=track.optString("thumbnail","");android.net.Uri image=android.net.Uri.parse(thumbnail);String host=image.getHost();if(!"https".equals(image.getScheme())||host==null||!(host.equals("ytimg.com")||host.endsWith(".ytimg.com")||host.equals("ggpht.com")||host.endsWith(".ggpht.com")))thumbnail="";
                list.tracks.add(new Track(source,title,creator,thumbnail,Math.max(0,track.optLong("duration"))));
            }
            result.add(list);
        }
        return result;
    }
    static void merge(SkiplineApp app,ArrayList<SavedPlaylist> imported){
        for(SavedPlaylist incoming:imported){if(FAVORITES_ID.equals(incoming.id)){app.favorites.add(incoming.tracks);app.saveFavorites();continue;}SavedPlaylist target=null;for(SavedPlaylist saved:app.library)if(saved.name.equalsIgnoreCase(incoming.name)){target=saved;break;}if(target==null)app.library.add(incoming);else target.add(incoming.tracks);}app.saveLibrary();
    }
}
