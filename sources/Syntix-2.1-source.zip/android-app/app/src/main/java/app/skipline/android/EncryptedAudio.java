package app.skipline.android;

import java.io.*;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.util.Arrays;
import javax.crypto.*;
import javax.crypto.spec.*;

/** Authenticated 64 KiB records permit seeking without a plaintext disk copy. */
final class EncryptedAudio {
    static final int CHUNK=65536, HEADER=88, TAG=16;
    private static final byte[] MAGIC="SYNTIXE1".getBytes(StandardCharsets.US_ASCII);
    private static byte[] metadata(long length,byte[] prefix,String binding){
        byte[] name=binding.getBytes(StandardCharsets.UTF_8);
        return ByteBuffer.allocate(28+name.length).put(MAGIC).putInt(CHUNK).putLong(length).put(prefix).put(name).array();
    }
    private static Cipher cipher(int mode,SecretKey key,byte[] nonce,byte[] aad)throws GeneralSecurityException {
        Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(mode,key,new GCMParameterSpec(128,nonce));cipher.updateAAD(aad);return cipher;
    }
    private static byte[] nonce(byte[] prefix,int chunk){return ByteBuffer.allocate(12).put(prefix).putInt(chunk).array();}
    private static byte[] aad(byte[] metadata,int chunk){return ByteBuffer.allocate(metadata.length+4).put(metadata).putInt(chunk).array();}
    static void write(File source,File destination,SecretKey master,String binding)throws IOException,GeneralSecurityException {
        long length=source.length();if(length<0||length>(1L<<40))throw new IOException("Unsupported offline audio size");
        SecureRandom random=new SecureRandom();byte[] rawKey=new byte[32],prefix=new byte[8];random.nextBytes(rawKey);random.nextBytes(prefix);
        SecretKey fileKey=new SecretKeySpec(rawKey,"AES");Arrays.fill(rawKey,(byte)0);byte[] meta=metadata(length,prefix,binding);
        Cipher wrap=Cipher.getInstance("AES/GCM/NoPadding");wrap.init(Cipher.ENCRYPT_MODE,master);wrap.updateAAD(meta);byte[] wrapped=wrap.doFinal(fileKey.getEncoded()),iv=wrap.getIV();
        if(iv.length!=12||wrapped.length!=48)throw new GeneralSecurityException("Unsupported key wrapping format");
        boolean complete=false;
        try(FileInputStream input=new FileInputStream(source);FileOutputStream bytes=new FileOutputStream(destination);DataOutputStream out=new DataOutputStream(new BufferedOutputStream(bytes))){
            out.write(MAGIC);out.writeInt(CHUNK);out.writeLong(length);out.write(iv);out.write(wrapped);out.write(prefix);
            byte[] block=new byte[CHUNK];long remaining=length;int index=0;
            while(remaining>0){int count=(int)Math.min(CHUNK,remaining);int read=0;while(read<count){int n=input.read(block,read,count-read);if(n<0)throw new EOFException("Offline audio changed during encryption");read+=n;}
                out.write(cipher(Cipher.ENCRYPT_MODE,fileKey,nonce(prefix,index),aad(meta,index)).doFinal(block,0,count));remaining-=count;index++;
            }
            if(input.read()!=-1)throw new IOException("Offline audio changed during encryption");
            out.flush();bytes.getFD().sync();Arrays.fill(block,(byte)0);complete=true;
        }finally{if(!complete)destination.delete();}
    }
    static final class Reader implements Closeable {
        private final RandomAccessFile file;
        final long length;
        private final SecretKey key;
        private final byte[] prefix,meta;
        private byte[] decoded;
        private long decodedChunk=-1;
        Reader(File source,SecretKey master,String binding)throws IOException,GeneralSecurityException {
            file=new RandomAccessFile(source,"r");
            try{
                byte[] magic=new byte[8];file.readFully(magic);if(!Arrays.equals(MAGIC,magic)||file.readInt()!=CHUNK)throw new IOException("Unsupported encrypted audio");
                length=file.readLong();if(length<0||length>(1L<<40))throw new IOException("Invalid encrypted audio length");
                long chunks=(length+CHUNK-1)/CHUNK;if(file.length()!=HEADER+length+chunks*TAG)throw new IOException("Incomplete encrypted audio");
                byte[] iv=new byte[12],wrapped=new byte[48];prefix=new byte[8];file.readFully(iv);file.readFully(wrapped);file.readFully(prefix);meta=metadata(length,prefix,binding);
                byte[] raw=cipher(Cipher.DECRYPT_MODE,master,iv,meta).doFinal(wrapped);try{if(raw.length!=32)throw new GeneralSecurityException("Invalid audio key");key=new SecretKeySpec(raw,"AES");}finally{Arrays.fill(raw,(byte)0);}
            }catch(IOException|GeneralSecurityException|RuntimeException e){file.close();throw e;}
        }
        int read(long position,byte[] output,int offset,int count)throws IOException {
            if(position<0||position>length)throw new IOException("Invalid audio position");if(count==0)return 0;if(position==length)return -1;
            long index=position/CHUNK;
            if(index!=decodedChunk){
                int plain=(int)Math.min(CHUNK,length-index*CHUNK);byte[] encrypted=new byte[plain+TAG];file.seek(HEADER+index*(CHUNK+TAG));file.readFully(encrypted);
                try{byte[] next=cipher(Cipher.DECRYPT_MODE,key,nonce(prefix,(int)index),aad(meta,(int)index)).doFinal(encrypted);if(decoded!=null)Arrays.fill(decoded,(byte)0);decoded=next;decodedChunk=index;}
                catch(GeneralSecurityException e){throw new IOException("Saved audio failed its integrity check. Remove this download and download it again.",e);}
            }
            int from=(int)(position%CHUNK),n=Math.min(count,decoded.length-from);System.arraycopy(decoded,from,output,offset,n);return n;
        }
        public void close()throws IOException{if(decoded!=null)Arrays.fill(decoded,(byte)0);file.close();}
    }
}
