package app.skipline.android;

import android.widget.*;
import android.text.TextUtils;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.textfield.*;
import com.google.android.material.snackbar.Snackbar;
import java.util.*;

@androidx.media3.common.util.UnstableApi
final class PlaylistAddSongs {
    static void show(MainActivity a,SavedPlaylist saved){RecommendationGrid.show(a,saved);}
    static void link(MainActivity a,SavedPlaylist saved){
        LinearLayout body=a.column();a.handle(body);body.addView(a.text("Add to "+saved.name,24,MainActivity.INK,true));a.gap(body,16);TextInputLayout field=new TextInputLayout(a);field.setHint("YouTube or Spotify song link");field.setBoxBackgroundMode(TextInputLayout.BOX_BACKGROUND_OUTLINE);TextInputEditText input=new TextInputEditText(a);input.setTextSize(16);input.setTextColor(MainActivity.INK);input.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_URI);field.addView(input);body.addView(field);a.gap(body,18);BottomSheetDialog[] dialog=new BottomSheetDialog[1];body.addView(a.button("Add songs",R.drawable.ic_plus,true,()->{try{String source=SpotifySong.musicLink(input.getText().toString());dialog[0].dismiss();a.importToPlaylist(source,saved);}catch(Exception e){field.setError(e.getMessage());}}),a.lp(-1,52));dialog[0]=a.sheet(body);
    }
}
