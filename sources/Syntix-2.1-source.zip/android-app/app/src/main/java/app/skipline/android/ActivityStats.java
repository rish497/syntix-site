package app.skipline.android;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import android.net.TrafficStats;
import android.os.*;
import java.util.*;
import java.util.concurrent.*;

/** Real observations only. No migration invents historical listening or battery readings. */
@androidx.media3.common.util.UnstableApi
final class ActivityStats {
    static final long HOUR=3600000L;
    static long cutoff(long now){return StatsTime.cutoff(now,TimeZone.getDefault());}
    static final class Artist {final String name;final long ms;Artist(String n,long m){name=n;ms=m;}}
    static final class Point {long at,listen,bytes,observed;double drop;}
    static final class Report {boolean available=true,networkAvailable=true;final ArrayList<Artist> artists=new ArrayList<>();final ArrayList<Point> points=new ArrayList<>();}
    private final SkiplineApp app;
    private final StatsDatabase database;
    private boolean suspended;
    private final ExecutorService io=Executors.newSingleThreadExecutor(r->{Thread t=new Thread(()->{android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND);r.run();},"syntix-statistics");return t;});
    private final Handler handler=new Handler(Looper.getMainLooper());
    private long lastElapsed=SystemClock.elapsedRealtime(),lastWall=System.currentTimeMillis(),lastBytes=-1;
    private int lastLevel=-1;private boolean lastCharging=true,playing;private String artist="",profile="default";
    private final Runnable tick=new Runnable(){public void run(){sample();handler.postDelayed(this,60000);}};
    ActivityStats(SkiplineApp a){app=a;database=new StatsDatabase(a);profile=a.profiles.active;readBaseline();enqueue(()->prune(getWritableDatabase()));handler.postDelayed(tick,60000);}
    private SQLiteDatabase getWritableDatabase(){return database.getWritableDatabase();}
    private void prune(SQLiteDatabase db){String[] args={Long.toString(cutoff(System.currentTimeMillis()))};db.delete("usage","hour < ?",args);db.delete("artists","hour < ?",args);}
    private long bytes(){long rx=TrafficStats.getUidRxBytes(android.os.Process.myUid()),tx=TrafficStats.getUidTxBytes(android.os.Process.myUid());return rx<0||tx<0?-1:rx+tx;}
    private int[] battery(){Intent i=app.registerReceiver(null,new IntentFilter(Intent.ACTION_BATTERY_CHANGED));if(i==null)return new int[]{-1,1};int level=i.getIntExtra(BatteryManager.EXTRA_LEVEL,-1),scale=i.getIntExtra(BatteryManager.EXTRA_SCALE,100),status=i.getIntExtra(BatteryManager.EXTRA_STATUS,-1);return new int[]{level<0||scale<=0?-1:Math.round(100f*level/scale),status==BatteryManager.BATTERY_STATUS_DISCHARGING||status==BatteryManager.BATTERY_STATUS_NOT_CHARGING?0:1};}
    private void readBaseline(){lastBytes=bytes();int[] b=battery();lastLevel=b[0];lastCharging=b[1]!=0;}
    /** Runs on main, writes on a serial background executor; no extra wake lock/alarm. */
    void sample(){if(suspended)return;long elapsed=SystemClock.elapsedRealtime(),wall=System.currentTimeMillis(),duration=elapsed-lastElapsed;long total=bytes(),network=total>=lastBytes&&lastBytes>=0?total-lastBytes:0;int[] b=battery();boolean observed=playing&&!lastCharging&&b[1]==0&&lastLevel>=0&&b[0]>=0;double drop=observed?Math.max(0,lastLevel-b[0]):0;long listening=playing?duration:0;String owner=profile,name=artist;long start=lastWall;lastElapsed=elapsed;lastWall=wall;lastBytes=total;lastLevel=b[0];lastCharging=b[1]!=0;
        if(duration<=0||duration>6*HOUR||Math.abs(wall-start-duration)>120000)return;
        if(listening==0&&network==0&&!observed)return;
        enqueue(()->{SQLiteDatabase db=getWritableDatabase();db.beginTransaction();try{for(long at=start;at<wall;){long hour=StatsTime.hourStart(at,TimeZone.getDefault()),end=Math.min(wall,hour+HOUR);double fraction=(double)(end-at)/Math.max(1,wall-start);db.execSQL("INSERT OR IGNORE INTO usage(profile,hour) VALUES (?,?)",new Object[]{owner,hour});db.execSQL("UPDATE usage SET listen=listen+?,bytes=bytes+?,drop_pct=drop_pct+?,observed=observed+? WHERE profile=? AND hour=?",new Object[]{Math.round(listening*fraction),Math.round(network*fraction),drop*fraction,observed?Math.round(duration*fraction):0,owner,hour});if(listening>0&&!name.isEmpty()){db.execSQL("INSERT OR IGNORE INTO artists(profile,hour,name,ms) VALUES (?,?,?,0)",new Object[]{owner,hour,name});db.execSQL("UPDATE artists SET ms=ms+? WHERE profile=? AND hour=? AND name=?",new Object[]{Math.round(listening*fraction),owner,hour,name});}at=end;}prune(db);db.setTransactionSuccessful();}finally{db.endTransaction();}});
    }
    void playerEvent(){if(suspended)return;boolean next=app.playback!=null&&app.playback.player.isPlaying();Track t=app.playback==null||app.playback.player.getCurrentMediaItem()==null?null:app.find(app.playback.player.getCurrentMediaItem().mediaId);String who=t==null?"":t.creator;if(who.equals("On this device")||who.equals("YouTube"))who="";
        if(next!=playing||!who.equals(artist)){sample();playing=next;artist=who;}}
    void suspend(){if(suspended)return;sample();playing=false;artist="";suspended=true;handler.removeCallbacks(tick);}
    void resume(){if(!suspended)return;suspended=false;lastElapsed=SystemClock.elapsedRealtime();lastWall=System.currentTimeMillis();readBaseline();handler.postDelayed(tick,60000);}
    void switchProfile(){sample();profile=app.profiles.active;playing=false;artist="";readBaseline();}
    void clear(){sample();String owner=profile;enqueue(()->{SQLiteDatabase db=getWritableDatabase();db.delete("usage","profile=?",new String[]{owner});db.delete("artists","profile=?",new String[]{owner});});}
    private void enqueue(Runnable work){io.execute(()->{try{work.run();}catch(RuntimeException failure){android.util.Log.w("Syntix","Could not save activity statistics",failure);}});}
    void report(java.util.function.Consumer<Report> done){report(0,Long.MAX_VALUE,done);}
    void report(long start,long end,java.util.function.Consumer<Report> done){sample();String owner=profile;boolean networkAvailable=lastBytes>=0;io.execute(()->{Report report=new Report();report.networkAvailable=networkAvailable;try{SQLiteDatabase db=getWritableDatabase();prune(db);try(Cursor c=db.rawQuery("SELECT name,SUM(ms) FROM artists WHERE profile=? AND hour>=? AND hour<? GROUP BY name ORDER BY SUM(ms) DESC",new String[]{owner,Long.toString(start),Long.toString(end)})){while(c.moveToNext())report.artists.add(new Artist(c.getString(0),c.getLong(1)));}try(Cursor c=db.rawQuery("SELECT hour,listen,bytes,drop_pct,observed FROM usage WHERE profile=? AND hour>=? AND hour<? ORDER BY hour",new String[]{owner,Long.toString(start),Long.toString(end)})){while(c.moveToNext()){Point p=new Point();p.at=c.getLong(0);p.listen=c.getLong(1);p.bytes=c.getLong(2);p.drop=c.getDouble(3);p.observed=c.getLong(4);report.points.add(p);}}}catch(RuntimeException failure){android.util.Log.e("Syntix","Statistics database read failed",failure);report.available=false;}app.main.post(()->{if(owner.equals(app.profiles.active))done.accept(report);});});}
}
