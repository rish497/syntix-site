package app.skipline.android;

import java.io.IOException;
import java.util.*;
import okhttp3.*;
import org.json.*;

/** One catalog metadata request, without view-count probes or audio downloads. */
final class RecordingSearch {
    static ArrayList<Track> search(String query,OkHttpClient client)throws Exception{return search(query,client,null);}
    static ArrayList<Track> search(String query,OkHttpClient client,Object tag)throws Exception{
        String version="1."+new java.text.SimpleDateFormat("yyyyMMdd",Locale.US).format(new Date())+".01.00";
        JSONObject body=new JSONObject().put("context",new JSONObject().put("client",new JSONObject().put("clientName","WEB_REMIX").put("clientVersion",version).put("hl","en")))
            .put("query",query.replaceFirst("(?i)\\s+official audio$", "")).put("params","EgWKAQIIAWoMEA4QChADEAQQCRAF");
        Request request=new Request.Builder().url("https://music.youtube.com/youtubei/v1/search?prettyPrint=false").tag(tag)
            .post(RequestBody.create(body.toString(),MediaType.get("application/json; charset=utf-8"))).build();
        try(Response response=client.newCall(request).execute()){
            if(response.code()==403||response.code()==429)throw new YouTubeMetadata.SearchBlockedException();
            if(!response.isSuccessful()||response.body()==null)throw new IOException("Song catalog unavailable");
            return parse(new JSONObject(YouTubeMetadata.readBounded(response.body().byteStream())));
        }
    }
    static ArrayList<Track> parse(JSONObject json){YouTubeSession.observe(json);LinkedHashMap<String,Track> out=new LinkedHashMap<>();walk(json,out,0);return new ArrayList<>(out.values());}
    private static void walk(Object value,LinkedHashMap<String,Track> out,int depth){
        if(depth>65||out.size()>=30)return;
        if(value instanceof JSONObject){JSONObject node=(JSONObject)value;JSONObject item=node.optJSONObject("musicResponsiveListItemRenderer");if(item!=null)add(item,out);
            Iterator<String> keys=node.keys();while(keys.hasNext())walk(node.opt(keys.next()),out,depth+1);
        }else if(value instanceof JSONArray){JSONArray array=(JSONArray)value;for(int i=0;i<array.length();i++)walk(array.opt(i),out,depth+1);}
    }
    private static void add(JSONObject item,LinkedHashMap<String,Track> out){
        JSONObject playlist=item.optJSONObject("playlistItemData");String id=playlist==null?"":playlist.optString("videoId");if(!id.matches("[A-Za-z0-9_-]{11}")||out.containsKey(id))return;
        JSONArray columns=item.optJSONArray("flexColumns");if(columns==null||columns.length()<2)return;
        String title="",album="";LinkedHashSet<String> artists=new LinkedHashSet<>();long duration=0;
        for(int c=0;c<columns.length();c++){
            JSONObject column=columns.optJSONObject(c);column=column==null?null:column.optJSONObject("musicResponsiveListItemFlexColumnRenderer");JSONObject text=column==null?null:column.optJSONObject("text");JSONArray runs=text==null?null:text.optJSONArray("runs");
            for(int i=0;runs!=null&&i<runs.length();i++){
                JSONObject run=runs.optJSONObject(i);if(run==null)continue;String label=run.optString("text");if(c==0){title+=label;continue;}
                JSONObject nav=run.optJSONObject("navigationEndpoint"),browse=nav==null?null:nav.optJSONObject("browseEndpoint");String browseId=browse==null?"":browse.optString("browseId");
                if(browseId.startsWith("UC")||browseId.startsWith("MPLA"))artists.add(label);else if(browseId.startsWith("MPRE"))album=label;
                if(label.matches("\\d+(?::\\d{2}){1,2}")){long seconds=0;for(String part:label.split(":"))seconds=seconds*60+Long.parseLong(part);duration=seconds;}
            }
        }
        if(title.isEmpty()||artists.isEmpty()||duration<=0)return;
        Track track=new Track("https://www.youtube.com/watch?v="+id,title,String.join(", ",artists),"https://i.ytimg.com/vi/"+id+"/hqdefault.jpg",duration,album,true);out.put(id,track);
    }
}
