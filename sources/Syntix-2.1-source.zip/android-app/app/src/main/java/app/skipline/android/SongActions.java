package app.skipline.android;

import android.content.res.ColorStateList;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.snackbar.Snackbar;
import java.util.*;

@androidx.media3.common.util.UnstableApi
final class SongActions {
    static void show(MainActivity a,Track track,SavedPlaylist owner){
        LinearLayout body=a.column();a.handle(body);
        LinearLayout summary=a.row();summary.addView(a.art(60,60,track.thumbnail));
        LinearLayout labels=a.column();labels.setPadding(a.dp(14),0,0,0);
        TextView name=a.text(track.title,18,MainActivity.INK,true);name.setMaxLines(2);name.setEllipsize(TextUtils.TruncateAt.END);labels.addView(name);a.gap(labels,5);
        labels.addView(a.text(track.creator+(track.duration>0?" · "+MainActivity.format(track.duration):""),13,MainActivity.MUTED,false));summary.addView(labels,new LinearLayout.LayoutParams(0,-2,1));body.addView(summary);a.gap(body,20);
        BottomSheetDialog[] dialog=new BottomSheetDialog[1];
        boolean favorite=a.app.isFavorite(track);
        row(a,body,favorite?R.drawable.ic_heart_filled:R.drawable.ic_heart,favorite?"Remove from Favorites":"Add to Favorites","Your hearted songs",()->{dialog[0].dismiss();a.app.toggleFavorite(track);});
        row(a,body,R.drawable.ic_plus,"Add to playlist","Choose a saved playlist",()->{dialog[0].dismiss();a.choosePlaylist(Collections.singletonList(track),null);});
        row(a,body,R.drawable.ic_queue,"Play next","Next in your listening order",()->{
            dialog[0].dismiss();int at=0;for(int n=0;n<a.app.queue.size();n++)if(a.app.queue.get(n).id.equals(a.current()))at=n+1;
            a.app.queue.add(Math.min(at,a.app.queue.size()),track.copy());if(a.app.playback!=null)a.app.playback.sync(false);a.app.changed();Snackbar.make(a.root,"Added to play next",Snackbar.LENGTH_SHORT).show();
        });
        if(track.source.startsWith("https://")){
            a.gap(body,8);boolean saved=a.app.offline.file(track.source)!=null;
            row(a,body,saved?R.drawable.ic_check:R.drawable.ic_download,saved?"Available offline":"Download for offline listening","Keep audio inside Syntix",()->{dialog[0].dismiss();OfflineScreens.song(a,track);});
        }
        if(owner!=null&&owner!=a.app.favorites){a.gap(body,8);row(a,body,R.drawable.ic_trash,"Remove from playlist","Keep the rest of your library",()->{
            dialog[0].dismiss();final String profile=a.app.profiles.active;int pos=owner.tracks.indexOf(track);if(pos<0)return;SpotifyProgress.membership(a.app,owner,track,true);owner.tracks.remove(pos);a.app.saveLibrary();
            Snackbar.make(a.root,"Removed from playlist",Snackbar.LENGTH_LONG).setAction("Undo",v->{if(!a.app.profiles.active.equals(profile))return;owner.tracks.add(Math.min(pos,owner.tracks.size()),track);SpotifyProgress.membership(a.app,owner,track,false);a.app.saveLibrary();}).show();
        });}
        if(a.app.queue.contains(track)){
            row(a,body,R.drawable.ic_play,"Play now","Start this song",()->{dialog[0].dismiss();a.playTrack(track);});
            row(a,body,R.drawable.ic_list_view,"Move in listening order","Move up or down",()->{dialog[0].dismiss();new MaterialAlertDialogBuilder(a).setTitle("Move song").setItems(new String[]{"Move up","Move down"},(d,i)->{int from=a.app.queue.indexOf(track),to=from+(i==0?-1:1);if(from>=0&&to>=0&&to<a.app.queue.size()){Collections.swap(a.app.queue,from,to);if(a.app.playback!=null)a.app.playback.sync(false);a.app.changed();}}).show();});
            row(a,body,R.drawable.ic_close,"Remove from listening order","Saved playlists stay unchanged",()->{dialog[0].dismiss();a.remove(track);});
        }
        if(a.page.equals("imported"))row(a,body,R.drawable.ic_trash,"Remove imported video","Remove from this collection",()->{
            dialog[0].dismiss();android.content.SharedPreferences prefs=a.app.prefs("imported_videos");ArrayList<Track> videos=ImportedVideos.read(prefs);videos.removeIf(t->t.source.equals(track.source));ImportedVideos.save(prefs,videos);a.app.changed();
        });
        dialog[0]=a.sheet(body);
    }
    private static void row(MainActivity a,LinearLayout body,int icon,String title,String subtitle,Runnable action){
        LinearLayout row=a.row();row.setPadding(0,a.dp(10),0,a.dp(10));row.setMinimumHeight(a.dp(64));
        FrameLayout glyph=new FrameLayout(a);a.rounded(glyph,MainActivity.RAISED,12);ImageView image=new ImageView(a);image.setImageResource(icon);image.setImageTintList(ColorStateList.valueOf(MainActivity.ACCENT));glyph.addView(image,new FrameLayout.LayoutParams(a.dp(22),a.dp(22),Gravity.CENTER));row.addView(glyph,a.lp(42,42));
        LinearLayout labels=a.column();labels.setPadding(a.dp(14),0,a.dp(8),0);labels.addView(a.text(title,16,MainActivity.INK,true));a.gap(labels,3);labels.addView(a.text(subtitle,12,MainActivity.MUTED,false));row.addView(labels,new LinearLayout.LayoutParams(0,-2,1));
        row.setBackground(new android.graphics.drawable.RippleDrawable(ColorStateList.valueOf(0x24e1cdae),null,new android.graphics.drawable.ColorDrawable(android.graphics.Color.WHITE)));
        row.setFocusable(true);row.setClickable(true);row.setOnClickListener(v->action.run());body.addView(row,a.lp(-1,-2));
    }
}
