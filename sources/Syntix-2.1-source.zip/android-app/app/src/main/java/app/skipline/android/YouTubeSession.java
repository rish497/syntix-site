package app.skipline.android;

import java.io.IOException;
import java.util.regex.*;
import okhttp3.*;
import org.json.*;

/** Public, anonymous visitor context. Memory only; never reads Google cookies or accounts. */
final class YouTubeSession {
    private static String visitor="";private static long until;
    static synchronized void observe(JSONObject response){
        JSONObject context=response.optJSONObject("responseContext");if(context!=null)remember(context.optString("visitorData"));
    }
    private static void remember(String value){if(!value.isEmpty()&&value.length()<4096&&!value.contains("\n")&&!value.contains("\r")){visitor=value;until=System.currentTimeMillis()+30*60*1000;}}
    static synchronized String get(OkHttpClient client)throws Exception{
        if(!visitor.isEmpty()&&System.currentTimeMillis()<until)return visitor;
        Request request=new Request.Builder().url("https://www.youtube.com/").header("User-Agent",DirectAudio.USER_AGENT).build();
        try(Response response=client.newCall(request).execute()){
            if(!response.isSuccessful()||response.body()==null)throw new IOException("Public playback session unavailable");
            String html=YouTubeMetadata.readBounded(response.body().byteStream());Matcher found=Pattern.compile("\"VISITOR_DATA\"\\s*:\\s*\"([^\"]+)\"").matcher(html);
            if(found.find())remember(new JSONObject("{\"value\":\""+found.group(1)+"\"}").getString("value"));
        }
        if(visitor.isEmpty())throw new IOException("Public playback session unavailable");return visitor;
    }
}
