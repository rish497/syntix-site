package app.skipline.android;

import java.io.IOException;
import java.net.URI;
import java.util.*;
import java.util.regex.*;
import okhttp3.*;
import org.json.*;

/** Public Spotify track identity only; playback uses the existing recording matcher. */
final class SpotifySong {
    static String link(String text){
        if(text==null)throw new IllegalArgumentException("Paste a Spotify song link.");
        Matcher uri=Pattern.compile("spotify:track:([A-Za-z0-9]{22})(?![A-Za-z0-9])").matcher(text);if(uri.find())return "https://open.spotify.com/track/"+uri.group(1);
        Matcher urls=Pattern.compile("https?://[^\\s<>\"\\[\\]\\(\\)]+",Pattern.CASE_INSENSITIVE).matcher(text);
        while(urls.find())try{URI u=new URI(urls.group().replaceAll("[),.;!?]+$",""));if(!"open.spotify.com".equalsIgnoreCase(u.getHost())||u.getUserInfo()!=null||u.getPort()!=-1)continue;Matcher path=Pattern.compile("^/(?:intl-[A-Za-z-]+/|embed/)?track/([A-Za-z0-9]{22})/?$").matcher(u.getPath());if(path.matches())return "https://open.spotify.com/track/"+path.group(1);}catch(Exception ignored){}
        throw new IllegalArgumentException("Use a full Spotify track link.");
    }
    static boolean accepts(String text){try{link(text);return true;}catch(IllegalArgumentException ignored){return false;}}
    static String musicLink(String text){if(accepts(text))return link(text);try{return Links.extract(text);}catch(Exception ignored){throw new IllegalArgumentException("Paste a YouTube or Spotify music link.");}}
    static SpotifyPlaylist.Song parse(String html)throws Exception{
        Matcher script=Pattern.compile("<script(?=[^>]*\\bid=[\"']__NEXT_DATA__[\"'])[^>]*>(.*?)</script>",Pattern.DOTALL|Pattern.CASE_INSENSITIVE).matcher(html);
        if(!script.find())throw new IOException("Spotify song details are unavailable. Try again later.");
        JSONObject entity=new JSONObject(script.group(1)).getJSONObject("props").getJSONObject("pageProps").getJSONObject("state").getJSONObject("data").getJSONObject("entity");
        if(!"track".equals(entity.optString("type")))throw new IOException("Choose a Spotify song link.");
        ArrayList<String> artists=new ArrayList<>();JSONArray names=entity.optJSONArray("artists");for(int i=0;names!=null&&i<names.length();i++){JSONObject artist=names.optJSONObject(i);if(artist!=null&&!artist.optString("name").isEmpty())artists.add(artist.optString("name"));}
        String title=entity.optString("title",entity.optString("name"));if(title.isEmpty()||artists.isEmpty())throw new IOException("Spotify did not expose a song title and artist.");
        return new SpotifyPlaylist.Song(title,String.join(", ",artists),entity.optLong("duration"),entity.optString("uri"),"",entity.has("isExplicit")?entity.optBoolean("isExplicit"):null);
    }
    static Track resolve(android.content.Context context,String text,java.util.function.BooleanSupplier active)throws Exception{
        String url=link(text),id=url.substring(url.lastIndexOf('/')+1);OkHttpClient client=DirectAudio.CLIENT.newBuilder().connectTimeout(4,java.util.concurrent.TimeUnit.SECONDS).readTimeout(7,java.util.concurrent.TimeUnit.SECONDS).callTimeout(9,java.util.concurrent.TimeUnit.SECONDS).build();SpotifyPlaylist.Song song;
        try(Response response=client.newCall(new Request.Builder().url("https://open.spotify.com/embed/track/"+id).header("User-Agent","Mozilla/5.0").build()).execute()){
            if(!response.isSuccessful()||response.body()==null)throw new IOException("Spotify song details are unavailable. Try again later.");song=parse(SpotifyPlaylist.read(response.body().byteStream()));
        }
        if(!active.getAsBoolean())throw new java.util.concurrent.CancellationException();Track cached=SpotifyMatchCache.get(context,song);if(cached!=null)return cached;
        Track match=SpotifyMatching.find(song,q->{if(!active.getAsBoolean())throw new java.util.concurrent.CancellationException();try{ArrayList<Track> catalog=RecordingSearch.search(q,client);if(!catalog.isEmpty())return catalog;}catch(YouTubeMetadata.SearchBlockedException blocked){throw blocked;}catch(Exception unavailable){}return YouTubeMetadata.fastMatch(q,client);},active);
        if(!active.getAsBoolean())throw new java.util.concurrent.CancellationException();if(match==null)throw new IOException("No reliable recording matched this song. Try its YouTube link.");SpotifyMatchCache.put(context,song,match);return match;
    }
}
