package app.skipline.android;

import java.io.IOException;
import java.util.*;
import java.util.concurrent.TimeUnit;
import okhttp3.*;
import org.json.*;

/** Native request for public, already deciphered HTTPS audio. Unsupported responses use the existing engine. */
final class DirectAudio {
    static final String USER_AGENT="Mozilla/5.0 (Macintosh; Intel Mac OS X 15_7_3) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0 Safari/605.1.15";
    static final OkHttpClient CLIENT=new OkHttpClient.Builder().connectTimeout(2,TimeUnit.SECONDS).readTimeout(3,TimeUnit.SECONDS).callTimeout(4,TimeUnit.SECONDS).build();
    static void cancel(){CLIENT.dispatcher().cancelAll();}
    static void prepareSession(){try{YouTubeSession.get(CLIENT);}catch(Exception ignored){}}
    static final class Data {final String url;final Track track;final Map<String,String> headers;Data(String url,Track track){this.url=url;this.track=track;headers=Collections.singletonMap("User-Agent",USER_AGENT);}}
    static Data resolve(String source)throws Exception{return resolve(source,CLIENT);}
    static Data resolve(String source,OkHttpClient client)throws Exception{
        String canonical=Links.singleVideo(source),id=HttpUrl.get(canonical).queryParameter("v"),visitor=YouTubeSession.get(client);
        JSONObject device=new JSONObject().put("clientName","VISIONOS").put("clientVersion","1.02").put("deviceMake","Apple").put("deviceModel","RealityDevice17,1").put("userAgent",USER_AGENT).put("osName","visionOS").put("osVersion","26.5.23O471").put("hl","en").put("visitorData",visitor);
        JSONObject body=new JSONObject().put("context",new JSONObject().put("client",device)).put("videoId",id).put("contentCheckOk",true).put("racyCheckOk",true)
            .put("playbackContext",new JSONObject().put("contentPlaybackContext",new JSONObject().put("html5Preference","HTML5_PREF_WANTS")));
        Request request=new Request.Builder().url("https://www.youtube.com/youtubei/v1/player?prettyPrint=false").header("User-Agent",USER_AGENT).header("Origin","https://www.youtube.com")
            .header("X-Youtube-Client-Name","101").header("X-Youtube-Client-Version","1.02").header("X-Goog-Visitor-Id",visitor).post(RequestBody.create(body.toString(),MediaType.get("application/json"))).build();
        Data data;
        try(Response response=client.newCall(request).execute()){
            if(!response.isSuccessful()||response.body()==null)throw new IOException("Public audio metadata unavailable");
            JSONObject json=new JSONObject(YouTubeMetadata.readBounded(response.body().byteStream()));YouTubeSession.observe(json);data=parse(json,id);
        }
        // Check the returned stream before caching it; no audio file is created by this small range request.
        Request probe=new Request.Builder().url(data.url).header("User-Agent",USER_AGENT).header("Range","bytes=0-0").build();
        try(Response response=client.newCall(probe).execute()){
            String type=response.header("Content-Type","");if(!response.isSuccessful()||response.body()==null||type.contains("text/html")||response.body().byteStream().read()<0)throw new IOException("Audio URL was rejected");
        }
        return data;
    }
    static Data parse(JSONObject json,String id)throws Exception{
        JSONObject status=json.optJSONObject("playabilityStatus"),details=json.optJSONObject("videoDetails"),streams=json.optJSONObject("streamingData");
        if(status==null||!"OK".equals(status.optString("status"))||details==null||!id.equals(details.optString("videoId"))||streams==null||streams.has("licenseInfos"))throw new IOException("No public direct audio stream");
        JSONArray formats=streams.optJSONArray("adaptiveFormats");JSONObject best=null;long score=-1;
        for(int i=0;formats!=null&&i<formats.length();i++){
            JSONObject format=formats.optJSONObject(i);if(format==null||format.has("drmFamilies")||format.has("signatureCipher")||format.has("cipher")||!format.optString("mimeType").startsWith("audio/"))continue;
            HttpUrl url=HttpUrl.parse(format.optString("url"));if(url==null||!url.isHttps()||!url.host().endsWith(".googlevideo.com"))continue;
            JSONObject audioTrack=format.optJSONObject("audioTrack");String label=audioTrack==null?"":audioTrack.optString("displayName").toLowerCase(Locale.ROOT);long language=label.contains("original")?30000000:audioTrack==null||audioTrack.optBoolean("audioIsDefault",true)?20000000:0;
            long rank=language+(format.optString("mimeType").startsWith("audio/mp4")?10000000:0)+format.optLong("bitrate");if(rank>score){score=rank;best=format;}
        }
        if(best==null)throw new IOException("No supported public HTTPS audio stream");
        Track track=new Track("https://www.youtube.com/watch?v="+id,details.optString("title","Untitled"),details.optString("author","YouTube"),"https://i.ytimg.com/vi/"+id+"/hqdefault.jpg",details.optLong("lengthSeconds"));return new Data(best.getString("url"),track);
    }
}
