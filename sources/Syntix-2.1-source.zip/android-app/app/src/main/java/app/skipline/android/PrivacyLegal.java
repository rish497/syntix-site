package app.skipline.android;

import android.widget.LinearLayout;
import android.widget.TextView;
import com.google.android.material.snackbar.Snackbar;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

/** Bundled, read-only legal information. No network requests or consent gates. */
@androidx.media3.common.util.UnstableApi
final class PrivacyLegal {
    static final String SUMMARY="Your profiles and library are stored on this device. Searches and media requests are sent to third-party services. Profiles are not password-protected.";

    static void section(MainActivity a,LinearLayout body){
        TextView heading=a.text("Privacy & About",22,MainActivity.INK,true);
        androidx.core.view.ViewCompat.setAccessibilityHeading(heading,true);
        body.addView(heading);a.gap(body,14);
        body.addView(a.button("Privacy Policy",R.drawable.ic_info,false,()->document(a,"PRIVACY_POLICY.md","Privacy Policy")),a.lp(-1,52));
        a.gap(body,8);
        body.addView(a.button("Terms of Use",R.drawable.ic_info,false,()->document(a,"TERMS_OF_USE.md","Terms of Use")),a.lp(-1,52));
        a.gap(body,14);body.addView(a.text(SUMMARY,13,MainActivity.MUTED,false));a.gap(body,12);
    }

    static void show(MainActivity a){LinearLayout body=a.column();a.handle(body);section(a,body);LinearLayout links=a.row();TextView notices=quietLink(a,"Open-source software",()->software(a));notices.setTag("open_source_text_link");links.addView(notices,new LinearLayout.LayoutParams(0,a.dp(48),1));TextView source=quietLink(a,"Source code",()->{try{a.startActivity(new android.content.Intent(android.content.Intent.ACTION_VIEW,android.net.Uri.parse("https://rish497.github.io/syntix-site/sources/Syntix-2.1-source.zip")));}catch(android.content.ActivityNotFoundException missing){Snackbar.make(a.root,"Open syntix-site on GitHub Pages to download source.",Snackbar.LENGTH_LONG).show();}});source.setTag("source_website_text_link");links.addView(source,a.lp(-2,48));body.addView(links);a.sheet(body);}
    private static TextView quietLink(MainActivity a,String text,Runnable action){TextView link=a.text(text,12,0xff919ba2,false);link.setGravity(android.view.Gravity.CENTER_VERTICAL);link.setContentDescription(text);link.setFocusable(true);link.setClickable(true);link.setBackgroundColor(android.graphics.Color.TRANSPARENT);link.setOnClickListener(v->action.run());return link;}

    static void software(MainActivity a){
        LinearLayout body=a.column();a.handle(body);body.addView(a.text("Open-source software",25,MainActivity.INK,true));a.gap(body,14);
        body.addView(a.text("Syntix uses open-source components. License notices and build information are available below.",14,MainActivity.MUTED,false));a.gap(body,18);
        body.addView(a.button("Third-party licenses",R.drawable.ic_info,false,()->document(a,"THIRD_PARTY_LICENSES.md","Third-party licenses")),a.lp(-1,52));a.gap(body,8);
        body.addView(a.button("Full third-party notices",R.drawable.ic_info,false,()->document(a,"THIRD_PARTY_NOTICES.md","Third-party notices")),a.lp(-1,52));a.gap(body,8);
        body.addView(a.button("Software license",R.drawable.ic_info,false,()->document(a,"PROJECT_LICENSE.txt","Software license")),a.lp(-1,52));a.gap(body,8);
        a.sheet(body);
    }

    static String read(MainActivity a,String filename)throws Exception{
        if(!filename.equals("PRIVACY_POLICY.md")&&!filename.equals("TERMS_OF_USE.md")&&!filename.equals("THIRD_PARTY_LICENSES.md")&&!filename.equals("SOURCE_DISTRIBUTION.md")&&!filename.equals("PROJECT_LICENSE.txt")&&!filename.equals("THIRD_PARTY_NOTICES.md"))throw new IllegalArgumentException("Unknown document");
        try(InputStream input=a.getAssets().open("legal/"+filename);ByteArrayOutputStream output=new ByteArrayOutputStream()){
            byte[] bytes=new byte[4096];int count;while((count=input.read(bytes))!=-1){if(output.size()+count>(filename.equals("THIRD_PARTY_NOTICES.md")?4*1024*1024:262144))throw new java.io.IOException("Document too large");output.write(bytes,0,count);}
            return output.toString(StandardCharsets.UTF_8.name());
        }
    }

    static void document(MainActivity a,String filename,String title){
        final String markdown;try{markdown=read(a,filename);}catch(Exception unavailable){Snackbar.make(a.root,"Could not open this document. Please try again.",Snackbar.LENGTH_LONG).show();return;}
        LinearLayout body=a.column();a.handle(body);
        TextView heading=a.text(title,27,MainActivity.INK,true);androidx.core.view.ViewCompat.setAccessibilityHeading(heading,true);body.addView(heading);a.gap(body,18);
        for(String block:markdown.split("\\r?\\n\\s*\\r?\\n")){
            String text=block.trim();if(text.isEmpty()||text.startsWith("# "))continue;
            boolean section=text.startsWith("## ");if(section)text=text.substring(3);
            TextView paragraph=a.text(text.replaceAll("(?m)^- ","• "),section?18:14,section?MainActivity.INK:MainActivity.MUTED,section);
            android.text.util.Linkify.addLinks(paragraph,android.text.util.Linkify.WEB_URLS);paragraph.setLinkTextColor(MainActivity.MUTED);paragraph.setTextIsSelectable(true);paragraph.setLineSpacing(a.dp(3),1);if(section)androidx.core.view.ViewCompat.setAccessibilityHeading(paragraph,true);body.addView(paragraph);a.gap(body,section?10:18);
        }
        a.sheet(body);
    }
}
