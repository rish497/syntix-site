package app.skipline.android;

import android.content.Context;
import java.util.*;
import org.json.*;

final class ListeningHistory {
    static final class Entry {Track track;int plays,night;long first,last;Entry(Track t,int p,long l){track=t;plays=p;last=l;}}
    private final ArrayList<Entry> entries=new ArrayList<>();private final android.content.SharedPreferences storage;
    ListeningHistory(Context context){this.storage=((SkiplineApp)context.getApplicationContext()).prefs("history");try{JSONArray list=new JSONArray(storage.getString("plays","[]"));for(int i=0;i<list.length();i++){JSONObject value=list.getJSONObject(i);Entry e=new Entry(Track.fromJson(value.getJSONObject("track")),value.getInt("plays"),value.getLong("last"));e.first=value.optLong("first",0);e.night=value.optInt("night",0);entries.add(e);}}catch(Exception ignored){}}
    void record(Track track){Entry found=null;for(Entry e:entries)if(e.track.source.equals(track.source)){found=e;break;}if(found==null)found=new Entry(track,0,0);else entries.remove(found);found.plays++;if(found.first==0&&found.plays==1)found.first=System.currentTimeMillis();int hour=Calendar.getInstance().get(Calendar.HOUR_OF_DAY);if(hour>=21||hour<5)found.night++;found.last=System.currentTimeMillis();found.track=track;entries.add(0,found);save();}
    ArrayList<Track> recent(){ArrayList<Track> tracks=new ArrayList<>();for(Entry e:entries)tracks.add(e.track);return tracks;}
    ArrayList<Entry> entries(){return new ArrayList<>(entries);}
    int size(){return entries.size();}
    ArrayList<Track> recommendationSeeds(int round){
        // Every retained listen contributes to artist weight; rotate discovery beyond the top artist.
        java.util.LinkedHashMap<String,Entry> representatives=new java.util.LinkedHashMap<>();java.util.HashMap<String,Long> weights=new java.util.HashMap<>();
        for(Entry e:entries){if(!e.track.source.startsWith("https://"))continue;String key=(e.track.creator.isEmpty()?e.track.title:e.track.creator).toLowerCase(java.util.Locale.ROOT);representatives.putIfAbsent(key,e);weights.put(key,weights.getOrDefault(key,0L)+e.plays);}
        ArrayList<String> keys=new ArrayList<>(representatives.keySet());keys.sort((a,b)->Long.compare(weights.get(b),weights.get(a)));ArrayList<Track> seeds=new ArrayList<>();
        if(keys.isEmpty())return seeds;seeds.add(representatives.get(keys.get(0)).track);int remaining=keys.size()-1;for(int i=0;i<Math.min(2,remaining);i++)seeds.add(representatives.get(keys.get(1+Math.floorMod(round*2+i,remaining))).track);return seeds;
    }
    int affinity(Track track){long score=0;for(Entry e:entries)if(!track.creator.isEmpty()&&e.track.creator.equalsIgnoreCase(track.creator))score+=(long)e.plays*10;return (int)Math.min(Integer.MAX_VALUE,score);}
    boolean heard(String source){for(Entry e:entries)if(e.track.source.equals(source))return true;return false;}
    void clear(){entries.clear();save();}
    private void save(){try{JSONArray values=new JSONArray();for(Entry e:entries)values.put(new JSONObject().put("track",e.track.json()).put("plays",e.plays).put("last",e.last).put("first",e.first).put("night",e.night));storage.edit().putString("plays",values.toString()).apply();}catch(Exception ignored){}}
}
