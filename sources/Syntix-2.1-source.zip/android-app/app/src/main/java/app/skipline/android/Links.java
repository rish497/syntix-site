package app.skipline.android;

import java.net.URI;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class Links {
    /** A video shared from a playlist still imports only that video. */
    static String singleVideo(String text){
        try{URI uri=new URI(extract(text));String id=null,path=uri.getPath();
            if("youtu.be".equalsIgnoreCase(uri.getHost()))id=path.replaceFirst("^/","");
            else if(path.startsWith("/shorts/")||path.startsWith("/live/"))id=path.substring(path.lastIndexOf('/')+1);
            else if("/watch".equals(path)&&uri.getQuery()!=null){Matcher m=Pattern.compile("(^|&)v=([^&]+)").matcher(uri.getQuery());if(m.find())id=m.group(2);}
            if(id!=null&&id.matches("[A-Za-z0-9_-]{11}"))return "https://www.youtube.com/watch?v="+id;
        }catch(Exception ignored){}
        throw new IllegalArgumentException("Paste a YouTube video link.");
    }
    private static final Pattern URL=Pattern.compile("https?://[^\\s<>\"\\u0000-\\u001f]+",Pattern.CASE_INSENSITIVE);
    public static boolean isPlaylist(String source){try{String query=new URI(source).getRawQuery();return query!=null&&Pattern.compile("(^|&)list=[^&]+",Pattern.CASE_INSENSITIVE).matcher(query).find();}catch(Exception e){return false;}}
    public static boolean isMediaLink(String source){try{String url=extract(source);if(isPlaylist(url))return true;URI uri=new URI(url);String id=null;if("youtu.be".equalsIgnoreCase(uri.getHost()))id=uri.getPath().replaceFirst("^/","");else if(uri.getPath().startsWith("/shorts/")||uri.getPath().startsWith("/live/"))id=uri.getPath().substring(uri.getPath().lastIndexOf('/')+1);else if("/watch".equals(uri.getPath())&&uri.getQuery()!=null){Matcher match=Pattern.compile("(^|&)v=([^&]+)").matcher(uri.getQuery());if(match.find())id=match.group(2);}return id!=null&&id.matches("[A-Za-z0-9_-]{11}");}catch(Exception e){return false;}}
    public static String extract(String text) {
        if(text==null)throw new IllegalArgumentException("Paste a YouTube video or playlist link.");
        Matcher m=URL.matcher(text);
        while(m.find()) {
            String url=m.group().replaceAll("[),.;!?]+$","");
            try {
                URI u=new URI(url); String h=u.getHost(); if(h==null||u.getUserInfo()!=null)continue;
                h=h.toLowerCase(Locale.ROOT);
                if(h.equals("youtu.be")||h.equals("youtube.com")||h.endsWith(".youtube.com"))return "https"+url.substring(url.indexOf(':'));
            }catch(Exception ignored){}
        }
        throw new IllegalArgumentException("Use a youtube.com or youtu.be video or playlist link.");
    }
}
