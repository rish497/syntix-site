package app.skipline.android;

import androidx.media3.common.C;
import androidx.media3.common.audio.BaseAudioProcessor;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/** Seven real PCM filters, independent of vendor audio-effect support. No network work. */
@androidx.media3.common.util.UnstableApi
final class SoundProcessor extends BaseAudioProcessor {
    static final int[] HZ={60,150,400,1000,2400,6000,16000};
    static final class Settings {
        final boolean enabled,normalize;final int[] bands;final int bass,space;
        Settings(boolean e,boolean n,int[] b,int low,int width){enabled=e;normalize=n;bands=b.clone();bass=Math.max(0,Math.min(100,low));space=Math.max(0,Math.min(100,width));}
    }
    private volatile Settings requested=new Settings(false,false,new int[7],0,0);
    private Settings applied;
    private double[][] coefficients=new double[7][5];
    private double[][] z1,z2;
    private double envelope=.02,gain=1;
    void settings(Settings value){requested=value;}
    @Override protected AudioFormat onConfigure(AudioFormat f)throws UnhandledAudioFormatException{
        if(f.encoding!=C.ENCODING_PCM_16BIT)throw new UnhandledAudioFormatException(f);return f;
    }
    @Override protected void onFlush(){z1=new double[inputAudioFormat.channelCount][7];z2=new double[inputAudioFormat.channelCount][7];applied=null;envelope=.02;gain=1;}
    @Override public void queueInput(ByteBuffer input){
        // Decoder/drain calls may pass the shared EMPTY_BUFFER. Copying it into
        // replaceOutputBuffer(0) aliases that same object and throws before audio starts.
        if(!input.hasRemaining())return;
        Settings s=requested;ByteBuffer output=replaceOutputBuffer(input.remaining());input.order(ByteOrder.LITTLE_ENDIAN);output.order(ByteOrder.LITTLE_ENDIAN);
        if(!s.enabled&&!s.normalize){output.put(input);output.flip();return;}
        if(applied!=s){for(int i=0;i<7;i++){double db=s.enabled?s.bands[i]+(i==0?s.bass*.06:0):0;coefficients[i]=HZ[i]>=inputAudioFormat.sampleRate*.5?new double[]{1,0,0,0,0}:peak(HZ[i],db,inputAudioFormat.sampleRate);}applied=s;}
        double boost=0;if(s.enabled){for(int i=0;i<7;i++)if(HZ[i]<inputAudioFormat.sampleRate*.5)boost=Math.max(boost,s.bands[i]+(i==0?s.bass*.06:0));}double headroom=Math.pow(10,-boost/20);
        int channels=inputAudioFormat.channelCount;double[] frame=new double[channels];double attack=1-Math.exp(-1.0/(inputAudioFormat.sampleRate*.01)),release=1-Math.exp(-1.0/(inputAudioFormat.sampleRate*.3));
        while(input.remaining()>=channels*2){double power=0;for(int ch=0;ch<channels;ch++){double x=input.getShort()/32768.0*headroom;for(int i=0;i<7;i++){double[] c=coefficients[i];double y=c[0]*x+z1[ch][i];z1[ch][i]=c[1]*x-c[3]*y+z2[ch][i];z2[ch][i]=c[2]*x-c[4]*y;x=y;}frame[ch]=x;power+=x*x;}
            if(s.enabled&&channels==2&&s.space>0){double mid=(frame[0]+frame[1])*.5,side=(frame[0]-frame[1])*.5*(1+s.space*.005);frame[0]=mid+side;frame[1]=mid-side;}
            if(s.normalize){double rms=power/channels;envelope+=(rms-envelope)*(rms>envelope?attack:release);double desired=Math.max(.25,Math.min(1.8,.13/Math.sqrt(Math.max(.00001,envelope))));gain+=(desired-gain)*(desired<gain?attack:release);}else gain=1;
            for(int ch=0;ch<channels;ch++){double x=frame[ch]*gain;if(!Double.isFinite(x))x=0;output.putShort((short)Math.round(Math.max(-1,Math.min(32767.0/32768,x))*32768));}
        }output.flip();
    }
    static double[] peak(double hz,double db,int rate){double a=Math.pow(10,db/40),w=2*Math.PI*hz/rate,alpha=Math.sin(w)/2,cos=Math.cos(w),a0=1+alpha/a;return new double[]{(1+alpha*a)/a0,-2*cos/a0,(1-alpha*a)/a0,-2*cos/a0,(1-alpha/a)/a0};}
}
