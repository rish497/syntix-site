package app.skipline.android;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.ArrayList;
import java.util.UUID;
import org.json.JSONArray;
import org.json.JSONObject;

/** On-device identities only. No contact verification, remote login or cloud synchronization. */
final class LocalProfiles {
    static final class Profile {
        final String id;String name,photo;
        Profile(String id,String name,String photo){this.id=id;this.name=name;this.photo=photo;}
    }
    final ArrayList<Profile> all=new ArrayList<>();
    private final SharedPreferences storage;
    String active="default";
    LocalProfiles(Context context){
        storage=context.getSharedPreferences("syntix_profiles",0);
        try{JSONArray list=new JSONArray(storage.getString("items","[]"));for(int i=0;i<list.length();i++){JSONObject j=list.getJSONObject(i);String id=j.getString("id");if(id.equals("default")||id.matches("[a-f0-9-]{36}"))all.add(new Profile(id,j.optString("name","Listener").trim().isEmpty()?"Listener":j.optString("name").substring(0,Math.min(40,j.optString("name").length())),j.optString("photo")));}}catch(Exception ignored){}
        if(all.isEmpty())all.add(new Profile("default","Listener",""));active=storage.getString("active","default");if(find(active)==null)active=all.get(0).id;
    }
    Profile current(){return find(active);}
    Profile find(String id){for(Profile p:all)if(p.id.equals(id))return p;return null;}
    Profile add(String name){if(all.size()>=10)throw new IllegalArgumentException("You can keep up to 10 profiles on this phone.");Profile p=new Profile(UUID.randomUUID().toString(),name,"");all.add(p);save();return p;}
    void save(){try{JSONArray items=new JSONArray();for(Profile p:all)items.put(new JSONObject().put("id",p.id).put("name",p.name).put("photo",p.photo));storage.edit().putString("items",items.toString()).putString("active",active).apply();}catch(Exception ignored){}}
}
