package app.skipline.android;

import java.util.ArrayList;
import java.util.UUID;
import org.json.JSONArray;
import org.json.JSONObject;

final class SavedPlaylist {
    final String id;
    String name;
    JSONObject spotifyDraft;
    final ArrayList<Track> tracks=new ArrayList<>();
    SavedPlaylist(String name){this.id=UUID.randomUUID().toString();this.name=name;}
    private SavedPlaylist(String id,String name){this.id=id;this.name=name;}
    int add(java.util.List<Track> items){int added=0;for(Track t:items){boolean exists=false;for(Track old:tracks)if(old.source.equals(t.source)){exists=true;break;}if(!exists){tracks.add(t);added++;}}return added;}
    JSONObject json() throws Exception {JSONArray items=new JSONArray();for(Track t:tracks)items.put(t.json());JSONObject result=new JSONObject().put("id",id).put("name",name).put("tracks",items);if(spotifyDraft!=null)result.put("spotifyDraft",spotifyDraft);return result;}
    static SavedPlaylist fromJson(JSONObject object)throws Exception{SavedPlaylist list=new SavedPlaylist(object.getString("id"),object.getString("name"));JSONArray items=object.getJSONArray("tracks");for(int i=0;i<items.length();i++)list.tracks.add(Track.fromJson(items.getJSONObject(i)));list.spotifyDraft=object.optJSONObject("spotifyDraft");return list;}
}
