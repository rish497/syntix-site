package app.skipline.android;

import android.content.*;
import android.net.Uri;
import android.database.Cursor;
import android.provider.OpenableColumns;
import java.util.*;
import org.json.*;

/** Only explicitly selected or successfully exported documents are indexed. */
final class DownloadedDocuments {
    static synchronized void record(Context context,String profile,Track track){try{android.content.SharedPreferences prefs=context.getSharedPreferences("download_documents_"+profile,0);JSONArray old=new JSONArray(prefs.getString("items","[]")),next=new JSONArray();for(int i=0;i<old.length();i++){Track t=Track.fromJson(old.getJSONObject(i));if(!t.source.equals(track.source))next.put(t.json());}next.put(track.json());prefs.edit().putString("items",next.toString()).apply();}catch(Exception ignored){}}
    static final class Item {final Track track;final long bytes;Item(Track track,long bytes){this.track=track;this.bytes=bytes;}}
    static ArrayList<Item> list(Context context,String profile){ArrayList<Item> out=new ArrayList<>();try{JSONArray items=new JSONArray(context.getSharedPreferences("download_documents_"+profile,0).getString("items","[]"));for(int i=0;i<items.length();i++){Track track=Track.fromJson(items.getJSONObject(i));Uri uri=Uri.parse(track.source);if(!"content".equals(uri.getScheme()))continue;try(android.content.res.AssetFileDescriptor fd=context.getContentResolver().openAssetFileDescriptor(uri,"r")){if(fd==null)continue;long size=fd.getLength();if(size<0)try(Cursor c=context.getContentResolver().query(uri,new String[]{OpenableColumns.SIZE},null,null,null)){if(c!=null&&c.moveToFirst()&&!c.isNull(0))size=c.getLong(0);}out.add(new Item(track,size));}catch(Exception ignored){}}}catch(Exception ignored){}return out;}
}
