package app.skipline.android;

import android.security.keystore.*;
import java.io.*;
import java.security.*;
import javax.crypto.*;

/** Installation-local key; no exported keys, passwords, network service or plaintext fallback. */
final class OfflineAudio {
    private static final String ALIAS="syntix.offline.audio.v1";
    private static final Object KEY_LOCK=new Object();
    private static SecretKey key()throws GeneralSecurityException,IOException {
        synchronized(KEY_LOCK){KeyStore store=KeyStore.getInstance("AndroidKeyStore");store.load(null);
        if(store.containsAlias(ALIAS))return (SecretKey)store.getKey(ALIAS,null);
        KeyGenerator generator=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
        generator.init(new KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT).setKeySize(256).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());
        return generator.generateKey();}
    }
    static boolean encrypted(File file){return file.getName().endsWith(".sxa");}
    static String binding(File file){return file.getName().substring(0,file.getName().lastIndexOf('.'));}
    static File seal(File plain)throws IOException {
        if(encrypted(plain))return plain;
        File target=new File(plain.getParentFile(),binding(plain)+".sxa");
        try{
            SecretKey master=key();
            
            File temp=new File(plain.getParentFile(),target.getName()+".tmp");
            EncryptedAudio.write(plain,temp,master,binding(target));
            try{java.nio.file.Files.move(temp.toPath(),target.toPath(),java.nio.file.StandardCopyOption.ATOMIC_MOVE,java.nio.file.StandardCopyOption.REPLACE_EXISTING);}catch(java.nio.file.AtomicMoveNotSupportedException unsupported){java.nio.file.Files.move(temp.toPath(),target.toPath(),java.nio.file.StandardCopyOption.REPLACE_EXISTING);}
            return target;
        }catch(GeneralSecurityException e){throw new IOException("Could not access secure offline storage. Keep this app's data and try again.",e);}
    }
    static EncryptedAudio.Reader open(File file)throws IOException {
        try{return new EncryptedAudio.Reader(file,key(),binding(file));}
        catch(GeneralSecurityException e){throw new IOException("This saved audio cannot be unlocked. Remove the download and download it again.",e);}
    }
}
