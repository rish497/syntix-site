package app.skipline.android;

import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import androidx.media3.common.Player;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.snackbar.Snackbar;

/** Artwork-led native player. Transport actions remain immediate; the sheet owns motion. */
@androidx.media3.common.util.UnstableApi
final class PlayerScreen {
    static void show(MainActivity a){
        if(a.app.playback==null||a.app.queue.isEmpty()){Snackbar.make(a.root,"Choose a song to start listening",Snackbar.LENGTH_SHORT).show();return;}
        Track current=NativeScreens.currentTrack(a);if(current==null)return;
        PlaybackService service=a.app.playback;Player p=service.player;
        LinearLayout body=a.column();
        int height=a.getResources().getDisplayMetrics().heightPixels;
        int width=a.getResources().getDisplayMetrics().widthPixels;
        BottomSheetDialog[] ref=new BottomSheetDialog[1];
        LinearLayout top=a.row();top.addView(a.icon(R.drawable.ic_down,"Close player",()->ref[0].dismiss()),a.lp(48,48));
        LinearLayout context=a.column();TextView origin=a.text(a.app.prefs("session").getString("playing_playlist","").isEmpty()?"Playing from queue":"Playing from playlist",12,MainActivity.INK,false);origin.setGravity(Gravity.CENTER);context.addView(origin);
        TextView playlist=a.text(a.app.playingPlaylistName(),15,MainActivity.INK,true);playlist.setSingleLine(true);playlist.setEllipsize(TextUtils.TruncateAt.END);playlist.setGravity(Gravity.CENTER);context.addView(playlist);
        top.addView(context,new LinearLayout.LayoutParams(0,-2,1));top.addView(a.icon(R.drawable.ic_more,"Song actions",()->{Track t=NativeScreens.currentTrack(a);if(t!=null)SongActions.show(a,t,null);}),a.lp(48,48));body.addView(top);a.gap(body,24);
        int artwork=Math.max(140,Math.min(420,Math.min((int)(width/a.getResources().getDisplayMetrics().density)-48,(int)(height/a.getResources().getDisplayMetrics().density*.39f))));
        ImageView art=a.art(artwork,artwork,current.thumbnail);art.setContentDescription("Artwork for "+current.title);LinearLayout.LayoutParams ap=a.lp(artwork,artwork);ap.gravity=Gravity.CENTER_HORIZONTAL;body.addView(art,ap);a.gap(body,34);
        LinearLayout metadata=a.row();LinearLayout labels=a.column();
        TextView title=a.text(current.title,25,MainActivity.INK,true);title.setMaxLines(2);title.setEllipsize(TextUtils.TruncateAt.END);labels.addView(title);a.gap(labels,5);
        TextView artist=a.text(current.creator,17,MainActivity.MUTED,false);artist.setSingleLine(true);artist.setEllipsize(TextUtils.TruncateAt.END);labels.addView(artist);metadata.addView(labels,new LinearLayout.LayoutParams(0,-2,1));
        MaterialButton favorite=a.icon(R.drawable.ic_heart,"Favorite current song",()->{Track t=NativeScreens.currentTrack(a);if(t!=null)a.app.toggleFavorite(t);});metadata.addView(favorite,a.lp(48,56));body.addView(metadata);a.gap(body,12);
        boolean[] seeking={false};SeekBar seek=new SeekBar(a);seek.setMax(1000);seek.setPadding(0,0,0,0);seek.setProgressTintList(ColorStateList.valueOf(MainActivity.INK));seek.setProgressBackgroundTintList(ColorStateList.valueOf(0xff647576));seek.setThumbTintList(ColorStateList.valueOf(MainActivity.INK));seek.setContentDescription("Playback position");
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onStartTrackingTouch(SeekBar s){seeking[0]=true;}public void onProgressChanged(SeekBar s,int n,boolean user){}public void onStopTrackingTouch(SeekBar s){if(p.getDuration()>0)p.seekTo(p.getDuration()*s.getProgress()/1000);seeking[0]=false;}});body.addView(seek,a.lp(-1,36));
        LinearLayout times=a.row();TextView elapsed=a.text("0:00",13,MainActivity.MUTED,false),duration=a.text("0:00",13,MainActivity.MUTED,false);times.addView(elapsed,new LinearLayout.LayoutParams(0,-2,1));times.addView(duration);body.addView(times);a.gap(body,18);
        LinearLayout controls=a.row();controls.setGravity(Gravity.CENTER);
        MaterialButton shuffle=a.icon(R.drawable.ic_shuffle,"Shuffle",()->p.setShuffleModeEnabled(!p.getShuffleModeEnabled()));controls.addView(shuffle,new LinearLayout.LayoutParams(0,a.dp(56),1));
        MaterialButton previous=a.icon(R.drawable.ic_previous,"Previous song",service::previous);previous.setIconSize(a.dp(28));controls.addView(previous,new LinearLayout.LayoutParams(0,a.dp(56),1));
        MaterialButton toggle=a.icon(R.drawable.ic_pause,"Pause",service::toggle);toggle.setIconSize(a.dp(30));toggle.setCornerRadius(a.dp(36));toggle.setBackgroundTintList(ColorStateList.valueOf(MainActivity.ACCENT));toggle.setIconTint(ColorStateList.valueOf(MainActivity.ON_ACCENT));controls.addView(toggle,a.lp(72,72));
        MaterialButton next=a.icon(R.drawable.ic_next,"Next song",service::next);next.setIconSize(a.dp(28));controls.addView(next,new LinearLayout.LayoutParams(0,a.dp(56),1));
        controls.addView(a.icon(R.drawable.ic_plus,"Add current song to playlist",()->{Track t=NativeScreens.currentTrack(a);if(t!=null)a.choosePlaylist(java.util.Collections.singletonList(t),null);}),new LinearLayout.LayoutParams(0,a.dp(56),1));
        MaterialButton repeat=a.icon(R.drawable.ic_repeat,"Loop off",()->p.setRepeatMode(nextRepeat(p.getRepeatMode())));controls.addView(repeat,new LinearLayout.LayoutParams(0,a.dp(56),1));body.addView(controls);a.gap(body,18);
        LinearLayout utility=a.row();utility.addView(a.icon(R.drawable.ic_speed,"Playback speed",()->new MaterialAlertDialogBuilder(a).setTitle("Playback speed").setItems(new String[]{"0.75×","1×","1.25×","1.5×","2×"},(d,i)->p.setPlaybackSpeed(new float[]{.75f,1f,1.25f,1.5f,2f}[i])).show()),a.lp(48,48));
        TextView mode=a.text("",12,MainActivity.MUTED,false);mode.setGravity(Gravity.CENTER);utility.addView(mode,new LinearLayout.LayoutParams(0,-2,1));utility.addView(a.icon(R.drawable.ic_queue,"Listening order",a::sessionSheet),a.lp(48,48));body.addView(utility);
        BottomSheetDialog dialog=a.sheet(body);ref[0]=dialog;
        body.setMinimumHeight(Math.max(0,height-a.dp(48)));
        // The window owns the wash so it continues behind the status bar and safe-area padding.
        int warmAccent=androidx.core.graphics.ColorUtils.blendARGB(MainActivity.PAGE,MainActivity.ACCENT,.35f);
        int warmSurface=androidx.core.graphics.ColorUtils.blendARGB(MainActivity.PAGE,MainActivity.ACCENT,.12f);
        GradientDrawable wash=new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{warmAccent,warmSurface,MainActivity.PAGE});body.setBackgroundColor(Color.TRANSPARENT);
        View sheet=dialog.findViewById(com.google.android.material.R.id.design_bottom_sheet);
        if(sheet!=null){
            sheet.setBackgroundColor(Color.TRANSPARENT);sheet.getLayoutParams().height=ViewGroup.LayoutParams.MATCH_PARENT;sheet.requestLayout();
            androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(sheet,(view,insets)->{
                androidx.core.graphics.Insets bars=insets.getInsets(androidx.core.view.WindowInsetsCompat.Type.systemBars()|androidx.core.view.WindowInsetsCompat.Type.displayCutout());
                view.setPadding(bars.left,bars.top,bars.right,bars.bottom);return insets;
            });
        }
        dialog.getBehavior().setFitToContents(false);dialog.getBehavior().setExpandedOffset(0);dialog.getBehavior().setSkipCollapsed(true);dialog.getBehavior().setState(BottomSheetBehavior.STATE_EXPANDED);
        if(dialog.getWindow()!=null){
            android.view.Window window=dialog.getWindow();
            androidx.core.view.WindowCompat.setDecorFitsSystemWindows(window,false);
            window.setBackgroundDrawable(wash);window.setStatusBarColor(Color.TRANSPARENT);window.setStatusBarContrastEnforced(false);window.setNavigationBarColor(MainActivity.PAGE);
            androidx.core.view.WindowInsetsControllerCompat bars=androidx.core.view.WindowCompat.getInsetsController(window,window.getDecorView());bars.setAppearanceLightStatusBars(false);bars.setAppearanceLightNavigationBars(false);
            if(sheet!=null){View parent=(View)sheet.getParent();parent.setFitsSystemWindows(false);((View)parent.getParent()).setFitsSystemWindows(false);androidx.core.view.ViewCompat.requestApplyInsets(sheet);}
        }
        Runnable tick=new Runnable(){String source="";public void run(){
            if(!dialog.isShowing())return;
            if(a.app.playback!=service){dialog.dismiss();return;}
            Track t=NativeScreens.currentTrack(a);
            if(t!=null){title.setText(t.title);artist.setText(t.creator);playlist.setText(a.app.playingPlaylistName());origin.setText(a.app.prefs("session").getString("playing_playlist","").isEmpty()?"Playing from queue":"Playing from playlist");
                if(!source.equals(t.source)){source=t.source;Images.load(art,t.thumbnail);art.setContentDescription("Artwork for "+t.title);}
                boolean heart=a.app.isFavorite(t);favorite.setIconResource(heart?R.drawable.ic_heart_filled:R.drawable.ic_heart);favorite.setIconTint(ColorStateList.valueOf(heart?MainActivity.ACCENT:MainActivity.INK));favorite.setContentDescription(heart?"Remove from Favorites":"Add to Favorites");}
            boolean playing=p.getPlayWhenReady();toggle.setIconResource(playing?R.drawable.ic_pause:R.drawable.ic_play);toggle.setContentDescription(playing?"Pause":"Play");
            shuffle.setIconTint(ColorStateList.valueOf(p.getShuffleModeEnabled()?MainActivity.ACCENT:MainActivity.INK));androidx.core.view.ViewCompat.setStateDescription(shuffle,p.getShuffleModeEnabled()?"On":"Off");shuffle.setContentDescription(p.getShuffleModeEnabled()?"Turn shuffle off":"Turn shuffle on");
            int loop=p.getRepeatMode();repeat.setIconResource(loop==Player.REPEAT_MODE_ONE?R.drawable.ic_repeat_one:R.drawable.ic_repeat);repeat.setIconTint(ColorStateList.valueOf(loop==Player.REPEAT_MODE_OFF?MainActivity.INK:MainActivity.ACCENT));
            String loopName=loop==Player.REPEAT_MODE_OFF?"Loop off":loop==Player.REPEAT_MODE_ONE?"Loop song":"Loop playlist";repeat.setContentDescription(loopName);androidx.core.view.ViewCompat.setStateDescription(repeat,loopName);mode.setText(loopName);
            long length=p.getDuration();seek.setEnabled(length>0);if(length>0&&!seeking[0])seek.setProgress((int)(p.getCurrentPosition()*1000/length));
            elapsed.setText(MainActivity.format(p.getCurrentPosition()/1000));duration.setText(length>0?MainActivity.format(length/1000):t!=null&&t.duration>0?MainActivity.format(t.duration):"–:–");
            if(a.screenStarted)a.handler.postDelayed(this,500);
        }};a.handler.post(tick);dialog.setOnDismissListener(d->a.handler.removeCallbacks(tick));
    }
    static int nextRepeat(int mode){return mode==Player.REPEAT_MODE_OFF?Player.REPEAT_MODE_ALL:mode==Player.REPEAT_MODE_ALL?Player.REPEAT_MODE_ONE:Player.REPEAT_MODE_OFF;}
}
