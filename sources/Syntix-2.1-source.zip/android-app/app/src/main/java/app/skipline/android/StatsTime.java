package app.skipline.android;

import java.util.Calendar;
import java.util.TimeZone;

final class StatsTime {
    static long hourStart(long time,TimeZone zone){Calendar c=Calendar.getInstance(zone);c.setTimeInMillis(time);c.set(Calendar.MINUTE,0);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);return c.getTimeInMillis();}
    static long cutoff(long now,TimeZone zone){Calendar c=Calendar.getInstance(zone);c.setTimeInMillis(now);c.add(Calendar.MONTH,-3);return c.getTimeInMillis();}
}
