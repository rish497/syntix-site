package app.skipline.android;
import org.junit.Test;
import static org.junit.Assert.*;

public class LinksTest {
    @Test public void acceptsVideoAndPlaylistShares(){
        assertEquals("https://youtu.be/abc123",Links.extract("Watch this: https://youtu.be/abc123"));
        assertEquals("https://www.youtube.com/playlist?list=PL123",Links.extract("https://www.youtube.com/playlist?list=PL123"));
        assertEquals("https://m.youtube.com/watch?v=abc",Links.extract("http://m.youtube.com/watch?v=abc."));
    }
    @Test public void rejectsLookalikeHostsAndCredentials(){
        for(String link:new String[]{"https://youtube.com.evil.test/watch?v=a","https://notyoutube.com/a","https://youtube.com@evil.test/a","file:///sdcard/private","hello"}) {
            try{Links.extract(link);fail(link);}catch(IllegalArgumentException expected){}
        }
    }
    @Test public void findsYoutubeAfterAnUnrelatedLink(){assertEquals("https://youtu.be/abc",Links.extract("https://example.com then https://youtu.be/abc"));}
    @Test public void distinguishesSharedPlaylistsFromSingleVideos(){assertTrue(Links.isPlaylist("https://www.youtube.com/playlist?list=PL123"));assertTrue(Links.isPlaylist("https://www.youtube.com/watch?v=abc&list=RDabc"));assertFalse(Links.isPlaylist("https://youtu.be/abc?t=3"));assertFalse(Links.isPlaylist("https://youtube.com/watch?v=list=abc"));}
    @Test public void shortcutsOnlyAcceptMediaLinks(){assertTrue(Links.isMediaLink("https://youtu.be/aqz-KE-bpKQ"));assertTrue(Links.isMediaLink("https://www.youtube.com/watch?v=aqz-KE-bpKQ&si=share"));assertTrue(Links.isMediaLink("https://www.youtube.com/playlist?list=PL123"));assertFalse(Links.isMediaLink("https://www.youtube.com/@creator"));assertFalse(Links.isMediaLink("https://www.youtube.com/channel/UC123456789"));assertFalse(Links.isMediaLink("https://example.com/watch?v=aqz-KE-bpKQ"));}
}
