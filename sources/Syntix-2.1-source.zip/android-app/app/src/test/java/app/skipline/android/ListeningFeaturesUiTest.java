package app.skipline.android;

import android.graphics.*;
import android.view.*;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import org.robolectric.android.controller.ActivityController;
import java.io.*;
import static org.junit.Assert.*;

/** Native View rendering evidence only; not an emulator/device capture or audio hardware test. */
@RunWith(RobolectricTestRunner.class)
@Config(sdk=31,application=ListeningFeaturesUiTest.UiApp.class,qualifiers="w393dp-h852dp-mdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@androidx.media3.common.util.UnstableApi
public class ListeningFeaturesUiTest {
    public static class UiApp extends SkiplineApp {@Override public void onCreate(){profiles=new LocalProfiles(this);offline=new OfflineStore(this,profiles.active);history=new ListeningHistory(this);}@Override void warmStream(Track track){}}
    @Test public void sevenNativeBandsExposeEditableAccessibilityRangesAndRender()throws Exception{
        try(ActivityController<MainActivity> controller=Robolectric.buildActivity(MainActivity.class).create().visible()){
            MainActivity a=controller.get();a.welcome=false;a.page="equalizer";a.refresh();assertEquals(7,countBands(a.root));
            EqualizerScreen.Band band=findBand(a.root);AccessibilityNodeInfo node=band.createAccessibilityNodeInfo();assertNotNull(node.getRangeInfo());assertEquals(-12,node.getRangeInfo().getMin(),0);assertEquals(12,node.getRangeInfo().getMax(),0);int previous=band.value;assertTrue(band.performAccessibilityAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD,null));assertEquals(previous+1,band.value);assertEquals(previous+1,a.app.prefs("sound").getInt("band_0",-100));capture(a,"equalizer-native-test.png");
            a.page="sleep";a.refresh();assertNotNull(findText(a.root,"End of song"));assertNotNull(a.root.findViewWithTag("sleep_remaining"));capture(a,"sleep-native-test.png");
            findText(a.root,"Custom duration · 30 min").performClick();assertEquals(1,a.activeSheets.size());com.google.android.material.bottomsheet.BottomSheetDialog durationDialog=a.activeSheets.get(a.activeSheets.size()-1);View durationSheet=durationDialog.getWindow().getDecorView();((NumberPicker)findDescription(durationSheet,"Hours")).setValue(2);((NumberPicker)findDescription(durationSheet,"Minutes")).setValue(15);findText(durationSheet,"Set duration").performClick();Shadows.shadowOf(android.os.Looper.getMainLooper()).idleFor(java.time.Duration.ofSeconds(1));assertEquals(135,a.sleepDraftMinutes);assertFalse("Custom duration sheet must close",durationDialog.isShowing());capture(a,"sleep-custom-native-test.png");
            SleepTimerScreen.clockPicker(a);android.app.TimePickerDialog clock=(android.app.TimePickerDialog)org.robolectric.shadows.ShadowDialog.getLatestDialog();clock.updateTime(10,30);clock.getButton(android.content.DialogInterface.BUTTON_POSITIVE).performClick();assertEquals(10,a.sleepClockHour);assertEquals(30,a.sleepClockMinute);assertEquals(1,a.sleepDraftMode);capture(a,"sleep-clock-native-test.png");
            a.page="downloads";a.refresh();capture(a,"downloads-native-test.png");findDescription(a.root,"Download quality").performClick();com.google.android.material.bottomsheet.BottomSheetDialog qualityDialog=a.activeSheets.get(a.activeSheets.size()-1);assertTrue(qualityDialog.isShowing());View sheet=qualityDialog.getWindow().getDecorView();assertNotNull(findText(sheet,"Standard · 128 kbps"));findText(sheet,"Standard · 128 kbps").performClick();assertEquals(128,a.app.offline.bitrate());findText(sheet,"Done").performClick();Shadows.shadowOf(android.os.Looper.getMainLooper()).idleFor(java.time.Duration.ofSeconds(1));assertFalse("Quality sheet must close after Done",qualityDialog.isShowing());
            android.content.res.Configuration config=new android.content.res.Configuration(a.getResources().getConfiguration());config.fontScale=1.3f;a.getResources().updateConfiguration(config,a.getResources().getDisplayMetrics());a.page="equalizer";a.refresh();capture(a,"equalizer-large-text-native-test.png");
        }
    }
    @Test public void removedNavigationIsAbsentAndResetPreservesUnrelatedPreferences(){
        try(ActivityController<MainActivity> controller=Robolectric.buildActivity(MainActivity.class).create().visible()){
            MainActivity a=controller.get();a.welcome=false;a.page="home";a.refresh();NativeScreens.drawer(a);assertNull(findText(a.drawerPanel,"Preview welcome"));assertNull(findText(a.drawerPanel,"Syntix Replay"));assertNull(findText(a.drawerPanel,"Settings and privacy"));assertNotNull(findText(a.drawerPanel,"Sleep timer"));android.view.View row=(android.view.View)findText(a.drawerPanel,"Sleep timer").getParent().getParent();assertTrue(row.getBackground() instanceof android.graphics.drawable.RippleDrawable);a.app.prefs("sound").edit().putInt("volume",42).putInt("saved_0",7).putBoolean("sleep_fade",false).putInt("band_0",8).commit();SoundSettings.reset(a.app);assertEquals(42,a.app.prefs("sound").getInt("volume",0));assertEquals(7,a.app.prefs("sound").getInt("saved_0",0));assertFalse(a.app.prefs("sound").getBoolean("sleep_fade",true));assertEquals(0,SoundSettings.bands(a.app)[0]);
        }
    }
    @Test public void createUsesOneProviderDetectingImportOption(){
        try(ActivityController<MainActivity> controller=Robolectric.buildActivity(MainActivity.class).create().visible()){
            MainActivity a=controller.get();a.welcome=false;NativeScreens.createSheet(a);
            View menu=a.activeSheets.get(a.activeSheets.size()-1).getWindow().getDecorView();
            assertNotNull(findText(menu,"Import playlist"));assertNull(findText(menu,"Import Spotify playlist"));assertNull(findText(menu,"Import YouTube playlist"));assertNotNull(findText(menu,"Import YouTube or Spotify song"));
            for(com.google.android.material.bottomsheet.BottomSheetDialog d:new java.util.ArrayList<>(a.activeSheets))d.dismiss();
            for(String link:new String[]{"https://open.spotify.com/playlist/54ZA9LXFvvFujmOVWXpHga","https://www.youtube.com/playlist?list=PLtest"}){
                a.pasteSheet(link);com.google.android.material.bottomsheet.BottomSheetDialog dialog=a.activeSheets.get(a.activeSheets.size()-1);View sheet=dialog.getWindow().getDecorView();assertNotNull(findText(sheet,link));assertNotNull(findText(sheet,"Paste a YouTube link or a public Spotify playlist link."));dialog.dismiss();
            }
        }
    }
    @Test public void spotifyAutomaticallySavesAndOpensMatchedPlaylistWithoutCsvOrReview()throws Exception{
        try(ActivityController<MainActivity> controller=Robolectric.buildActivity(MainActivity.class).create().visible()){
            MainActivity a=controller.get();a.welcome=false;
            SpotifyImport.showLink(a,null);View sheet=a.activeSheets.get(a.activeSheets.size()-1).getWindow().getDecorView();
            assertNotNull(findText(sheet,"Import playlist"));assertNull(findText(sheet,"Import track-list CSV"));
            for(com.google.android.material.bottomsheet.BottomSheetDialog d:new java.util.ArrayList<>(a.activeSheets))d.dismiss();Shadows.shadowOf(android.os.Looper.getMainLooper()).idle();
            SpotifyImport.Job job=finishedSpotifyJob(a.app);a.app.spotifyImport=job;a.page="spotify-import";a.refresh();
            assertNotNull(findText(a.root,"3 available out of 715 items"));assertNull(findText(a.root,"Review & save matched songs"));capture(a,"spotify-auto-import-native-fixture.png");
            SpotifyImport.complete(a.app,job);SpotifyImport.complete(a.app,job);assertEquals(1,a.app.library.size());assertEquals(1,job.saved.tracks.size());assertTrue(job.summary.contains("2 unmatched or duplicate entries skipped"));assertTrue(job.summary.contains("3 of 715"));
            a.refresh();assertEquals("library",a.page);assertSame(job.saved,a.selectedPlaylist);assertNull(a.app.spotifyImport);assertEquals(0,a.activeSheets.size());Shadows.shadowOf(android.os.Looper.getMainLooper()).idle();
            androidx.appcompat.app.AlertDialog result=(androidx.appcompat.app.AlertDialog)org.robolectric.shadows.ShadowDialog.getLatestDialog();assertTrue(result.isShowing());assertNotNull(findText(result.getWindow().getDecorView(),"Playlist imported"));assertNotNull(findText(result.getWindow().getDecorView(),"Songs imported: 1\nSongs skipped: 2\n\nSpotify exposed 3 of 715 items."));result.getButton(android.content.DialogInterface.BUTTON_POSITIVE).performClick();Shadows.shadowOf(android.os.Looper.getMainLooper()).idle();assertFalse(result.isShowing());a.refresh();Shadows.shadowOf(android.os.Looper.getMainLooper()).idle();assertFalse(result.isShowing());

        }
    }
    @Test public void spotifyImportWithNoSkippedSongsOpensWithoutPopup(){
        try(ActivityController<MainActivity> controller=Robolectric.buildActivity(MainActivity.class).create().visible()){
            MainActivity a=controller.get();a.welcome=false;SpotifyImport.Job job=finishedSpotifyJob(a.app);job.rows.remove(2);job.rows.remove(1);job.data.songs.subList(1,job.data.songs.size()).clear();job.data.total=1;a.app.spotifyImport=job;a.page="spotify-import";
            android.app.Dialog previous=org.robolectric.shadows.ShadowDialog.getLatestDialog();SpotifyImport.complete(a.app,job);a.refresh();Shadows.shadowOf(android.os.Looper.getMainLooper()).idle();assertEquals(0,job.skippedCount);assertSame(previous,org.robolectric.shadows.ShadowDialog.getLatestDialog());assertSame(job.saved,a.selectedPlaylist);
        }
    }
    @Test public void cancelledWrongProfileAndUnmatchedImportsDoNotSave(){
        SkiplineApp app=(SkiplineApp)org.robolectric.RuntimeEnvironment.getApplication();SpotifyImport.Job job=finishedSpotifyJob(app);app.spotifyImport=job;job.cancelled=true;SpotifyImport.complete(app,job);assertTrue(app.library.isEmpty());
        job.cancelled=false;SpotifyImport.Job other=new SpotifyImport.Job("another-profile");other.data=job.data;other.rows.addAll(job.rows);app.spotifyImport=other;SpotifyImport.complete(app,other);assertTrue(app.library.isEmpty());app.spotifyImport=job;app.taskDismissed=true;SpotifyImport.complete(app,job);assertTrue(app.library.isEmpty());app.taskDismissed=false;
        job.rows.get(0).match=null;job.rows.get(1).match=null;SpotifyImport.complete(app,job);assertTrue(app.library.isEmpty());assertTrue(job.error.contains("No reliable matches"));
    }
    private static SpotifyImport.Job finishedSpotifyJob(SkiplineApp app){
        SpotifyImport.Job job=new SpotifyImport.Job(app.profiles.active);job.data=new SpotifyPlaylist.Data();job.data.name="Test playlist";job.data.total=715;
        for(int i=0;i<3;i++){SpotifyPlaylist.Song song=new SpotifyPlaylist.Song("Test song "+i,"Test artist",180000,"");job.data.songs.add(song);SpotifyImport.Row row=new SpotifyImport.Row(song);row.attempted=true;job.rows.add(row);}
        job.rows.get(0).match=new Track("https://www.youtube.com/watch?v=abcdefghijk","Matched recording","YouTube artist","",181);job.rows.get(1).match=job.rows.get(0).match.copy();return job;
    }
    private static View findDescription(View view,String label){if(label.contentEquals(view.getContentDescription()==null?"":view.getContentDescription()))return view;if(view instanceof ViewGroup)for(int i=0;i<((ViewGroup)view).getChildCount();i++){View found=findDescription(((ViewGroup)view).getChildAt(i),label);if(found!=null)return found;}return null;}
    private static int countBands(View view){int n=view instanceof EqualizerScreen.Band?1:0;if(view instanceof ViewGroup)for(int i=0;i<((ViewGroup)view).getChildCount();i++)n+=countBands(((ViewGroup)view).getChildAt(i));return n;}
    private static EqualizerScreen.Band findBand(View view){if(view instanceof EqualizerScreen.Band)return (EqualizerScreen.Band)view;if(view instanceof ViewGroup)for(int i=0;i<((ViewGroup)view).getChildCount();i++){EqualizerScreen.Band found=findBand(((ViewGroup)view).getChildAt(i));if(found!=null)return found;}return null;}
    private static TextView findText(View view,String text){if(view instanceof TextView&&((TextView)view).getText().toString().equals(text))return (TextView)view;if(view instanceof ViewGroup)for(int i=0;i<((ViewGroup)view).getChildCount();i++){TextView found=findText(((ViewGroup)view).getChildAt(i),text);if(found!=null)return found;}return null;}
    private static void capture(MainActivity a,String name)throws Exception{String path=System.getProperty("syntix.reviewDir");if(path==null)return;a.root.forceLayout();a.root.measure(View.MeasureSpec.makeMeasureSpec(393,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(852,View.MeasureSpec.EXACTLY));a.root.layout(0,0,393,852);a.root.getViewTreeObserver().dispatchOnGlobalLayout();a.root.getViewTreeObserver().dispatchOnPreDraw();Bitmap image=Bitmap.createBitmap(393,852,Bitmap.Config.ARGB_8888);a.root.draw(new Canvas(image));File dir=new File(path);if(!dir.exists()&&!dir.mkdirs())throw new IOException("Could not create review directory");try(FileOutputStream out=new FileOutputStream(new File(dir,name))){image.compress(Bitmap.CompressFormat.PNG,100,out);}finally{image.recycle();}}
}
