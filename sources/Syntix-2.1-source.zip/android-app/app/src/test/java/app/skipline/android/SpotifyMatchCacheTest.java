package app.skipline.android;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.Config;
import android.content.Context;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class)
@Config(sdk=31,application=ListeningFeaturesUiTest.UiApp.class)
public class SpotifyMatchCacheTest {
    private SpotifyPlaylist.Song song(String title){return new SpotifyPlaylist.Song(title,"Sidhu Moose Wala, Sunny Malton",284000,"");}
    private Track track(String title){return new Track("https://www.youtube.com/watch?v=abcdefghijk",title,"Sidhu Moose Wala","",284);}
    @Test public void cachedMatchSurvivesNewLookupButExpiresAndReturnsFreshQueueIdentity(){
        Context c=RuntimeEnvironment.getApplication();SpotifyPlaylist.Song song=song("Just Listen");Track original=track("Just Listen");SpotifyMatchCache.put(c,song,original,1000);
        Track cached=SpotifyMatchCache.get(c,song,1001);assertNotNull(cached);assertEquals(original.source,cached.source);assertNotEquals(original.id,cached.id);assertNull(SpotifyMatchCache.get(c,song,1000+SpotifyMatchCache.TTL));
    }
    @Test public void unrelatedOrWrongVersionResultsAreNotCached(){Context c=RuntimeEnvironment.getApplication();SpotifyMatchCache.put(c,song("Just Listen"),track("Unrelated track"),1000);assertNull(SpotifyMatchCache.get(c,song("Just Listen"),1001));SpotifyMatchCache.put(c,song("Just Listen"),track("Just Listen COVER"),1000);assertNull(SpotifyMatchCache.get(c,song("Just Listen"),1001));}
    @Test public void cacheIsBoundedAndDoesNotStoreAudio()throws Exception{Context c=RuntimeEnvironment.getApplication();android.content.SharedPreferences p=c.getSharedPreferences("spotify_recording_matches_v2",Context.MODE_PRIVATE);android.content.SharedPreferences.Editor fixture=p.edit();for(int i=0;i<SpotifyMatchCache.LIMIT;i++)fixture.putString("fixture-"+i,new org.json.JSONObject().put("time",1000+i).put("track",track("Track "+i).json()).toString());assertTrue(fixture.commit());SpotifyMatchCache.put(c,song("Track 512"),track("Track 512"),2000);SpotifyMatchCache.put(c,song("Track 513"),track("Track 513"),2001);assertEquals(SpotifyMatchCache.LIMIT,p.getAll().size());assertFalse(p.contains("fixture-0"));assertFalse(p.contains("fixture-1"));assertNotNull(SpotifyMatchCache.get(c,song("Track 513"),2002));}
}
