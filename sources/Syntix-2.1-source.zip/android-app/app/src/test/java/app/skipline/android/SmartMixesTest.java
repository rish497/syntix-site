package app.skipline.android;

import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.Config;
import org.json.*;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class)
@Config(sdk=31,application=SmartMixesTest.HistoryApp.class)
public class SmartMixesTest {
    public static class HistoryApp extends SkiplineApp {@Override public void onCreate(){profiles=new LocalProfiles(this);}}
    private SkiplineApp app;private long now=System.currentTimeMillis();
    @Before public void setup(){app=(SkiplineApp)RuntimeEnvironment.getApplication();app.prefs("history").edit().clear().commit();}
    private JSONObject entry(String title,int plays,int daysAgo,int night,int discoveredDays)throws Exception{return new JSONObject().put("track",new Track("https://youtube.com/watch?v="+title,title,"Artist","",180000).json()).put("plays",plays).put("last",now-daysAgo*86400000L).put("night",night).put("first",discoveredDays<0?0:now-discoveredDays*86400000L);}
    private ListeningHistory history(JSONObject... entries){JSONArray array=new JSONArray();for(JSONObject e:entries)array.put(e);app.prefs("history").edit().putString("plays",array.toString()).commit();return new ListeningHistory(app);}
    @Test public void mixesHaveDistinctObservedRules()throws Exception{ListeningHistory h=history(entry("Popular",12,0,0,40),entry("Night",2,1,2,10),entry("Forgotten",3,20,0,50),entry("New",1,0,0,1));assertEquals("Popular",SmartMixes.tracks(h,"Most Played",now).get(0).title);assertEquals("Night",SmartMixes.tracks(h,"Late Night",now).get(0).title);assertEquals(1,SmartMixes.tracks(h,"Forgotten Favorites",now).size());assertEquals("Forgotten",SmartMixes.tracks(h,"Forgotten Favorites",now).get(0).title);assertEquals("New",SmartMixes.tracks(h,"Recently Discovered",now).get(0).title);}
    @Test public void legacyCountsNeverInventDiscoveryOrNightPlays()throws Exception{ListeningHistory h=history(entry("Legacy",15,10,0,-1));assertTrue(SmartMixes.tracks(h,"Late Night",now).isEmpty());assertTrue(SmartMixes.tracks(h,"Recently Discovered",now).isEmpty());h.record(h.recent().get(0));assertEquals(0,h.entries().get(0).first);}
    @Test public void newFirstListenPersistsWithoutMovingOnRepeat(){ListeningHistory h=history();Track track=new Track("https://youtube.com/watch?v=actual","Actual song","Artist","",1000);h.record(track);long first=h.entries().get(0).first;assertTrue(first>0);h.record(track);ListeningHistory reopened=new ListeningHistory(app);assertEquals(first,reopened.entries().get(0).first);assertEquals(2,reopened.entries().get(0).plays);}
    @Test public void anotherProfileHasNoSeededHistory()throws Exception{history(entry("Private",4,0,1,0));LocalProfiles.Profile other=app.profiles.add("Other");app.profiles.active=other.id;assertTrue(new ListeningHistory(app).recent().isEmpty());}
    @Test public void fortyNineSongsNeverExposeAMixButFiftyDo()throws Exception{JSONObject[] rows=new JSONObject[50];for(int i=0;i<50;i++)rows[i]=entry("Song"+i,2,10,1,12);assertTrue(SmartMixes.available(history(java.util.Arrays.copyOf(rows,49)),now).isEmpty());assertEquals(4,SmartMixes.available(history(rows),now).size());}
    @Test public void eachMixMustMeetItsOwnThreshold()throws Exception{JSONObject[] rows=new JSONObject[50];for(int i=0;i<50;i++)rows[i]=entry("Song"+i,1,0,i==49?0:1,40);java.util.LinkedHashMap<String,java.util.ArrayList<Track>> available=SmartMixes.available(history(rows),now);assertEquals(1,available.size());assertTrue(available.containsKey("Most Played"));}
    @Test public void repeatedSourcesCannotInflateTheThreshold()throws Exception{JSONObject[] rows=new JSONObject[50];for(int i=0;i<50;i++)rows[i]=entry("SameSong",3,10,1,12);assertTrue(SmartMixes.available(history(rows),now).isEmpty());}
}
