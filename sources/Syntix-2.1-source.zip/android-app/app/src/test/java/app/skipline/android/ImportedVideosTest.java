package app.skipline.android;

import android.app.Application;
import android.content.SharedPreferences;
import java.io.File;
import java.util.Arrays;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.Config;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class)
@Config(sdk=31,manifest=Config.NONE,application=Application.class)
public class ImportedVideosTest {
    private Application context;
    @Before public void setup(){context=RuntimeEnvironment.getApplication();}
    private Track track(String id){return new Track("https://www.youtube.com/watch?v="+id,"Imported title","Creator","",183);}
    @Test public void importsPersistAndDoNotDuplicateOrLeakToOtherProfiles(){
        SharedPreferences first=context.getSharedPreferences("videos_first",0),second=context.getSharedPreferences("videos_second",0);first.edit().clear().commit();second.edit().clear().commit();
        Track t=track("abcdefghijk");assertTrue(ImportedVideos.add(first,t));assertFalse(ImportedVideos.add(first,t.copy()));
        assertEquals(1,ImportedVideos.read(first).size());assertEquals(183,ImportedVideos.read(first).get(0).duration);assertTrue(ImportedVideos.read(second).isEmpty());
        ImportedVideos.add(first,track("zyxwvutsrqp"));assertEquals("https://www.youtube.com/watch?v=zyxwvutsrqp",ImportedVideos.read(first).get(0).source);
    }
    @Test public void offlineQueueDeduplicatesAndCompletionSurvivesReopen() throws Exception {
        String profile="v9_download_test";context.getSharedPreferences("offline_"+profile,0).edit().clear().commit();OfflineStore store=new OfflineStore(context,profile);
        Track a=track("abcdefghijk"),b=track("zyxwvutsrqp");store.enqueue(Arrays.asList(a,a.copy(),b));assertEquals(2,store.remaining());assertEquals(1,store.pendingFor(Arrays.asList(a)));
        assertTrue(store.directory.isDirectory()||store.directory.mkdirs());File file=new File(store.directory,OfflineStore.key(a.source)+".opus");try(java.io.FileOutputStream out=new java.io.FileOutputStream(file)){out.write(new byte[]{1,2,3});}
        store.complete(a,file);OfflineStore reopened=new OfflineStore(context,profile);assertEquals(1,reopened.remaining());assertEquals(1,reopened.ready(Arrays.asList(a,b)));assertNotNull(reopened.file(a.source));assertEquals(1,reopened.pendingFor(Arrays.asList(a,b)));reopened.clear();
    }
}
