package app.skipline.android;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.Config;
import org.robolectric.android.controller.ActivityController;
import android.view.*;
import android.widget.TextView;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class)
@Config(sdk=31,application=ListeningFeaturesUiTest.UiApp.class,qualifiers="w393dp-h852dp-mdpi")
@androidx.media3.common.util.UnstableApi
public class SpotifyProgressTest {
    @Test public void incrementalMatchesKeepScreenScrollAndUnchangedSongViewsInPlace(){
        try(ActivityController<MainActivity> c=Robolectric.buildActivity(MainActivity.class).create().visible()){
            MainActivity a=c.get();a.welcome=false;a.page="spotify-import";a.app.listeners.add(a.refresh);SpotifyImport.Job job=attach(a.app);job.running=true;a.refresh();
            View host=a.root.getChildAt(0);android.widget.ScrollView scroll=a.bodyScroll;SpotifyProgress.Binding binding=a.spotifyBinding;TextView unchanged=text(a.root,"Song 1");View pending=binding.rows.get(job.rows.get(0)).holder.getChildAt(0);scroll.scrollTo(0,120);int position=scroll.getScrollY();
            job.rows.get(0).match=track(0);job.rows.get(0).attempted=true;SpotifyProgress.persist(a.app,job);
            assertSame(host,a.root.getChildAt(0));assertSame(scroll,a.bodyScroll);assertSame(binding,a.spotifyBinding);assertSame(unchanged,text(a.root,"Song 1"));assertNotSame(pending,binding.rows.get(job.rows.get(0)).holder.getChildAt(0));assertEquals(position,scroll.getScrollY());assertNotNull(text(a.root,"Finding songs · 1 of 3"));a.app.listeners.remove(a.refresh);
        }
    }
    @Test public void resolvedOrUnavailablePrioritySongDoesNotStallOtherMetadataSearches(){
        SkiplineApp app=(SkiplineApp)RuntimeEnvironment.getApplication();SpotifyImport.Job job=attach(app);SpotifyImport.Row wanted=job.rows.get(2),other=job.rows.get(0);SpotifyImport.prioritize(job,wanted);assertTrue(SpotifyImport.yieldsToRequested(job,other));assertFalse(SpotifyImport.yieldsToRequested(job,wanted));wanted.match=track(2);assertFalse(SpotifyImport.yieldsToRequested(job,other));wanted.match=null;wanted.error="Search unavailable";assertFalse(SpotifyImport.yieldsToRequested(job,other));SpotifyImport.prioritize(job,wanted);assertTrue(SpotifyImport.yieldsToRequested(job,other));
    }
    @Test public void listeningMetadataDoesNotRebuildTheOpenPlaylist(){
        try(ActivityController<MainActivity> c=Robolectric.buildActivity(MainActivity.class).create().visible()){
            MainActivity a=c.get();a.welcome=false;a.page="spotify-import";SpotifyImport.Job job=attach(a.app);job.running=true;a.refresh();a.app.listeners.add(a.refresh);
            View host=a.root.getChildAt(0);android.widget.ScrollView scroll=a.bodyScroll;SpotifyProgress.Binding binding=a.spotifyBinding;
            a.app.listeningChanged();assertSame(host,a.root.getChildAt(0));assertSame(scroll,a.bodyScroll);assertSame(binding,a.spotifyBinding);assertFalse(a.app.listeningUpdate);
            a.app.listeners.remove(a.refresh);
        }
    }
    private SpotifyPlaylist.Data data(){SpotifyPlaylist.Data d=new SpotifyPlaylist.Data();d.name="Quick playlist";d.source="https://open.spotify.com/playlist/54ZA9LXFvvFujmOVWXpHga";d.total=3;for(int i=0;i<3;i++)d.songs.add(new SpotifyPlaylist.Song("Song "+i,"Artist One",180000,"spotify:track:"+String.format(java.util.Locale.ROOT,"%022d",i)));return d;}
    private Track track(int i){return new Track("https://www.youtube.com/watch?v=aaaaaaaaaa"+i,"Song "+i,"Artist One","",180);}
    private SpotifyImport.Job attach(SkiplineApp app){SpotifyImport.Job job=new SpotifyImport.Job(app.profiles.active);app.spotifyImport=job;SpotifyProgress.attach(app,job,data());return job;}
    @Test public void playlistOpensWithAllMetadataBeforeAnySongHasBeenMatched(){
        try(ActivityController<MainActivity> c=Robolectric.buildActivity(MainActivity.class).create().visible()){
            MainActivity a=c.get();a.welcome=false;a.page="spotify-import";SpotifyImport.Job job=attach(a.app);job.running=true;a.refresh();
            assertEquals("library",a.page);assertSame(job.target,a.selectedPlaylist);assertEquals(1,a.app.library.size());assertTrue(job.target.tracks.isEmpty());assertTrue(a.app.queue.isEmpty());assertEquals(3,SpotifyProgress.total(job.target));assertNotNull(text(a.root,"Song 0"));assertNotNull(text(a.root,"Song 1"));assertNotNull(text(a.root,"Song 2"));assertNotNull(text(a.root,"Finding songs · 0 of 3"));
        }
    }
    @Test public void partialProgressSurvivesSerializationAndKeepsPlayableMediaIdsStable()throws Exception{
        SkiplineApp app=(SkiplineApp)RuntimeEnvironment.getApplication();SpotifyImport.Job job=attach(app);job.rows.get(2).match=track(2);job.rows.get(2).attempted=true;SpotifyProgress.persist(app,job);app.setPlayingPlaylist(job.target);PlaylistQueue.replace(app.queue,job.target.tracks);String playingId=app.queue.get(0).id;
        job.rows.get(0).match=track(0);job.rows.get(0).attempted=true;SpotifyProgress.persist(app,job);assertEquals(track(0).source,app.queue.get(0).source);assertEquals(playingId,app.queue.get(1).id);assertEquals(3,SpotifyProgress.total(job.target));
        SavedPlaylist disk=SavedPlaylist.fromJson(new org.json.JSONObject(job.target.json().toString()));SpotifyImport.Job restored=SpotifyProgress.restore(disk,app.profiles.active);assertNotNull(restored);assertEquals(1,restored.pending());assertEquals(2,restored.matched());assertSame(disk.tracks.get(0),restored.rows.get(0).match);assertEquals("9 min",SpotifyProgress.duration(disk));
        job.rows.get(1).match=track(1);job.rows.get(1).attempted=true;SpotifyProgress.persist(app,job);SpotifyImport.complete(app,job);assertEquals(1,app.library.size());assertSame(job.target,job.saved);assertNull(job.target.spotifyDraft);assertEquals(3,job.target.tracks.size());assertEquals(0,job.skippedCount);
    }
    @Test public void tappedSongAndFollowingSongsMoveAheadOfTheCurrentBackgroundOrder(){
        SkiplineApp app=(SkiplineApp)RuntimeEnvironment.getApplication();SpotifyImport.Job job=attach(app);job.current=job.rows.get(0);SpotifyImport.prioritize(job,job.rows.get(2));assertSame(job.rows.get(2),job.wanted);assertSame(job.rows.get(2),job.todo.pollFirst());assertSame(job.rows.get(1),job.todo.pollFirst());assertNull(job.todo.pollFirst());job.cancel();assertNull(job.wanted);
    }
    @Test public void aLaterPlaySelectionPreventsAnEarlierPendingSongFromTakingOver(){
        try(ActivityController<MainActivity> c=Robolectric.buildActivity(MainActivity.class).create().visible()){
            MainActivity a=c.get();a.welcome=false;SpotifyImport.Job job=attach(a.app);job.wanted=job.rows.get(2);Track other=new Track("https://www.youtube.com/watch?v=bbbbbbbbbbb","Different song","Other Artist","",180);a.playTrack(other);String requested=a.pendingPlay;assertNull(job.wanted);job.rows.get(2).match=track(2);job.rows.get(2).attempted=true;SpotifyProgress.persist(a.app,job);a.refresh();assertEquals(requested,a.pendingPlay);assertEquals(1,a.app.queue.size());assertEquals(other.source,a.app.queue.get(0).source);
        }
    }
    @Test public void removingAndUndoingAReadySongDuringImportDoesNotReintroduceIt()throws Exception{
        SkiplineApp app=(SkiplineApp)RuntimeEnvironment.getApplication();SpotifyImport.Job job=attach(app);job.rows.get(0).match=track(0);job.rows.get(0).attempted=true;SpotifyProgress.persist(app,job);Track ready=job.target.tracks.get(0);SpotifyProgress.membership(app,job.target,ready,true);job.target.tracks.remove(ready);SpotifyProgress.persist(app,job);assertTrue(job.target.tracks.isEmpty());assertTrue(job.rows.get(0).skipped);job.target.tracks.add(ready);SpotifyProgress.membership(app,job.target,ready,false);SpotifyProgress.persist(app,job);assertEquals(1,job.target.tracks.size());assertFalse(job.rows.get(0).skipped);
        app.library.remove(job.target);SpotifyProgress.persist(app,job);for(int i=0;i<3;i++){job.rows.get(i).match=track(i);job.rows.get(i).attempted=true;}SpotifyImport.complete(app,job);assertTrue(app.library.isEmpty());
    }
    private static TextView text(View view,String expected){if(view instanceof TextView&&((TextView)view).getText().toString().equals(expected))return (TextView)view;if(view instanceof ViewGroup)for(int i=0;i<((ViewGroup)view).getChildCount();i++){TextView found=text(((ViewGroup)view).getChildAt(i),expected);if(found!=null)return found;}return null;}
}
