package app.skipline.android;

import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.android.controller.ActivityController;
import org.robolectric.annotation.Config;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class)
@Config(sdk=31,application=ListeningFeaturesUiTest.UiApp.class,qualifiers="w393dp-h852dp-mdpi")
@androidx.media3.common.util.UnstableApi
public class PrivacyLegalTest {
    @Test public void profileEntryOpensOnlyRequiredRowsAndBundledDocuments()throws Exception{
        try(ActivityController<MainActivity> c=Robolectric.buildActivity(MainActivity.class).create().visible()){
            MainActivity a=c.get();a.welcome=false;a.page="home";a.refresh();String profile=a.app.profiles.active;int playlists=a.app.library.size(),queue=a.app.queue.size();
            NativeScreens.drawer(a);TextView entry=find(a.drawerPanel,"Privacy & About");assertNotNull(entry);((View)entry.getParent().getParent()).performClick();
            View sheet=latest(a);assertNotNull(find(sheet,PrivacyLegal.SUMMARY));assertNotNull(find(sheet,"Privacy Policy"));assertNotNull(find(sheet,"Terms of Use"));assertNull(find(sheet,"Clear data"));
            assertTrue(find(sheet,"Privacy Policy").performClick());assertNotNull(find(latest(a),"Information sent to external services"));assertTrue(PrivacyLegal.read(a,"PRIVACY_POLICY.md").contains("Profiles are not password-protected"));
            a.activeSheets.get(a.activeSheets.size()-1).dismiss();find(sheet,"Terms of Use").performClick();assertNotNull(find(latest(a),"Content and personal use"));
            assertEquals(profile,a.app.profiles.active);assertEquals(playlists,a.app.library.size());assertEquals(queue,a.app.queue.size());assertFalse(a.app.busy);
        }
    }
    @Test public void existingSettingsReusesTheSectionWithoutDuplicatingPrivacyRow(){
        try(ActivityController<MainActivity> c=Robolectric.buildActivity(MainActivity.class).create().visible()){
            MainActivity a=c.get();a.legacySettings();View sheet=latest(a);assertNotNull(find(sheet,"Privacy & About"));assertNotNull(find(sheet,"Privacy Policy"));assertNotNull(find(sheet,"Terms of Use"));assertNull(find(sheet,"Privacy"));assertNotNull(find(sheet,"Update playback engine"));assertNotNull(find(sheet,"Export playlists"));
        }
    }
    @Test public void bundledAgeTermsAndOfflineNoticesMatchTheRelease()throws Exception{
        try(ActivityController<MainActivity> c=Robolectric.buildActivity(MainActivity.class).create().visible()){
            MainActivity a=c.get();assertTrue(Onboarding.CONSENT.contains("13+"));
            for(String name:new String[]{"PRIVACY_POLICY.md","TERMS_OF_USE.md"}){String text=PrivacyLegal.read(a,name);assertTrue(text.contains("13+"));assertFalse(text.contains("intends Syntix for all ages"));}
            String notices=PrivacyLegal.read(a,"THIRD_PARTY_NOTICES.md");assertTrue(notices.contains("Apache License"));assertTrue(notices.contains("Phosphor"));assertTrue(notices.contains("QuickJS"));assertTrue(notices.contains("GNU GENERAL PUBLIC LICENSE"));
        }
    }
    private static View latest(MainActivity a){return a.activeSheets.get(a.activeSheets.size()-1).getWindow().getDecorView();}
    private static TextView find(View view,String text){if(view instanceof TextView&&((TextView)view).getText().toString().equals(text))return (TextView)view;if(view instanceof ViewGroup)for(int i=0;i<((ViewGroup)view).getChildCount();i++){TextView child=find(((ViewGroup)view).getChildAt(i),text);if(child!=null)return child;}return null;}
}
