package app.skipline.android;

import org.json.*;
import org.junit.Test;
import static org.junit.Assert.*;

public class SpotifyEmbedTest {
    @Test public void onlyPublicTrackMetadataIsReadAndIncompleteItemsAreCounted()throws Exception{
        JSONArray songs=new JSONArray().put(new JSONObject().put("uri","spotify:track:one").put("title","Song").put("subtitle","Artist").put("duration",188600)).put(new JSONObject().put("uri","spotify:episode:two").put("title","Episode").put("subtitle","Host"));
        JSONObject entity=new JSONObject().put("type","playlist").put("title","My playlist").put("trackList",songs);JSONObject next=new JSONObject().put("props",new JSONObject().put("pageProps",new JSONObject().put("state",new JSONObject().put("data",new JSONObject().put("entity",entity)))));
        SpotifyPlaylist.Data data=SpotifyPlaylist.parseEmbed("<script type=\"application/json\" id=\"__NEXT_DATA__\">"+next+"</script>");assertEquals(1,data.songs.size());assertEquals(1,data.skipped);assertEquals(188600,data.songs.get(0).durationMs);assertFalse(data.complete());
    }
}
