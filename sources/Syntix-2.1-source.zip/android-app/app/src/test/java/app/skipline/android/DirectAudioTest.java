package app.skipline.android;
import org.junit.Test;import org.json.*;import okhttp3.*;import java.util.concurrent.atomic.AtomicInteger;import static org.junit.Assert.*;
public class DirectAudioTest {
    private JSONObject data()throws Exception{return new JSONObject().put("playabilityStatus",new JSONObject().put("status","OK")).put("videoDetails",new JSONObject().put("videoId","abcdefghijk").put("title","Song").put("author","Artist").put("lengthSeconds",180)).put("streamingData",new JSONObject().put("adaptiveFormats",new JSONArray().put(new JSONObject().put("mimeType","audio/mp4").put("url","https://unit.googlevideo.com/audio").put("bitrate",128000))));}
    @Test public void resolvesAndChecksPublicAudioWithoutAnExtractorProcess()throws Exception{
        YouTubeSession.observe(new JSONObject().put("responseContext",new JSONObject().put("visitorData","test-visitor")));AtomicInteger calls=new AtomicInteger();
        OkHttpClient client=new OkHttpClient.Builder().addInterceptor(chain->{calls.incrementAndGet();boolean media=chain.request().url().host().endsWith(".googlevideo.com");try{if(media)assertEquals("bytes=0-0",chain.request().header("Range"));return new Response.Builder().request(chain.request()).protocol(Protocol.HTTP_1_1).code(media?206:200).message("OK").body(ResponseBody.create(media?"x":data().toString(),MediaType.get(media?"audio/mp4":"application/json"))).build();}catch(Exception e){throw new java.io.IOException(e);}}).build();
        DirectAudio.Data found=DirectAudio.resolve("https://youtu.be/abcdefghijk",client);assertEquals("Artist",found.track.creator);assertEquals(2,calls.get());
    }
    @Test public void rejectsProtectedAndMismatchedResponses()throws Exception{
        JSONObject json=data();json.getJSONObject("streamingData").put("licenseInfos",new JSONArray());try{DirectAudio.parse(json,"abcdefghijk");fail();}catch(java.io.IOException expected){}
        try{DirectAudio.parse(data(),"lmnopqrstuv");fail();}catch(java.io.IOException expected){}
        json=data();json.getJSONObject("streamingData").getJSONArray("adaptiveFormats").getJSONObject(0).put("signatureCipher","encrypted");try{DirectAudio.parse(json,"abcdefghijk");fail();}catch(java.io.IOException expected){}
    }
}
