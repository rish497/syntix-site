package app.skipline.android;

import android.os.Looper;
import androidx.media3.common.Player;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.Config;
import org.robolectric.android.controller.ServiceController;
import java.time.Duration;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class)
@Config(sdk=31,application=ListeningFeaturesUiTest.UiApp.class)
@androidx.media3.common.util.UnstableApi
public class SleepTimerTest {
    private ServiceController<PlaybackService> controller;private PlaybackService service;
    @Before public void setup(){controller=Robolectric.buildService(PlaybackService.class).create();service=controller.get();}
    @After public void close(){controller.destroy();}
    @Test public void timerFadesThenStopsAndRestoresTheUsersVolume(){SkiplineApp app=(SkiplineApp)RuntimeEnvironment.getApplication();app.prefs("sound").edit().putInt("volume",80).commit();service.sleep.start(15,false,true);Shadows.shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMinutes(14).plusSeconds(45));assertEquals(.4,service.player.getVolume(),.04);Shadows.shadowOf(Looper.getMainLooper()).idleFor(Duration.ofSeconds(16));assertFalse(service.sleep.active());assertFalse(service.player.getPlayWhenReady());assertEquals(.8,service.player.getVolume(),.01);assertTrue(service.timerFinished);}
    @Test public void cancellationRemovesTheDeadlineAndRestoresVolume(){service.sleep.start(30,false,true);service.sleep.cancel();assertFalse(service.sleep.active());Shadows.shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMinutes(31));assertFalse(service.timerFinished);}
    @Test public void endOfSongIgnoresManualSeekButStopsAtAutomaticTransition(){service.sleep.start(30,true,true);service.sleep.transition(Player.MEDIA_ITEM_TRANSITION_REASON_SEEK);assertTrue(service.sleep.active());service.sleep.transition(Player.MEDIA_ITEM_TRANSITION_REASON_AUTO);assertFalse(service.sleep.active());assertTrue(service.timerFinished);}
    @Test public void customHoursUseOneMonotonicDeadline(){service.sleep.start(135,false,true);assertEquals(135*60000L,service.sleep.remaining(),1000);assertEquals(0,service.sleep.wallDeadline);}
    @Test public void clockModeExpiresAndCanBeCancelled(){service.sleep.startAt(10,30,true);assertTrue(service.sleep.wallDeadline>System.currentTimeMillis());assertEquals(0,service.sleep.deadline);service.sleep.wallDeadline=System.currentTimeMillis()-1;Shadows.shadowOf(Looper.getMainLooper()).idleFor(Duration.ofSeconds(1));assertFalse(service.sleep.active());assertTrue(service.timerFinished);service.sleep.startAt(10,30,false);service.sleep.cancel();assertEquals(0,service.sleep.wallDeadline);assertFalse(service.sleep.active());}
}
