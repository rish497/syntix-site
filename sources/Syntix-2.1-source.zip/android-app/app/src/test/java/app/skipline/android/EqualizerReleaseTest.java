package app.skipline.android;

import android.graphics.*;
import android.view.*;
import android.widget.*;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import org.robolectric.android.controller.ActivityController;
import java.io.*;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class)
@Config(sdk=29,application=ListeningFeaturesUiTest.UiApp.class,qualifiers="w393dp-h852dp-mdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@androidx.media3.common.util.UnstableApi
public class EqualizerReleaseTest {
    @Test public void approvedGraphUsesExistingBandsAndPresetSettings()throws Exception{
        try(ActivityController<MainActivity> c=Robolectric.buildActivity(MainActivity.class).create().visible()){
            MainActivity a=c.get();a.welcome=false;a.page="equalizer";SoundSettings.preset(a.app,"Rock");a.app.prefs("sound").edit().putInt("bass",18).putInt("space",5).putInt("volume",85).putBoolean("normalize",true).commit();a.refresh();
            EqualizerScreen.Graph graph=findGraph(a.root);assertNotNull(graph);assertEquals(7,graph.bands.length);for(int i=0;i<7;i++)assertEquals(SoundSettings.bands(a.app)[i],graph.bands[i].value);assertEquals("Rock",((TextView)a.root.findViewWithTag("eq_preset_label")).getText().toString());assertNull(a.navBarView);capture(a,"equalizer-0.2.png");
            EqualizerScreen.Band band=graph.bands[0];assertTrue(band.performAccessibilityAction(android.view.accessibility.AccessibilityNodeInfo.ACTION_SCROLL_FORWARD,null));assertEquals(5,a.app.prefs("sound").getInt("band_0",0));assertEquals("Custom",((TextView)a.root.findViewWithTag("eq_preset_label")).getText().toString());assertTrue(a.app.prefs("sound").getBoolean("enabled",false));
            findText(a.root,"Save custom preset").performClick();assertEquals(5,a.app.prefs("sound").getInt("saved_0",0));assertEquals(18,a.app.prefs("sound").getInt("saved_bass",0));SoundSettings.preset(a.app,"Flat");SoundSettings.preset(a.app,"Custom");assertEquals(5,SoundSettings.bands(a.app)[0]);assertEquals(18,a.app.prefs("sound").getInt("bass",0));
        }
    }
    private static EqualizerScreen.Graph findGraph(View v){if(v instanceof EqualizerScreen.Graph)return (EqualizerScreen.Graph)v;if(v instanceof ViewGroup)for(int i=0;i<((ViewGroup)v).getChildCount();i++){EqualizerScreen.Graph found=findGraph(((ViewGroup)v).getChildAt(i));if(found!=null)return found;}return null;}
    private static TextView findText(View v,String s){if(v instanceof TextView&&((TextView)v).getText().toString().equals(s))return (TextView)v;if(v instanceof ViewGroup)for(int i=0;i<((ViewGroup)v).getChildCount();i++){TextView f=findText(((ViewGroup)v).getChildAt(i),s);if(f!=null)return f;}return null;}
    private static void capture(MainActivity a,String name)throws Exception{a.root.measure(View.MeasureSpec.makeMeasureSpec(393,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(852,View.MeasureSpec.EXACTLY));a.root.layout(0,0,393,852);a.root.getViewTreeObserver().dispatchOnPreDraw();Bitmap image=Bitmap.createBitmap(393,852,Bitmap.Config.ARGB_8888);a.root.draw(new Canvas(image));File dir=new File(System.getProperty("syntix.reviewDir","."));dir.mkdirs();try(FileOutputStream out=new FileOutputStream(new File(dir,name))){image.compress(Bitmap.CompressFormat.PNG,100,out);}finally{image.recycle();}}
}
