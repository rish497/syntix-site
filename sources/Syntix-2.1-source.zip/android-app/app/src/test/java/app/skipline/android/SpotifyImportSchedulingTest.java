package app.skipline.android;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.annotation.Config;
import java.util.concurrent.*;
import static org.junit.Assert.*;

/** No network or audio engine: verifies imports yield without blocking the player. */
@RunWith(RobolectricTestRunner.class)
@Config(sdk=31,application=ListeningFeaturesUiTest.UiApp.class)
public class SpotifyImportSchedulingTest {
    @Test public void matchingWaitsForBufferingAndContinuesWhenReady()throws Exception{
        SkiplineApp app=(SkiplineApp)RuntimeEnvironment.getApplication();app.playbackBuffering=true;
        SpotifyImport.Job job=new SpotifyImport.Job("default");ExecutorService worker=Executors.newSingleThreadExecutor();
        try{Future<Boolean> ready=worker.submit(()->SpotifyImport.awaitPlayback(app,job));
            try{ready.get(150,TimeUnit.MILLISECONDS);fail("Matching must wait while buffering");}catch(TimeoutException expected){}
            app.playbackBuffering=false;assertTrue(ready.get(2,TimeUnit.SECONDS));
        }finally{worker.shutdownNow();app.playbackBuffering=false;}
    }
    @Test public void cancelAndTaskDismissalReleaseTheWait()throws Exception{
        SkiplineApp app=(SkiplineApp)RuntimeEnvironment.getApplication();app.playbackBuffering=true;
        SpotifyImport.Job job=new SpotifyImport.Job("default");ExecutorService worker=Executors.newSingleThreadExecutor();
        try{Future<Boolean> ready=worker.submit(()->SpotifyImport.awaitPlayback(app,job));job.cancel();assertFalse(ready.get(2,TimeUnit.SECONDS));
            job.cancelled=false;app.taskDismissed=true;assertFalse(SpotifyImport.awaitPlayback(app,job));
        }finally{worker.shutdownNow();app.playbackBuffering=false;app.taskDismissed=false;}
    }
    @Test public void idleAppPausesMatchingAndReadyPlaybackDoesNotDelayIt(){
        SkiplineApp app=(SkiplineApp)RuntimeEnvironment.getApplication();SpotifyImport.Job job=new SpotifyImport.Job("default");
        assertTrue(SpotifyImport.awaitPlayback(app,job));app.backgroundIdle=true;
        try{assertFalse(SpotifyImport.awaitPlayback(app,job));assertTrue(job.paused);}finally{app.backgroundIdle=false;}
    }
}
