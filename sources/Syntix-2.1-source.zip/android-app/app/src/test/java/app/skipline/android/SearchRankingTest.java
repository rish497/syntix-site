package app.skipline.android;
import org.junit.Test;import java.util.*;import static org.junit.Assert.*;
public class SearchRankingTest {
    @Test public void artistRecordingPrecedesCoverAndUnverifiedUploads(){Track fan=new Track("https://www.youtube.com/watch?v=aaaaaaaaaaa","Song","Fan","",180),cover=new Track("https://www.youtube.com/watch?v=bbbbbbbbbbb","Song cover","Artist","",180).verified(true),official=new Track("https://www.youtube.com/watch?v=ccccccccccc","Song","Artist","",180).verified(true),catalog=new Track("https://www.youtube.com/watch?v=ddddddddddd","Song","Artist","",180,"Album",true);ArrayList<Track> ordered=SearchRanking.order("Song",Arrays.asList(cover,fan,official,catalog));assertSame(catalog,ordered.get(0));assertSame(official,ordered.get(1));assertSame(cover,SearchRanking.order("Song cover",Arrays.asList(cover,fan)).get(0));}
}
