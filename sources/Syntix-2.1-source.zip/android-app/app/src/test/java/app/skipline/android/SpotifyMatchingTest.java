package app.skipline.android;

import java.util.*;
import org.junit.Test;
import static org.junit.Assert.*;

public class SpotifyMatchingTest {
    private SpotifyPlaylist.Song song(){return new SpotifyPlaylist.Song("Counting Stars","OneRepublic",284000,"");}
    private Track video(String title,String artist,long duration){return new Track("https://youtube.com/watch?v=example",title,artist,"",duration);}
    @Test public void exactRecordingIsPreferredOverUnrelatedAndCoverResults(){Track cover=video("Counting Stars cover","Another Singer",284),wrong=video("Counting Stars","Other Artist",284),right=video("OneRepublic - Counting Stars (Official Music Video)","OneRepublic",284);assertSame(right,SpotifyMatching.choose(song(),new ArrayList<>(Arrays.asList(cover,wrong,right))));}
    @Test public void durationAndVersionMismatchRequireReview(){assertFalse(SpotifyMatching.confident(song(),video("OneRepublic - Counting Stars LIVE","OneRepublic",284)));assertFalse(SpotifyMatching.confident(song(),video("OneRepublic - Counting Stars","OneRepublic",400)));}
    @Test public void shortTitlesStillRequireStrongArtistEvidence(){SpotifyPlaylist.Song target=new SpotifyPlaylist.Song("Home","Artist One",180000,"");assertFalse(SpotifyMatching.confident(target,video("Home","Random Channel",180)));}
    @Test public void accentsAndNonLatinTitlesAreRetainedInMatching(){assertEquals(1,SpotifyMatching.coverage("Beyoncé","Beyonce official"),0);assertEquals(1,SpotifyMatching.coverage("तुम ही हो","तुम ही हो official audio"),0);assertEquals(0,SpotifyMatching.coverage("दिल","दल"),0);}
    @Test public void primaryArtistIsEnoughWithoutEveryProducerAndFeaturedCredit(){
        SpotifyPlaylist.Song target=new SpotifyPlaylist.Song("So High","Sidhu Moose Wala, Byg Byrd",234000,"");
        assertTrue(SpotifyMatching.confident(target,video("So High | Sidhu Moose Wala | Official Audio","Humble Music",235)));
        assertTrue(SpotifyMatching.confident(target,video("So High","Byg Byrd",234)));
        assertFalse(SpotifyMatching.confident(target,video("So High","Uncredited artist",234)));
        assertTrue(SpotifyMatching.confident(target,video("So High | SidhuMooseWala","Humble Music",234)));
        assertTrue(SpotifyMatching.confident(target,video("So High | Sidhu Moosewala","Humble Music",234)));
    }
    @Test public void featuredCreditAndSoundtrackAnnotationsDoNotBecomeRequiredTitleWords(){
        SpotifyPlaylist.Song target=new SpotifyPlaylist.Song("Same Beef (feat. Bohemia)","Sidhu Moose Wala, Bohemia",290000,"");
        assertTrue(SpotifyMatching.confident(target,video("Same Beef | Sidhu Moose Wala | Official Audio","YRF",291)));
        assertEquals("Tum Hi Ho",SpotifyMatching.title("Tum Hi Ho (From Aashiqui 2)"));
    }
    @Test public void smallUploadDurationDifferencesAndMissingDurationAreNotAutomaticRejections(){
        assertFalse(SpotifyMatching.confident(song(),video("Counting Stars | OneRepublic","OneRepublic",305)));
        assertTrue(SpotifyMatching.confident(song(),video("Counting Stars","OneRepublic",0)));
        assertFalse(SpotifyMatching.confident(song(),video("Counting Stars","Unrelated singer",0)));
        assertFalse(SpotifyMatching.confident(song(),video("Counting Stars full album","OneRepublic",284)));
    }
    @Test public void fallbackQueryAndTransientRetryFindARecordingRatherThanSkip()throws Exception{
        Track right=video("Counting Stars","OneRepublic",284);java.util.concurrent.atomic.AtomicInteger calls=new java.util.concurrent.atomic.AtomicInteger();
        assertSame(right,SpotifyMatching.find(song(),q->{if(calls.getAndIncrement()==0)throw new java.io.IOException("temporary");return new ArrayList<>(Arrays.asList(right));},()->true));assertEquals(2,calls.get());
        calls.set(0);assertSame(right,SpotifyMatching.find(song(),q->{calls.incrementAndGet();return q.endsWith("official audio")?new ArrayList<>():new ArrayList<>(Arrays.asList(right));},()->true));assertEquals(2,calls.get());
    }
    @Test(expected=java.io.IOException.class) public void searchOutageIsAnErrorNotAnUnmatchedResult()throws Exception{SpotifyMatching.find(song(),q->{throw new java.io.IOException("offline");},()->true);}
    @Test public void blockedSearchStopsImmediatelyWithoutRetryStorm()throws Exception{
        java.util.concurrent.atomic.AtomicInteger calls=new java.util.concurrent.atomic.AtomicInteger();
        try{SpotifyMatching.find(song(),q->{calls.incrementAndGet();throw new YouTubeMetadata.SearchBlockedException();},()->true);fail("Blocked search must remain pending");}catch(YouTubeMetadata.SearchBlockedException expected){assertEquals(1,calls.get());}
    }
    @Test public void romanizedSpellingVariantsNeedMatchingArtistAndCloseDuration(){
        SpotifyPlaylist.Song target=new SpotifyPlaylist.Song("Jaat Da Muqabala","Sidhu Moose Wala",204360,"");assertTrue(SpotifyMatching.confident(target,video("Jatt Da Muqabala | Sidhu Moose Wala","T-Series",205)));assertFalse(SpotifyMatching.confident(target,video("Jatt Da Muqabala","Unrelated Artist",205)));assertFalse(SpotifyMatching.confident(target,video("Jatt Da Muqabala","Sidhu Moose Wala",230)));
        target=new SpotifyPlaylist.Song("Yaar Anmule","Sharry Mann",276280,"");assertTrue(SpotifyMatching.confident(target,video("Yaar Anmulle | Sharry Mann","sharrymann",279)));
        target=new SpotifyPlaylist.Song("Angel Eyes","Artist One",200000,"");assertFalse(SpotifyMatching.confident(target,video("Anger Eyes","Artist One",200)));
    }
    @Test public void alteredAudioIsRejectedAndArtistUploadsWinCloseDurationTies(){
        Track boosted=video("Counting Stars BASS BOOSTED","OneRepublic",284),spatial=video("Counting Stars 8D AUDIO","OneRepublic",284),fan=video("Counting Stars | OneRepublic","Fan Channel",284),official=video("Counting Stars","OneRepublic",285);assertFalse(SpotifyMatching.confident(song(),boosted));assertFalse(SpotifyMatching.confident(song(),spatial));assertSame(official,SpotifyMatching.choose(song(),new ArrayList<>(Arrays.asList(boosted,spatial,fan,official))));
    }

    @Test public void namedLivePerformancesAndAlternateMixesAreNotStudioRecordings(){
        String[] versions={"Counting Stars (MTV Unplugged)","Counting Stars (Devonshire Mix)","Counting Stars (Brendan O'Brien Mix)","Counting Stars (Studio Outtake)","Counting Stars (Alternate Version)","Counting Stars (Video Version Edit)"};
        for(String title:versions)assertFalse(title,SpotifyMatching.confident(song(),video(title,"OneRepublic",284)));
        Track catalog=new Track("https://www.youtube.com/watch?v=abcdefghijk","Counting Stars","Different Singer","",284,"Original album",true);assertFalse(SpotifyMatching.confident(song(),catalog));
        catalog=new Track("https://www.youtube.com/watch?v=abcdefghijk","Counting Stars","OneRepublic Tribute Band","",284,"Studio",true);assertFalse(SpotifyMatching.confident(song(),catalog));
        catalog=new Track("https://www.youtube.com/watch?v=abcdefghijk","Counting Stars","OneRepublic","",284,"Live in Dublin",true);assertFalse(SpotifyMatching.confident(song(),catalog));
    }
    @Test public void explicitRequestedLiveRecordingsRemainSupported(){SpotifyPlaylist.Song wanted=new SpotifyPlaylist.Song("Enter Sandman - Live","Metallica",459000,"","S&M",true);assertTrue(SpotifyMatching.confident(wanted,new Track("https://www.youtube.com/watch?v=abcdefghijk","Enter Sandman (Live with the SFSO)","Metallica","",460,"S&M",true)));}
    @Test public void requestedLiveAlbumDoesNotAcceptADifferentConcert(){SpotifyPlaylist.Song wanted=new SpotifyPlaylist.Song("For Whom The Bell Tolls - Live","Metallica",292000,"","S&M",true);assertFalse(SpotifyMatching.confident(wanted,new Track("https://www.youtube.com/watch?v=abcdefghijk","For Whom The Bell Tolls (Live)","Metallica","",293,"Live in Mexico City",true)));assertTrue(SpotifyMatching.confident(wanted,new Track("https://www.youtube.com/watch?v=abcdefghijk","For Whom The Bell Tolls (Live with the SFSO)","Metallica","",293,"S&M",true)));}
    @Test(expected=java.util.concurrent.CancellationException.class) public void playbackOrCancellationGateStopsFurtherSearches()throws Exception{SpotifyMatching.find(song(),q->{fail("No request while paused");return null;},()->false);}
}
