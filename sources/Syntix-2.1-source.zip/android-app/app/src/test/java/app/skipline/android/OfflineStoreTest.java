package app.skipline.android;

import org.junit.Test;
import static org.junit.Assert.*;

public class OfflineStoreTest {
    @Test public void remoteSourcesCannotBecomeFilePaths(){
        for(String source:new String[]{"https://youtube.com/watch?v=abc","../../outside", "https://youtube.com/watch?v=../../secret", "a very long source "+"x".repeat(10000)}){
            String key=OfflineStore.key(source);assertTrue(key.matches("[a-f0-9]{64}"));assertTrue(OfflineStore.validName(key+".m4a"));
        }
    }
    @Test public void partialAndMetadataFilesAreNeverPlayable(){
        String key=OfflineStore.key("https://youtube.com/watch?v=abc");
        assertFalse(OfflineStore.validName(key+".m4a.part"));assertFalse(OfflineStore.validName(key+".webm.ytdl"));assertFalse(OfflineStore.validName("../"+key+".m4a"));assertFalse(OfflineStore.validName(key+".json"));assertFalse(OfflineStore.validName("/tmp/"+key+".m4a"));
    }
    @Test public void sameSongReusesDownloadAndDifferentSourcesStaySeparate(){
        String source="https://youtube.com/watch?v=abc";assertEquals(OfflineStore.key(source),OfflineStore.key(source));assertNotEquals(OfflineStore.key(source),OfflineStore.key(source+"2"));
    }
}
