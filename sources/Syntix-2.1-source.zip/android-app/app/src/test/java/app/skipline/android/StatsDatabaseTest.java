package app.skipline.android;

import android.app.Application;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class)
@Config(sdk=31,manifest=Config.NONE,application=Application.class)
@SQLiteMode(SQLiteMode.Mode.NATIVE)
public class StatsDatabaseTest {
    private Application context;
    @Before public void prepare(){context=RuntimeEnvironment.getApplication();context.deleteDatabase("activity-v7.db");}
    @Test public void freshDatabaseOpensAndConsumesSecureDeletePragma(){try(StatsDatabase helper=new StatsDatabase(context)){SQLiteDatabase db=helper.getWritableDatabase();try(Cursor c=db.rawQuery("PRAGMA secure_delete",null)){assertTrue(c.moveToFirst());assertEquals(1,c.getInt(0));}try(Cursor c=db.rawQuery("SELECT COUNT(*) FROM usage",null)){assertTrue(c.moveToFirst());assertEquals(0,c.getInt(0));}}}
    @Test public void observedActivityPersistsAcrossReopenWithoutInventingOtherProfiles(){try(StatsDatabase helper=new StatsDatabase(context)){SQLiteDatabase db=helper.getWritableDatabase();db.execSQL("INSERT INTO usage(profile,hour,listen,bytes,drop_pct,observed) VALUES (?,?,?,?,?,?)",new Object[]{"default",7200000L,60000L,12345L,1,60000L});db.execSQL("INSERT INTO artists(profile,hour,name,ms) VALUES (?,?,?,?)",new Object[]{"default",7200000L,"Recorded artist",60000L});}
        try(StatsDatabase helper=new StatsDatabase(context)){try(Cursor c=helper.getReadableDatabase().rawQuery("SELECT listen,bytes,drop_pct FROM usage WHERE profile=?",new String[]{"default"})){assertTrue(c.moveToFirst());assertEquals(60000,c.getLong(0));assertEquals(12345,c.getLong(1));assertEquals(1,c.getDouble(2),0);}try(Cursor c=helper.getReadableDatabase().rawQuery("SELECT COUNT(*) FROM usage WHERE profile=?",new String[]{"another"})){assertTrue(c.moveToFirst());assertEquals(0,c.getInt(0));}}}
}
