package app.skipline.android;

import androidx.media3.common.C;
import androidx.media3.common.audio.AudioProcessor.AudioFormat;
import java.nio.*;
import org.junit.Test;
import static org.junit.Assert.*;

@org.junit.runner.RunWith(org.robolectric.RobolectricTestRunner.class)
@org.robolectric.annotation.Config(sdk=31,manifest=org.robolectric.annotation.Config.NONE,application=android.app.Application.class)
@androidx.media3.common.util.UnstableApi
public class SoundProcessorTest {
    private SoundProcessor processor(boolean enabled,boolean normalize,int[] bands)throws Exception{SoundProcessor p=new SoundProcessor();p.settings(new SoundProcessor.Settings(enabled,normalize,bands,0,0));p.configure(new AudioFormat(48000,2,C.ENCODING_PCM_16BIT));p.flush();return p;}
    private ByteBuffer signal(int hz){ByteBuffer b=ByteBuffer.allocateDirect(48000*4).order(ByteOrder.LITTLE_ENDIAN);for(int i=0;i<48000;i++){short x=(short)(Math.sin(i*2*Math.PI*hz/48000)*4000);b.putShort(x);b.putShort((short)0);}b.flip();return b;}
    private double power(ByteBuffer b){b.order(ByteOrder.LITTLE_ENDIAN);double sum=0;int count=0;while(b.remaining()>=4){double l=b.getShort();assertEquals("Filter state must not leak into silent right channel",0,b.getShort());if(count++>4800)sum+=l*l;}return sum/(count-4800);}
    @Test public void emptyDecoderBufferDoesNotCopyTheSharedEmptyBufferIntoItself()throws Exception{SoundProcessor p=processor(false,false,new int[7]);p.queueInput(androidx.media3.common.audio.AudioProcessor.EMPTY_BUFFER);assertFalse(p.getOutput().hasRemaining());p.queueInput(signal(440));assertTrue(p.getOutput().hasRemaining());}
    @Test public void emptyInputKeepsQueuedAudioForEveryEffectMode()throws Exception{for(boolean enabled:new boolean[]{false,true})for(boolean normalize:new boolean[]{false,true}){SoundProcessor p=processor(enabled,normalize,new int[7]);p.queueInput(androidx.media3.common.audio.AudioProcessor.EMPTY_BUFFER);ByteBuffer input=signal(440);int bytes=input.remaining();p.queueInput(input);p.queueInput(androidx.media3.common.audio.AudioProcessor.EMPTY_BUFFER);assertEquals(bytes,p.getOutput().remaining());p.queueInput(androidx.media3.common.audio.AudioProcessor.EMPTY_BUFFER);assertFalse(p.getOutput().hasRemaining());p.flush();p.queueInput(androidx.media3.common.audio.AudioProcessor.EMPTY_BUFFER);p.queueInput(signal(440));assertTrue(p.getOutput().hasRemaining());}}
    @Test public void bypassPreservesEveryPcmByteAndFrame()throws Exception{ByteBuffer in=signal(440),expected=in.duplicate();SoundProcessor p=processor(false,false,new int[7]);p.queueInput(in);ByteBuffer out=p.getOutput();assertEquals(expected.remaining(),out.remaining());while(expected.hasRemaining())assertEquals(expected.get(),out.get());}
    @Test public void flatPresetIsTransparent()throws Exception{ByteBuffer in=signal(1000),expected=in.duplicate().order(ByteOrder.LITTLE_ENDIAN);SoundProcessor p=processor(true,false,new int[7]);p.queueInput(in);ByteBuffer out=p.getOutput().order(ByteOrder.LITTLE_ENDIAN);while(expected.hasRemaining())assertEquals(expected.getShort(),out.getShort());}
    @Test public void bassCutActuallyChangesBassPcmAndPreservesStereoIsolation()throws Exception{int[] b=new int[7];b[0]=-12;SoundProcessor cut=processor(true,false,b),flat=processor(false,false,new int[7]);cut.queueInput(signal(60));flat.queueInput(signal(60));assertTrue(power(cut.getOutput())<power(flat.getOutput())*.2);}
    @Test public void normalizationAdjustsQuietAudioWithoutOverflow()throws Exception{SoundProcessor p=processor(false,true,new int[7]),flat=processor(false,false,new int[7]);p.queueInput(signal(1000));flat.queueInput(signal(1000));assertTrue(power(p.getOutput())>power(flat.getOutput()));}
    @Test public void flushClearsFilterTailBetweenSongs()throws Exception{int[] b={12,12,12,12,12,12,12};SoundProcessor p=processor(true,false,b);p.queueInput(signal(440));p.getOutput();p.flush();ByteBuffer silence=ByteBuffer.allocateDirect(800).order(ByteOrder.LITTLE_ENDIAN);p.queueInput(silence);ByteBuffer result=p.getOutput();while(result.hasRemaining())assertEquals(0,result.get());}
    @Test public void bandAboveNyquistDoesNotAlterLowSampleRateAudio()throws Exception{int[] b=new int[7];b[6]=12;SoundProcessor p=new SoundProcessor();p.settings(new SoundProcessor.Settings(true,false,b,0,0));p.configure(new AudioFormat(8000,2,C.ENCODING_PCM_16BIT));p.flush();ByteBuffer input=signal(440),expected=input.duplicate();p.queueInput(input);ByteBuffer actual=p.getOutput();while(expected.hasRemaining())assertEquals(expected.get(),actual.get());}
}
