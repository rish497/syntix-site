package app.skipline.android;

import java.util.Arrays;
import java.util.Collections;
import org.junit.Test;
import static org.junit.Assert.*;

public class PlaylistDurationsTest {
    private Track track(long seconds){return new Track("https://www.youtube.com/watch?v=abcdefghijk","Song","Artist","",seconds);}
    @Test public void playlistLengthAggregatesSecondsAcrossSongs(){assertEquals("1 hr 1 min",PlaylistDurations.total(Arrays.asList(track(1800),track(1860))));}
    @Test public void unknownDurationsNeverBecomeAFabricatedTotal(){assertEquals("3 min +",PlaylistDurations.total(Arrays.asList(track(180),track(0))));assertEquals("Duration unavailable",PlaylistDurations.total(Collections.singletonList(track(0))));assertEquals("0 min",PlaylistDurations.total(Collections.emptyList()));}
}
