package app.skipline.android;
import org.junit.Test;import org.json.*;import okhttp3.*;import java.util.*;import java.util.concurrent.atomic.AtomicInteger;import static org.junit.Assert.*;
public class YouTubePlaylistTest {
    private JSONObject page(int offset,int count,boolean more)throws JSONException{
        JSONArray items=new JSONArray();for(int i=offset;i<offset+count;i++)items.put(new JSONObject().put("playlistVideoRenderer",new JSONObject().put("videoId",String.format(Locale.US,"%011d",i)).put("title",new JSONObject().put("simpleText","Song "+i)).put("shortBylineText",new JSONObject().put("simpleText","Artist")).put("lengthSeconds",180)));
        if(more)items.put(new JSONObject().put("continuationCommand",new JSONObject().put("token","page2")));return new JSONObject().put("contents",items);
    }
    @Test public void readsEveryPageBeyondOneHundredWithoutIndividualVideoRequests()throws Exception{
        AtomicInteger calls=new AtomicInteger();OkHttpClient client=new OkHttpClient.Builder().addInterceptor(chain->{try{int n=calls.getAndIncrement();assertEquals("/youtubei/v1/browse",chain.request().url().encodedPath());return new Response.Builder().request(chain.request()).protocol(Protocol.HTTP_1_1).code(200).message("OK").body(ResponseBody.create(page(n==0?0:100,n==0?100:50,n==0).toString(),MediaType.get("application/json"))).build();}catch(Exception e){throw new java.io.IOException(e);}}).build();
        ArrayList<Track> tracks=YouTubePlaylist.read("https://www.youtube.com/playlist?list=PLexample",client,()->true);assertEquals(150,tracks.size());assertEquals("Song 149",tracks.get(149).title);assertEquals(2,calls.get());
    }
    @Test public void modernRowsRetainDurationAndArtistVerification()throws Exception{
        JSONObject artist=new JSONObject().put("content","Artist").put("attachmentRuns",new JSONArray().put(new JSONObject().put("imageName","AUDIO_BADGE")));
        JSONObject row=new JSONObject().put("metadataParts",new JSONArray().put(new JSONObject().put("text",artist)));
        JSONObject metadata=new JSONObject().put("title",new JSONObject().put("content","Official song")).put("metadata",new JSONObject().put("contentMetadataViewModel",new JSONObject().put("metadataRows",new JSONArray().put(row))));
        JSONObject lock=new JSONObject().put("contentId","abcdefghijk").put("metadata",new JSONObject().put("lockupMetadataViewModel",metadata)).put("contentImage",new JSONObject().put("thumbnailBadgeViewModel",new JSONObject().put("text","3:45")));
        Track track=YouTubePlaylist.parse(new JSONObject().put("lockupViewModel",lock)).get(0);assertEquals(225,track.duration);assertEquals("Artist",track.creator);assertTrue(track.verifiedArtist);
    }
}
