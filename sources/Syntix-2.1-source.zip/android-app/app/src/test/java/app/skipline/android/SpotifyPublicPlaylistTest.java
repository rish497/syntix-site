package app.skipline.android;

import java.util.*;
import okhttp3.*;
import org.json.*;
import org.junit.Test;
import static org.junit.Assert.*;

public class SpotifyPublicPlaylistTest {
    @Test public void fullPublicImportPagesPastOneHundredWithoutLosingOrder()throws Exception{
        ArrayList<Integer> offsets=new ArrayList<>();
        OkHttpClient client=new OkHttpClient.Builder().addInterceptor(chain->{
            Request request=chain.request();JSONObject reply=new JSONObject();
            try{
                if(request.url().host().equals("code.thetadev.de"))reply.put("1",new JSONArray().put(1).put(2).put(3));
                else if(request.url().encodedPath().equals("/api/token"))reply.put("accessToken","anonymous-test-token").put("isAnonymous",true);
                else{
                    assertEquals("api-partner.spotify.com",request.url().host());JSONObject args=new JSONObject(request.url().queryParameter("variables"));int offset=args.getInt("offset");offsets.add(offset);JSONArray items=new JSONArray();
                    for(int i=offset;i<Math.min(offset+343,715);i++)items.put(item(i));
                    reply.put("data",new JSONObject().put("playlistV2",new JSONObject().put("name","Large playlist").put("content",new JSONObject().put("totalCount",715).put("items",items))));
                }
            }catch(JSONException failure){throw new java.io.IOException(failure);}
            return new Response.Builder().request(request).protocol(Protocol.HTTP_1_1).code(200).message("OK").body(ResponseBody.create(reply.toString(),MediaType.get("application/json"))).build();
        }).build();
        SpotifyPlaylist.Data data=SpotifyPlaylist.fetch("https://open.spotify.com/playlist/5O4Ye7AOJlE6B2WIArQnTV",client);assertEquals(Arrays.asList(0,343,686),offsets);assertEquals(715,data.songs.size());assertEquals("Song 714",data.songs.get(714).title);assertEquals("Original album",data.songs.get(0).album);assertTrue(data.complete());
    }
    @Test public void cancellationDoesNotFallBackToAnotherNetworkRequest()throws Exception{
        OkHttpClient client=new OkHttpClient.Builder().addInterceptor(chain->{fail("No network work after cancellation");throw new java.io.IOException();}).build();
        try{SpotifyPlaylist.fetch("https://open.spotify.com/playlist/5O4Ye7AOJlE6B2WIArQnTV",client,()->false);fail("Expected cancellation");}catch(java.util.concurrent.CancellationException expected){}
    }
    private static JSONObject item(int index)throws JSONException{
        JSONObject artist=new JSONObject().put("profile",new JSONObject().put("name","Original Artist"));
        JSONObject song=new JSONObject().put("__typename","Track").put("name","Song "+index).put("uri","spotify:track:"+index)
            .put("trackDuration",new JSONObject().put("totalMilliseconds",180000)).put("albumOfTrack",new JSONObject().put("name","Original album"))
            .put("artists",new JSONObject().put("items",new JSONArray().put(artist)));
        return new JSONObject().put("itemV2",new JSONObject().put("data",song));
    }
}
