package app.skipline.android;

import android.security.keystore.KeyGenParameterSpec;
import androidx.media3.datasource.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.Config;
import java.io.*;
import java.nio.file.Files;
import java.security.*;
import java.security.cert.Certificate;
import java.security.spec.AlgorithmParameterSpec;
import java.util.*;
import javax.crypto.*;
import static org.junit.Assert.*;

/** Exercises storage/routing with a test-only JCA provider; not hardware-Keystore evidence. */
@RunWith(RobolectricTestRunner.class)
@Config(sdk={29,31},application=ListeningFeaturesUiTest.UiApp.class)
@androidx.media3.common.util.UnstableApi
public class EncryptedOfflinePlaybackTest {
    private Provider previous;
    @Before public void provider(){previous=Security.getProvider("AndroidKeyStore");if(previous!=null)Security.removeProvider(previous.getName());Security.addProvider(new TestProvider());Store.keys.clear();}
    @After public void restore(){Security.removeProvider("AndroidKeyStore");if(previous!=null)Security.addProvider(previous);Store.keys.clear();}
    private OfflineStore store(){return new OfflineStore(RuntimeEnvironment.getApplication(),UUID.randomUUID().toString());}
    private Track song(){return new Track("https://www.youtube.com/watch?v=abcdefghijk","Song","Artist","",120);}
    private File plain(OfflineStore store,Track track,byte[] bytes)throws Exception{store.directory.mkdirs();File file=new File(store.directory,OfflineStore.key(track.source)+".opus");Files.write(file.toPath(),bytes);return file;}

    @Test public void completedDownloadIsEncryptedAndCanSeekWithoutPlaintextPlaybackFiles()throws Exception{
        OfflineStore store=store();Track track=song();byte[] audio=new byte[140000];new Random(7).nextBytes(audio);store.enqueue(Collections.singletonList(track));File original=plain(store,track,audio);store.completeEncrypted(track,original);
        assertFalse(original.exists());assertTrue(store.file(track.source).getName().endsWith(".sxa"));assertEquals(0,store.remaining());
        OfflineDataSource source=new OfflineDataSource(new DefaultDataSource.Factory(RuntimeEnvironment.getApplication()));
        assertEquals(70000,source.open(new DataSpec.Builder().setUri(android.net.Uri.fromFile(store.file(track.source))).setPosition(60000).setLength(70000).build()));
        try{byte[] found=new byte[70000];int at=0;while(at<found.length){int n=source.read(found,at,found.length-at);assertTrue(n>0);at+=n;}assertArrayEquals(Arrays.copyOfRange(audio,60000,130000),found);assertEquals(-1,source.read(new byte[1],0,1));}finally{source.close();}
        assertFalse(original.exists());assertEquals(1,new OfflineStore(RuntimeEnvironment.getApplication(),store.profile).count());
    }
    @Test public void markedCompletionRecoversButUnfinishedTranscodeIsNotPublished()throws Exception{
        OfflineStore store=store();Track track=song();store.enqueue(Collections.singletonList(track));File original=plain(store,track,new byte[400]);
        assertFalse(store.recoverReady(track));assertNull(store.file(track.source));store.markReady(track,original);
        OfflineStore reopened=new OfflineStore(RuntimeEnvironment.getApplication(),store.profile);assertTrue(reopened.recoverReady(track));assertFalse(original.exists());assertEquals(0,reopened.remaining());
        reopened.completeEncrypted(track,original);assertEquals(1,reopened.count());assertFalse(new File(store.directory,OfflineStore.key(track.source)+".ready").exists());
    }
    @Test public void legacyManagedAudioMigratesAndClearRemovesEncryptedStorage()throws Exception{
        OfflineStore store=store();Track track=song();File original=plain(store,track,new byte[100]);store.complete(track,original);store.secureExistingDownloads(()->true);
        assertFalse(original.exists());assertTrue(store.playbackFile(track.source).getName().endsWith(".sxa"));store.clear();assertNull(store.file(track.source));assertEquals(0,store.bytes());
    }
    public static final class TestProvider extends Provider {public TestProvider(){super("AndroidKeyStore",1.0,"Test-only in-memory keys");put("KeyStore.AndroidKeyStore",Store.class.getName());put("KeyGenerator.AES",Generator.class.getName());}}
    public static final class Generator extends KeyGeneratorSpi {
        String alias;
        protected void engineInit(SecureRandom random){}
        protected void engineInit(int size,SecureRandom random){}
        protected void engineInit(AlgorithmParameterSpec spec,SecureRandom random){alias=((KeyGenParameterSpec)spec).getKeystoreAlias();}
        protected SecretKey engineGenerateKey(){try{KeyGenerator g=KeyGenerator.getInstance("AES","SunJCE");g.init(256);SecretKey key=g.generateKey();Store.keys.put(alias,key);return key;}catch(GeneralSecurityException e){throw new IllegalStateException(e);}}
    }
    public static final class Store extends KeyStoreSpi {
        static final Map<String,Key> keys=new HashMap<>();
        public Key engineGetKey(String alias,char[] password){return keys.get(alias);}
        public Certificate[] engineGetCertificateChain(String alias){return null;}
        public Certificate engineGetCertificate(String alias){return null;}
        public Date engineGetCreationDate(String alias){return null;}
        public void engineSetKeyEntry(String alias,Key key,char[] password,Certificate[] chain){keys.put(alias,key);}
        public void engineSetKeyEntry(String alias,byte[] key,Certificate[] chain){throw new UnsupportedOperationException();}
        public void engineSetCertificateEntry(String alias,Certificate certificate){throw new UnsupportedOperationException();}
        public void engineDeleteEntry(String alias){keys.remove(alias);}
        public Enumeration<String> engineAliases(){return Collections.enumeration(keys.keySet());}
        public boolean engineContainsAlias(String alias){return keys.containsKey(alias);}
        public int engineSize(){return keys.size();}
        public boolean engineIsKeyEntry(String alias){return keys.containsKey(alias);}
        public boolean engineIsCertificateEntry(String alias){return false;}
        public String engineGetCertificateAlias(Certificate certificate){return null;}
        public void engineStore(OutputStream output,char[] password){}
        public void engineLoad(InputStream input,char[] password){}
    }
}
