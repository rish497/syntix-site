package app.skipline.android;

import org.junit.Test;
import org.json.*;
import okhttp3.*;
import java.util.ArrayList;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import static org.junit.Assert.*;

public class LiveSearchTest {
    private static String page(String id, boolean more)throws Exception {
        JSONObject data=new JSONObject().put("contents",new JSONArray().put(new JSONObject().put("videoRenderer",new JSONObject().put("videoId",id).put("title",new JSONObject().put("simpleText","Real search result")).put("ownerText",new JSONObject().put("simpleText","Artist")).put("lengthText",new JSONObject().put("simpleText","3:12")))));
        if(more)data.put("continuationCommand",new JSONObject().put("token","next-page"));
        return data.toString();
    }
    private static Response response(Request request,int code,String body){return new Response.Builder().request(request).protocol(Protocol.HTTP_1_1).code(code).message("Test response").body(ResponseBody.create(body,MediaType.get("application/json"))).build();}

    @Test public void firstSongsArePlayableBeforeTheNextPageCompletes()throws Exception {
        CountDownLatch first=new CountDownLatch(1),next=new CountDownLatch(1),release=new CountDownLatch(1);
        AtomicInteger calls=new AtomicInteger();AtomicReference<Track> shown=new AtomicReference<>();
        String initial=page("abcdefghijk",true),later=page("lmnopqrstuv",false);
        OkHttpClient client=new OkHttpClient.Builder().addInterceptor(chain->{
            assertEquals("https",chain.request().url().scheme());assertEquals("POST",chain.request().method());
            if(calls.incrementAndGet()==1)return response(chain.request(),200,initial);
            next.countDown();try{if(!release.await(3,TimeUnit.SECONDS))throw new java.io.IOException("Test continuation timed out");}catch(InterruptedException e){throw new java.io.IOException(e);}
            return response(chain.request(),200,later);
        }).build();
        ExecutorService worker=Executors.newSingleThreadExecutor();
        try{
            Future<ArrayList<Track>> result=worker.submit(()->YouTubeMetadata.liveSearch("song",tracks->{shown.set(tracks.get(0));first.countDown();},()->true,client));
            assertTrue(first.await(3,TimeUnit.SECONDS));assertTrue(next.await(3,TimeUnit.SECONDS));
            assertEquals("https://www.youtube.com/watch?v=abcdefghijk",shown.get().source);
            assertFalse("Displaying songs must not wait for continuation",result.isDone());
            release.countDown();assertEquals(2,result.get(3,TimeUnit.SECONDS).size());
        }finally{release.countDown();worker.shutdownNow();}
    }
    @Test public void abandonedQueryDoesNotRequestAnotherPage()throws Exception {
        AtomicBoolean active=new AtomicBoolean(true);AtomicInteger calls=new AtomicInteger();String initial=page("abcdefghijk",true);
        OkHttpClient client=new OkHttpClient.Builder().addInterceptor(chain->{calls.incrementAndGet();return response(chain.request(),200,initial);}).build();
        assertEquals(1,YouTubeMetadata.liveSearch("song",tracks->active.set(false),active::get,client).size());assertEquals(1,calls.get());
    }
    @Test public void unavailableContinuationKeepsTheFirstPage()throws Exception {
        AtomicInteger calls=new AtomicInteger();String initial=page("abcdefghijk",true);
        OkHttpClient client=new OkHttpClient.Builder().addInterceptor(chain->calls.incrementAndGet()==1?response(chain.request(),200,initial):response(chain.request(),503,"{}")).build();
        assertEquals(1,YouTubeMetadata.liveSearch("song",null,()->true,client).size());assertEquals(2,calls.get());
    }
    @Test public void supersededQueryDoesNotStartANetworkRequest()throws Exception {
        AtomicInteger calls=new AtomicInteger();OkHttpClient client=new OkHttpClient.Builder().addInterceptor(chain->{calls.incrementAndGet();return response(chain.request(),200,"{}");}).build();
        try{YouTubeMetadata.liveSearch("old query",null,()->false,client);fail("Superseded query should cancel");}catch(CancellationException expected){assertEquals(0,calls.get());}
    }
}
