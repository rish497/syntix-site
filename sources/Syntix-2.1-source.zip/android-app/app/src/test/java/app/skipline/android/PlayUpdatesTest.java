package app.skipline.android;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.Config;
import org.robolectric.android.controller.ActivityController;
import androidx.lifecycle.*;
import com.google.android.play.core.appupdate.testing.FakeAppUpdateManager;
import com.google.android.play.core.install.model.AppUpdateType;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class)
@Config(sdk=29,application=ListeningFeaturesUiTest.UiApp.class)
@androidx.media3.common.util.UnstableApi
public class PlayUpdatesTest {
    @Test public void immediateFlowShowsOnlyForAvailableUpdatesAndResumesAfterBackground(){
        try(ActivityController<MainActivity> c=Robolectric.buildActivity(MainActivity.class).create()){
            MainActivity a=c.get();FakeAppUpdateManager fake=new FakeAppUpdateManager(a);PlayUpdates updates=new PlayUpdates(a,fake);LifecycleRegistry lifecycle=(LifecycleRegistry)a.getLifecycle();lifecycle.handleLifecycleEvent(Lifecycle.Event.ON_START);lifecycle.handleLifecycleEvent(Lifecycle.Event.ON_RESUME);updates.check();Shadows.shadowOf(android.os.Looper.getMainLooper()).idle();assertFalse(fake.isImmediateFlowVisible());fake.setUpdateAvailable(99,AppUpdateType.IMMEDIATE);updates.check();Shadows.shadowOf(android.os.Looper.getMainLooper()).idle();assertTrue(fake.isImmediateFlowVisible());assertEquals(Integer.valueOf(AppUpdateType.IMMEDIATE),fake.getTypeForUpdateInProgress());fake.userAcceptsUpdate();updates.paused();updates.check();Shadows.shadowOf(android.os.Looper.getMainLooper()).idle();assertTrue(fake.isImmediateFlowVisible());
        }
    }
    @Test public void sideloadedInstallDoesNotStartPlayChecks(){try(ActivityController<MainActivity> c=Robolectric.buildActivity(MainActivity.class).create()){assertNull(PlayUpdates.create(c.get()));}}
}
