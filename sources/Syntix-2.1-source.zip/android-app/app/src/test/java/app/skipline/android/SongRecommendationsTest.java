package app.skipline.android;

import org.junit.Test;
import org.json.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import static org.junit.Assert.*;

public class SongRecommendationsTest {
    static JSONObject page(int start,int count,String token)throws Exception{JSONArray rows=new JSONArray();for(int i=start;i<start+count;i++)rows.put(new JSONObject().put("videoRenderer",new JSONObject().put("videoId",String.format(Locale.ROOT,"vid%08d",i)).put("title",new JSONObject().put("simpleText","Song "+i)).put("ownerText",new JSONObject().put("simpleText","Artist "+i)).put("lengthText",new JSONObject().put("simpleText","3:10"))));JSONObject result=new JSONObject().put("items",rows);if(!token.isEmpty())result.put("continuationCommand",new JSONObject().put("token",token));return result;}
    @Test public void continuationPagesExcludeExistingAndDuplicateSongs()throws Exception{
        ArrayList<String> tokens=new ArrayList<>();SongRecommendations.Cursor cursor=new SongRecommendations.Cursor(Collections.singletonList("80s songs"),(q,t)->{tokens.add(t);return t.isEmpty()?page(0,20,"next"):page(10,20,"");});cursor.exclude("https://www.youtube.com/watch?v=vid00000000");assertEquals(19,cursor.next().size());assertEquals(10,cursor.next().size());assertEquals(Arrays.asList("","next"),tokens);assertFalse(cursor.hasMore());
    }
    @Test public void failureCanRetryTheSamePageAndClosingStopsRequests()throws Exception{
        AtomicInteger calls=new AtomicInteger();SongRecommendations.Cursor c=new SongRecommendations.Cursor(Collections.singletonList("songs"),(q,t)->{if(calls.incrementAndGet()==1)throw new java.io.IOException("temporary");return page(0,2,"");});try{c.next();fail();}catch(java.io.IOException expected){}assertTrue(c.hasMore());assertEquals(2,c.next().size());assertEquals(2,calls.get());c.close();assertTrue(c.next().isEmpty());assertEquals(2,calls.get());
    }
    @Test public void themesAndAllHistoryArtistsContributeToQueries(){SavedPlaylist saved=new SavedPlaylist("80s rock");Track playlist=new Track("https://www.youtube.com/watch?v=abcdefghijk","Song","Artist A","",180);saved.tracks.add(playlist);List<Track> history=Arrays.asList(new Track("https://www.youtube.com/watch?v=lmnopqrstuv","Another","Artist B","",180),new Track("https://www.youtube.com/watch?v=12345678901","Third","Artist C","",180));List<String> q=SongRecommendations.queries(saved,history);assertEquals("80s rock songs",q.get(0));assertTrue(q.contains("Artist A songs"));assertTrue(q.contains("Artist B songs"));assertTrue(q.contains("Artist C songs"));saved.tracks.clear();q=SongRecommendations.queries(saved,history);assertFalse(q.contains("80s rock songs"));assertTrue(q.contains("Artist B songs"));}
}
