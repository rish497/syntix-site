package app.skipline.android;

import org.junit.Test;
import static org.junit.Assert.*;
import java.util.*;

public class YouTubeMetadataTest {
    @Test public void fastSearchUsesOneJsonPostAndParsesRealResults()throws Exception{
        okhttp3.OkHttpClient client=new okhttp3.OkHttpClient.Builder().addInterceptor(chain->{assertEquals("POST",chain.request().method());assertEquals("/youtubei/v1/search",chain.request().url().encodedPath());okio.Buffer body=new okio.Buffer();chain.request().body().writeTo(body);String payload=body.readUtf8();assertTrue(payload.contains("Specific song Artist"));assertTrue(payload.contains("\"clientName\":\"WEB\""));String response="{\"contents\":[{\"videoRenderer\":{\"videoId\":\"abcdefghijk\",\"title\":{\"simpleText\":\"Specific song\"},\"ownerText\":{\"simpleText\":\"Artist\"},\"lengthText\":{\"simpleText\":\"3:12\"}}}]}";return new okhttp3.Response.Builder().request(chain.request()).protocol(okhttp3.Protocol.HTTP_1_1).code(200).message("OK").body(okhttp3.ResponseBody.create(response,okhttp3.MediaType.get("application/json"))).build();}).build();
        java.util.ArrayList<Track> found=YouTubeMetadata.fastMatch("Specific song Artist",client);assertEquals(1,found.size());assertEquals(192,found.get(0).duration);assertEquals("Artist",found.get(0).creator);
    }
    @Test(expected=YouTubeMetadata.SearchBlockedException.class) public void fastSearchRespectsRateLimits()throws Exception{
        okhttp3.OkHttpClient client=new okhttp3.OkHttpClient.Builder().addInterceptor(chain->new okhttp3.Response.Builder().request(chain.request()).protocol(okhttp3.Protocol.HTTP_1_1).code(429).message("Too many requests").body(okhttp3.ResponseBody.create("",okhttp3.MediaType.get("application/json"))).build()).build();YouTubeMetadata.fastMatch("song",client);
    }
    @Test(expected=YouTubeMetadata.SearchBlockedException.class) public void verificationRedirectIsNotReportedAsNoMatchingSongs()throws Exception{
        okhttp3.OkHttpClient transport=new okhttp3.OkHttpClient.Builder().followRedirects(false).addInterceptor(chain->new okhttp3.Response.Builder().request(chain.request()).protocol(okhttp3.Protocol.HTTP_1_1).code(302).message("Found").header("Location","https://www.google.com/sorry/index").body(okhttp3.ResponseBody.create("",okhttp3.MediaType.get("text/html"))).build()).build();YouTubeMetadata.match("song",transport);
    }
    @Test public void spotifyMatchingReceivesTheWholeFirstPageNotOnlyTenResults()throws Exception{
        org.json.JSONArray items=new org.json.JSONArray();for(int i=0;i<30;i++)items.put(new org.json.JSONObject().put("videoRenderer",new org.json.JSONObject().put("videoId",String.format(java.util.Locale.ROOT,"%011d",i)).put("title",new org.json.JSONObject().put("simpleText","Song "+i)).put("lengthText",new org.json.JSONObject().put("simpleText","3:12"))));
        String html="var ytInitialData = "+new org.json.JSONObject().put("items",items)+";";
        okhttp3.OkHttpClient transport=new okhttp3.OkHttpClient.Builder().addInterceptor(chain->new okhttp3.Response.Builder().request(chain.request()).protocol(okhttp3.Protocol.HTTP_1_1).code(200).message("OK").body(okhttp3.ResponseBody.create(html,okhttp3.MediaType.get("text/html"))).build()).build();
        assertEquals(30,YouTubeMetadata.match("test",transport).size());
    }
    @Test(expected=java.io.IOException.class) public void oversizedMetadataResponsesAreRejectedBeforeParsing()throws Exception{YouTubeMetadata.readBounded(new java.io.ByteArrayInputStream(new byte[4*1024*1024+1]));}
    @Test public void parsesRealRendererShapeAndIgnoresDuplicateAndNonVideoIds()throws Exception{
        String video="{\"videoRenderer\":{\"videoId\":\"abcdefghijk\",\"title\":{\"runs\":[{\"text\":\"A {title} \\\"quoted\\\"\"}]},\"ownerText\":{\"runs\":[{\"text\":\"Source channel\"}]},\"lengthText\":{\"simpleText\":\"3:12\"}}}";
        ArrayList<Track> found=YouTubeMetadata.parse("<script>var ytInitialData = {\"items\":["+video+","+video+",{\"videoRenderer\":{\"videoId\":\"playlist-not-a-video\",\"title\":{\"simpleText\":\"Ignore\"}}}]};</script>");
        assertEquals(1,found.size());assertEquals("Source channel",found.get(0).creator);assertEquals(192,found.get(0).duration);assertEquals("https://www.youtube.com/watch?v=abcdefghijk",found.get(0).source);assertTrue(found.get(0).title.contains("{title}"));
    }
    @Test(expected=java.io.IOException.class) public void consentOrUnavailablePageNeverCreatesSampleSongs()throws Exception{YouTubeMetadata.parse("<html>Unavailable</html>");}
    @Test public void discoverCardsChangeEachDayAndStayDistinct(){for(long day=100;day<115;day++){Set<Integer> current=new HashSet<>(),next=new HashSet<>();for(int slot=0;slot<3;slot++){current.add(DailyDiscovery.index(day,slot));next.add(DailyDiscovery.index(day+1,slot));}assertEquals(3,current.size());current.retainAll(next);assertTrue(current.isEmpty());}}
}
