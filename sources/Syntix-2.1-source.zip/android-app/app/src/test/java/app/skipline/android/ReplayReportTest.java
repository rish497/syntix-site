package app.skipline.android;

import android.os.Looper;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import java.time.*;
import java.util.concurrent.atomic.AtomicReference;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class)
@Config(sdk=31,application=SmartMixesTest.HistoryApp.class)
@SQLiteMode(SQLiteMode.Mode.NATIVE)
@androidx.media3.common.util.UnstableApi
public class ReplayReportTest {
    @Test public void actualSqliteReportFiltersMonthAndProfileWithoutChangingAllTimeStats()throws Exception{
        SkiplineApp app=(SkiplineApp)RuntimeEnvironment.getApplication();app.deleteDatabase("activity-v7.db");YearMonth previous=YearMonth.now().minusMonths(1);long start=previous.atDay(1).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli(),end=previous.plusMonths(1).atDay(1).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli();
        try(StatsDatabase db=new StatsDatabase(app)){for(Object[] row:new Object[][]{{"default",start+3600000,60000,"Previous artist"},{"default",end+3600000,180000,"Current artist"},{"other",start+3600000,999999,"Other profile artist"}}){db.getWritableDatabase().execSQL("INSERT INTO usage(profile,hour,listen) VALUES (?,?,?)",new Object[]{row[0],row[1],row[2]});db.getWritableDatabase().execSQL("INSERT INTO artists(profile,hour,name,ms) VALUES (?,?,?,?)",new Object[]{row[0],row[1],row[3],row[2]});}}
        ActivityStats stats=new ActivityStats(app);AtomicReference<ActivityStats.Report> month=new AtomicReference<>();stats.report(start,end,month::set);await(month);assertTrue(month.get().available);assertEquals(1,month.get().points.size());assertEquals(60000,month.get().points.get(0).listen);assertEquals("Previous artist",month.get().artists.get(0).name);AtomicReference<ActivityStats.Report> all=new AtomicReference<>();stats.report(all::set);await(all);assertEquals(2,all.get().points.size());assertEquals(2,all.get().artists.size());stats.suspend();
    }
    private static void await(AtomicReference<?> result)throws Exception{long deadline=System.nanoTime()+5_000_000_000L;while(result.get()==null&&System.nanoTime()<deadline){Shadows.shadowOf(Looper.getMainLooper()).idle();Thread.sleep(10);}assertNotNull("Statistics callback did not complete",result.get());}
}
