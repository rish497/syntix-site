package app.skipline.android;

import org.junit.Test;
import java.time.*;
import java.util.TimeZone;
import static org.junit.Assert.*;

public class StatsTimeTest {
    @Test public void indiaHoursAlignToLocalHourRatherThanUtcHalfHour(){
        long time=Instant.parse("2026-11-02T07:17:31Z").toEpochMilli();
        assertEquals(Instant.parse("2026-11-02T06:30:00Z").toEpochMilli(),StatsTime.hourStart(time,TimeZone.getTimeZone("Asia/Kolkata")));
    }
    @Test public void retentionIsThreeCalendarMonthsWithMonthEndClamping(){
        long now=Instant.parse("2026-05-31T12:00:00Z").toEpochMilli();
        assertEquals(Instant.parse("2026-02-28T12:00:00Z").toEpochMilli(),StatsTime.cutoff(now,TimeZone.getTimeZone("UTC")));
    }
    @Test public void hourBucketContainsObservationAtDstBoundary(){
        long now=Instant.parse("2026-03-08T07:38:00Z").toEpochMilli();
        long start=StatsTime.hourStart(now,TimeZone.getTimeZone("America/New_York"));
        assertTrue(start<=now);assertTrue(now-start<3600000L);
    }
}
