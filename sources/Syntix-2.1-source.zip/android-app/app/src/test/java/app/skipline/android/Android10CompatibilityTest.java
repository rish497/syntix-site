package app.skipline.android;
import org.junit.Test;import org.junit.runner.RunWith;import org.robolectric.*;import org.robolectric.annotation.Config;import org.robolectric.android.controller.ActivityController;import static org.junit.Assert.*;
@RunWith(RobolectricTestRunner.class)
@Config(sdk=29,application=ListeningFeaturesUiTest.UiApp.class)
@androidx.media3.common.util.UnstableApi
public class Android10CompatibilityTest {
    @Test public void coreScreensAndProfileCreationOpenOnAndroid10(){try(ActivityController<MainActivity> c=Robolectric.buildActivity(MainActivity.class).create().visible()){MainActivity a=c.get();a.app.statistics=new ActivityStats(a.app);a.welcome=false;for(String page:new String[]{"home","library","downloads","search","sleep","equalizer","statistics"}){a.page=page;a.refresh();assertTrue(a.root.getChildCount()>0);}a.welcome=true;a.onboardingStage=1;a.refresh();assertNotNull(a.root.findViewWithTag("create_profile"));a.app.statistics.suspend();}}
}
