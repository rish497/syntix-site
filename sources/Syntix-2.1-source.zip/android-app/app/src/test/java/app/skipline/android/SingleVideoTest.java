package app.skipline.android;

import org.junit.Test;
import static org.junit.Assert.*;

public class SingleVideoTest {
    @Test public void videoFromPlaylistIsCanonicalizedWithoutImportingWholePlaylist(){assertEquals("https://www.youtube.com/watch?v=abcdefghijk",Links.singleVideo("https://www.youtube.com/watch?v=abcdefghijk&list=PL123&index=3"));assertEquals("https://www.youtube.com/watch?v=abcdefghijk",Links.singleVideo("https://youtu.be/abcdefghijk?si=share"));}
    @Test public void shortsWorkButPlaylistOnlyAndLookalikeHostsAreRejected(){assertEquals("https://www.youtube.com/watch?v=abcdefghijk",Links.singleVideo("https://youtube.com/shorts/abcdefghijk"));for(String link:new String[]{"https://youtube.com/playlist?list=PL123","https://youtube.com.evil.test/watch?v=abcdefghijk"}){try{Links.singleVideo(link);fail("Must reject "+link);}catch(IllegalArgumentException expected){}}}
}
