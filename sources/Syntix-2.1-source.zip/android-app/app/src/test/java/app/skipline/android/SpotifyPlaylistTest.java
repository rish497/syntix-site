package app.skipline.android;

import java.io.*;
import java.nio.charset.StandardCharsets;
import org.junit.Test;
import static org.junit.Assert.*;

public class SpotifyPlaylistTest {
    private static final String ID="54ZA9LXFvvFujmOVWXpHga",URL="https://open.spotify.com/playlist/"+ID;
    private SpotifyPlaylist.Data csv(String value)throws Exception{return SpotifyPlaylist.csv(new ByteArrayInputStream(value.getBytes(StandardCharsets.UTF_8)),"My music.csv");}
    @Test public void linksRemoveTrackingAndAcceptSharesAndLocalePaths(){assertEquals(URL,SpotifyPlaylist.link("Listen: "+URL+"?si=abc"));assertEquals(URL,SpotifyPlaylist.link("[playlist]("+URL+"?si=abc)"));assertEquals(URL,SpotifyPlaylist.link("https://open.spotify.com/intl-en/playlist/"+ID));assertEquals(URL,SpotifyPlaylist.link("spotify:playlist:"+ID));}
    @Test public void unrelatedSharesAndLookalikeHostsNeverBecomeSpotifyImports(){for(String value:new String[]{"https://open.spotify.com.evil.example/playlist/"+ID,"https://open.spotify.com@evil.example/playlist/"+ID,"https://open.spotify.com:8000/playlist/"+ID,"https://open.spotify.com/track/"+ID,"https://youtube.com/watch?v=abc Spotify.com music"})assertFalse(value,SpotifyPlaylist.looksLike(value));}
    @Test public void publicPreviewSizeIsNeverTreatedAsTheFullPlaylist(){int total=SpotifyPlaylist.publicCount("<meta property=\"og:description\" content=\"Playlist · user · 715 items · 69.8K saves\">");assertEquals(715,total);SpotifyPlaylist.Data data=new SpotifyPlaylist.Data();data.total=total;for(int i=0;i<100;i++)data.songs.add(new SpotifyPlaylist.Song("Song"+i,"Artist",1000,""));assertFalse(data.complete());assertEquals(-1,SpotifyPlaylist.publicCount("<meta property=\"og:description\" content=\"Playlist · user\">"));}
    @Test public void quotedCommaEscapedQuotesAndNewlinesArePreserved()throws Exception{SpotifyPlaylist.Data d=csv("Track Name,Artist Name(s),Duration (ms)\r\n\"Hello, World\",\"Artist \"\"A\"\"\",188600\r\n\"A\nB\",Singer,1000\r\n");assertEquals(2,d.songs.size());assertEquals("Hello, World",d.songs.get(0).title);assertEquals("Artist \"A\"",d.songs.get(0).artist);assertEquals(188600,d.songs.get(0).durationMs);assertEquals("A\nB",d.songs.get(1).title);assertEquals("My music",d.name);}
    @Test public void fullCsvIsNotTruncatedAtThePublicPreviewLimit()throws Exception{StringBuilder data=new StringBuilder("\ufeffTrack Name,Artist Name(s),Duration (ms)\n");for(int i=0;i<715;i++)data.append("Song ").append(i).append(",Artist,180000\n");SpotifyPlaylist.Data d=csv(data.toString());assertEquals(715,d.songs.size());assertTrue(d.complete());}
    @Test public void unsupportedAndIncompleteCsvRowsAreCounted()throws Exception{SpotifyPlaylist.Data d=csv("Title,Artist,Track URI\nGood,Artist,spotify:track:abc\nPodcast,Host,spotify:episode:abc\nMissing,,\n");assertEquals(1,d.songs.size());assertEquals(2,d.skipped);assertEquals(3,d.total);}
    @Test(expected=IOException.class) public void malformedCsvQuotesAreRejected()throws Exception{csv("Track Name,Artist\n\"unfinished,Artist");}
    @Test(expected=IOException.class) public void missingTrackColumnsAreRejected()throws Exception{csv("Album,Date\nMusic,2026");}
    @Test(expected=IOException.class) public void excessiveCsvRowsAreRejectedRatherThanSilentlyTruncated()throws Exception{StringBuilder data=new StringBuilder("Title,Artist\n");for(int i=0;i<5001;i++)data.append("Song,Artist\n");csv(data.toString());}
}
