package app.skipline.android;

import java.util.*;
import org.junit.Test;
import static org.junit.Assert.*;

public class PlaylistQueueTest {
    @Test public void progressiveImportPreservesUserOrderAndManualQueueEntries(){
        Track a=track("a"),b=track("b"),extra=track("manual"),c=track("c");ArrayList<Track> queue=new ArrayList<>(Arrays.asList(b,extra,a));
        assertTrue(PlaylistQueue.mergeReady(queue,Arrays.asList(a,b,c)));assertSame(b,queue.get(0));assertEquals("c",queue.get(1).source);assertSame(extra,queue.get(2));assertSame(a,queue.get(3));
        assertFalse(PlaylistQueue.mergeReady(queue,Arrays.asList(a,b,c)));
    }
    private Track track(String source){return new Track(source,"Song","Artist","",180);}
    @Test public void tappingSamePlaylistKeepsExistingMediaIds(){Track a=track("a"),b=track("b");ArrayList<Track> queue=new ArrayList<>(Arrays.asList(a,b));PlaylistQueue.replace(queue,Arrays.asList(a.copy(),b.copy()));assertSame(a,queue.get(0));assertSame(b,queue.get(1));}
    @Test public void reorderingReusesIdsAndNewSongsGetIndependentEntries(){Track a=track("a"),b=track("b"),c=track("c");ArrayList<Track> queue=new ArrayList<>(Arrays.asList(a,b));PlaylistQueue.replace(queue,Arrays.asList(b,a,c));assertSame(b,queue.get(0));assertSame(a,queue.get(1));assertEquals("c",queue.get(2).source);assertNotEquals(c.id,queue.get(2).id);}
    @Test public void repeatedSourcesNeverShareAMediaId(){Track a=track("a");ArrayList<Track> queue=new ArrayList<>(Collections.singletonList(a));PlaylistQueue.replace(queue,Arrays.asList(a,a));assertEquals(2,queue.size());assertNotEquals(queue.get(0).id,queue.get(1).id);}
}
