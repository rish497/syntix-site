package app.skipline.android;

import org.junit.Test;
import java.time.Instant;
import java.util.*;
import static org.junit.Assert.*;

@androidx.annotation.OptIn(markerClass = androidx.media3.common.util.UnstableApi.class)
public class StatsSeriesTest {
    private long at(String s){return Instant.parse(s).toEpochMilli();}
    private ActivityStats.Point point(String time,long minutes){ActivityStats.Point p=new ActivityStats.Point();p.at=at(time);p.listen=minutes*60000;return p;}
    @Test public void monthsIncludeRetainedPartialMonthsAndRejectOldAndFutureActivity(){
        long now=at("2026-11-02T12:30:00Z");
        List<ActivityStats.Point> points=Arrays.asList(point("2026-08-03T13:00:00Z",30),point("2026-09-10T13:00:00Z",30),point("2026-10-10T13:00:00Z",30),point("2026-11-02T12:00:00Z",30),point("2026-08-02T12:00:00Z",1000),point("2026-11-03T00:00:00Z",1000));
        StatsSeries series=StatsSeries.make(points,0,2,now,TimeZone.getTimeZone("UTC"));assertEquals(4,series.dates.length);assertEquals(120*60000L,series.totalMs);assertArrayEquals(new double[]{30,30,30,30},series.values,0);
    }
    @Test public void hourlyBucketsRespectHalfHourTimeZones(){
        StatsSeries series=StatsSeries.make(Collections.singletonList(point("2026-11-02T06:30:00Z",5)),0,0,at("2026-11-02T07:17:31Z"),TimeZone.getTimeZone("Asia/Kolkata"));
        assertEquals(24,series.dates.length);assertEquals(at("2026-11-02T06:30:00Z"),series.dates[23]);assertEquals(5,series.values[23],0);
    }
    @Test public void daysUseCalendarBoundariesAcrossDaylightSaving(){
        StatsSeries series=StatsSeries.make(Collections.emptyList(),0,1,at("2026-11-02T12:30:00Z"),TimeZone.getTimeZone("America/New_York"));
        assertEquals(30,series.dates.length);assertEquals(25*3600000L,series.dates[29]-series.dates[28]);
    }
    @Test public void batteryRatesAreWeightedByObservedPlaybackTime(){
        ActivityStats.Point a=point("2026-11-02T09:00:00Z",30),b=point("2026-11-02T10:00:00Z",60);a.observed=30*60000L;a.drop=1;b.observed=60*60000L;b.drop=4;
        StatsSeries series=StatsSeries.make(Arrays.asList(a,b),2,1,at("2026-11-02T12:30:00Z"),TimeZone.getTimeZone("UTC"));
        assertEquals(90*60000L,series.totalObserved);assertEquals(5,series.totalDrop,0);assertEquals(5/1.5,series.values[29],.0001);assertEquals(0,series.observed[0]);
    }
    @Test public void networkSeriesOnlyTotalsTheSelectedWindow(){
        ActivityStats.Point a=point("2026-11-02T09:00:00Z",0),b=point("2026-09-02T09:00:00Z",0);a.bytes=3000000;b.bytes=9000000;
        StatsSeries series=StatsSeries.make(Arrays.asList(a,b),1,1,at("2026-11-02T12:30:00Z"),TimeZone.getTimeZone("UTC"));assertEquals(3000000,series.totalBytes);assertEquals(3,series.values[29],0);
    }
}
