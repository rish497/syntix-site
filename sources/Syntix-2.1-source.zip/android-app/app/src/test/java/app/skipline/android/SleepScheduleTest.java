package app.skipline.android;

import java.time.*;
import org.junit.Test;
import static org.junit.Assert.*;

public class SleepScheduleTest {
    private long at(String value){return ZonedDateTime.parse(value).toInstant().toEpochMilli();}
    @Test public void clockTimeLaterTodayIsNotMovedToTomorrow(){ZoneId zone=ZoneId.of("Asia/Kolkata");long now=at("2026-11-02T09:00+05:30[Asia/Kolkata]");assertEquals(at("2026-11-02T10:30+05:30[Asia/Kolkata]"),SleepSchedule.next(now,zone,10,30));}
    @Test public void passedTimeAndExactMinuteUseTheNextDay(){ZoneId zone=ZoneId.of("Asia/Kolkata");long now=at("2026-11-02T10:30+05:30[Asia/Kolkata]");assertEquals(at("2026-11-03T10:30+05:30[Asia/Kolkata]"),SleepSchedule.next(now,zone,10,30));}
    @Test public void midnightRollsIntoTheNextMonth(){ZoneId zone=ZoneId.of("Asia/Kolkata");assertEquals(at("2026-12-01T00:00+05:30[Asia/Kolkata]"),SleepSchedule.next(at("2026-11-30T23:59+05:30[Asia/Kolkata]"),zone,0,0));}
    @Test public void springGapResolvesToARealFutureInstant(){ZoneId zone=ZoneId.of("America/New_York");assertEquals(at("2026-03-08T03:30-04:00[America/New_York]"),SleepSchedule.next(at("2026-03-08T01:30-05:00[America/New_York]"),zone,2,30));}
    @Test public void repeatedHourCanStillUseItsSecondOccurrence(){ZoneId zone=ZoneId.of("America/New_York");assertEquals(at("2026-11-01T01:30-05:00[America/New_York]"),SleepSchedule.next(at("2026-11-01T01:45-04:00[America/New_York]"),zone,1,30));}
    @Test public void hoursAndMinutesAreCombinedWithoutOverflow(){assertEquals(8100000,SleepSchedule.duration(2,15));assertEquals(86340000,SleepSchedule.duration(23,59));}
    @Test(expected=IllegalArgumentException.class) public void zeroDurationIsRejected(){SleepSchedule.duration(0,0);}
    @Test(expected=IllegalArgumentException.class) public void invalidClockTimeIsRejected(){SleepSchedule.next(0,ZoneId.of("UTC"),25,0);}
}
