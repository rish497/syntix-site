package app.skipline.android;

import org.junit.*;
import org.junit.rules.TemporaryFolder;
import static org.junit.Assert.*;
import java.io.*;
import java.nio.file.Files;
import java.security.GeneralSecurityException;
import java.util.*;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

public class EncryptedAudioTest {
    @Rule public TemporaryFolder temp=new TemporaryFolder();
    private final SecretKey key=new SecretKeySpec(new byte[32],"AES");
    private File sealed(byte[] audio)throws Exception{File plain=temp.newFile(),encrypted=temp.newFile();Files.write(plain.toPath(),audio);EncryptedAudio.write(plain,encrypted,key,"recording");return encrypted;}
    @Test public void roundTripAndSeekingWorkAcrossEveryRecordBoundary()throws Exception{
        for(int length:new int[]{0,1,65535,65536,65537,3*65536+317}){
            byte[] audio=new byte[length];new Random(length).nextBytes(audio);File encrypted=sealed(audio);
            assertEquals(EncryptedAudio.HEADER+length+((length+65535L)/65536)*16,encrypted.length());
            try(EncryptedAudio.Reader reader=new EncryptedAudio.Reader(encrypted,key,"recording")){
                byte[] restored=new byte[length];int at=0;while(at<length){int n=reader.read(at,restored,at,Math.min(17001,length-at));assertTrue(n>0);at+=n;}assertArrayEquals(audio,restored);
                for(int position:new int[]{0,Math.min(65535,length),Math.min(65536,length),Math.max(0,length-17),length}){
                    byte[] piece=new byte[31];int count=reader.read(position,piece,0,piece.length);
                    if(position==length)assertEquals(-1,count);else assertArrayEquals(Arrays.copyOfRange(audio,position,position+count),Arrays.copyOf(piece,count));
                }
            }
        }
    }
    @Test public void modifiedAudioIsRejectedBeforeBytesAreReleased()throws Exception{
        File file=sealed(new byte[100]);try(RandomAccessFile bytes=new RandomAccessFile(file,"rw")){bytes.seek(EncryptedAudio.HEADER+9);bytes.write(45);}
        try(EncryptedAudio.Reader reader=new EncryptedAudio.Reader(file,key,"recording")){
            byte[] output=new byte[30];Arrays.fill(output,(byte)77);
            try{reader.read(0,output,0,output.length);fail("Tampering must fail authentication");}catch(IOException expected){for(byte value:output)assertEquals(77,value);}
        }
    }
    @Test public void chunksCannotBeReordered()throws Exception{
        File file=sealed(new byte[2*EncryptedAudio.CHUNK]);try(RandomAccessFile bytes=new RandomAccessFile(file,"rw")){
            byte[] chunk=new byte[EncryptedAudio.CHUNK+16];bytes.seek(EncryptedAudio.HEADER);bytes.readFully(chunk);bytes.seek(EncryptedAudio.HEADER+chunk.length);bytes.write(chunk);
        }
        try(EncryptedAudio.Reader reader=new EncryptedAudio.Reader(file,key,"recording")){try{reader.read(EncryptedAudio.CHUNK,new byte[1],0,1);fail("Wrong record index must fail");}catch(IOException expected){}}
    }
    @Test public void wrongInstallationKeyAndWrongRecordingBindingAreRejected()throws Exception{
        File file=sealed(new byte[300]);byte[] wrong=new byte[32];wrong[0]=1;
        for(boolean wrongKey:new boolean[]{false,true})try(EncryptedAudio.Reader ignored=new EncryptedAudio.Reader(file,wrongKey?new SecretKeySpec(wrong,"AES"):key,wrongKey?"recording":"different-recording")){fail("Wrong key or binding must fail");}catch(GeneralSecurityException expected){}
    }
    @Test public void truncationAndForgedLengthAreRejected()throws Exception{
        File cut=sealed(new byte[1000]);try(RandomAccessFile bytes=new RandomAccessFile(cut,"rw")){bytes.setLength(bytes.length()-1);}
        try(EncryptedAudio.Reader ignored=new EncryptedAudio.Reader(cut,key,"recording")){fail("Truncation must fail");}catch(IOException expected){}
        File changed=sealed(new byte[1000]);try(RandomAccessFile bytes=new RandomAccessFile(changed,"rw")){bytes.seek(12);bytes.writeLong(Long.MAX_VALUE);}
        try(EncryptedAudio.Reader ignored=new EncryptedAudio.Reader(changed,key,"recording")){fail("Invalid length must fail");}catch(IOException expected){}
    }
    @Test public void identicalAudioGetsDifferentKeysAndCiphertext()throws Exception{
        byte[] audio=new byte[1000];assertFalse(Arrays.equals(Files.readAllBytes(sealed(audio).toPath()),Files.readAllBytes(sealed(audio).toPath())));
    }
}
