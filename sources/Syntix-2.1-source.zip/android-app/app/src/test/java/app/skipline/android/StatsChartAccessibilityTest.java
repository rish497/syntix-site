package app.skipline.android;

import android.app.Application;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.Config;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class)
@Config(sdk=31,manifest=Config.NONE,application=Application.class,qualifiers="en-rUS")
@androidx.annotation.OptIn(markerClass = androidx.media3.common.util.UnstableApi.class)
public class StatsChartAccessibilityTest {
    @Test public void subMinuteListeningIsNotAnnouncedAsZero(){assertEquals("Less than one minute",StatisticsPlot.accessibleAmount(RuntimeEnvironment.getApplication(),0,20/60d,0));}
    @Test public void smallNetworkReadingsKeepTheirMeaningfulUnit(){String reading=StatisticsPlot.accessibleAmount(RuntimeEnvironment.getApplication(),1,.1,0);assertTrue(reading,reading.contains("100"));assertFalse(reading.equals("0M"));}
    @Test public void missingBatteryReadingDiffersFromMeasuredZero(){assertEquals("No reading",StatisticsPlot.accessibleAmount(RuntimeEnvironment.getApplication(),2,0,0));assertEquals("0.0 percent per hour",StatisticsPlot.accessibleAmount(RuntimeEnvironment.getApplication(),2,0,60000));}
}
