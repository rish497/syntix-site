package app.skipline.android;
import android.app.Activity;
import android.os.Bundle;
import android.widget.*;
/** Test-only UI; this is not the YouTube application and is never presented as one. */
public final class ShortcutFixtureActivity extends Activity {
    static int selected;
    @Override public void onCreate(Bundle state){super.onCreate(state);selected=0;LinearLayout root=new LinearLayout(this);root.setOrientation(1);TextView label=new TextView(this);label.setText("CONTROLLED TEST FIXTURE — not YouTube");root.addView(label);for(int i=1;i<=2;i++){final int index=i;LinearLayout card=new LinearLayout(this);card.setId(i==1?R.id.video_card:R.id.playlist_card);card.setOrientation(1);TextView title=new TextView(this);title.setText(i==1?"Test video":"Test playlist");card.addView(title);Button share=new Button(this);share.setText("Share");share.setId(R.id.share_button);share.setOnClickListener(v->selected=index);card.addView(share);root.addView(card,new LinearLayout.LayoutParams(-1,240));}setContentView(root);}
}
