package app.skipline.android;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.SystemClock;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.test.core.app.ActivityScenario;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.media3.common.Player;
import java.io.File;
import java.io.FileOutputStream;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.ArrayList;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;

@RunWith(AndroidJUnit4.class)
@androidx.media3.common.util.UnstableApi
public class CompanionTest {
    @org.junit.Before public void prepareSurface()throws Exception{Context testContext=InstrumentationRegistry.getInstrumentation().getTargetContext();testContext.getSharedPreferences("preparation",0).edit().putBoolean("automatic",false).putBoolean("paused",true).putBoolean("v3_initialized",true).commit();testContext.getSharedPreferences("history",0).edit().putBoolean("recommendations_enabled",false).commit();InstrumentationRegistry.getInstrumentation().getUiAutomation().executeShellCommand("cmd statusbar collapse").close();SystemClock.sleep(300);}
    @Test public void extractorRuntimeRuns()throws Exception{
        Context context=InstrumentationRegistry.getInstrumentation().getTargetContext();
        Extractor.init(context);
        com.yausername.youtubedl_android.YoutubeDLRequest request=new com.yausername.youtubedl_android.YoutubeDLRequest(java.util.Collections.emptyList());
        request.addOption("--version");
        String version=com.yausername.youtubedl_android.YoutubeDL.INSTANCE.execute(request,"runtime-test",false,null).getOut();
        assertTrue("The bundled extractor must execute on this Android version",version.matches("(?s).*20[0-9]{2}\\.[0-9]{2}\\.[0-9]{2}.*"));
        try(FileOutputStream out=new FileOutputStream(new File(context.getFilesDir(),"engine-version.txt"))){out.write(version.getBytes(java.nio.charset.StandardCharsets.UTF_8));}
    }
    @Test public void liveYoutubeDiagnostic()throws Exception{
        String link=InstrumentationRegistry.getArguments().getString("youtubeTestUrl","");
        if(link.isEmpty())return;
        Context context=InstrumentationRegistry.getInstrumentation().getTargetContext();
        String report;
        try{
            long started=SystemClock.elapsedRealtime();ArrayList<Track> tracks=Extractor.inspect(context,link);assertFalse(tracks.isEmpty());long inspected=SystemClock.elapsedRealtime();Extractor.Resolved stream=Extractor.resolve(context,tracks.get(0).source);long cached=SystemClock.elapsedRealtime();ArrayList<Track> repeated=Extractor.inspect(context,link);long repeatedAt=SystemClock.elapsedRealtime();assertNotEquals("Repeated imports need distinct timeline IDs",tracks.get(0).id,repeated.get(0).id);
            SkiplineApp app=(SkiplineApp)context.getApplicationContext();
            InstrumentationRegistry.getInstrumentation().runOnMainSync(()->{app.queue.clear();app.queue.add(tracks.get(0));app.playback.sync(false);app.playback.play(0);});
            AtomicBoolean played=new AtomicBoolean(false),failed=new AtomicBoolean(false);
            for(int i=0;i<450&&!played.get()&&!failed.get();i++){InstrumentationRegistry.getInstrumentation().runOnMainSync(()->{played.set(app.playback.player.isPlaying()&&app.playback.player.getCurrentPosition()>300);failed.set(app.playback.player.getPlayerError()!=null);});SystemClock.sleep(100);}
            report="Resolved public YouTube metadata and HTTPS audio stream: "+tracks.get(0).title+". Actual ExoPlayer playback: "+played.get()+". Initial extraction ms: "+(inspected-started)+"; cached resolve ms: "+(cached-inspected)+"; repeated import ms: "+(repeatedAt-cached)+"; time to audio ms: "+(SystemClock.elapsedRealtime()-started)+". "+app.error;
            InstrumentationRegistry.getInstrumentation().runOnMainSync(()->{app.playback.player.pause();app.queue.clear();app.playback.sync(false);app.changed();});
        }
        catch(Exception error){report="YouTube source diagnostic: "+Extractor.error(error)+"\n"+error.getClass().getSimpleName()+": "+error.getMessage();}
        try(FileOutputStream out=new FileOutputStream(new File(context.getFilesDir(),"youtube-diagnostic.txt"))){out.write(report.getBytes(java.nio.charset.StandardCharsets.UTF_8));}
    }
    private View find(View view,String text){if(view instanceof TextView&&((TextView)view).getText().toString().equals(text))return view;if(view instanceof ViewGroup){ViewGroup group=(ViewGroup)view;for(int i=0;i<group.getChildCount();i++){View match=find(group.getChildAt(i),text);if(match!=null)return match;}}return null;}
    private void capture(String name)throws Exception{InstrumentationRegistry.getInstrumentation().waitForIdleSync();SystemClock.sleep(500);Bitmap bitmap=InstrumentationRegistry.getInstrumentation().getUiAutomation().takeScreenshot();assertNotNull(bitmap);File path=new File(InstrumentationRegistry.getInstrumentation().getTargetContext().getFilesDir(),name+".png");try(FileOutputStream out=new FileOutputStream(path)){bitmap.compress(Bitmap.CompressFormat.PNG,100,out);}}
    @Test public void welcomeQueueAndBackgroundPlayback()throws Exception{
        Context context=InstrumentationRegistry.getInstrumentation().getTargetContext();
        context.getSharedPreferences("MainActivity",0).edit().clear().commit();
        context.getSharedPreferences("session",0).edit().clear().commit();
        InstrumentationRegistry.getInstrumentation().runOnMainSync(()->{SkiplineApp app=(SkiplineApp)context.getApplicationContext();app.queue.clear();app.library.clear();app.saveLibrary();if(app.playback!=null)app.playback.sync(false);app.changed();});
        try(ActivityScenario<MainActivity> scenario=ActivityScenario.launch(MainActivity.class)){
            scenario.onActivity(a->{View start=find(a.getWindow().getDecorView(),"Get started");assertNotNull(start);});
            capture("welcome");
            scenario.onActivity(a->find(a.getWindow().getDecorView(),"Get started").performClick());
            InstrumentationRegistry.getInstrumentation().waitForIdleSync();
            capture("empty");
            scenario.onActivity(a->{View sample=find(a.getWindow().getDecorView(),"Try a local playback sample");assertNotNull(sample);sample.performClick();});
            AtomicBoolean playing=new AtomicBoolean(false);
            for(int i=0;i<150&&!playing.get();i++){scenario.onActivity(a->{SkiplineApp app=(SkiplineApp)a.getApplication();playing.set(app.playback!=null&&app.playback.player.isPlaying());});SystemClock.sleep(100);}
            assertTrue("Local audio must actually play",playing.get());
            InstrumentationRegistry.getInstrumentation().waitForIdleSync();capture("queue");
            scenario.onActivity(a->a.moveTaskToBack(true));SystemClock.sleep(1200);
            InstrumentationRegistry.getInstrumentation().runOnMainSync(()->{SkiplineApp app=(SkiplineApp)context.getApplicationContext();assertTrue("Playback continues after leaving Activity",app.playback.player.isPlaying());assertEquals(1,app.queue.size());assertTrue(app.playback.player.getCurrentPosition()>0);});
            InstrumentationRegistry.getInstrumentation().runOnMainSync(()->{SkiplineApp app=(SkiplineApp)context.getApplicationContext();app.playback.player.pause();});
            scenario.moveToState(androidx.lifecycle.Lifecycle.State.DESTROYED);
        }
    }
    @Test public void shareIntentDisplaysListenAndQueueActions()throws Exception{
        Context context=InstrumentationRegistry.getInstrumentation().getTargetContext();
        Intent intent=new Intent(context,MainActivity.class).setAction(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT,"https://www.youtube.com/playlist?list=PL_demo");
        try(ActivityScenario<MainActivity> scenario=ActivityScenario.launch(intent)){
            InstrumentationRegistry.getInstrumentation().waitForIdleSync();
            capture("share");
            // The app must not start network extraction until the user chooses an action.
            scenario.onActivity(a->{assertFalse(((SkiplineApp)a.getApplication()).busy);});
        }
    }
    private android.view.accessibility.AccessibilityNodeInfo node(String label){
        android.view.accessibility.AccessibilityNodeInfo root=InstrumentationRegistry.getInstrumentation().getUiAutomation().getRootInActiveWindow();return search(root,label);
    }
    private android.view.accessibility.AccessibilityNodeInfo search(android.view.accessibility.AccessibilityNodeInfo root,String label){if(root==null)return null;if(label.contentEquals(root.getText()==null?"":root.getText())||label.contentEquals(root.getContentDescription()==null?"":root.getContentDescription()))return root;for(int i=0;i<root.getChildCount();i++){android.view.accessibility.AccessibilityNodeInfo hit=search(root.getChild(i),label);if(hit!=null)return hit;}return null;}
    private android.view.accessibility.AccessibilityNodeInfo scrollable(android.view.accessibility.AccessibilityNodeInfo root){if(root==null)return null;if(root.isScrollable())return root;for(int i=0;i<root.getChildCount();i++){android.view.accessibility.AccessibilityNodeInfo hit=scrollable(root.getChild(i));if(hit!=null)return hit;}return null;}
    private void click(String label){InstrumentationRegistry.getInstrumentation().waitForIdleSync();android.view.accessibility.AccessibilityNodeInfo hit=node(label);for(int i=0;hit==null&&i<5;i++){android.view.accessibility.AccessibilityNodeInfo scroll=scrollable(InstrumentationRegistry.getInstrumentation().getUiAutomation().getRootInActiveWindow());if(scroll==null)break;scroll.performAction(android.view.accessibility.AccessibilityNodeInfo.ACTION_SCROLL_FORWARD);SystemClock.sleep(300);hit=node(label);}assertNotNull("Visible action: "+label,hit);while(hit!=null&&!hit.isClickable())hit=hit.getParent();assertNotNull(hit);assertTrue(hit.performAction(android.view.accessibility.AccessibilityNodeInfo.ACTION_CLICK));InstrumentationRegistry.getInstrumentation().waitForIdleSync();SystemClock.sleep(300);}
    private android.view.accessibility.AccessibilityNodeInfo input(android.view.accessibility.AccessibilityNodeInfo root){if(root==null)return null;if("android.widget.EditText".contentEquals(root.getClassName()))return root;for(int i=0;i<root.getChildCount();i++){android.view.accessibility.AccessibilityNodeInfo hit=input(root.getChild(i));if(hit!=null)return hit;}return null;}
}
