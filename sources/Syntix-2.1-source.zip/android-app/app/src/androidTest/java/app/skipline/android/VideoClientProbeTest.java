package app.skipline.android;

import android.content.Context;
import android.os.SystemClock;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import com.yausername.youtubedl_android.YoutubeDL;
import org.json.JSONObject;
import org.junit.Test;
import org.junit.runner.RunWith;
import java.io.File;
import java.io.FileOutputStream;
import java.util.Iterator;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

@RunWith(AndroidJUnit4.class)
public class VideoClientProbeTest {
    @Test public void directClientLatency()throws Exception{
        String source=InstrumentationRegistry.getArguments().getString("probeUrl","");if(source.isEmpty())return;
        Context context=InstrumentationRegistry.getInstrumentation().getTargetContext();Extractor.init(context);long start=SystemClock.elapsedRealtime();String report;
        try{
            JSONObject info=new JSONObject(YoutubeDL.INSTANCE.execute(Extractor.request(source).addOption("--no-playlist").addOption("--skip-download").addOption("--dump-single-json").addOption("-f","bestaudio[protocol=https]/best[protocol=https]").addOption("--extractor-args","youtube:player_client=visionos"),"client-probe",false,null).getOut());
            long extracted=SystemClock.elapsedRealtime();Request.Builder request=new Request.Builder().url(info.getString("url"));JSONObject headers=info.optJSONObject("http_headers");if(headers!=null){Iterator<String> names=headers.keys();while(names.hasNext()){String key=names.next();request.header(key,headers.getString(key));}}request.header("Range","bytes=0-1023");
            try(Response response=new OkHttpClient.Builder().callTimeout(20,java.util.concurrent.TimeUnit.SECONDS).build().newCall(request.build()).execute()){byte[] bytes=new byte[1024];int count=response.body()==null?-1:response.body().byteStream().read(bytes);report="visionos extraction ms: "+(extracted-start)+"; HTTP status: "+response.code()+"; media bytes read: "+count;}
        }catch(Exception error){report="visionos client probe unavailable: "+Extractor.error(error);}
        try(FileOutputStream out=new FileOutputStream(new File(context.getFilesDir(),"client-probe.txt"))){out.write(report.getBytes(java.nio.charset.StandardCharsets.UTF_8));}
    }
}
