# Syntix Android V13.3 test — scoped design record

## Overview

This narrow native refinement preserves the incumbent Syntix design system. It addresses the second and third welcome illustration placements, improves first-run local profile setup, and removes the playback icon over playlist-row artwork while retaining the selected shade. It records implementation and reviewed test evidence, not native visual acceptance. `DESIGN.md`, product truth, design sidecars, supplied identity assets and Outfit fonts remain authoritative and unchanged by this documentation pass.

The review disposition is **RECAPTURE**: the supplied review found no actionable source/layout defect, but physical-device or emulator acceptance remains outstanding. No ADB device is connected. Robolectric renders are layout evidence only.

## Colors

Preserve the incumbent slate shell, ivory primary actions, ink text and muted secondary text. Welcome artwork retains the component-local beige paper field (`#CBBDAF`). The current playlist row retains warm-slate selection (`#34362F`) and ivory title/state text. These are existing component treatments, not new global tokens.

## Typography

Retain Outfit regular/semibold and native font scaling. Welcome headings remain 38 sp, reducing to 30 sp in compact-height mode, with left alignment and the existing tight tracking. The profile header is now “Make it yours.” at 36 sp with the same tight tracking. Secondary copy, field labels, helper text and legal links retain the incumbent hierarchy.

## Layout

Welcome pages remain manually controlled ViewPager2 pages with scrollable content, a column capped at 540 dp and 24 dp horizontal padding. `Onboarding.Illustration` replaces the prior transparent-canvas `FIT_END` placement: it scans each bitmap for visible alpha greater than 40, caches that bounding rectangle and scales it uniformly to fit the scene view's width and height. It draws the visible rectangle centered horizontally, anchored to the paper's lower baseline, 8 dp above the scene bottom. The paper is inset 16 dp horizontally, starts 8 dp below the scene top and retains 22 dp corners. The figure can overhang the inset paper sideways while staying within the scene bounds. Transparent export margins no longer determine figure scale or baseline. Raster assets are unchanged.

Artwork height still adapts to available text space with a 160 dp minimum when visible. Below 350 dp of pager height it hides, leaving the compact heading/copy and footer route. The landscape render demonstrates this compact treatment; the tablet render demonstrates a centered bounded column. These renders do not verify Android system insets or native swipe behavior.

Profile setup remains a scrolling column capped at 560 dp. Its order is Back, heading and short introduction, centered optional photo control, name label/field/helper, explicit consent, Create profile and the local-storage explanation. The large-text render shows the introduction wrapping and the name area lower in the viewport; it does not show the lower consent/action region. Scrolling to those controls at font scale 1.3 still requires native acceptance.

## Elevation & Depth

Keep flat tonal layering: slate page, beige paper, transparent figure and incumbent native controls. The photo's small raised-slate badge distinguishes the picker action. No new scene shadows, decorative depth system or animation grammar is introduced.

## Shapes

The welcome paper retains 22 dp corners and the forward action its 60 dp circular form. Profile setup uses a 104 dp circular photo within a centered 120 × 112 dp hit region, with a 44 dp photo badge. “Add a photo” has a separate 48 dp-high actionable label. The name field is 60 dp high with 14 dp corners; Create profile is 56 dp high with 28 dp corners. Playlist selection retains 8 dp corners.

## Components

### Welcome artwork

The fresh `onboarding-welcome-1.png` shows the seated headphone listener grounded at the inset paper baseline, with the visible figure within the page. `onboarding-welcome-2.png` shows the two listeners and raised hand within the scene width, with intentional overhang beyond the paper. These compare the updated source against the V13.2 record's `FIT_END` behavior; they do not establish a measured before/after device result.

### Local profile setup

The centered ivory avatar, photo badge and “Add a photo” label open the existing Android document picker through `NativeScreens.choosePhoto`. An existing photo uses center-crop; otherwise the incumbent profile symbol is shown. Name remains optional in first-run setup, limited to 40 characters, with “What should we call you?” and nickname helper text.

The unchanged consent reads: “I confirm I am 13+ and agree to the Terms of Use and acknowledge the Privacy Policy.” It begins unchecked, with separate readable Terms and Privacy links. Create profile is disabled and dimmed until accepted; the action handler also rejects unaccepted completion. Acceptance records local legal versions and a timestamp. The accepted test render shows the ivory enabled action, but the native checked glyph still needs device inspection.

Copy explicitly states “No email or password. Saved on this phone.” and that profiles are not password-protected. This is local personalization, with no signup backend, verified identity, cloud account or child-consent mechanism. Additional-profile creation keeps its existing name requirement and initially unchecked agreement; editing an existing profile remains separate.

### Playlist playback state

`NativeScreens` binds the ordinary track artwork and text to `PlaylistPlayback.bindRow` without an artwork playback overlay. The current source retains the selected warm-slate row shade, ivory text, selected accessibility state and Playing/Loading/Paused subtitle prefix for the actual current track in the current playlist. Other rows return to transparent backgrounds and incumbent text colors. The top playlist play/pause control remains stateful. There is no fresh playing-row image in this reviewed set; shade retention and absence of overlay are source findings pending native capture.

### Preserved import flow

Full Spotify metadata pagination, canonical catalog artist/version matching and removal of the 100-song truncation remain behind the existing native import/progress experience. They introduce no new screen or design system here. Backend correctness, matching accuracy and device latency are outside this visual record; no such claims follow from these renders.

## Do's and Don'ts

- **Do** preserve slate/ivory, Outfit, supplied identity and the paper/figure composition.
- **Do** fit visible illustration bounds to the scene and anchor the figures to the inset paper baseline.
- **Do** preserve explicit unchecked 13+ consent, local-only profile explanations and readable legal links.
- **Do** recapture welcome pages 2–3, profile unchecked/checked/photo-picked/keyboard states, font scale 1.3 scrolled through Create profile, current playlist-row shade without overlay, and status/navigation insets on a physical device or emulator.
- **Don't** equate Robolectric rendering with phone/emulator capture, gesture verification, visual signoff, matching accuracy or device playback/search timing.
- **Don't** infer that the large-text viewport proves lower actions reachable or that the accepted test-render checkbox proves its native glyph.

Evidence compared: `PRODUCT.md`, incumbent `DESIGN.md`, `DESIGN-V13.2-TEST.md`, Impeccable `reference/document.md`, current `Onboarding.java`, relevant profile/photo/track composition in `NativeScreens.java`, and `PlaylistPlayback.java`. Visually inspected fresh Robolectric renders in `.impeccable/review/v13/`: `onboarding-welcome-1.png`, `onboarding-welcome-2.png`, `onboarding-profile-unchecked.png`, `onboarding-profile-accepted.png`, `onboarding-profile-large-text.png`, `onboarding-welcome-landscape.png` and `onboarding-welcome-tablet.png`. The documenter did not run builds/tests or change code, raster assets, fonts, product truth, incumbent design records or sidecars.
