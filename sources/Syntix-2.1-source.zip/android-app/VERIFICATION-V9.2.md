# Syntix 0.9.2

Version code 11. Color-only player refinement: the full-window gradient blends the existing ivory accent into the slate page color (35% accent at the top, 12% at the middle, slate at the bottom). It uses the app's actual theme constants rather than a separate teal palette. Existing edge-to-edge status-bar coverage and safe-area padding are preserved. Playback and all other features remain unchanged from 0.9.1.

Release assembly/lint and production-signature checks accompany this APK. No new phone screenshot or on-device color validation is available. The existing 26-test result belongs to the preceding playback hotfix; tests are not rerun for this reversible color-only change.
