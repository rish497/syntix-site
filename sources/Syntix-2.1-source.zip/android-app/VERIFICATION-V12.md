# V12 verification

Version: 0.12.0 / code 20. Android 12+ and the existing production signing identity are retained.

Scope: retain Spotify public-link and optional CSV metadata import, reviewed YouTube matches and existing ad-free native playback. No Spotify audio embed is used for playback, no advertising SDK is added and imports do not download audio automatically. The only playback-related addition publishes buffering state so automatic metadata matching can yield before issuing further searches. Existing cache and warmup behavior are unchanged.

Automated checks passed: release assembly, release lint (0 errors / 66 warnings) and all 81 debug unit tests (0 failures/errors). New scheduling tests verify the matcher waits while a song buffers, resumes once ready, releases on cancel/task dismissal, and pauses for background idle. These use no live network or audio engine. Existing tests cover full 715-row CSV, partial-preview notices, safe link handling, conservative matching, explicit save and the app's other features.

Device limits: no physical phone is connected. Real playback start latency, audible output, live Spotify/YouTube availability, battery use and manufacturer-specific lifecycle behavior have not been measured for V12. A fixed startup-time guarantee is not made. Native graphics evidence is Robolectric rendering, not a phone capture. Previous native finish-review recapture remains pending.

Live public inspection from V11.3 of the supplied playlist showed 715 items and 100 exposed track entries. This is a per-playlist observation, not a universal Spotify limit. The app displays partial/unverified lists rather than silently asserting completeness. CSV remains an optional path and is supported up to 5,000 supplied entries / 5 MB.

Import progress survives Activity recreation in memory, but not process termination. Active metadata requests are bounded and may complete while playback starts; new automatic requests wait during buffering. Public-page format changes or restrictions can still prevent import. Matching is conservative and may require manual review.

Packaging retains earlier APKs, uses the existing production key and excludes signing keys, SDK paths and build caches from the source archive. Syntix-0.12.0.sha256 contains the APK hash.
