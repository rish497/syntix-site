# Spotify import loss: 2026-11-03

The supplied Sidhu Moose Wala Radio playlist exposes all 50 metadata entries through its public Spotify embed. The observed loss is not a 100-entry preview cap.

An actual Java/OkHttp run using the app's parser and search transport reproduced 5 matched entries and 45 search errors. Instrumenting unsuccessful responses confirmed HTTP 302 redirects to Google's `/sorry/index` verification page. The importer previously caught these IOExceptions, marked the row attempted, and later included it in the skipped total. Thus the reported 45 skips did not establish that 45 songs were unavailable on YouTube. A second run confirmed the same redirect behavior and was stopped instead of continuing requests.

Separate source defects could also reject available recordings: requiring nearly all credited artists for short titles, treating missing duration as disqualifying, tight duration tolerance, including featured/soundtrack annotations as title identity, rejecting ordinary album labels, retaining only ten first-page candidates and performing no alternate query for an unmatched recording.

Source changes, not yet packaged as a new APK:

- Detect verification/rate-limit responses explicitly and stop automatic matching requests. Do not retry a verification redirect repeatedly.
- Leave interrupted/blocked rows pending, retain the in-memory draft, avoid committing an incomplete successful playlist, and offer Retry import. Actual unmatched rows and blocked search requests are distinct.
- Accept strong title evidence plus a credited artist, including normal artist-name spacing variants; allow modest duration differences and strongly identified results with omitted duration metadata.
- Normalize featured/soundtrack annotations; retain wrong-recording/cover/remix guards, prefer close duration matches, use the full first page and a second query when necessary.
- Retry transient request failures once, while preserving the buffering/cancellation gate and two-worker limit.

These changes prevent false skip reporting and improve recording matching. They do not remove Google's verification restriction or demonstrate 50/50 successful importing. The exact playlist has not completed a successful full import with the revised source. No claim of guaranteed zero skips, playback equivalence or physical-phone verification is made. V12.3's delivered APK remains the previous binary.

Reproduction output is kept in `.site-deps/spotify-radio-audit.json`; only public track metadata and match/error results are recorded. The sanitized embed fixture contains track metadata only. No audio was downloaded in this diagnosis.


## Follow-up: V12.4

The later yt-dlp metadata-search test completed the supplied 50-track snapshot and the final Java matcher found 50 distinct matches. See VERIFICATION-V12.4.md for clean-run conditions and device-testing limits. This supersedes the earlier incomplete-import status above.
