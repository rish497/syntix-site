# Syntix V11 verification

Release: **0.11.0**, version code **16**, application ID `app.skipline.android`, minimum API **31**, target API **35**; ARMv7 and ARM64 native libraries.

## Scope

V11 adds native Equalizer, Sleep timer, Replay, history-derived Smart Mixes and selectable future offline audio quality. Custom playlist covers are excluded. Source responsibilities are `SoundProcessor`, `SoundSettings`, `SleepTimer`, `EqualizerScreen`, `ListeningFeatures` and `SmartMixes`, integrated with existing native navigation, profiles, history, activity reports and services.

The playback engine, extraction, cache and latency infrastructure are preserved except for the default-bypassed PCM processor and service timer. Profile settings persist separately; new first-listen/night metadata begins in V11 while old play counts remain intact. Earlier version records remain historical and are not overwritten by this document.

## Final automated validation

Final `assembleRelease`, `lintRelease` and `testDebugUnitTest` completed with **BUILD SUCCESSFUL**. The suite contains **49 tests, 0 failures, 0 skipped**. Release lint reports **0 errors and 62 warnings** (prior baseline 56; additions include hardcoded English strings).

Tests cover PCM bypass and flat response, frequency response, stereo isolation, normalization, flush state and Nyquist handling; Smart Mix criteria, legacy data, profile isolation and first-listen persistence; real SQLite reports across month/profile boundaries; timer fade, cancellation and song-end behavior; and seven accessible native Equalizer bands plus native View rendering. These checks do not establish listening quality, phone accessibility behavior or real-device performance.

## APK verification and packaging

The signed release APK is **121,256,476 bytes**, below the 500 MB limit. `apksigner` verified the incumbent production certificate SHA-256:

`a3e24ba7f432a86074664663f9f2e5a7752ca9eb073e8df439498725c47d90e3`

Final repository-root output is `Syntix-0.11.0.apk`, with `Syntix-0.11.0.sha256` and `syntix-v11-android-source.zip`. Packaging completed; the source archive excludes build caches, local SDK configuration and signing keys. Certificate verification establishes signing identity, not production certification. Do not uninstall an existing same-key installation to perform a direct update; retained-data upgrade behavior still needs phone verification.

## Finish review: RECAPTURE

The native finish reviewer requires real phone/emulator captures and font scale **1.3** before completing visual acceptance. Constrained source/render inspection found the Equalizer composition consistent with the user's vertical-control reference through the slate/ivory adaptation, including seven accessible ranges and at least 48 dp band touch widths. This is not device visual signoff.

Evidence under repository-root `.impeccable/review/v11/`:

- `equalizer-native-test.png`: native Robolectric View graphic, 393 × 852, including app chrome.
- `sleep-native-test.png`: native Robolectric View graphic, 393 × 852, content only.
- `quality-native-test.png`: native Robolectric View graphic, 393 × 852, content only.

These are test renders, not phone/emulator captures or shipping artwork. The user reference path and asset provenance are recorded in DESIGN-V11.md. No native web-detector run was performed. No ADB device is attached, and no emulator is installed or created; the required recapture cannot be completed in this environment.

## Remaining native checks

Capture the reference-matched Equalizer and all added surfaces on a real phone or emulator at normal and 1.3 font scale. Check system insets, lower-control scrolling, touch gestures, focus and TalkBack values/actions. Verify timer fade/song-end/cancel across screen lock and task dismissal; real audio response and profile sound switching; once-per-profile monthly invitation using real prior-month activity; Replay sharing; Smart Mix playback/save and empty states; and bitrate selection for future downloads while existing files remain intact.

No new device battery, performance, startup-latency or production-certification evidence exists. Automated success does not close the outstanding **RECAPTURE** requirement.
