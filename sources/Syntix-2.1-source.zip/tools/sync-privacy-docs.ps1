$ErrorActionPreference = 'Stop'
$taskRoot = Split-Path $PSScriptRoot -Parent
$taskLegal = Join-Path $taskRoot 'android-app/app/src/main/assets/legal'
New-Item -ItemType Directory -Path $taskLegal -Force | Out-Null
# Root Markdown files are canonical. Rerun after filling placeholders or changing the policy.
foreach ($taskDocument in @('PRIVACY_POLICY.md','TERMS_OF_USE.md','THIRD_PARTY_LICENSES.md','SOURCE_DISTRIBUTION.md')) {
    Copy-Item -LiteralPath (Join-Path $taskRoot $taskDocument) -Destination (Join-Path $taskLegal $taskDocument) -Force
}

Copy-Item -LiteralPath (Join-Path $taskRoot 'android-app/LICENSE') -Destination (Join-Path $taskLegal 'PROJECT_LICENSE.txt') -Force

# Static legal assets only; this does not add runtime network access.
Copy-Item -LiteralPath (Join-Path $taskRoot 'NATIVE_BUILD_AUDIT.md') -Destination (Join-Path $taskLegal 'NATIVE_BUILD_AUDIT.md') -Force
