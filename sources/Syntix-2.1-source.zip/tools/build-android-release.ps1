param([string]$SigningFile = (Join-Path $env:USERPROFILE '.skipline/signing/signing-credentials.json'), [string[]]$Tasks = @('assembleRelease'))
$ErrorActionPreference = 'Stop'
$taskRoot = Split-Path $PSScriptRoot -Parent
& (Join-Path $PSScriptRoot 'sync-privacy-docs.ps1')
& (Join-Path $PSScriptRoot 'prepare-source-archive.ps1')
$taskSigning = Get-Content -LiteralPath $SigningFile -Raw | ConvertFrom-Json
$taskJdk = Join-Path $taskRoot '.site-deps/android-build/jdk'
if (Test-Path -LiteralPath $taskJdk) { $env:JAVA_HOME = (Get-ChildItem -LiteralPath $taskJdk -Directory | Select-Object -First 1).FullName }
$env:SKIPLINE_KEYSTORE = $taskSigning.keystore
$env:SKIPLINE_STORE_PASSWORD = $taskSigning.password
$env:SKIPLINE_KEY_ALIAS = $taskSigning.alias
$env:SKIPLINE_KEY_PASSWORD = $taskSigning.password
try {
    & (Join-Path $taskRoot 'android-app/gradlew.bat') -p (Join-Path $taskRoot 'android-app') @Tasks --console=plain
    if ($LASTEXITCODE -ne 0) { throw 'Android release build failed.' }
} finally {
    Remove-Item Env:SKIPLINE_STORE_PASSWORD,Env:SKIPLINE_KEY_PASSWORD -ErrorAction SilentlyContinue
    $taskSigning = $null
}
