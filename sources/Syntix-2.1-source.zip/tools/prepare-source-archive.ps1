$ErrorActionPreference = 'Stop'
$taskRoot = Split-Path $PSScriptRoot -Parent
$taskApp = Join-Path $taskRoot 'android-app'
$taskGradle = Get-Content -LiteralPath (Join-Path $taskApp 'app/build.gradle') -Raw
$taskVersion = [regex]::Match($taskGradle,"versionName '([A-Za-z0-9._-]+)'").Groups[1].Value
if (!$taskVersion) { throw 'Could not determine the source archive version.' }
$taskOutput = Join-Path $taskRoot "public-site/sources/Syntix-$taskVersion-source.zip"
New-Item -ItemType Directory -Path (Split-Path $taskOutput -Parent) -Force | Out-Null
$taskStage = Join-Path $taskRoot '.site-deps/source-archive'
New-Item -ItemType Directory -Path $taskStage -Force | Out-Null
$taskTemp = Join-Path $taskStage 'application-source.zip'
Add-Type -AssemblyName System.IO.Compression
$taskStream = [System.IO.File]::Open($taskTemp,[System.IO.FileMode]::Create)
$taskZip = [System.IO.Compression.ZipArchive]::new($taskStream,[System.IO.Compression.ZipArchiveMode]::Create)
try {
    Get-ChildItem -LiteralPath $taskApp -File -Recurse | ForEach-Object {
        $taskRelative = $_.FullName.Substring($taskApp.Length+1).Replace('\','/')
        if ($taskRelative -match '(^|/)(build|\.gradle|test-releases)/|(^|/)local.properties$|\.(zip|apk|aab|keystore|jks|p12|pfx|key)$|signing-credentials' -or $taskRelative -match '(^|/)\.env') { return }
        [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($taskZip,$_.FullName,"android-app/$taskRelative",[System.IO.Compression.CompressionLevel]::Optimal) | Out-Null
    }
    foreach ($taskDocument in @('PRIVACY_POLICY.md','TERMS_OF_USE.md','THIRD_PARTY_LICENSES.md','CONTENT_RIGHTS_NOTES.md','SOURCE_DISTRIBUTION.md','NATIVE_BUILD_AUDIT.md','STORE_POLICY_REVIEW.md','STORE_LISTING.md')) {
        [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($taskZip,(Join-Path $taskRoot $taskDocument),$taskDocument,[System.IO.Compression.CompressionLevel]::Optimal) | Out-Null
    }
    foreach ($taskScript in @('build-android-release.ps1','sync-privacy-docs.ps1','prepare-source-archive.ps1','prepare-release-notices.py')) {
        [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($taskZip,(Join-Path $PSScriptRoot $taskScript),"tools/$taskScript",[System.IO.Compression.CompressionLevel]::Optimal) | Out-Null
    }
} finally { $taskZip.Dispose(); $taskStream.Dispose() }
Copy-Item -LiteralPath $taskTemp -Destination $taskOutput -Force
Get-Item -LiteralPath $taskOutput | Select-Object Name,Length
