"""Rebuild offline notices from the exact cached release coordinates; no runtime network."""
from pathlib import Path
import re,zipfile,io,hashlib,json,shutil
root=Path(__file__).resolve().parents[1];cache=Path.home()/'.gradle/caches/modules-2/files-2.1'
out=root/'android-app/app/src/main/assets/legal/notices';out.mkdir(parents=True,exist_ok=True)
text=(root/'THIRD_PARTY_LICENSES.md').read_text(encoding='utf-8').split('## Resolved releaseRuntimeClasspath')[1].split('## Resolved debugUnitTestRuntimeClasspath')[0]
coordinates=re.findall(r'^\| `([^`]+)` \| ([^|]+) \|',text,re.M);index=[]; notices=[]
for coordinate,version in coordinates:
 group,artifact=coordinate.split(':');version=version.strip();folder=cache/group/artifact/version
 files=list(folder.rglob('*.aar'))+list(folder.rglob('*.jar'));paths=[]
 def collect(z,prefix=''):
  for n in z.namelist():
   if n.endswith('/') or n.lower().endswith('.class'):continue
   if re.search(r'(^|/)(license|notice|copying|copyright|dependencies)([._-].*|\d*|)$',n,re.I):
    b=z.read(n)
    if b'\x00' in b:continue
    name=f'{group}.{artifact}-{version}-'+re.sub(r'[^A-Za-z0-9._-]','_',prefix+n)
    (out/name).write_bytes(b);paths.append({'path':name,'source_entry':prefix+n,'sha256':hashlib.sha256(b).hexdigest()});notices.append((coordinate+':'+version+' / '+prefix+n,b.decode('utf-8',errors='replace')))
   if n=='classes.jar':collect(zipfile.ZipFile(io.BytesIO(z.read(n))),'classes.jar/')
 for f in files:collect(zipfile.ZipFile(f))
 index.append({'coordinate':coordinate,'version':version,'files':paths})
for name in ['Outfit-OFL.txt','Phosphor-MIT.txt']:
 f=root/'android-app/licenses'/name;shutil.copyfile(f,out/name);notices.append((name,f.read_text(encoding='utf-8')))
for f in (root/'android-app/licenses/evidence/upstream').glob('*'):
 if f.is_file():shutil.copyfile(f,out/f.name);notices.append((f.name,f.read_text(encoding='utf-8',errors='replace')))
(out/'index.json').write_text(json.dumps(index,indent=2),encoding='utf-8')
combined='# Third-party notices\n\nFull notices extracted from the exact resolved release Maven artifacts, plus upstream native license texts and font/icon attribution. The license inventory and native audit describe remaining corresponding-source/provenance gaps.\n\n'+'\n\n'.join('## '+title+'\n\n'+body for title,body in notices)
(root/'android-app/app/src/main/assets/legal/THIRD_PARTY_NOTICES.md').write_text(combined,encoding='utf-8')
print('Runtime coordinates:',len(index),'notice files:',len(notices),'combined bytes:',len(combined.encode('utf-8')))
