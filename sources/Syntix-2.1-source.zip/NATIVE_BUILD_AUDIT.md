# Native build audit — Syntix 0.13.1

Checked 3 November 2026. Identification is evidence, not a claim of complete corresponding-source delivery.

## Exact payload shipped

Coordinates: io.github.junkfood02.youtubedl-android library/common/ffmpeg 0.18.1. Only arm64-v8a and armeabi-v7a are shipped. Upstream tag 0.18.1 resolves to tree d725d5c9a18c3a99a13ee0308bf78275dc310760. All 12 selected native payload files, their SHA-256 hashes and all files inside the Python/FFmpeg ZIP payloads are recorded in android-app/licenses/native-payload-inventory.json. Every packaged native file also matches its Git blob in the upstream 0.18.1 tag; this proves binary identity, not source completeness. The wrapper version is not the FFmpeg version.

| Component | Binary/source evidence | License and source |
|---|---|---|
| FFmpeg | 7.1.1; libavcodec 61.19.101; both executable configuration strings include --enable-gpl and --enable-version3 | GPLv3-or-later FFmpeg build; full GPLv3 text and upstream LICENSE.md bundled. Baseline source https://github.com/FFmpeg/FFmpeg/tree/n7.1.1 |
| CPython | 3.12.11 embedded string; Python 3.12 standard-library tree | PSF license plus incorporated notices, full v3.12.11 LICENSE bundled; baseline source https://github.com/python/cpython/tree/v3.12.11 |
| QuickJS | executable says QuickJS version 2025-04-26 | MIT; license extracted from https://bellard.org/quickjs/quickjs-2025-04-26.tar.xz ; archive SHA-256 2f20074c25166ef6f781f381c50d57b502cb85d470d639abccebbef7954c83bf |
| yt-dlp | 2025.11.12 in archive version.py | Unlicense for upstream source; https://github.com/yt-dlp/yt-dlp/tree/2025.11.12 ; full license bundled. Runtime updater can replace it. |
| Mutagen | __init__.py version tuple (1,47,0) | GPLv2-or-later; release COPYING bundled; https://github.com/quodlibet/mutagen/tree/release-1.47.0 |
| PyCryptodomex | Cryptodome/__init__.py says 3.23.0 | BSD/public-domain components as described in exact release LICENSE.rst, bundled; https://github.com/Legrandin/pycryptodome/tree/v3.23.0 |
| OpenSSL in Python payload | libcrypto string OpenSSL 3.5.2 5 Aug 2025 | Apache-2.0; baseline source https://github.com/openssl/openssl/tree/openssl-3.5.2 ; see upstream native dependency notice gap below |

## Provenance and source limits — NOT CLEARED

The exact upstream commit introducing the FFmpeg archive is f2280ae7d8bc8d59590c8727a89f047983867c10 (27 September 2025, message Bump ffmpeg 7.1.1). The Python archive was last changed at 4e2bb8b4dbe15d13f57cf37c72e155b9f359d3fb (message Add quickJS). These commits contain prebuilt native payloads. They identify distributed bytes, not complete source/build provenance.

Tag-pinned upstream build guides are copied under licenses/evidence/upstream. They point to Termux packages but do not pin its checkout or retain a native package-source manifest. The Python guide still describes Python 3.7/3.8 and therefore cannot substantiate the shipped 3.12.11 build. FFmpeg's recorded configuration is preserved in the payload inventory. GPL and version3 are enabled; this cannot be treated as an LGPL-only build.

The payload also contains numerous native libraries (x264, x265, FFTW, GLib, GnuTLS, readline, GDBM and others), some of which have their own copyleft obligations. Merely identifying FFmpeg's headline GPL license does not clear these. The complete exact Termux patch set, build scripts/toolchain mapping, component source revisions, copyright notices and corresponding-source delivery have NOT been established. Upstream baseline source links are not a substitute. No claim is made that the existing app-source ZIP satisfies those missing materials.

For additional primary evidence, 67 package recipes were downloaded at the reference Termux snapshot immediately before the FFmpeg upstream commit: 8ddd9a7fc8e06330545487d81bb7591cb40f1aa6. Their declared licenses and source URLs are preserved in licenses/termux-reference-recipes.json and licenses/evidence/termux-reference. This is a reference snapshot, NOT evidence of the actual build checkout. Recipe license labels may describe a whole package, not only the shipped library; custom/multi-license labels require checking exact source files and copyright texts. No guess is substituted for a missing source manifest.

## Reference recipe declarations (not a verified build BOM)

| Termux package | Recipe-declared license | Reference recipe |
|---|---|---|
| ffmpeg | GPL-3.0 | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/ffmpeg/build.sh |
| python | custom | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/python/build.sh |
| quickjs | MIT | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/quickjs/build.sh |
| openssl | Apache-2.0 | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/openssl/build.sh |
| zlib | ZLIB | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/zlib/build.sh |
| libffi | MIT | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/libffi/build.sh |
| ncurses | MIT | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/ncurses/build.sh |
| libexpat | MIT | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/libexpat/build.sh |
| gdbm | GPL-3.0 | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/gdbm/build.sh |
| libandroid-support | Apache-2.0, MIT | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/libandroid-support/build.sh |
| libandroid-posix-semaphore | MIT | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/libandroid-posix-semaphore/build.sh |
| readline | GPL-3.0 | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/readline/build.sh |
| libsqlite | Public Domain | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/libsqlite/build.sh |
| liblzma | LGPL-2.1, GPL-2.0, GPL-3.0 | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/liblzma/build.sh |
| libbz2 | BSD | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/libbz2/build.sh |
| libass | BSD | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/libass/build.sh |
| librav1e | BSD 2-Clause | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/librav1e/build.sh |
| libx264 | GPL-2.0 | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/libx264/build.sh |
| libxml2 | MIT | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/libxml2/build.sh |
| libnettle | GPL-2.0, LGPL-3.0 | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/libnettle/build.sh |
| libv4l | LGPL-2.1 | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/libv4l/build.sh |
| libvo-amrwbenc | Apache-2.0 | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/libvo-amrwbenc/build.sh |
| game-music-emu | LGPL-2.1 | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/game-music-emu/build.sh |
| xvidcore | GPL-2.0 | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/xvidcore/build.sh |
| libvpx | BSD 3-Clause | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/libvpx/build.sh |
| libandroid-glob | BSD 3-Clause | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/libandroid-glob/build.sh |
| libmpg123 | LGPL-2.1 | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/libmpg123/build.sh |
| fftw | GPL-2.0 | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/fftw/build.sh |
| littlecms | MIT | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/littlecms/build.sh |
| libsrt | MPL-2.0 | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/libsrt/build.sh |
| libogg | BSD 3-Clause | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/libogg/build.sh |
| pcre2 | BSD 3-Clause | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/pcre2/build.sh |
| glib | LGPL-2.1 | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/glib/build.sh |
| libpng | Libpng | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/libpng/build.sh |
| libwebp | BSD 3-Clause | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/libwebp/build.sh |
| ocl-icd | BSD 2-Clause | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/ocl-icd/build.sh |
| libvmaf | custom | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/libvmaf/build.sh |
| libaom | BSD 2-Clause | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/libaom/build.sh |
| libzimg | WTFPL | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/libzimg/build.sh |
| brotli | MIT | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/brotli/build.sh |
| libvorbis | BSD 3-Clause | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/libvorbis/build.sh |
| libopenmpt | BSD 3-Clause | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/libopenmpt/build.sh |
| libbluray | LGPL-2.1 | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/libbluray/build.sh |
| libssh | LGPL-2.1, BSD 2-Clause | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/libssh/build.sh |
| libgnutls | LGPL-2.1, GPL-3.0 | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/libgnutls/build.sh |
| libgmp | LGPL-3.0 | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/libgmp/build.sh |
| libvidstab | GPL-2.0 | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/libvidstab/build.sh |
| libzmq | LGPL-2.0 | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/libzmq/build.sh |
| libsodium | ISC | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/libsodium/build.sh |
| libx265 | GPL-2.0 | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/libx265/build.sh |
| libopus | BSD 3-Clause | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/libopus/build.sh |
| libdav1d | BSD 2-Clause | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/libdav1d/build.sh |
| libgraphite | LGPL-2.0 | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/libgraphite/build.sh |
| libudfread | LGPL-2.1 | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/libudfread/build.sh |
| harfbuzz | MIT | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/harfbuzz/build.sh |
| libsoxr | LGPL-2.1 | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/libsoxr/build.sh |
| libunistring | LGPL-3.0, GPL-2.0 | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/libunistring/build.sh |
| libidn2 | LGPL-3.0, GPL-2.0, GPL-3.0 | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/libidn2/build.sh |
| libopencore-amr | Apache-2.0 | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/libopencore-amr/build.sh |
| libiconv | LGPL-2.1, GPL-3.0 | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/libiconv/build.sh |
| freetype | GPL-2.0 | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/freetype/build.sh |
| svt-av1 | custom | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/svt-av1/build.sh |
| rubberband | GPL-2.0 | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/rubberband/build.sh |
| libsamplerate | BSD 2-Clause | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/libsamplerate/build.sh |
| libtheora | BSD | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/libtheora/build.sh |
| fribidi | LGPL-2.0 | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/fribidi/build.sh |
| fontconfig | MIT | https://raw.githubusercontent.com/termux/termux-packages/8ddd9a7fc8e06330545487d81bb7591cb40f1aa6/packages/fontconfig/build.sh |

## Release consequence

This investigation resolves the previously missing Gradle license identities and identifies the principal native versions. It does NOT clear every native/source/notice obligation. Before describing a public distribution as legally cleared, obtain the exact native source/patch/build/notice manifest from upstream, or produce and verify corresponding builds from complete controlled source. No dependencies, extractor/media features or manifest permissions were changed in this task. Artwork redistribution rights are a separate non-library issue.
