# Syntix source and build information

Developer: Rishabh Mittal
Contact: mittal.rishabh2010@gmail.com

## Application source

Version 2.1 application source is supplied as a separate website download:

https://rish497.github.io/syntix-site/sources/Syntix-2.1-source.zip

The website footer has a small, readable Source code link. The application no longer embeds a source ZIP or offers a source-export control. Licence notices remain bundled, with this source location in the third-party licence information. Keep clear source directions with every binary/store distribution, and keep each version's source available. The development repository may remain private, but this archive is available publicly under the applicable licences.

The archive includes application source/resources/tests, Gradle configuration and wrapper, the project licence, bundled notices, legal documents and source-packaging/build instructions. It excludes personal data, SDK/build caches, machine-local properties and signing credentials. This application-source archive does not by itself resolve the native provenance/corresponding-source limitations noted below.

## Build the application

Install JDK 21 and an Android SDK with platform 36/build tools. Set ANDROID_HOME/ANDROID_SDK_ROOT for your machine or create android-app/local.properties with your SDK path. Use the bundled Gradle 9.3.0 wrapper on Windows:

    powershell -File tools/sync-privacy-docs.ps1
    powershell -File tools/prepare-source-archive.ps1
    android-app/gradlew.bat -p android-app assembleDebug testDebugUnitTest lintDebug

On other systems use Gradle 9.3.0 with the same -p android-app tasks, or generate its standard platform wrapper. Recreate the website source ZIP using the supplied PowerShell script (PowerShell is available for multiple systems). Release builds require your own signing configuration; private developer signing keys are not shipped. The supplied production build helper expects local signing credentials outside this archive. You can build/install a debug variant without those credentials. Never add passwords or signing keys to a source package.

The application uses minSDK 29, target/compile SDK 36, Android Gradle Plugin 9.0.1, Java 17 source compatibility and the dependencies/versions recorded in THIRD_PARTY_LICENSES.md. AndroidX/Media3, Material and extraction wrapper dependencies are fetched from the configured Google/Maven repositories. Network access is needed to resolve missing build dependencies.

## External software and unresolved verification

The youtubedl-android library/common/FFmpeg wrapper artifacts are version 0.18.1 and declare GPL-3.0 in their POMs. Upstream source/build recipes: https://github.com/JunkFood02/youtubedl-android and https://github.com/yausername/youtubedl-android . The inspected bundled yt-dlp archive reports 2025.11.12; source: https://github.com/yt-dlp/yt-dlp/tree/2025.11.12 . Runtime engine updates can change that version.

The shipped native headline versions and configurations are identified in NATIVE_BUILD_AUDIT.md: FFmpeg 7.1.1 (GPL/version3 enabled), CPython 3.12.11 and QuickJS 2025-04-26. Complete exact Termux source/patch/build mapping and all native dependency notices remain NOT CLEARED. Bundled baseline source links and application source do not establish full corresponding-source compliance. Resource license/notice exclusions have been replaced by merges, and extracted full notices are bundled in the APK.

No claim of legal compliance, copyright permission or store approval is made by this archive. This is source access for recipients, not a reason to hide or remove it.
