# Content-rights notes — release draft

Developer: Rishabh Mittal
Document updated: 4 November 2026; legal review outstanding
Intended distribution: worldwide through Uptodown and Aptoide; operator location: Indirapuram, Ghaziabad, Uttar Pradesh, India
Developer contact: mittal.rishabh2010@gmail.com; no independent legal reviewer identified

This is a code-based risk inventory, not legal clearance. The V13.2 test build removes standalone audio/video export actions and their service. Managed offline downloads remain; their completed files are encrypted, which does not resolve content or platform rights.

| Feature | Inspected implementation | Unresolved content/service risk |
|---|---|---|
| Search, autocomplete, themes and daily discovery | YouTubeMetadata / NativeSearch / SearchCatalogue; YouTube results HTML, internal `youtubei/v1/search`, Google suggestions; yt-dlp fallback | Automated access/internal endpoints are not a configured official Data API integration. Platform restrictions can apply independently of public availability. Metadata/artwork reuse needs review. |
| YouTube video/playlist import | Links / Extractor / youtubedl-android / yt-dlp flat extraction | Public links do not grant permission for automated extraction or subsequent copying. Imports may be incomplete or unavailable. |
| Spotify playlist import and matching | Public Spotify embed/page metadata, anonymous web-session and paginated Pathfinder metadata requests; public web-client configuration from code.thetadev.de; SpotifyMatching sends title/artist searches to YouTube Music catalog search with ordinary YouTube search fallback | No Spotify audio is retrieved. Spotify metadata access/reuse and YouTube matching still require terms review; matching a recording does not confer content rights. |
| Playback, background and screen-off listening | Media3/ExoPlayer, OkHttp, yt-dlp media URL extraction, direct HTTPS streams | Separate audio playback/direct-stream access outside the official player may conflict with platform conditions. Advertised ad-free/background behavior does not establish permission or paid-service entitlement. |
| Offline songs and playlists | OfflineDownloadService, yt-dlp, FFmpeg, per-profile private files; selected quality transcoding | Copying, audio separation and transcoding may require rights. Local/private use does not by itself establish a lawful exception or service authorization. |
| Artwork and theme tiles | YouTube thumbnails/returned image URLs; bundled decorative cover images | Album/artist imagery and brands may be protected. Existing source records are provenance, not evidence of a redistribution license. |
| Smart Mixes and suggestions | Local history-driven selection; recommendation seed searches sent to YouTube | Local organization does not grant rights to underlying content. Network queries can reveal listening interests. |
| Local audio/document playback | User-selected content URI through Android document picker; Media3 | The user's local file still may have third-party rights. No additional service access is required merely to play an already local file. |
| Stable playback-engine update action | Legacy Settings invokes `YoutubeDL.updateYoutubeDL(...STABLE)`; GitHub release API/assets | Updates affect extraction behavior and executable versions. Recheck software licenses, notices, corresponding source and distribution/store rules. Updating software does not grant content rights. The current normal UI does not expose the legacy Settings sheet. |

## Terms and copyright concerns

YouTube's published Terms restrict unauthorized copying/downloading, interference with restrictions and automated access. They distinguish permitted use from actions needing service and/or rights-holder authorization. Syntix's scraping, direct-stream playback, offline copying paths therefore warrant review; a rights-holder permission alone may not resolve the separate platform agreement. This is a risk flag, not a finding that every use is unlawful. See [YouTube Terms](https://www.youtube.com/static?template=terms).

Spotify import uses public metadata rather than Spotify audio, but public accessibility is not a blanket license for automated collection or reuse. Review the applicable [Spotify terms](https://www.spotify.com/legal/end-user-agreement/) for the actual territory and access method. This draft does not claim a verified Spotify partnership or API authorization.

Copyright exceptions, permissions, contractual enforceability and access-control rules depend on content, conduct and jurisdiction. Complete a jurisdiction-specific review before public release. No legal certifications, rights guarantees or exemptions have been invented here.

## Software and distribution concerns left unchanged

- The Gradle wrapper library/FFmpeg wrapper POMs declare GPL-3.0. The precise FFmpeg/Python/other native builds and any engine updates require separate license/source/notice verification. See THIRD_PARTY_LICENSES.md and [FFmpeg's legal page](https://ffmpeg.org/legal.html).
- Existing Gradle packaging excludes `META-INF/LICENSE*` and `META-INF/NOTICE*`. A license-name inventory alone is not complete notice/source compliance. No exclusion was edited.
- Existing app marketing/onboarding mentions ad-free listening. That is not proof of a content license, service authorization or universal technical availability. No copy or feature was altered.
- Store/distribution rules, executable engine updates, artist/album images and trademark use require review for the actual distribution channel. No store approval is claimed.
- No feature has been disabled, removed, gated or recommended for automatic removal. Any future change needs the developer's decision.

## Supplied release preferences requiring resolution

The developer intends all-ages worldwide distribution and a private GitHub repository. These preferences are recorded, not treated as compliance evidence. The current app has no child-consent workflow; applicable child-privacy and service-age requirements need review. Private GitHub access alone is not a corresponding-source delivery mechanism for APK recipients. No feature, age gate, repository visibility or source-distribution decision was changed automatically.
